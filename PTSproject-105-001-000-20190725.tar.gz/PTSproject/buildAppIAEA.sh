#!/bin/bash
mkdir -p ../PTSproject-build/PTSapps/$1
mkdir -p ../PTSproject-install/PTSapps/$1
cd ../PTSproject-build/PTSapps/$1
if test -e Makefile ; then
make clean
fi
cmake $2 \
      -DUSEROOT=ON \
      -DUSEIAEAPHSP=ON \
      -DIAEAPHSP_WRITE_USE=ON \
      -DCMAKE_INSTALL_PREFIX=../../../PTSproject-install/PTSapps/$1 \
      ../../../PTSproject/PTSapps/$1
make
make install
