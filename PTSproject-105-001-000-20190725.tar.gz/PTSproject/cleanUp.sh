#!/bin/bash
rm -rf ../PTSproject-build/PTStoolkit/*
rm -rf ../PTSproject-build/PTSapps/DynamicPort/*
