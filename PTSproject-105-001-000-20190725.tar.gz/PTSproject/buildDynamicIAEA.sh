#!/bin/bash
mkdir -p ../PTSproject-build/PTSapps/DynamicPort
mkdir -p ../PTSproject-install/PTSapps/DynamicPort
rm -rf   ../PTSproject-build/PTSapps/DynamicPort/*
cd ../PTSproject-build/PTSapps/DynamicPort
if [ -f Makefile ]
then
make clean
fi
# Options 
# -DUSECSV=OFF \
# -DUSEXML=OFF \
# -DUSEMPI=ON \
#
cmake $1 $2 \
      -DUSEROOT=ON \
      -DCMAKE_INSTALL_PREFIX=../../../PTSproject-install/PTSapps/DynamicPort \
      -DUSEIAEAPHSP=ON \
      -DIAEAPHSP_WRITE_USE=ON \
      ../../../PTSproject/PTSapps/DynamicPort
make
make install

#