#!/bin/bash
mkdir -p ../PTSproject-build/PTStoolkit
mkdir -p ../PTSproject-install/PTStoolkit
rm -rf ../PTSproject-build/PTStoolkit/*
cd ../PTSproject-build/PTStoolkit
cmake $1 $2 \
      -DCMAKE_INSTALL_PREFIX=../../PTSproject-install/PTStoolkit \
      -DUSEIAEAPHSP=ON \
      ../../PTSproject/PTStoolkit

make -j 3
make install

