#!/bin/bash
mkdir -p ../PTSproject-build/PTSapps/DynamicPort
mkdir -p ../PTSproject-install/PTSapps/DynamicPort
cd ../PTSproject-build/PTSapps/DynamicPort
if [ -f Makefile ]
then
make clean
fi
cmake $1 \
      -DCMAKE_INSTALL_PREFIX=../../../PTSproject-install/PTSapps/DynamicPort \
      -DUSEROOT=ON \
      -DUSEMPI=ON \
      -DUSEIAEAPHSP=ON \
      -DIAEAPHSP_WRITE_USE=ON \
      ../../../PTSproject/PTSapps/DynamicPort
make
make install
#
