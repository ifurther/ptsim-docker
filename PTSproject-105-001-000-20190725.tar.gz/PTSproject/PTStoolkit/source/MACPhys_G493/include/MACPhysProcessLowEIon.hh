//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessIon.hh
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef MACPhysProcessLowEIon_h
#define MACPhysProcessLowEIon_h 1

#include "globals.hh"
#include "G4ios.hh"

#include "G4VPhysicsConstructor.hh"

/******************************************************************************/
 class MACPhysProcessLowEIon : public G4VPhysicsConstructor
/******************************************************************************/
{
//=======
  public: 
//=======
    MACPhysProcessLowEIon(const G4String& name="LowEIon");
    virtual ~MACPhysProcessLowEIon();

    // This method will be invoked in the Construct() method. 
    // each particle type will be instantiated
    virtual void ConstructParticle();
 
    // This method will be invoked in the Construct() method.
    // each physics process will be instantiated and
    // registered to the process manager of each particle type 
    virtual void ConstructProcess();

};


#endif

