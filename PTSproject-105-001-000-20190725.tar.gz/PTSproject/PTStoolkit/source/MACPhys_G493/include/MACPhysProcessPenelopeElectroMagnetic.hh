//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessPenelopeElectroMagnetic.hh
//
// [Description]
//   The 'Physics List Constructor' for the electromagnetic processes.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   26,Oct 2005, T. Aso : The 1st version created.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef MACPhysProcessPenelopeElectroMagnetic_h
#define MACPhysProcessPenelopeElectroMagnetic_h 1

#include "globals.hh"
#include "G4ios.hh"

#include "G4VPhysicsConstructor.hh"

/******************************************************************************/
 class MACPhysProcessPenelopeElectroMagnetic : public G4VPhysicsConstructor
/******************************************************************************/
{
//=======
  public:
//======= 
    MACPhysProcessPenelopeElectroMagnetic(const G4String& name ="PenelopeElectroMagnetic");
    virtual ~MACPhysProcessPenelopeElectroMagnetic();
 
//-- This method will be invoked in the Construct() method. 
//   each particle type will be instantiated
    virtual void ConstructParticle();
 
//-- This method will be invoked in the Construct() method.
//   each physics process will be instantiated and
//   registered to the process manager of each particle type 
    virtual void ConstructProcess();

};


#endif





