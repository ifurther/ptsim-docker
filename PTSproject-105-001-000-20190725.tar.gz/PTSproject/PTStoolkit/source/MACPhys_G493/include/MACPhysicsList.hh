//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysicsList.hh
//
// [Description]
//   Physics list for the P152 (NIRS) experiment.
//
// [Histoy]
//   8 April, 2003  K. Amako : The 1st version created.
//                  T. Aso   : Maintained for HIBMC simulation.
//  18 May,   2009  T. Aso   : Merge with G4 Physics-list.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#ifndef MACPhysicsList_h
#define MACPhysicsList_h 1

#include "globals.hh" 
#include "G4VModularPhysicsList.hh"

#include "MACPhysicsListMessenger.hh"
#include <vector>

/******************************************************************************/
 class MACPhysicsList: public G4VModularPhysicsList
/******************************************************************************/
{
public:
  MACPhysicsList();
  virtual ~MACPhysicsList();
  
  // SetCuts() 
  virtual void SetCuts();

public:
  void RegisterPhysicsModule(G4String newValue);
  void SetStepLimitForRegion(G4double stepValue,const G4String& rname);
  void SetProtonEnLossFluc(G4bool flag=TRUE);
  void SetProtonTransition(G4double energy);
  void SetProtonParameterisation(G4String name);

private:
  MACPhysicsListMessenger* fPhysListMessenger;

};

#endif



