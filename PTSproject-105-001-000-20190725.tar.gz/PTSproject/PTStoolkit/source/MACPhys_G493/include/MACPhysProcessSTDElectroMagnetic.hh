//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessSTDElectroMagnetic.hh
//
// [Description]
//   The 'Physics List Constructor' for the electromagnetic processes.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   26 Oct,  2005, T. Aso   : Maintain for HIBMC simulation
//   31 Oct,  2005, T. Aso   : Modify to avoid termination error.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef MACPhysProcessSTDElectroMagnetic_h
#define MACPhysProcessSTDElectroMagnetic_h 1

#include "globals.hh"
#include "G4ios.hh"

#include "G4VPhysicsConstructor.hh"

/******************************************************************************/
 class MACPhysProcessSTDElectroMagnetic : public G4VPhysicsConstructor
/******************************************************************************/
{
//=======
  public:
//======= 
    MACPhysProcessSTDElectroMagnetic(const G4String& name ="STDElectroMagnetic");
    virtual ~MACPhysProcessSTDElectroMagnetic();
 
//-- This method will be invoked in the Construct() method. 
//   each particle type will be instantiated
    virtual void ConstructParticle();
 
//-- This method will be invoked in the Construct() method.
//   each physics process will be instantiated and
//   registered to the process manager of each particle type 
    virtual void ConstructProcess();

};


#endif





