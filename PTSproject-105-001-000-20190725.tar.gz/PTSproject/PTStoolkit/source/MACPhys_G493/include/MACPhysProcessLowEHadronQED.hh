//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessLowEHadronQED.hh
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//  21 Aug,   2006, T. Aso   : Modified for PTS.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef MACPhysProcessLowEHadronQED_h
#define MACPhysProcessLowEHadronQED_h 1

#include "globals.hh"
#include "G4VPhysicsConstructor.hh"

class G4hLowEnergyIonisation;

/******************************************************************************/
 class MACPhysProcessLowEHadronQED : public G4VPhysicsConstructor
/******************************************************************************/{

//=======
  public:
//======= 
    MACPhysProcessLowEHadronQED(const G4String& name ="LowEHadronQED");
    virtual ~MACPhysProcessLowEHadronQED();

    // This method will be invoked in the Construct() method. 
    // each particle type will be instantiated
    virtual void ConstructParticle();
 
    // This method will be invoked in the Construct() method.
    // each physics process will be instantiated and
    // registered to the process manager of each particle type 
    virtual void ConstructProcess();

 public:
   void SetProtonEnlossFlucOn(G4bool flag = TRUE);
   void SetHighEnergyForProtonParameterisation(G4double energy = 10.0*MeV)
   {fTransition = energy; }
   void SetElectronicStoppingPowerModel(G4String name = "SRIM2000p")
   { fStoppingPower = name; }

 private:
   G4hLowEnergyIonisation* theProtonIonisation;
   G4double                fTransition;
   G4String                fStoppingPower;
};


#endif

