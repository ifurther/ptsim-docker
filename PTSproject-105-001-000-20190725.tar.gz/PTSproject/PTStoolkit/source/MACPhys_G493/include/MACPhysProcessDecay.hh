//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessDecay.hh
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//   21 Aug, 2006, T. Aso : Modified for PTS.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#ifndef MACPhysProcessDecay_h
#define MACPhysProcessDecay_h 1

#include "G4VPhysicsConstructor.hh"

/******************************************************************************/
 class MACPhysProcessDecay : public G4VPhysicsConstructor
/******************************************************************************/
{
//=======
  public: 
//=======

//-- Constructor/Destructor
  MACPhysProcessDecay(const G4String& name = "Decay");
  virtual ~MACPhysProcessDecay();

//-- Process constructions should be defined in this methods
  virtual void ConstructProcess();

//-- This method should be dummied because the current class is only
//   for process constructions
  virtual void ConstructParticle() {};

};

#endif








