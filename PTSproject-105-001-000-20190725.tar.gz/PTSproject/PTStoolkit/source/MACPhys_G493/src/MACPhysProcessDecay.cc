//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessDecay.cc
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//   21 Aug, 2006, T. Aso : Modified for PTS.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessDecay.hh"
#include "G4ParticleDefinition.hh"
#include "G4ProcessManager.hh"

/******************************************************************************/
 MACPhysProcessDecay::MACPhysProcessDecay(const G4String& name)
/******************************************************************************/
 : G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessDecay::~MACPhysProcessDecay()
/******************************************************************************/
{}

#include "G4Decay.hh"
/******************************************************************************/
 void MACPhysProcessDecay::ConstructProcess()
/******************************************************************************/
{

//-- Decay process object
  G4Decay* fDecayProcess = new G4Decay;

//-- Add Decay Process
  theParticleIterator->reset();        // Iterator is from G4VPhysicsConstructor

  while( (*theParticleIterator)() ){
    G4ParticleDefinition* particle = theParticleIterator->value();
    G4ProcessManager* pmanager = particle->GetProcessManager();

    if (fDecayProcess->IsApplicable(*particle)) { 

      pmanager ->AddProcess(fDecayProcess);

      // Set orderings
      pmanager ->SetProcessOrdering(fDecayProcess, idxPostStep);
      pmanager ->SetProcessOrdering(fDecayProcess, idxAtRest);
    }
  }
}

