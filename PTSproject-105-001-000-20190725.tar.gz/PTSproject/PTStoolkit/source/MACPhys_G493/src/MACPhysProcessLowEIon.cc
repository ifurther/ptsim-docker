//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessIon.cc
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessLowEIon.hh"

#include "globals.hh"
#include "G4ios.hh"
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessLowEIon::MACPhysProcessLowEIon(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessLowEIon::~MACPhysProcessLowEIon()
/******************************************************************************/
{}

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

// Nuclei
#include "G4IonConstructor.hh"

/******************************************************************************/
 void MACPhysProcessLowEIon::ConstructParticle()
/******************************************************************************/
{
//--  Construct light ions
  G4IonConstructor pConstructor;
  pConstructor.ConstructParticle();  

}


#include "G4ProcessManager.hh"

#include "G4HadronElasticProcess.hh"
#include "G4LElastic.hh"
#include "G4DeuteronInelasticProcess.hh"
#include "G4LEDeuteronInelastic.hh"
#include "G4TritonInelasticProcess.hh"
#include "G4LETritonInelastic.hh"
#include "G4AlphaInelasticProcess.hh"
#include "G4LEAlphaInelastic.hh"
#include "G4hLowEnergyIonisation.hh"
#include "G4MultipleScattering.hh"
#include "G4hMultipleScattering.hh"

/******************************************************************************/
 void MACPhysProcessLowEIon::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;

//-- Elastic Process
   G4HadronElasticProcess* theElasticProcess=new G4HadronElasticProcess;
   G4LElastic* theElasticModel = new G4LElastic();
   theElasticProcess->RegisterMe(theElasticModel);

//-- Generic Ion
   //G4MultipleScattering*   fIonMultipleScattering=new G4MultipleScattering;
  G4hMultipleScattering*   fIonMultipleScattering=new G4hMultipleScattering;
  G4hLowEnergyIonisation* fIonIonisation=new G4hLowEnergyIonisation;

  pManager = G4GenericIon::GenericIon()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);

  pManager->AddProcess(fIonIonisation, ordInActive, 2, 2);

  pManager->AddProcess(fIonMultipleScattering);
  pManager->SetProcessOrdering(fIonMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fIonMultipleScattering, idxPostStep,  1);

//-- Deuteron 
  //G4MultipleScattering* fDeuteronMultipleScattering=new G4MultipleScattering;
  G4hMultipleScattering* fDeuteronMultipleScattering=new G4hMultipleScattering;
   G4hLowEnergyIonisation* fDeuteronIonisation=new G4hLowEnergyIonisation;
   G4DeuteronInelasticProcess* fDeuteronProcess=new G4DeuteronInelasticProcess;
   G4LEDeuteronInelastic* fDeuteronModel=new G4LEDeuteronInelastic;
   fDeuteronProcess->RegisterMe(fDeuteronModel);

  pManager = G4Deuteron::Deuteron()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fDeuteronProcess);
  pManager->AddProcess(fDeuteronIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fDeuteronMultipleScattering);
  pManager->SetProcessOrdering(fDeuteronMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fDeuteronMultipleScattering, idxPostStep,  1);
 
//-- Triton 
  //G4MultipleScattering* fTritonMultipleScattering=new G4MultipleScattering;
  G4hMultipleScattering* fTritonMultipleScattering=new G4hMultipleScattering;
  G4hLowEnergyIonisation* fTritonIonisation=new G4hLowEnergyIonisation;
  G4TritonInelasticProcess* fTritonProcess = new G4TritonInelasticProcess;
  G4LETritonInelastic* fTritonModel=new G4LETritonInelastic;
  fTritonProcess->RegisterMe(fTritonModel);

  pManager = G4Triton::Triton()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fTritonProcess);
  pManager->AddProcess(fTritonIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fTritonMultipleScattering);
  pManager->SetProcessOrdering(fTritonMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fTritonMultipleScattering, idxPostStep,  1);
 
//-- Alpha 
  //G4MultipleScattering* fAlphaMultipleScattering=new G4MultipleScattering;
   G4hMultipleScattering* fAlphaMultipleScattering=new G4hMultipleScattering;
   G4hLowEnergyIonisation* fAlphaIonisation=new G4hLowEnergyIonisation;
   G4AlphaInelasticProcess* fAlphaProcess=new G4AlphaInelasticProcess;
   G4LEAlphaInelastic* fAlphaModel=new G4LEAlphaInelastic;
   fAlphaProcess->RegisterMe(fAlphaModel);

  pManager = G4Alpha::Alpha()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fAlphaProcess);
  pManager->AddProcess(fAlphaIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fAlphaMultipleScattering);
  pManager->SetProcessOrdering(fAlphaMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fAlphaMultipleScattering, idxPostStep,  1);
 
//-- He3
  //G4MultipleScattering* fHe3MultipleScattering=new G4MultipleScattering;
  G4hMultipleScattering* fHe3MultipleScattering=new G4hMultipleScattering;
   G4hLowEnergyIonisation* fHe3Ionisation=new G4hLowEnergyIonisation;

  pManager = G4He3::He3()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddProcess(fHe3Ionisation, ordInActive, 2, 2);
  pManager->AddProcess(fHe3MultipleScattering);
  pManager->SetProcessOrdering(fHe3MultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fHe3MultipleScattering, idxPostStep,  1);
   
}



