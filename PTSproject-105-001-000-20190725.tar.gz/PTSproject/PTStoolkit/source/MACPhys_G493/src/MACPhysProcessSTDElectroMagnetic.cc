//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessSTDElectroMagnetic.cc
//
// [Description]
//   The 'Physics List Constructor' for the electromagnetic processes.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//  26-oct,2005         T. Aso   : Maintained for HIBMC Simulation
//   8-Jun,2010         T. Aso   : Replace MultipleScattering for v9.3.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessSTDElectroMagnetic.hh"

#include "globals.hh"
#include "G4ios.hh"
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessSTDElectroMagnetic::MACPhysProcessSTDElectroMagnetic(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessSTDElectroMagnetic::~MACPhysProcessSTDElectroMagnetic()
/******************************************************************************/
{}


#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

#include "G4Gamma.hh"
#include "G4Electron.hh"
#include "G4Positron.hh"
#include "G4NeutrinoE.hh"
#include "G4AntiNeutrinoE.hh"

/******************************************************************************/
 void MACPhysProcessSTDElectroMagnetic::ConstructParticle()
/******************************************************************************/
{
//-- gamma
  G4Gamma::GammaDefinition();
 
//-- electron
  G4Electron::ElectronDefinition();
  G4Positron::PositronDefinition();
  G4NeutrinoE::NeutrinoEDefinition();
  G4AntiNeutrinoE::AntiNeutrinoEDefinition();
}


#include "G4ProcessManager.hh"

#include "G4PhotoElectricEffect.hh"
#include "G4ComptonScattering.hh"
#include "G4GammaConversion.hh"
#include "G4OpRayleigh.hh"

#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
#include "G4MultipleScattering.hh"
#else
#include "G4eMultipleScattering.hh"
#endif

#include "G4eIonisation.hh"
#include "G4eBremsstrahlung.hh"

#include "G4eplusAnnihilation.hh"

/******************************************************************************/
 void MACPhysProcessSTDElectroMagnetic::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;
  
//-- Gamma Physics
  pManager = G4Gamma::Gamma()->GetProcessManager();
  pManager->AddDiscreteProcess(new G4PhotoElectricEffect);
  pManager->AddDiscreteProcess(new G4ComptonScattering);
  pManager->AddDiscreteProcess(new G4GammaConversion);
  pManager->AddDiscreteProcess(new G4OpRayleigh);

//-- Electron Physics
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering* emult = new G4MultipleScattering;
#else  
  G4eMultipleScattering* emult = new G4eMultipleScattering;
#endif
  G4eIonisation*        eioni = new G4eIonisation;      
  G4eBremsstrahlung*    ebrem = new G4eBremsstrahlung;

  pManager = G4Electron::Electron()->GetProcessManager();
   // add processes
  pManager->AddDiscreteProcess(ebrem);  
  pManager->AddProcess(eioni, ordInActive,2, 2);
  pManager->AddProcess(emult);
  pManager->SetProcessOrdering(emult, idxAlongStep,  1);
  pManager->SetProcessOrdering(emult, idxPostStep,  1);

//-- Positron Physics
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering* pmult = new G4MultipleScattering;
#else  
  G4eMultipleScattering* pmult = new G4eMultipleScattering;
#endif
  G4eIonisation*        pioni = new G4eIonisation;      
  G4eBremsstrahlung*    pbrem = new G4eBremsstrahlung;
  G4eplusAnnihilation*  panni = new G4eplusAnnihilation;

  pManager = G4Positron::Positron()->GetProcessManager();
  // add processes
  pManager->AddDiscreteProcess(pbrem);
  pManager->AddDiscreteProcess(panni);
  pManager->AddRestProcess(panni);
  pManager->AddProcess(pioni, ordInActive,2, 2);
  pManager->AddProcess(pmult);
  pManager->SetProcessOrdering(pmult, idxAlongStep,  1);
  pManager->SetProcessOrdering(pmult, idxPostStep,  1);

}



