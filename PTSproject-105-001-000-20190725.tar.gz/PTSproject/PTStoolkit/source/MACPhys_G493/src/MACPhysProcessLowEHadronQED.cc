//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessLowEHadronQED.cc
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//                  T. Aso   : Maintained for HIBMC Simulation
//  21 Aug,   2006, T. Aso   : Modified for PTS.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessLowEHadronQED.hh"
#include "G4ProcessType.hh"
#include "G4StepLimiter.hh"

#include "globals.hh"
#include "G4ios.hh"
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessLowEHadronQED::MACPhysProcessLowEHadronQED(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{
   fTransition = 10.*MeV;
   fStoppingPower = "SRIM2000p";
}

/******************************************************************************/
 MACPhysProcessLowEHadronQED::~MACPhysProcessLowEHadronQED()
/******************************************************************************/
{}

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

// Nuclei
#include "G4MesonConstructor.hh"
#include "G4BaryonConstructor.hh"
#include "G4ShortLivedConstructor.hh"

#include "G4Proton.hh"
#include "G4AntiProton.hh"
#include "G4PionPlus.hh"
#include "G4PionMinus.hh"
#include "G4KaonPlus.hh"
#include "G4KaonMinus.hh"
#include "G4SigmaMinus.hh"
#include "G4AntiSigmaMinus.hh"
#include "G4SigmaPlus.hh"
#include "G4AntiSigmaPlus.hh"
#include "G4XiMinus.hh"
#include "G4AntiXiMinus.hh"
#include "G4OmegaMinus.hh"
#include "G4AntiOmegaMinus.hh"


/******************************************************************************/
void MACPhysProcessLowEHadronQED::ConstructParticle()
/******************************************************************************/
{
//-- Construct all mesons
  G4MesonConstructor pMesonConstructor;
  pMesonConstructor.ConstructParticle();

//--  Construct all barions
  G4BaryonConstructor pBaryonConstructor;
  pBaryonConstructor.ConstructParticle();

//--  Construct  resonaces and quarks
  G4ShortLivedConstructor pShortLivedConstructor;
  pShortLivedConstructor.ConstructParticle();  

}


#include "G4ProcessManager.hh"

#include "G4hMultipleScattering.hh"
#include "G4MultipleScattering.hh"
#include "G4MultipleScattering71.hh"
#include "G4hIonisation.hh"
#include "G4hLowEnergyIonisation.hh"

/******************************************************************************/
void MACPhysProcessLowEHadronQED::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;
  
//-- PionPlus
  //G4MultipleScattering* thePionPlusMult=new G4MultipleScattering;
  G4hMultipleScattering* thePionPlusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* thePionPlusIonisation=new G4hLowEnergyIonisation;

  pManager = G4PionPlus::PionPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(thePionPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(thePionPlusMult);
  pManager->SetProcessOrdering(thePionPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(thePionPlusMult, idxPostStep, 1);

//-- PionMinus
  //G4MultipleScattering* thePionMinusMult = new G4MultipleScattering;
  G4hMultipleScattering* thePionMinusMult = new G4hMultipleScattering;
  G4hLowEnergyIonisation* thePionMinusIonisation
      = new G4hLowEnergyIonisation;

  pManager = G4PionMinus::PionMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(thePionMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(thePionMinusMult);
  pManager->SetProcessOrdering(thePionMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(thePionMinusMult, idxPostStep, 1);

//-- KaonPlus
  pManager = G4KaonPlus::KaonPlus()->GetProcessManager();
  //G4MultipleScattering* theKaonPlusMult=new G4MultipleScattering;
  G4hMultipleScattering* theKaonPlusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theKaonPlusIonisation=new G4hLowEnergyIonisation;

  // add process
  pManager->AddProcess(theKaonPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theKaonPlusMult);
  pManager->SetProcessOrdering(theKaonPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theKaonPlusMult, idxPostStep, 1);

//-- KaonMinus
  //G4MultipleScattering* theKaonMinusMult=new G4MultipleScattering;
  G4hMultipleScattering* theKaonMinusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theKaonMinusIonisation=new G4hLowEnergyIonisation;

  pManager = G4KaonMinus::KaonMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theKaonMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theKaonMinusMult);
  pManager->SetProcessOrdering(theKaonMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theKaonMinusMult, idxPostStep, 1);

//-- Proton
  
  G4hMultipleScattering* theProtonMult=new G4hMultipleScattering;
  //G4MultipleScattering* theProtonMult=new G4MultipleScattering;
  //G4MultipleScattering71* theProtonMult=new G4MultipleScattering71;
  theProtonIonisation= new G4hLowEnergyIonisation;
  theProtonIonisation->SetProcessType(fElectromagnetic);

  pManager = G4Proton::Proton()->GetProcessManager();

  // add process
  //theProtonIonisation.SetNuclearStoppingOff();
  //theProtonIonisation->SetElectronicStoppingPowerModel(G4Proton::Proton(),
  //						       "SRIM2000p");
  theProtonIonisation->SetElectronicStoppingPowerModel(G4Proton::Proton(),
  						       fStoppingPower);
  //theProtonIonisation->SetHighEnergyForProtonParametrisation(10.*MeV);
  theProtonIonisation->SetHighEnergyForProtonParametrisation(fTransition);
  //
  //pManager->AddProcess(theProtonIonisation, ordInActive,2, 2);
  //pManager->AddProcess(theProtonMult);
  //pManager->SetProcessOrdering(theProtonMult, idxAlongStep, 1);
  //pManager->SetProcessOrdering(theProtonMult, idxPostStep, 1);
  //                                       AtRest, Along, Post
  pManager->AddProcess(theProtonMult,       -1,     1,     1);
  pManager->AddProcess(theProtonIonisation, -1,     2,     2);
  pManager->AddProcess(new G4StepLimiter,   -1,    -1,     3);

//-- Anti-Proton
  //G4MultipleScattering* theAntiProtonMult=new G4MultipleScattering;
  G4hMultipleScattering* theAntiProtonMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theAntiProtonIonisation= new G4hLowEnergyIonisation;

  pManager = G4AntiProton::AntiProton()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiProtonIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiProtonMult);
  pManager->SetProcessOrdering(theAntiProtonMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiProtonMult, idxPostStep, 1);

//-- SigmaMinus
  //G4MultipleScattering* theSigmaMinusMult=new G4MultipleScattering;
  G4hMultipleScattering* theSigmaMinusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theSigmaMinusIonisation= new G4hLowEnergyIonisation;
  
  pManager = G4SigmaMinus::SigmaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theSigmaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theSigmaMinusMult);
  pManager->SetProcessOrdering(theSigmaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theSigmaMinusMult, idxPostStep, 1);

//-- Anti-SigmaMinus
  //G4MultipleScattering* theAntiSigmaMinusMult=new G4MultipleScattering;
  G4hMultipleScattering* theAntiSigmaMinusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theAntiSigmaMinusIonisation=
       new G4hLowEnergyIonisation;

  pManager = G4AntiSigmaMinus::AntiSigmaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiSigmaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiSigmaMinusMult);
  pManager->SetProcessOrdering(theAntiSigmaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiSigmaMinusMult, idxPostStep, 1);

//-- SigmaPlus
  //G4MultipleScattering* theSigmaPlusMult=new G4MultipleScattering;
  G4hMultipleScattering* theSigmaPlusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theSigmaPlusIonisation=new G4hLowEnergyIonisation;

  pManager = G4SigmaPlus::SigmaPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(theSigmaPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theSigmaPlusMult);
  pManager->SetProcessOrdering(theSigmaPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theSigmaPlusMult, idxPostStep, 1);

//-- Anti-SigmaPlus
  //G4MultipleScattering* theAntiSigmaPlusMult=new G4MultipleScattering;
  G4hMultipleScattering* theAntiSigmaPlusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theAntiSigmaPlusIonisation=
       new G4hLowEnergyIonisation;

  pManager = G4AntiSigmaPlus::AntiSigmaPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiSigmaPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiSigmaPlusMult);
  pManager->SetProcessOrdering(theAntiSigmaPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiSigmaPlusMult, idxPostStep, 1);

//-- XiMinus
  //G4MultipleScattering* theXiMinusMult = new G4MultipleScattering;
  G4hMultipleScattering* theXiMinusMult = new G4hMultipleScattering;
   G4hLowEnergyIonisation* theXiMinusIonisation=new G4hLowEnergyIonisation;

  pManager = G4XiMinus::XiMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theXiMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theXiMinusMult);
  pManager->SetProcessOrdering(theXiMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theXiMinusMult, idxPostStep, 1);

//-- Anti-XiMinus
  //G4MultipleScattering* theAntiXiMinusMult=new G4MultipleScattering;
  G4hMultipleScattering* theAntiXiMinusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theAntiXiMinusIonisation=new G4hLowEnergyIonisation;

  pManager = G4AntiXiMinus::AntiXiMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiXiMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiXiMinusMult);
  pManager->SetProcessOrdering(theAntiXiMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiXiMinusMult, idxPostStep, 1);

//-- OmegaMinus
  //G4MultipleScattering* theOmegaMinusMult=new G4MultipleScattering;
  G4hMultipleScattering* theOmegaMinusMult=new G4hMultipleScattering;
  G4hLowEnergyIonisation* theOmegaMinusIonisation=new G4hLowEnergyIonisation;
   
  pManager = G4OmegaMinus::OmegaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theOmegaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theOmegaMinusMult);
  pManager->SetProcessOrdering(theOmegaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theOmegaMinusMult, idxPostStep, 1);

//-- Anti-OmegaMinus
  //G4MultipleScattering* theAntiOmegaMinusMult = new G4MultipleScattering;
  G4hMultipleScattering* theAntiOmegaMinusMult = new G4hMultipleScattering;
  G4hLowEnergyIonisation* theAntiOmegaMinusIonisation
      = new G4hLowEnergyIonisation;

  pManager = G4AntiOmegaMinus::AntiOmegaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiOmegaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiOmegaMinusMult);
  pManager->SetProcessOrdering(theAntiOmegaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiOmegaMinusMult, idxPostStep, 1);

}
/******************************************************************************/
void MACPhysProcessLowEHadronQED::SetProtonEnlossFlucOn(G4bool flag){
  // Energy fluct on/off
  theProtonIonisation->SetEnlossFluc(flag);
}
/******************************************************************************/
