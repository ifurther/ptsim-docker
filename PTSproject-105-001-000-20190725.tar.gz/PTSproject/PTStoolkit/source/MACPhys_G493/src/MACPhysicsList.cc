//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysicsList.cc
//
// [Description]
//   Physics list for Medical Accelerator. (Mainly for hadron therapy)
//
// [Histoy]
//  25 OCT,   2005  T. Aso   : Created
//  18 May,   2009  T. Aso   : Merge with G4 Physics-list.
//  08 Jul,   2010  T. Aso   : RadioactiveDecay
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysicsList.hh"
#include "MACParticleConstruction.hh"

#include "MACPhysProcessDecay.hh"
#include "MACPhysProcessLowEElectroMagnetic.hh"
#include "MACPhysProcessSTDElectroMagnetic.hh"
#include "MACPhysProcessPenelopeElectroMagnetic.hh"
#include "MACPhysProcessLowEHadronQED.hh"
#include "MACPhysProcessHadronQED.hh"
#include "MACPhysProcessMyHadronQED.hh"
#include "HadronPhysicsLHEP_PRECO_HP.hh"
#include "HadronPhysicsLHEP_BERT_HP.hh"
#include "HadronPhysicsQGSP_BERT_HP.hh"
#include "HadronPhysicsQGSP_BIC_HP.hh"
#include "G4QStoppingPhysics.hh"
#include "MACPhysProcessLowEIon.hh"
#include "MACPhysProcessIon.hh"
#include "MACPhysProcessMuon.hh"
#include "G4HadronElasticPhysics.hh"
#include "G4RadioactiveDecayPhysics.hh"

//=====
#include "G4Region.hh"
#include "G4RegionStore.hh"
#include "G4UserLimits.hh"
//=====

#include "G4UImanager.hh"

/******************************************************************************/
 MACPhysicsList::MACPhysicsList()
/******************************************************************************/
{   
  SetVerboseLevel(1);
  fPhysListMessenger = new MACPhysicsListMessenger(this);

  // Register particles
  RegisterPhysics( new MACParticleConstruction() );

}

/******************************************************************************/
 MACPhysicsList::~MACPhysicsList()
/******************************************************************************/
{
    delete fPhysListMessenger;
}

/******************************************************************************/
void MACPhysicsList::SetCuts()
/******************************************************************************/
{
  // set cut values for gamma at first and for e- second and next for e+,
  //// because some processes for e+/e- need cut values for gamma
  SetCutsWithDefault();
}

/******************************************************************************/
void MACPhysicsList::SetStepLimitForRegion(G4double stepValue,
					   const G4String&rname)
/******************************************************************************/
{
  G4Region* reg = G4RegionStore::GetInstance()->GetRegion(rname);
  if ( reg ){
    G4UserLimits* ulimits = reg->GetUserLimits();
    if ( ulimits ){
      ulimits->SetMaxAllowedStep(stepValue);
    }else{
      G4UserLimits* ulimits = new G4UserLimits(stepValue);
      reg->SetUserLimits(ulimits);
    }
    G4cout << " StepLimits for region " << stepValue/mm << G4endl;
  } else {
    G4cout << " MACPhysicsList::SetUserLimits() region "<<rname<<" not found"
	   << G4endl;
  }
}
/******************************************************************************/
void MACPhysicsList::SetProtonEnLossFluc(G4bool flag){
  if ( GetPhysics("HadronQED") || GetPhysics("MyHadronQED")){
    G4UImanager* UImanager= G4UImanager::GetUIpointer();
    if ( flag ){
      UImanager-> ApplyCommand("/process/eLoss/fluct true");
    }else{
      UImanager-> ApplyCommand("/process/eLoss/fluct false");
    }
  }
  if ( GetPhysics("LowEHadronQED")){
    MACPhysProcessLowEHadronQED* phys = 
      (MACPhysProcessLowEHadronQED*)GetPhysics("LowEHadronQED");
    phys->SetProtonEnlossFlucOn(flag);
  }

}
/******************************************************************************/
void MACPhysicsList::SetProtonTransition(G4double energy){
  if ( GetPhysics("HadronQED") ){
    G4Exception("Not supported:MACPhysicsList::SetProtonTransition");
  }else if ( GetPhysics("MyHadronQED") ){
    MACPhysProcessMyHadronQED* phys = 
      (MACPhysProcessMyHadronQED*)GetPhysics("MyHadronQED");
    phys->SetHighEnergyForProtonParameterisation(energy);
  }
  if ( GetPhysics("LowEHadronQED") ){
    MACPhysProcessLowEHadronQED* phys = 
      (MACPhysProcessLowEHadronQED*)GetPhysics("LowEHadronQED");
    phys->SetHighEnergyForProtonParameterisation(energy);
  }
  G4UImanager* UImanager= G4UImanager::GetUIpointer();
  UImanager-> ApplyCommand("/run/physicsModified");
}
/******************************************************************************/
void MACPhysicsList::SetProtonParameterisation(G4String name){
  if ( GetPhysics("HadronQED") ){
    G4Exception("Not supported:MACPhysicsList::SetProtonTransition");
  }else if ( GetPhysics("MyHadronQED") ){
    G4Exception("Not supported:MACPhysicsList::SetProtonTransition");
  }
  if ( GetPhysics("LowEHadronQED")){
    MACPhysProcessLowEHadronQED* phys = 
      (MACPhysProcessLowEHadronQED*)GetPhysics("LowEHadronQED");
    phys->SetElectronicStoppingPowerModel(name);
  }
  G4UImanager* UImanager= G4UImanager::GetUIpointer();
  UImanager-> ApplyCommand("/run/physicsModified");
}

/******************************************************************************/
void MACPhysicsList::RegisterPhysicsModule(G4String newValue){
    if ( GetPhysics(newValue) ){
	G4cout << "@@@MACPhysicsList::RegisterPhysicsModule " 
	       << newValue << " had already registered "<< G4endl;
	return;
    }

    G4cout << "+++MACPhysicsList registration :: " <<newValue<<G4endl;

  // Register physics processes
    ///////////////////////////
    // Electron/Positon/Gamma//
    //////////////////////////
    if ( newValue == "LowEElectroMagnetic" ){
	if ( GetPhysics("PenelopeElectroMagnetic" ) 
	     || GetPhysics("STDElectroMagnetic" ) ){
	    G4cout << "@@@MACPhysicsList::RegisterPhysicsModule "
		   << newValue << " could not be registered "
		   << "because Penelope or STDElectroMagnetic "
		   << "has already been registered." << G4endl;
	    return;
	}
	RegisterPhysics( new MACPhysProcessLowEElectroMagnetic(newValue) );
    }else if ( newValue == "PenelopeElectroMagnetic" ){
	if ( GetPhysics("LowEElectroMagnetic" ) 
	     || GetPhysics("STDElectroMagnetic" ) ){
	    G4cout << "@@@MACPhysicsList::RegisterPhysicsModule "
		   << newValue << " could not be registered "
		   << "because LowE or STD ElectroMagnetic "
		   << "has already been registered." << G4endl;
	    return;
	}
	RegisterPhysics( new MACPhysProcessPenelopeElectroMagnetic(newValue) );
    }else if ( newValue == "STDElectroMagnetic" ){
	if ( GetPhysics("LowEElectroMagnetic" ) 
	     || GetPhysics("PenelopeElectroMagnetic" ) ){
	    G4cout << "@@@MACPhysicsList::RegisterPhysicsModule "
		   << newValue << " could not be registered "
		   << "because LowE or Pelenlope ElectroMagnetic "
		   << "has already been registered." << G4endl;
	    return;
	}
	RegisterPhysics( new MACPhysProcessSTDElectroMagnetic(newValue) );
    ///////////////////////////
    // Hadron QED Process    //
    //////////////////////////
    }else if ( newValue == "LowEHadronQED" ) {
	if ( GetPhysics("HadronQED" ) || GetPhysics("MyHadronQED")){
	    G4cout << "@@@MACPhysicsList::RegisterPhysicsModule "
		   << newValue << " could not be registered "
		   << "because hadronQED "
		   << "has already been registered." << G4endl;
	    return;
	}
	RegisterPhysics( new MACPhysProcessLowEHadronQED(newValue) );
    }else if ( newValue == "HadronQED" ) {
	if ( GetPhysics("LowEHadronQED" ) || GetPhysics("MyHadronQED") ){
	    G4cout << "@@@MACPhysicsList::RegisterPhysicsModule "
		   << newValue << " could not be registered "
		   << "because LowEhadronQED "
		   << "has already been registered." << G4endl;
	    return;
	}
	RegisterPhysics( new MACPhysProcessHadronQED(newValue) );
    }else if ( newValue == "MyHadronQED" ) {
	if ( GetPhysics("LowEHadronQED") || GetPhysics("MyHadronQED") ){
	    G4cout << "@@@MACPhysicsList::RegisterPhysicsModule "
		   << newValue << " could not be registered "
		   << "because LowEhadronQED "
		   << "has already been registered." << G4endl;
	    return;
	}
	RegisterPhysics( new MACPhysProcessMyHadronQED(newValue) );
    /////////////////////////////////////////
    // Hadron Elastic/Inelastic Process            //
    /////////////////////////////////////////
    }else if ( newValue == "hadronLHEP_PRECO_HP" ){
      RegisterPhysics( new HadronPhysicsLHEP_PRECO_HP(newValue) );
    }else if ( newValue == "hadronLHEP_BERT_HP" ) {
      RegisterPhysics( new HadronPhysicsLHEP_BERT_HP(newValue) );
    }else if ( newValue == "hadronQGSP_BERT_HP" ) {
      RegisterPhysics( new HadronPhysicsQGSP_BERT_HP(newValue) );
    }else if ( newValue == "hadronQGSP_BIC_HP" ) {
      RegisterPhysics( new HadronPhysicsQGSP_BIC_HP(newValue) );
    }else if ( newValue == "QStopping" ){  // Capture for hadron/mu
      RegisterPhysics( new G4QStoppingPhysics("stopping")); //Capture
    }else if ( newValue == "hadronElastic" ) {
	RegisterPhysics( new G4HadronElasticPhysics("LElastic",1,true) );
    }else if ( newValue == "UhadronElastic" ) {
	RegisterPhysics( new G4HadronElasticPhysics("elastic",0,false) );
    /////////////////////////////////////////
    // Decays                              //
    /////////////////////////////////////////
    }else if ( newValue == "Decay" ) {
	RegisterPhysics( new MACPhysProcessDecay(newValue) ); 
    }else if ( newValue == "RadioactiveDecay" ){
	RegisterPhysics(new G4RadioactiveDecayPhysics(newValue) );
    /////////////////////////////////////////
    // Muons                               //
    /////////////////////////////////////////
    }else if ( newValue == "Muon" ) {
	RegisterPhysics( new MACPhysProcessMuon(newValue) ); 
    /////////////////////////////////////////
    // Ions                                //
    /////////////////////////////////////////
    }else if ( newValue == "LowEIon" ) {
	RegisterPhysics( new MACPhysProcessLowEIon(newValue) );
    }else if ( newValue == "Ion" ) {
	RegisterPhysics( new MACPhysProcessIon(newValue) );
    /////////////////////////////////////////
    // Error                               //
    /////////////////////////////////////////
    }else{
	G4cout << "@@@MACPhysicsList::RegisterPhysicsModule " 
	       <<  newValue << " is unknown process Skipped" << G4endl;
    }
}
/******************************************************************************/
