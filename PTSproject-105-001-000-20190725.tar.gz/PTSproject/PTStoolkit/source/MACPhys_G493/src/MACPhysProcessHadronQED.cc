//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessHadronQED.cc
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//  10 Oct, 2007    T.Aso Multiple scattering was replaced to 
//                  G4hMultipleScattering.
//  19 Dec, 2008    T.Aso EmOptions for stable range calculation.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessHadronQED.hh"
#include "G4ProcessType.hh"
#include "G4StepLimiter.hh"
#include "G4EmProcessOptions.hh"

#include "globals.hh"
#include "G4ios.hh"
//#include "g4std/iomanip"   
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessHadronQED::MACPhysProcessHadronQED(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessHadronQED::~MACPhysProcessHadronQED()
/******************************************************************************/
{}

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

// Nuclei
#include "G4MesonConstructor.hh"
#include "G4BaryonConstructor.hh"
#include "G4ShortLivedConstructor.hh"

#include "G4Proton.hh"
#include "G4AntiProton.hh"
#include "G4PionPlus.hh"
#include "G4PionMinus.hh"
#include "G4KaonPlus.hh"
#include "G4KaonMinus.hh"
#include "G4SigmaMinus.hh"
#include "G4AntiSigmaMinus.hh"
#include "G4SigmaPlus.hh"
#include "G4AntiSigmaPlus.hh"
#include "G4XiMinus.hh"
#include "G4AntiXiMinus.hh"
#include "G4OmegaMinus.hh"
#include "G4AntiOmegaMinus.hh"


/******************************************************************************/
void MACPhysProcessHadronQED::ConstructParticle()
/******************************************************************************/
{
//-- Construct all mesons
  G4MesonConstructor pMesonConstructor;
  pMesonConstructor.ConstructParticle();

//--  Construct all barions
  G4BaryonConstructor pBaryonConstructor;
  pBaryonConstructor.ConstructParticle();

//--  Construct  resonaces and quarks
  G4ShortLivedConstructor pShortLivedConstructor;
  pShortLivedConstructor.ConstructParticle();  

}


#include "G4ProcessManager.hh"

#include "G4MultipleScattering.hh"
#include "G4hMultipleScattering.hh"
#include "G4hIonisation.hh"

/******************************************************************************/
void MACPhysProcessHadronQED::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;
  
//-- PionPlus
  //G4MultipleScattering* thePionPlusMult = new G4MultipleScattering;
 G4hMultipleScattering* thePionPlusMult = new G4hMultipleScattering;
 G4hIonisation* thePionPlusIonisation = new G4hIonisation;

  pManager = G4PionPlus::PionPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(thePionPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(thePionPlusMult);
  pManager->SetProcessOrdering(thePionPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(thePionPlusMult, idxPostStep, 1);

//-- PionMinus
  //G4MultipleScattering* thePionMinusMult = new G4MultipleScattering;
  G4hMultipleScattering* thePionMinusMult = new G4hMultipleScattering;
  G4hIonisation* thePionMinusIonisation = new G4hIonisation;


  pManager = G4PionMinus::PionMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(thePionMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(thePionMinusMult);
  pManager->SetProcessOrdering(thePionMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(thePionMinusMult, idxPostStep, 1);

//-- KaonPlus
   //-- K + 
   //G4MultipleScattering* theKaonPlusMult = new G4MultipleScattering;
   G4hMultipleScattering* theKaonPlusMult = new G4hMultipleScattering;
   G4hIonisation* theKaonPlusIonisation = new G4hIonisation;

  pManager = G4KaonPlus::KaonPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(theKaonPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theKaonPlusMult);
  pManager->SetProcessOrdering(theKaonPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theKaonPlusMult, idxPostStep, 1);

//-- KaonMinus

   //-- K -
   //G4MultipleScattering* theKaonMinusMult = new G4MultipleScattering;
   G4hMultipleScattering* theKaonMinusMult = new G4hMultipleScattering;
   G4hIonisation* theKaonMinusIonisation = new G4hIonisation;

  pManager = G4KaonMinus::KaonMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theKaonMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theKaonMinusMult);
  pManager->SetProcessOrdering(theKaonMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theKaonMinusMult, idxPostStep, 1);

//-- Proton

   //-- Proton
   //G4MultipleScattering* theProtonMult = new G4MultipleScattering;
   G4hMultipleScattering* theProtonMult = new G4hMultipleScattering;
   G4hIonisation* theProtonIonisation = new G4hIonisation;
   theProtonIonisation->SetProcessType(fElectromagnetic);
 

  pManager = G4Proton::Proton()->GetProcessManager();

  // add process
  //theProtonIonisation.SetNuclearStoppingOff();
  //theProtonIonisation.SetHighEnergyForProtonParametrisation(0.8*MeV);
  //pManager->AddProcess(theProtonIonisation, ordInActive,2, 2);
  //pManager->AddProcess(theProtonMult);
  //pManager->SetProcessOrdering(theProtonMult, idxAlongStep, 1);
  //pManager->SetProcessOrdering(theProtonMult, idxPostStep, 1);
  //
  //                                       AtRest, Along, Post
  pManager->AddProcess(theProtonMult,      -1,     1,      1);
  pManager->AddProcess(theProtonIonisation,-1,     2,      2);
  pManager->AddProcess(new G4StepLimiter,  -1,    -1,      3);

//-- Anti-Proton
   //-- Anti-proton
   //G4MultipleScattering* theAntiProtonMult = new G4MultipleScattering;
   G4hMultipleScattering* theAntiProtonMult = new G4hMultipleScattering;
   G4hIonisation* theAntiProtonIonisation = new G4hIonisation;
    

  pManager = G4AntiProton::AntiProton()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiProtonIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiProtonMult);
  pManager->SetProcessOrdering(theAntiProtonMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiProtonMult, idxPostStep, 1);

//-- SigmaMinus
   //-- SigmaMinus
   //G4MultipleScattering* theSigmaMinusMult = new G4MultipleScattering;
   G4hMultipleScattering* theSigmaMinusMult = new G4hMultipleScattering;
   G4hIonisation* theSigmaMinusIonisation = new G4hIonisation;
  

  pManager = G4SigmaMinus::SigmaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theSigmaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theSigmaMinusMult);
  pManager->SetProcessOrdering(theSigmaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theSigmaMinusMult, idxPostStep, 1);

//-- Anti-SigmaMinus
   //-- AntiSigmaMinus
   //G4MultipleScattering* theAntiSigmaMinusMult =new G4MultipleScattering;
   G4hMultipleScattering* theAntiSigmaMinusMult =new G4hMultipleScattering;
   G4hIonisation* theAntiSigmaMinusIonisation = new G4hIonisation;
 

  pManager = G4AntiSigmaMinus::AntiSigmaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiSigmaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiSigmaMinusMult);
  pManager->SetProcessOrdering(theAntiSigmaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiSigmaMinusMult, idxPostStep, 1);

//-- SigmaPlus
   //-- SigmaPlus
   //G4MultipleScattering* theSigmaPlusMult =new G4MultipleScattering;
   G4hMultipleScattering* theSigmaPlusMult =new G4hMultipleScattering;
   G4hIonisation* theSigmaPlusIonisation = new G4hIonisation;
 

  pManager = G4SigmaPlus::SigmaPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(theSigmaPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theSigmaPlusMult);
  pManager->SetProcessOrdering(theSigmaPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theSigmaPlusMult, idxPostStep, 1);

//-- Anti-SigmaPlus
   //-- AntiSigmaPlus
   //G4MultipleScattering* theAntiSigmaPlusMult =new G4MultipleScattering;
   G4hMultipleScattering* theAntiSigmaPlusMult =new G4hMultipleScattering;
   G4hIonisation* theAntiSigmaPlusIonisation = new G4hIonisation;

  pManager = G4AntiSigmaPlus::AntiSigmaPlus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiSigmaPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiSigmaPlusMult);
  pManager->SetProcessOrdering(theAntiSigmaPlusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiSigmaPlusMult, idxPostStep, 1);

//-- XiMinus
 
   //-- XiMinus
   //G4MultipleScattering* theXiMinusMult =new G4MultipleScattering;
   G4hMultipleScattering* theXiMinusMult =new G4hMultipleScattering;
   G4hIonisation* theXiMinusIonisation = new G4hIonisation;

  pManager = G4XiMinus::XiMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theXiMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theXiMinusMult);
  pManager->SetProcessOrdering(theXiMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theXiMinusMult, idxPostStep, 1);

//-- Anti-XiMinus

   //-- AntiXiMinus
   //G4MultipleScattering* theAntiXiMinusMult =new G4MultipleScattering;
   G4hMultipleScattering* theAntiXiMinusMult =new G4hMultipleScattering;
   G4hIonisation* theAntiXiMinusIonisation = new G4hIonisation;

  pManager = G4AntiXiMinus::AntiXiMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiXiMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiXiMinusMult);
  pManager->SetProcessOrdering(theAntiXiMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiXiMinusMult, idxPostStep, 1);

//-- OmegaMinus
  
   //-- OmegaMinus
   //G4MultipleScattering* theOmegaMinusMult =new G4MultipleScattering;
   G4hMultipleScattering* theOmegaMinusMult =new G4hMultipleScattering;
   G4hIonisation* theOmegaMinusIonisation = new G4hIonisation;

  pManager = G4OmegaMinus::OmegaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theOmegaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theOmegaMinusMult);
  pManager->SetProcessOrdering(theOmegaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theOmegaMinusMult, idxPostStep, 1);

//-- Anti-OmegaMinus
   
   //-- AntiOmegaMinus
   //G4MultipleScattering* theAntiOmegaMinusMult =new G4MultipleScattering;
   G4hMultipleScattering* theAntiOmegaMinusMult =new G4hMultipleScattering;
   G4hIonisation* theAntiOmegaMinusIonisation = new G4hIonisation;

  pManager = G4AntiOmegaMinus::AntiOmegaMinus()->GetProcessManager();
  // add process
  pManager->AddProcess(theAntiOmegaMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(theAntiOmegaMinusMult);
  pManager->SetProcessOrdering(theAntiOmegaMinusMult, idxAlongStep, 1);
  pManager->SetProcessOrdering(theAntiOmegaMinusMult, idxPostStep, 1);


  //
  // EmProcessOptions for stable range calcualtion
  //  (19-Dec-08) T.Aso From TestEm7.
  //  This may be specified by online-commands
  // or should be default of EM-process.
  //
  //G4EmProcessOptions opt;
  //opt.SetVerbose(verbose);
  //opt.SetMinEnergy(0.1*keV);
  //opt.SetMaxEnergy(100.*GeV);
  //opt.SetDEDXBinning(360);
  //opt.SetLambdaBinning(360);
  //opt.SetLinearLossLimit(1.e-6);
  //opt.SetSplineFlag(true);
}





