//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessPenelopeElectroMagnetic.cc
//
// [Description]
//   The 'Physics List Constructor' for the electromagnetic processes.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   26-OCT-2005     T. Aso   : Maintained for HIBMC Simulation
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessPenelopeElectroMagnetic.hh"

#include "globals.hh"
#include "G4ios.hh"
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessPenelopeElectroMagnetic::MACPhysProcessPenelopeElectroMagnetic(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessPenelopeElectroMagnetic::~MACPhysProcessPenelopeElectroMagnetic()
/******************************************************************************/
{}


#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

#include "G4Gamma.hh"
#include "G4Electron.hh"
#include "G4Positron.hh"
#include "G4NeutrinoE.hh"
#include "G4AntiNeutrinoE.hh"

/******************************************************************************/
 void MACPhysProcessPenelopeElectroMagnetic::ConstructParticle()
/******************************************************************************/
{
//-- gamma
  G4Gamma::GammaDefinition();
 
//-- electron
  G4Electron::ElectronDefinition();
  G4Positron::PositronDefinition();
  G4NeutrinoE::NeutrinoEDefinition();
  G4AntiNeutrinoE::AntiNeutrinoEDefinition();
}


#include "G4ProcessManager.hh"

#include "G4PenelopePhotoElectric.hh"
#include "G4PenelopeCompton.hh"
#include "G4PenelopeGammaConversion.hh"
#include "G4PenelopeRayleigh.hh"

#include "G4MultipleScattering.hh"

#include "G4PenelopeIonisation.hh"
#include "G4PenelopeBremsstrahlung.hh"
#include "G4PenelopeAnnihilation.hh"

/******************************************************************************/
 void MACPhysProcessPenelopeElectroMagnetic::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;

//-- Gamma Physics
  G4PenelopePhotoElectric* thePhotoEffect = new G4PenelopePhotoElectric;
  G4PenelopeCompton* theComptonEffect     = new G4PenelopeCompton;
  G4PenelopeGammaConversion* thePairProduction= new G4PenelopeGammaConversion;
  G4PenelopeRayleigh* theRayleigh = new G4PenelopeRayleigh;

  pManager = G4Gamma::Gamma()->GetProcessManager();
  pManager->AddDiscreteProcess(thePhotoEffect);
  pManager->AddDiscreteProcess(theComptonEffect);
  pManager->AddDiscreteProcess(thePairProduction);
  pManager->AddDiscreteProcess(theRayleigh);

//-- Electron Physics
  G4MultipleScattering* theElectronMultipleScattering
      = new G4MultipleScattering;
  G4PenelopeIonisation* theElectronIonisation
      = new G4PenelopeIonisation;
  G4PenelopeBremsstrahlung* theElectronBremsStrahlung
      = new G4PenelopeBremsstrahlung;

  pManager = G4Electron::Electron()->GetProcessManager();
  pManager->AddDiscreteProcess(theElectronBremsStrahlung);  
  pManager->AddProcess(theElectronIonisation, ordInActive,2, 2);
  pManager->AddProcess(theElectronMultipleScattering);
  pManager->SetProcessOrdering(theElectronMultipleScattering, idxAlongStep, 1);
  pManager->SetProcessOrdering(theElectronMultipleScattering, idxPostStep,  1);

//-- Positron Physics
  G4MultipleScattering* thePositronMultipleScattering
      = new G4MultipleScattering;
  G4PenelopeIonisation* thePositronIonisation
      = new G4PenelopeIonisation;
  G4PenelopeBremsstrahlung* thePositronBremsStrahlung
      = new G4PenelopeBremsstrahlung;
  G4PenelopeAnnihilation* theAnnihilation
      = new G4PenelopeAnnihilation;

  pManager = G4Positron::Positron()->GetProcessManager();
  pManager->AddDiscreteProcess(thePositronBremsStrahlung);
  pManager->AddDiscreteProcess(theAnnihilation);
  pManager->AddRestProcess(theAnnihilation);
  pManager->AddProcess(thePositronIonisation, ordInActive,2, 2);
  pManager->AddProcess(thePositronMultipleScattering);
  pManager->SetProcessOrdering(thePositronMultipleScattering, idxAlongStep, 1);
  pManager->SetProcessOrdering(thePositronMultipleScattering, idxPostStep, 1);

}



