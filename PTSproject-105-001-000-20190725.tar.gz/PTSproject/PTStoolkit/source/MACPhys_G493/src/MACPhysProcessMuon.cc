//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessMuon.cc
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//  21 Aug,   2006, T. Aso   : Modified for PTS.
//   8-Jun,2010         T. Aso   : Replace MultipleScattering for v9.3.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessMuon.hh"

#include "globals.hh"
#include "G4ios.hh"
//#include "g4std/iomanip"   
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessMuon::MACPhysProcessMuon(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessMuon::~MACPhysProcessMuon()
/******************************************************************************/
{}

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

#include "G4MuonPlus.hh"
#include "G4MuonMinus.hh"
#include "G4TauMinus.hh"
#include "G4TauPlus.hh"
#include "G4NeutrinoTau.hh"
#include "G4AntiNeutrinoTau.hh"
#include "G4NeutrinoMu.hh"
#include "G4AntiNeutrinoMu.hh"

/******************************************************************************/
 void MACPhysProcessMuon::ConstructParticle()
/******************************************************************************/
{

//-- Mu
  G4MuonPlus::MuonPlusDefinition();
  G4MuonMinus::MuonMinusDefinition();
  G4NeutrinoMu::NeutrinoMuDefinition();
  G4AntiNeutrinoMu::AntiNeutrinoMuDefinition();

//-- Tau
  G4TauMinus::TauMinusDefinition();
  G4TauPlus::TauPlusDefinition();
  G4NeutrinoTau::NeutrinoTauDefinition();
  G4AntiNeutrinoTau::AntiNeutrinoTauDefinition();
}


#include "G4ProcessManager.hh"
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
#include "G4MultipleScattering.hh"
#else
#include "G4MuMultipleScattering.hh"
#endif
#include "G4MuBremsstrahlung.hh"
#include "G4MuPairProduction.hh"
#include "G4MuIonisation.hh"
#include "G4hIonisation.hh"

#include "G4MuonMinusCaptureAtRest.hh"

/******************************************************************************/
 void MACPhysProcessMuon::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;

//-- Muon Plus Physics
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering* emult = new G4MultipleScattering;
#else  
  G4MuMultipleScattering*  fMuPlusMultipleScattering 
    = new G4MuMultipleScattering;
#endif
  G4MuBremsstrahlung* fMuPlusBremsstrahlung=new G4MuBremsstrahlung;
  G4MuPairProduction* fMuPlusPairProduction=new G4MuPairProduction;
  G4MuIonisation*     fMuPlusIonisation=new G4MuIonisation;

  pManager = G4MuonPlus::MuonPlus()->GetProcessManager();
  // add processes
  pManager->AddProcess(fMuPlusIonisation, ordInActive,2, 2);
  pManager->AddDiscreteProcess(fMuPlusBremsstrahlung);
  pManager->AddDiscreteProcess(fMuPlusPairProduction);
  pManager->AddProcess(fMuPlusMultipleScattering);
  pManager->SetProcessOrdering(fMuPlusMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fMuPlusMultipleScattering, idxPostStep,  1);

//-- Muon Minus Physics
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering*  fMuMinusMultipleScattering= new G4MultipleScattering;
#else  
  G4MuMultipleScattering*  fMuMinusMultipleScattering 
    = new G4MuMultipleScattering;
#endif
  G4MuBremsstrahlung* fMuMinusBremsstrahlung=new G4MuBremsstrahlung;
  G4MuPairProduction* fMuMinusPairProduction=new G4MuPairProduction;
  G4MuIonisation*     fMuMinusIonisation=new G4MuIonisation;
  G4MuonMinusCaptureAtRest* fMuMinusCaptureAtRest=new G4MuonMinusCaptureAtRest;

  pManager = G4MuonMinus::MuonMinus()->GetProcessManager();
  // add processes
  pManager->AddProcess(fMuMinusIonisation, ordInActive,2, 2);
  pManager->AddDiscreteProcess(fMuMinusBremsstrahlung);
  pManager->AddDiscreteProcess(fMuMinusPairProduction);
  pManager->AddProcess(fMuMinusMultipleScattering);
  pManager->SetProcessOrdering(fMuMinusMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fMuMinusMultipleScattering, idxPostStep,  1);
  pManager->AddRestProcess(fMuMinusCaptureAtRest);

//-- Tau Plus Physics
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering*  fTauPlusMultipleScattering = new G4MultipleScattering;
#else  
  G4MuMultipleScattering*  fTauPlusMultipleScattering 
    = new G4MuMultipleScattering;
#endif
   G4hIonisation* fTauPlusIonisation=new G4hIonisation;

  pManager = G4TauPlus::TauPlus()->GetProcessManager();
  // add processes
  pManager->AddProcess(fTauPlusIonisation, ordInActive,2, 2);
  pManager->AddProcess(fTauPlusMultipleScattering);
  pManager->SetProcessOrdering(fTauPlusMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fTauPlusMultipleScattering, idxPostStep,  1);

//-- Tau Minus Physics
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering*  fTauMinusMultipleScattering = new G4MultipleScattering;
#else  
  G4MuMultipleScattering*  fTauMinusMultipleScattering 
    = new G4MuMultipleScattering;
#endif
  G4hIonisation* fTauMinusIonisation=new G4hIonisation;

  pManager = G4TauMinus::TauMinus()->GetProcessManager();
  // add processes
  pManager->AddProcess(fTauMinusIonisation, ordInActive,2, 2);
  pManager->AddProcess(fTauMinusMultipleScattering);
  pManager->SetProcessOrdering(fTauMinusMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fTauMinusMultipleScattering, idxPostStep,  1);

}



