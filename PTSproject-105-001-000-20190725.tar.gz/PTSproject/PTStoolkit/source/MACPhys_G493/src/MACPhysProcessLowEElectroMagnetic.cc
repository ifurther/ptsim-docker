//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessLowEElectroMagnetic.cc
//
// [Description]
//   The 'Physics List Constructor' for the electromagnetic processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//                  T. Aso   : Maintained for HIBMC Simulation
//   31 Oct,  2005, T. Aso   : Modification to avoid error at termination
//   8-Jun,2010         T. Aso   : Replace MultipleScattering for v9.3.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessLowEElectroMagnetic.hh"

#include "globals.hh"
#include "G4ios.hh"
#include <iomanip>   

/******************************************************************************/
 MACPhysProcessLowEElectroMagnetic::MACPhysProcessLowEElectroMagnetic(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessLowEElectroMagnetic::~MACPhysProcessLowEElectroMagnetic()
/******************************************************************************/
{}

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

#include "G4Gamma.hh"
#include "G4Electron.hh"
#include "G4Positron.hh"
#include "G4NeutrinoE.hh"
#include "G4AntiNeutrinoE.hh"

/******************************************************************************/
 void MACPhysProcessLowEElectroMagnetic::ConstructParticle()
/******************************************************************************/
{
//-- gamma
  G4Gamma::GammaDefinition();
 
//-- electron
  G4Electron::ElectronDefinition();
  G4Positron::PositronDefinition();
  G4NeutrinoE::NeutrinoEDefinition();
  G4AntiNeutrinoE::AntiNeutrinoEDefinition();
}


#include "G4ProcessManager.hh"

#include "G4LowEnergyPhotoElectric.hh"
#include "G4LowEnergyCompton.hh"
#include "G4LowEnergyGammaConversion.hh"
#include "G4LowEnergyRayleigh.hh"

#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
#include "G4MultipleScattering.hh"
#else
#include "G4eMultipleScattering.hh"
#endif

#include "G4LowEnergyIonisation.hh"
#include "G4LowEnergyBremsstrahlung.hh"

#include "G4eIonisation.hh"
#include "G4eBremsstrahlung.hh"

#include "G4eplusAnnihilation.hh"

/******************************************************************************/
 void MACPhysProcessLowEElectroMagnetic::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;
  
//-- Gamma Physics
  pManager = G4Gamma::Gamma()->GetProcessManager();
  pManager->AddDiscreteProcess(new G4LowEnergyPhotoElectric);
  pManager->AddDiscreteProcess(new G4LowEnergyCompton);
  pManager->AddDiscreteProcess(new G4LowEnergyGammaConversion);

//-- Electron Physics
  G4LowEnergyBremsstrahlung* ebrem = new G4LowEnergyBremsstrahlung;
  G4LowEnergyIonisation* eioni = new G4LowEnergyIonisation;
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering* emult = new G4MultipleScattering;
#else  
  G4eMultipleScattering* emult = new G4eMultipleScattering;
#endif
  pManager = G4Electron::Electron()->GetProcessManager();
   // add processes
  pManager->AddDiscreteProcess(ebrem);  
  pManager->AddProcess(eioni, ordInActive,2, 2);
  pManager->AddProcess(emult);

  pManager->SetProcessOrdering(emult, idxAlongStep,  1);
  pManager->SetProcessOrdering(emult, idxPostStep,  1);

//-- Positron Physics
  G4eBremsstrahlung* pbrem = new G4eBremsstrahlung;
  G4eIonisation* pioni = new G4eIonisation;
#if defined(G4VERSION_NUMBER) && (G4VERSION < 930)
  G4MultipleScattering* pmult = new G4MultipleScattering;
#else  
  G4eMultipleScattering* pmult = new G4eMultipleScattering;
#endif
  G4eplusAnnihilation*       panni = new G4eplusAnnihilation;

  pManager = G4Positron::Positron()->GetProcessManager();

  // add processes
  pManager->AddDiscreteProcess(pbrem);
  pManager->AddDiscreteProcess(panni);
  pManager->AddRestProcess(panni);
  pManager->AddProcess(pioni, ordInActive,2, 2);
  pManager->AddProcess(pmult);
  pManager->SetProcessOrdering(pmult, idxAlongStep,  1);
  pManager->SetProcessOrdering(pmult, idxPostStep,  1);
}



