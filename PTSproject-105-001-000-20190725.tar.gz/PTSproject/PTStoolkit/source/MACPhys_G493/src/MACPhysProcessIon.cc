//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysProcessIon.cc
//
// [Description]
//   The 'Physics List Constructor' for the decay processes used in the
//   simulator of the P152 experiment. It is based on 'examples/novice/N04'.
//
// [Note]
//   You have to create this object in the heap area and to register
//   the pointer to 'Modular Physics List'.
//
// [Histoy]
//   8 April, 2003, K. Amako : The 1st version created.
//  21 Aug,   2006, T. Aso   : Modified for PTS.
//  06 Feb,   2009, T. Aso   : Contribution from Toshito_san.
//                             Physics processes for carbon therapy.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysProcessIon.hh"
#include "G4BinaryLightIonReaction.hh"
#include "G4TripathiCrossSection.hh"
//#include "myG4TripathiCrossSection.hh"
#include "G4IonsShenCrossSection.hh"
#include "G4QMDReaction.hh"

#include "globals.hh"
#include "G4ios.hh"
//#include "g4std/iomanip"   
#include <iomanip>   

#include "G4EmProcessOptions.hh"

//#include "G4QIonIonElastic.hh"

/******************************************************************************/
 MACPhysProcessIon::MACPhysProcessIon(const G4String& name)
/******************************************************************************/
 :  G4VPhysicsConstructor(name)
{}

/******************************************************************************/
 MACPhysProcessIon::~MACPhysProcessIon()
/******************************************************************************/
{}

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"

// Nuclei
#include "G4IonConstructor.hh"

/******************************************************************************/
 void MACPhysProcessIon::ConstructParticle()
/******************************************************************************/
{

//--  Construct light ions
  G4IonConstructor pConstructor;
  pConstructor.ConstructParticle();  
}


#include "G4ProcessManager.hh"

#include "G4HadronElasticProcess.hh"
#include "G4LElastic.hh"
#include "G4DeuteronInelasticProcess.hh"
#include "G4LEDeuteronInelastic.hh"
#include "G4TritonInelasticProcess.hh"
#include "G4LETritonInelastic.hh"
#include "G4AlphaInelasticProcess.hh"
#include "G4LEAlphaInelastic.hh"
#include "G4ionIonisation.hh"
//#include "G4MultipleScattering.hh"

//#include "G4hIonisation.hh"
#include "G4hMultipleScattering.hh"

//#include "G4ScreenedNuclearRecoil.hh"

/******************************************************************************/
 void MACPhysProcessIon::ConstructProcess()
/******************************************************************************/
{
  G4ProcessManager * pManager = 0;
 
//-- Elastic Process
  G4HadronElasticProcess* theElasticProcess =new G4HadronElasticProcess;
  G4LElastic* theElasticModel = new G4LElastic();
  theElasticProcess->RegisterMe(theElasticModel);

//-- Generic Ion
//  G4ScreenedNuclearRecoil* nucr = new G4ScreenedNuclearRecoil();

/*
  G4hMultipleScattering*  fIonMultipleScattering=new G4hMultipleScattering;
  G4ionIonisation*       fIonIonisation = new G4ionIonisation;
*/

//  fIonIonisation->SetProcessType(fElectromagnetic);

  pManager = G4GenericIon::GenericIon()->GetProcessManager();
  // add process

  pManager->AddDiscreteProcess(theElasticProcess);


  pManager->AddProcess(new G4hMultipleScattering, -1,1,1);
  pManager->AddProcess(new G4ionIonisation, -1, 2, 2);

//  pManager->AddProcess(fIonMultipleScattering,-1,1,1);
//  pManager->AddProcess(fIonIonisation,-1,1,1);


/*
  pManager->AddProcess(fIonIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fIonMultipleScattering);
  pManager->SetProcessOrdering(fIonMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fIonMultipleScattering, idxPostStep,  1);
*/


//      pManager->AddProcess(new G4ionIonisation,      -1, 1,1);
//      pManager->AddDiscreteProcess(nucr);      


//binary cascade
   G4TripathiCrossSection * TripathiCrossSection= new G4TripathiCrossSection;
   G4IonsShenCrossSection * aShen = new G4IonsShenCrossSection;
/////BC
   G4HadronInelasticProcess* theIPGenericIon
       = new G4HadronInelasticProcess("IonInelastic",
                                      G4GenericIon::GenericIon());
   theIPGenericIon->AddDataSet(aShen);
   theIPGenericIon->AddDataSet(TripathiCrossSection);

   G4BinaryLightIonReaction *theModel= new G4BinaryLightIonReaction;
//  G4QMDReaction * theModel = new G4QMDReaction;

   theModel->SetMinEnergy(0*MeV);
   theModel->SetMaxEnergy(10*GeV);

   theIPGenericIon->RegisterMe(theModel);
   pManager->AddDiscreteProcess(theIPGenericIon);

//080918 TK Add 
//  G4QIonIonElastic* theQIonIonElastic = new G4QIonIonElastic();
//  pManager->AddDiscreteProcess(theQIonIonElastic);


/////



//-- Deuteron 
  G4hMultipleScattering* fDeuteronMultipleScattering=new G4hMultipleScattering;
  G4ionIonisation*      fDeuteronIonisation= new G4ionIonisation;
  G4DeuteronInelasticProcess* fDeuteronProcess= new G4DeuteronInelasticProcess;
//  G4LEDeuteronInelastic* fDeuteronModel = new G4LEDeuteronInelastic();
//  fDeuteronProcess->RegisterMe(fDeuteronModel);

//binary cascade
   fDeuteronProcess->AddDataSet(aShen);
   fDeuteronProcess->AddDataSet(TripathiCrossSection);
//BC
   fDeuteronProcess->RegisterMe(theModel);

  pManager = G4Deuteron::Deuteron()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fDeuteronProcess);
  pManager->AddProcess(fDeuteronIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fDeuteronMultipleScattering);
  pManager->SetProcessOrdering(fDeuteronMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fDeuteronMultipleScattering, idxPostStep,  1);
 
//-- Triton 
   G4hMultipleScattering* fTritonMultipleScattering=new G4hMultipleScattering;
   G4ionIonisation*      fTritonIonisation=new G4ionIonisation;
   G4TritonInelasticProcess* fTritonProcess=new G4TritonInelasticProcess;
//   G4LETritonInelastic*        fTritonModel=new G4LETritonInelastic;
//   fTritonProcess->RegisterMe(fTritonModel);

//binary cascade
  fTritonProcess->AddDataSet(aShen);
  fTritonProcess->AddDataSet(TripathiCrossSection);
//BC
  fTritonProcess->RegisterMe(theModel);

  pManager = G4Triton::Triton()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fTritonProcess);
  pManager->AddProcess(fTritonIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fTritonMultipleScattering);
  pManager->SetProcessOrdering(fTritonMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fTritonMultipleScattering, idxPostStep,  1);

 
//-- Alpha 
  G4hMultipleScattering*  fAlphaMultipleScattering=new G4hMultipleScattering;
  G4ionIonisation*       fAlphaIonisation=new G4ionIonisation;
  G4AlphaInelasticProcess* fAlphaProcess=new G4AlphaInelasticProcess;
//  G4LEAlphaInelastic*     fAlphaModel=new G4LEAlphaInelastic;
//  fAlphaProcess->RegisterMe(fAlphaModel);

//binary cascade
   fAlphaProcess->AddDataSet(aShen);
   fAlphaProcess->AddDataSet(TripathiCrossSection);
//BC
   fAlphaProcess->RegisterMe(theModel);

  pManager = G4Alpha::Alpha()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fAlphaProcess);
  pManager->AddProcess(fAlphaIonisation, ordInActive, 2, 2);
  pManager->AddProcess(fAlphaMultipleScattering);
  pManager->SetProcessOrdering(fAlphaMultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fAlphaMultipleScattering, idxPostStep,  1);

 
//-- He3
  G4hMultipleScattering* fHe3MultipleScattering=new G4hMultipleScattering;
  G4ionIonisation*      fHe3Ionisation=new G4ionIonisation;

//binary cascade
  G4HadronInelasticProcess *fHe3Process =
    new G4HadronInelasticProcess("He3Inelastic", G4He3::He3());
  fHe3Process->AddDataSet(aShen);
  fHe3Process->AddDataSet(TripathiCrossSection);
//BC
  fHe3Process->RegisterMe(theModel);

  pManager = G4He3::He3()->GetProcessManager();
  // add process
  pManager->AddDiscreteProcess(theElasticProcess);
  pManager->AddDiscreteProcess(fHe3Process);
  pManager->AddProcess(fHe3Ionisation, ordInActive, 2, 2);
  pManager->AddProcess(fHe3MultipleScattering);
  pManager->SetProcessOrdering(fHe3MultipleScattering, idxAlongStep,  1);
  pManager->SetProcessOrdering(fHe3MultipleScattering, idxPostStep,  1);





  // Em options
  //      
  G4int verbose = 1;
  G4EmProcessOptions opt;
  opt.SetVerbose(verbose);
  
  // Multiple Coulomb scattering
  //
//  opt.SetMscStepLimitation(fUseDistanceToBoundary);
//  opt.SetMscRangeFactor(0.02);
    
  // Physics tables
  //
  opt.SetMinEnergy(100*eV);
  opt.SetMaxEnergy(100*TeV);
  opt.SetDEDXBinning(120);
  opt.SetLambdaBinning(120);
  opt.SetSplineFlag(true);
  
  // Energy loss
  //
  opt.SetLinearLossLimit(0.01);
//  opt.SetLinearLossLimit(0.001);
  
  // Ionization
  //
  opt.SetSubCutoff(true);  




//  opt.SetLossFluctuations(false);

}




