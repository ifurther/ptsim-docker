//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//
// PhysicsList.cc
//
// [Description]
//   Physics list for Medical Accelerator. (Mainly for hadron therapy)
//
// [Histoy]
//  25 OCT,   2005  T. Aso   : Created
//  18 May,   2009  T. Aso   : Merge with G4 Physics-list.
//  08 Jul,   2010  T. Aso   : RadioactiveDecay
//  2012-01-15      T. Aso   : HadronPhysicsQGSP_INCL_ABLA was replaced to
//                             HadronPhysicsQGSP_INCLXX.
//                             G4IonInclAblaPhysics were replaced to
//                             G4IonINCLXXPhysics.
//  2013-03-27 T.Aso : Add entries for processes in Parallel world geometries.
//
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#include "MACPhysicsList.hh"
#include "MACParticleConstruction.hh"
// ParallelWorld Processes
#include "G4MParallelWorldProcess.hh"
#include "G4MParallelWorldScoringProcess.hh"

// EM processes including generic ions.
#include "G4EmDNAPhysics.hh"
#include "G4EmLivermorePhysics.hh"
#include "G4EmPenelopePhysics.hh"
#include "G4EmStandardPhysics.hh"
#include "G4EmStandardPhysics_option1.hh"
#include "G4EmStandardPhysics_option2.hh"
#include "G4EmStandardPhysics_option3.hh"
//                                     
//==== Hadrons
// Elastic process for hadrons. 
#include "G4HadronElasticPhysics.hh"
//
// Inelastic processes except for ions. 
#include "HadronPhysicsCHIPS.hh"
#include "HadronPhysicsFTFP_BERT_HP.hh"
#include "HadronPhysicsFTFP_BERT.hh"
#include "HadronPhysicsFTFP_BERT_TRV.hh"
#include "HadronPhysicsFTF_BIC.hh"
#include "HadronPhysicsLHEP.hh"
#include "HadronPhysicsLHEP_EMV.hh"
#include "HadronPhysicsQGSC_BERT.hh"
#include "HadronPhysicsQGSC_CHIPS.hh"
#include "HadronPhysicsQGSP.hh"
#include "HadronPhysicsQGSP_BERT.hh"
#include "HadronPhysicsQGSP_BERT_CHIPS.hh"
#include "HadronPhysicsQGSP_BERT_HP.hh"
#include "HadronPhysicsQGSP_BERT_NOLEP.hh"
#include "HadronPhysicsQGSP_BERT_TRV.hh"
#include "HadronPhysicsQGSP_BIC.hh"
#include "HadronPhysicsQGSP_BIC_HP.hh"
#include "HadronPhysicsQGSP_FTFP_BERT.hh"
#include "HadronPhysicsQGSP_INCLXX.hh"
#include "HadronPhysicsQGS_BIC.hh"
#include "HadronPhysicsShielding.hh"
// Stopping Physics and Radioactive decay
#include "G4QStoppingPhysics.hh"
#include "G4RadioactiveDecayPhysics.hh"
//
//===== Ions including Generic Ions. 
#include "G4IonBinaryCascadePhysics.hh"
#include "G4IonINCLXXPhysics.hh"
#include "G4IonQMDPhysics.hh"
#include "G4QIonPhysics.hh"
//
//===== Decay 
#include "G4DecayPhysics.hh"
//                                     
//=====
#include "G4Region.hh"
#include "G4RegionStore.hh"
#include "G4UserLimits.hh"
//=====

#include "G4UImanager.hh"

/******************************************************************************/
 MACPhysicsList::MACPhysicsList()
/******************************************************************************/
{   
  SetVerboseLevel(1);
  fPhysListMessenger = new MACPhysicsListMessenger(this);
  fEmProcess=NULL;
  fHadronElasticProcess=NULL;
  fHadronInElasticProcess=NULL;
  fStoppingProcess=NULL;
  fRadioactiveProcess=NULL;
  fIonInElasticProcess=NULL;
  fDecayProcess=NULL;

  // Register particles
  RegisterPhysics( new MACParticleConstruction() );

}

/******************************************************************************/
 MACPhysicsList::~MACPhysicsList()
/******************************************************************************/
{
    delete fPhysListMessenger;
}

/******************************************************************************/
void MACPhysicsList::SetCuts()
/******************************************************************************/
{
  // set cut values for gamma at first and for e- second and next for e+,
  //// because some processes for e+/e- need cut values for gamma
  SetCutsWithDefault();
}

/******************************************************************************/
void MACPhysicsList::SetStepLimitForRegion(G4double stepValue,
                                           const G4String&rname)
/******************************************************************************/
{
  G4Region* reg = G4RegionStore::GetInstance()->GetRegion(rname);
  if ( reg ){
    G4UserLimits* ulimits = reg->GetUserLimits();
    if ( ulimits ){
      ulimits->SetMaxAllowedStep(stepValue);
    }else{
      G4UserLimits* ulimits = new G4UserLimits(stepValue);
      reg->SetUserLimits(ulimits);
    }
    G4cout << " StepLimits for region " << stepValue/mm << G4endl;
  } else {
    G4cout << " MACPhysicsList::SetUserLimits() region "<<rname<<" not found"
           << G4endl;
  }
}
/******************************************************************************/
void MACPhysicsList::RegisterParallelWorldModule(G4String& nameProc,G4bool layered, 
                                                 G4String& namePW, G4int verbose ){
  G4VPhysicsConstructor* p=0;  
  p = new G4MParallelWorldProcess(nameProc,layered,namePW,verbose);
  RegisterPhysics(p);
}
/******************************************************************************/
void MACPhysicsList::RegisterParallelWorldScoringModule(G4String& nameProc,
                                                        G4String& namePW, G4int verbose ){
  G4VPhysicsConstructor* p=0;  
  p = new G4MParallelWorldScoringProcess(nameProc,namePW,verbose);
  RegisterPhysics(p);
}
/******************************************************************************/
void MACPhysicsList::RegisterPhysicsModule(G4String& newValue){

    // Register physics processes
    ///////////////////////////
    // EM processes
    //////////////////////////
  G4VPhysicsConstructor* p=0;
  if ( !fEmProcess ) {
    if( newValue == "G4EmDNAPhysics" ){
      p = new G4EmDNAPhysics();
    }else if ( newValue == "G4EmLivermorePhysics"){
      p = new G4EmLivermorePhysics();
    }else if ( newValue == "G4EmPenelopePhysics"){
      p = new G4EmPenelopePhysics();
    }else if ( newValue == "G4EmStandardPhysics"){
      p = new G4EmStandardPhysics();
    }else if ( newValue == "G4EmStandardPhysics_option1"){
      p = new G4EmStandardPhysics_option1();
    }else if ( newValue == "G4EmStandardPhysics_option2"){
      p = new G4EmStandardPhysics_option2();
    }else if ( newValue == "G4EmStandardPhysics_option3"){
      p = new G4EmStandardPhysics_option3();
    }
    if ( p ) {
      RegisterPhysics(p);
      fEmProcess = p;
      return;
    }
  } 
    ///////////////////////////
    // Hadron Elastic processes
    //////////////////////////
  p = 0;
  if ( !fHadronElasticProcess ){
    if ( newValue == "G4HadronElasticPhysics"){
      p = new G4HadronElasticPhysics();
    }
    if ( p ) {
      RegisterPhysics(p);
      fHadronElasticProcess = p;
      return;
    }
  }

    ///////////////////////////
    // Hadron Inelastic processes
    //////////////////////////
  p = 0;
  if ( !fHadronInElasticProcess ){
    if ( newValue == "HadronPhysicsCHIPS"){
      p = new HadronPhysicsCHIPS();
    }else if ( newValue == "HadronPhysicsFTFP_BERT"){
      p = new HadronPhysicsFTFP_BERT();
    }else if ( newValue == "HadronPhysicsFTFP_BERT_HP"){
      p = new HadronPhysicsFTFP_BERT_HP();
    }else if ( newValue == "HadronPhysicsFTFP_BERT_TRV"){
      p = new HadronPhysicsFTFP_BERT_TRV();
    }else if ( newValue == "HadronPhysicsFTF_BIC"){
      p = new HadronPhysicsFTF_BIC();
    }else if ( newValue == "HadronPhysicsLHEP"){
      p = new HadronPhysicsLHEP();
    }else if ( newValue == "HadronPhysicsLHEP_EMV"){
      p = new HadronPhysicsLHEP_EMV();
    }else if ( newValue == "HadronPhysicsQGSC_BERT"){
      p = new HadronPhysicsQGSC_BERT();
    }else if ( newValue == "HadronPhysicsQGSC_CHIPS"){
      p = new HadronPhysicsQGSC_CHIPS();
    }else if ( newValue == "HadronPhysicsQGSP"){
      p = new HadronPhysicsQGSP();
    }else if ( newValue == "HadronPhysicsQGSP_BERT"){
      p = new HadronPhysicsQGSP_BERT();
    }else if ( newValue == "HadronPhysicsQGSP_BERT_CHIPS"){
      p = new HadronPhysicsQGSP_BERT_CHIPS();
    }else if ( newValue == "HadronPhysicsQGSP_BERT_HP"){
      p = new HadronPhysicsQGSP_BERT_HP();
    }else if ( newValue == "HadronPhysicsQGSP_BERT_NOLEP"){
      p = new HadronPhysicsQGSP_BERT_NOLEP();
    }else if ( newValue == "HadronPhysicsQGSP_BERT_TRV"){
      p = new HadronPhysicsQGSP_BERT_TRV();
    }else if ( newValue == "HadronPhysicsQGSP_BIC"){
      p = new HadronPhysicsQGSP_BIC();
    }else if ( newValue == "HadronPhysicsQGSP_BIC_HP"){
      p = new HadronPhysicsQGSP_BIC_HP();
    }else if ( newValue == "HadronPhysicsQGSP_FTFP_BERT"){
      p = new HadronPhysicsQGSP_FTFP_BERT();
    } else if ( newValue == "HadronPhysicsQGSP_INCLXX"){
            p = new HadronPhysicsQGSP_INCLXX();
    }else if ( newValue == "HadronPhysicsQGS_BIC"){
      p = new HadronPhysicsQGS_BIC();
    }else if ( newValue == "HadronPhysicsShielding"){
      p = new HadronPhysicsShielding();
    }
    if ( p ) {
      RegisterPhysics(p);
      fHadronInElasticProcess = p;
      return;
    }
  }

    ///////////////////////////
    // Stopping (Capture) processes
    //////////////////////////

  p = 0;
  if ( !fStoppingProcess ){
    if ( newValue == "G4QStoppingPhysics"){
      p = new G4QStoppingPhysics();      
    }
    if ( p ) {
      RegisterPhysics(p);
      fStoppingProcess = p;
      return;
    }
  }

    ///////////////////////////
    // Radioactive processes
    //////////////////////////
  p = 0;
  if ( !fRadioactiveProcess ){
    if ( newValue == "G4RadioactiveDecayPhysics"){
      p = new G4RadioactiveDecayPhysics();
    }
    if ( p ) {
      RegisterPhysics(p);
      fRadioactiveProcess = p;
      return;
    }
  }


    ///////////////////////////
    // Ion InElastic processes
    //////////////////////////
  p = 0;
  if ( !fIonInElasticProcess) {
    if ( newValue == "G4IonBinaryCascadePhysics"){
      p = new G4IonBinaryCascadePhysics();
    }else if ( newValue == "G4IonINCLXXPhysics"){
      p = new G4IonINCLXXPhysics();
    }else if ( newValue == "G4IonQMDPhysics"){
      p = new G4IonQMDPhysics();
    }else if ( newValue == "G4QIonPhysics"){
      p = new G4QIonPhysics();
    }
    if ( p ) {
      RegisterPhysics(p);
      fIonInElasticProcess = p;
      return;
    }
  }

    ///////////////////////////
    // Decay processes
    //////////////////////////

  p = 0;
  if ( !fDecayProcess ) {
    if ( newValue == "G4DecayPhysics"){
      p = new G4DecayPhysics();
    }
    if ( p ) {
      RegisterPhysics(p);
      fDecayProcess = p;
      return;
    }
  }
  
  //
  // No matching process. 
  // 

  G4String msg = "Process "+newValue+" can not be registed. ";
  G4Exception("MACPhysicsList","RegisterPhysicsModule",JustWarning,msg);
}
/******************************************************************************/
