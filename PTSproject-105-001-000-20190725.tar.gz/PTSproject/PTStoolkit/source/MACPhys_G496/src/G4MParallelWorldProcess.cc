//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id$
//
//---------------------------------------------------------------------------
//
// ClassName:   G4MParallelWorldProcess
//
// (History)
// 2013-03-27 T.Aso Created. 
//
//----------------------------------------------------------------------------
//

#include "G4MParallelWorldProcess.hh"
#include "G4RunManager.hh"
#include "G4VUserDetectorConstruction.hh"
#include "G4VUserParallelWorld.hh"
#include "G4ParticleDefinition.hh"
#include "G4ProcessManager.hh"

#include "G4BosonConstructor.hh"
#include "G4LeptonConstructor.hh"
#include "G4MesonConstructor.hh"
#include "G4BosonConstructor.hh"
#include "G4BaryonConstructor.hh"
#include "G4IonConstructor.hh"
#include "G4ShortLivedConstructor.hh"

G4MParallelWorldProcess::G4MParallelWorldProcess(const G4String& nameProc, G4bool layered,
                                               const G4String& namePW, G4int ver)
  :  G4VPhysicsConstructor(nameProc),wasActivated(false),fLayered(layered),fNamePW(namePW)
{
  verbose=ver;
}

G4MParallelWorldProcess::~G4MParallelWorldProcess()
{}

void G4MParallelWorldProcess::ConstructParticle()
{
  if ( verbose > 0 ){
    G4cout << "G4MParallelWorldProcess::ConstructParticle" << G4endl;
  }

  G4BosonConstructor  pBosonConstructor;
  pBosonConstructor.ConstructParticle();

  G4LeptonConstructor pLeptonConstructor;
  pLeptonConstructor.ConstructParticle();

  G4MesonConstructor pMesonConstructor;
  pMesonConstructor.ConstructParticle();

  G4BaryonConstructor pBaryonConstructor;
  pBaryonConstructor.ConstructParticle();

  G4IonConstructor pIonConstructor;
  pIonConstructor.ConstructParticle();

  G4ShortLivedConstructor pShortLivedConstructor;
  pShortLivedConstructor.ConstructParticle();  
}

void G4MParallelWorldProcess::ConstructProcess()
{
  if(wasActivated) { return; }
  wasActivated = true;

  // Add 
  G4ParallelWorldProcess* theParallelWorldProcess = 
    new G4ParallelWorldProcess(GetPhysicsName());
  theParallelWorldProcess->SetParallelWorld(fNamePW);
  if ( fLayered ) theParallelWorldProcess->SetLayeredMaterialFlag();

  theParticleIterator->reset();

  while( (*theParticleIterator)() ){
    G4ProcessManager* pmanager = theParticleIterator->value()->GetProcessManager();
    pmanager->AddProcess(theParallelWorldProcess);
    if ( theParallelWorldProcess->IsAtRestRequired(theParticleIterator->value())){
      //pmanager->SetProcessOrderingToLast(theParallelWorldProcess,idxAtRest);
      pmanager->SetProcessOrdering(theParallelWorldProcess,idxAtRest,ordLast);
    }
    pmanager->SetProcessOrdering(theParallelWorldProcess,idxAlongStep,1);
    //pmanager->SetProcessOrderingToLast(theParallelWorldProcess,idxPostStep);
    pmanager->SetProcessOrdering(theParallelWorldProcess,idxPostStep,ordLast);
  }
}
