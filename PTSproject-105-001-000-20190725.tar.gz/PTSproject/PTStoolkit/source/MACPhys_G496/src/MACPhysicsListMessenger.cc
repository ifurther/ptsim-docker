// ----------------------------------------------------------------------------
//
//
//
//    MACPhysicsListMessenger
//
//  (Description)
//    Register PhysicsList
//
//    28, OCT, 2005 T.ASO 
//    21. AUG. 2006 T.ASO  Added command for energy fluctuation of proton.
//                         Added command for step limitation for region.
//    2013-03-27 T.Aso Add commands for processes in parallel world geometries.
//    2014-04-09 T.Aso Add Merge commands for parallel world bwt. G496 and G410.
//
// ----------------------------------------------------------------------------
#include "MACPhysicsListMessenger.hh"
#include "MACPhysicsList.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcommand.hh"

MACPhysicsListMessenger::MACPhysicsListMessenger(MACPhysicsList * physList)
:physicsList(physList)
{  
 listDir = new G4UIdirectory("/My/physics/");

  // Building modular PhysicsList

 physicsListCmd = new G4UIcmdWithAString("/My/physics/register",this);  
 physicsListCmd->SetGuidance("Register process of PhysicsList.");
 physicsListCmd->SetParameterName("processList",false);
 physicsListCmd->AvailableForStates(G4State_PreInit);

 G4UIparameter* param = 0; 
 stepCmd = new G4UIcommand("/My/physics/stepLimitForRegion",this);  
 stepCmd->SetGuidance("Set Step Limit for a region");
 param = new G4UIparameter("Region",'s',false);
 stepCmd->SetParameter(param);
 param = new G4UIparameter("step",'d',false);
 param->SetParameterRange("step > 0.0");
 stepCmd->SetParameter(param);
 param = new G4UIparameter("Unit",'s',true);
 param->SetDefaultValue("mm");
 param->SetParameterCandidates(stepCmd->UnitsList(stepCmd->CategoryOf("mm")));
 stepCmd->SetParameter(param);
 stepCmd->AvailableForStates(G4State_Idle);

 pWorldProcCmd = new G4UIcommand("/My/physics/pwProcess",this);
 pWorldProcCmd->SetGuidance("ParallelWorldProcess"); 
 param->SetGuidance("True: Layered material,  False: materials are ingored");
 param = new G4UIparameter("ProcessName",'s',false);
 pWorldProcCmd->SetParameter(param);
 param = new G4UIparameter("layered",'b',false);
 pWorldProcCmd->SetParameter(param);
 param = new G4UIparameter("pwName",'s',true);
 param->SetDefaultValue("none");
 pWorldProcCmd->SetParameter(param);
 param = new G4UIparameter("Verbose",'d',true);
 param->SetDefaultValue("0");
 pWorldProcCmd->SetParameter(param);
 pWorldProcCmd->AvailableForStates(G4State_PreInit);

 pWorldScProcCmd= new G4UIcommand("/My/physics/pwScoringProcess",this);
 pWorldScProcCmd->SetGuidance("ParallelWorldScoringProcess");
 param = new G4UIparameter("ProcessName",'s',false);
 pWorldScProcCmd->SetParameter(param);
 param = new G4UIparameter("pwName",'s',false);
 pWorldScProcCmd->SetParameter(param);
 param = new G4UIparameter("Verbose",'d',true);
 param->SetDefaultValue("0");
 pWorldScProcCmd->SetParameter(param);
 pWorldScProcCmd->AvailableForStates(G4State_PreInit);

}

MACPhysicsListMessenger::~MACPhysicsListMessenger()
{
  delete pWorldProcCmd;
  delete pWorldScProcCmd;
  delete physicsListCmd;
  delete stepCmd;
  delete listDir;
}

void MACPhysicsListMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{

 if (command == pWorldProcCmd){
   G4String s[4];
   G4String nameProc;
   G4bool layered;
   G4String namePW;
   G4int verbose;
   std::istringstream is(newValue);
   //G4cout << newValue << G4endl;
   is >> s[0] >> s[1] >> s[2] >> s[3];
   nameProc = s[0];
   layered  = pWorldProcCmd->ConvertToBool(s[1]);
   namePW   = s[2];
   verbose  = pWorldProcCmd->ConvertToInt(s[3]);
   //G4cout << nameProc<<","<<layered<<","<<namePW<<","<<verbose<<G4endl;
   if ( namePW == "none" ) namePW = nameProc;
   physicsList->RegisterParallelWorldModule(nameProc,layered, namePW,verbose );
 }else if ( command == pWorldScProcCmd ){
   G4String nameProc;
   G4String namePW;
   G4int verbose;
   std::istringstream is(newValue);
   is >> nameProc >> namePW >> verbose;
   physicsList->RegisterParallelWorldScoringModule(nameProc,namePW,verbose );
 }

 if (command == physicsListCmd)
    { physicsList->RegisterPhysicsModule(newValue);} 
 else if ( command == stepCmd ) { 
   std::istringstream is(newValue);
   char regName[50];
   G4double cVal;
   char uniName[10];
   is >> regName >> cVal >> uniName;
   G4String regN = regName;
   G4String uniN = uniName;
   physicsList->SetStepLimitForRegion(cVal*(stepCmd->ValueOf(uniN)),regN); 
 } 

}
