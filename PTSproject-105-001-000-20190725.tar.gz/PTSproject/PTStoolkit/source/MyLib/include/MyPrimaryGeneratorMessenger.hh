//
//
//    MyPrimaryGeneratorMessenger
//
//  (Description)
//     Messenger for MyPrimaryGenerator
//
//    03, FEB, 2007 T.ASO 
//
// ----------------------------------------------------------------------------

#ifndef MyPrimaryGeneratorMESSENGER_HH
#define MyPrimaryGeneratorMESSENGER_HH 1

#include "globals.hh"
#include "G4UImessenger.hh"

class MyPrimaryGeneratorAction;
class G4UIdirectory;
class G4UIcmdWithAString;

class MyPrimaryGeneratorMessenger: public G4UImessenger {

public:
  
  MyPrimaryGeneratorMessenger(MyPrimaryGeneratorAction* primaryAction);
  
  ~MyPrimaryGeneratorMessenger();
  
  void SetNewValue(G4UIcommand*, G4String);
  
private:
  
  MyPrimaryGeneratorAction* fPrimaryGeneratorAction;   
  G4UIdirectory* listDir;
  G4UIcmdWithAString* fSelectCmd;
};

#endif








