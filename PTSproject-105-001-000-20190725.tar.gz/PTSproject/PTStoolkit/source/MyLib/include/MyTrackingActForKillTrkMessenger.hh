//
//
//    MyTrackingActForKillTrkMessenger
//
//  (Description)
//     Messenger for MyTrackingActForKillTrk
//
//    03, FEB, 2006 T.ASO 
//
// ----------------------------------------------------------------------------

#ifndef MyTrackingActForKillTrkMESSENGER_HH
#define MyTrackingActForKillTrkMESSENGER_HH 1

#include "globals.hh"
#include "G4UImessenger.hh"

class MyTrackingActForKillTrk;
class G4UIdirectory;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWithABool;

class MyTrackingActForKillTrkMessenger: public G4UImessenger {

public:
  
  MyTrackingActForKillTrkMessenger(const G4String& name,
				   MyTrackingActForKillTrk* trackAction);
  
  ~MyTrackingActForKillTrkMessenger();
  
  void SetNewValue(G4UIcommand*, G4String);
  
private:
  
  MyTrackingActForKillTrk* fTrackAction;   
  G4UIdirectory* listDir;
  G4UIcmdWithADoubleAndUnit* fZUpStreamCmd;
  G4UIcmdWithABool* fKillNeutralCmd;
  G4UIcmdWithABool* fKillLeptonCmd;
  G4UIcmdWithABool* fKillSecondaryCmd;
};

#endif








