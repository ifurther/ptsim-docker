// $Id: MyEventActForIAEAWriter.hh,v 1.3 2006/11/20 10:24:08 aso Exp $
// $Name:  $
// ====================================================================
//   MyEventActForIAEAWriter.hh
//
//  2013-04-08 T.Aso Created.
// ====================================================================
#ifdef USEIAEAPHSP
//
#ifndef My_EVENT_ACT_IAEAWriter_H
#define My_EVENT_ACT_IAEAWriter_H

#include "globals.hh"
#include "G4MVEventActionConstructor.hh"

class G4Event;
// ====================================================================
//
// class definition
//
// ====================================================================
class G4Event;

class MyEventActForIAEAWriter : public G4MVEventActionConstructor {

public:
  MyEventActForIAEAWriter(const G4String& name ="EventActForIAEAWriter");
  ~MyEventActForIAEAWriter();

  void BeginOfEventAction(const G4Event* aevent);
  void EndOfEventAction(const G4Event* aevent);

};

#endif

#endif
