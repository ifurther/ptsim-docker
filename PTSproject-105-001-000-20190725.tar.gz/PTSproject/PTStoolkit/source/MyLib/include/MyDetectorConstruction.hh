// $Id: MyDetectorConstruction.hh,v 1.2 2006/11/20 02:12:41 aso Exp $
// $Name:  $
// ====================================================================
//   MyDetectorConstruction.hh
//
//                                         2005 Q
// ====================================================================
#ifndef MY_DETECTOR_CONSTRUCTION_H
#define MY_DETECTOR_CONSTRUCTION_H

#include "G4VUserDetectorConstruction.hh"
#include "MyDetectorConstructionMessenger.hh"
// ====================================================================
//
// class definition
//
// (HISTORY)
// 19-SEP-2006  T.Aso Introducing MaterialFileConstrction.
// 2013-03-27   T.Aso CreateParalleWorld() method.
// 2014-03-11   T.Aso fVerbose.
//
// ====================================================================
//class MyPTSGeometryBuilder;
class G4MVGeometryBuilder;
class G4MMaterialFileConstruction;

class MyDetectorConstruction : public G4VUserDetectorConstruction {

public:
   MyDetectorConstruction(G4MVGeometryBuilder* builder);
  ~MyDetectorConstruction();

  virtual G4VPhysicalVolume* Construct();

  void CreateParallelWorld(const G4String &pName);

  virtual void ConstructSDandField(); //Geant4_version10

  void List();

  void SetVerbose(G4int v ){ fVerbose = v; }

private:
  G4MMaterialFileConstruction* materialConstructor;
  G4MVGeometryBuilder* ptsBuilder;

  MyDetectorConstructionMessenger* fMessenger;

  G4int fVerbose;

};

#endif
