#ifndef MygMocrenManager_hh
#define MygMocrenManager_hh

#include "G4MgMocrenDataIO.hh"
#include "MygMocrenManagerMessenger.hh"

#include <vector>
#include "G4ThreeVector.hh"

class G4MDICOMData;
class G4TrajectoryContainer;

class MygMocrenManager {
protected:
  G4MgMocrenDataIO mocren;
  G4MDICOMData * dicomData;
  static std::vector<G4double *> tracks;
  static std::vector<G4double *> dose;
  static G4bool use;
  static G4String filename;

  static MygMocrenManagerMessenger * fMessenger;
public:
  MygMocrenManager();
  ~MygMocrenManager() {;}
  MygMocrenManager(G4MDICOMData * _dicomData);

  //
  void setHeader();
  void setNumberOfEvents(G4int _nevent);
  //
  void setModalityImage();
  //
  void setDoseDistribution();
  void addDose(G4int _x, G4int _y, G4int _z, G4double _dose);
  unsigned long getDoseDistLength();
  void getDoseDistribution(unsigned int* sdose, unsigned long len);
  //
  void setROI(); // 
  //
  void setTracks();
  void addTracks(G4TrajectoryContainer * & _trajCont,
                 int _maxNumTracks = 0);

  void setUse(G4bool _use);
  G4bool getUse();
  void setFileName(G4String filename);
  G4String& getFileName() { return filename; };
  void storeData(G4String filename);
  //void storeData();  //ASO 20171013 commented.
  void storeData(G4int rank=-1); // ASO 12-Oct-09

  void setDICOMData(G4MDICOMData * _dicomData);


private:
  void calcModalityImage();
  float ct2density(short _ct, std::vector<G4double *> & _map);
  short density2ct(G4double _density, std::vector<G4double *> & _map);
  G4bool isInRegion(G4ThreeVector & _pre, G4ThreeVector & _post,
                    G4ThreeVector _region[2]);
};

#endif
