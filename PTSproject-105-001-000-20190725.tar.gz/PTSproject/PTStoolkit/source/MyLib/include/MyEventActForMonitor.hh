// $Id: MyEventActForMonitor.hh,v 1.3 2006/11/20 10:24:08 aso Exp $
// $Name:  $
// ====================================================================
//   MyEventActForMonitor.hh
//
//  2013-04-08 T.Aso Created.
//  2014-03-18 T.Aso Bugfix: Remove definition of IAEAPHSP.
// ====================================================================
//
#ifndef My_EVENT_ACT_Monitor_H
#define My_EVENT_ACT_Monitor_H

#include "globals.hh"
#include "G4MVEventActionConstructor.hh"
#include "MyEventActForMonitorMessenger.hh"

class G4Event;
// ====================================================================
//
// class definition
//
// ====================================================================
class G4Event;

class MyEventActForMonitor : public G4MVEventActionConstructor {

public:
  MyEventActForMonitor(const G4String& name ="EventActForMonitor");
  ~MyEventActForMonitor();

  void BeginOfEventAction(const G4Event* aevent);
  void EndOfEventAction(const G4Event* aevent);

  void SetFileName(G4String& fname){ fFileName = fname; };
  void SetEventInterval(G4int nInterval){ fNevtIntval = nInterval; };

private:
  G4int    fNevtIntval;
  G4String fFileName;
  G4int    fNevToBeProcessed;

  MyEventActForMonitorMessenger* fMessenger;

};

#endif

