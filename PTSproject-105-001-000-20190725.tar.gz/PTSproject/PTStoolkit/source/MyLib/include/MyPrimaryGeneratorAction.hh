// $Id: MyPrimaryGeneratorAction.hh,v 1.2 2007/03/01 11:46:26 aso Exp $
// $Name:  $
// ====================================================================
//   MyPrimaryGeneratorAction.hh
//
//                                         2005 Q
//  1-Feb-2007 T.Aso  Introduce SetPrimaryGenerator() and Messenger.
//  2013-11-04 T.Aso  SetRank() for G4MPI.
//  2017-03-31 T.Aso  Remove SetRank() for G4MPI.
// ====================================================================
#ifndef MY_PRIMARY_GENERATOR_ACTION_H
#define MY_PRIMARY_GENERATOR_ACTION_H

#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4VPrimaryGenerator.hh"
#include "MyPrimaryGeneratorMessenger.hh"

// ====================================================================
//
// class definition
//
// ====================================================================
class MyPrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction {
private:
  // use G4 particle gun
  G4VPrimaryGenerator* fGenerator;
  MyPrimaryGeneratorMessenger* fMessenger;

public:
  MyPrimaryGeneratorAction();
  ~MyPrimaryGeneratorAction();

  G4VPrimaryGenerator* GetPrimaryGenerator() const;
  void  SetPrimaryGenerator(const G4String& name);

  virtual void GeneratePrimaries(G4Event* anEvent);

};

// ====================================================================
//   inline functions
// ====================================================================
inline G4VPrimaryGenerator* MyPrimaryGeneratorAction::GetPrimaryGenerator() const
{  return fGenerator; }

#endif
