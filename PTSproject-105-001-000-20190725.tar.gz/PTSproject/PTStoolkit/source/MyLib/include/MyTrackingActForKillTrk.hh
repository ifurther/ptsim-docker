//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: MyTrackingActForKillTrk.hh,v 1.1 2006/08/22 08:09:37 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) MyTrackingActForKillTrk
//
//  Assign a track information relevant to the process.
//  T.Aso
//
//  11-MAR-07  T.Aso suppress output for debug.
//  06-MAR-09  T.Aso Modify code for remving string operation.
//
//====================================================================


#ifndef MyTrackingActForKillTrk_h
#define MyTrackingActForKillTrk_h 1

#include "globals.hh"
#include "G4MVTrackingActionConstructor.hh"
#include "MyTrackingActForKillTrkMessenger.hh"

class MyTrackingActForKillTrk : public G4MVTrackingActionConstructor {

  public:
    MyTrackingActForKillTrk(const G4String& name="MyTrackingActForKillTrk");
    virtual ~MyTrackingActForKillTrk();
   
    virtual void PreUserTrackingAction(const G4Track*);
    virtual void PostUserTrackingAction(const G4Track*);

  public:
    void SetKillUpStream(const G4double z=DBL_MAX){ zKillUpStream = z;};
    void SetKillNeutral(const G4bool flag=true);
    void SetKillLepton(const G4bool flag=true);
    void SetKillSecondary(const G4bool flag=true);
    void ResetKill();

  private:
    G4double zKillUpStream;
    G4bool   bKillNeutral;
    G4bool   bKillLepton;
    G4bool   bKillSecondary;

    MyTrackingActForKillTrkMessenger* messenger;
};

inline 
void MyTrackingActForKillTrk::SetKillNeutral(const G4bool flag){
  bKillNeutral = flag;
}

inline
void MyTrackingActForKillTrk::SetKillLepton(const G4bool flag){ 
  bKillLepton = flag;
}
inline
void MyTrackingActForKillTrk::SetKillSecondary(const G4bool flag){
  bKillSecondary = flag;
}
inline
void  MyTrackingActForKillTrk::ResetKill(){
  bKillNeutral = false;
  bKillLepton = false;
  bKillSecondary = false;
}
#endif
