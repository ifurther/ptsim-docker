//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: MySteppingActForTrkInfo.hh,v 1.3 2007/02/13 09:38:45 aso Exp $
// GEANT4 tag $Name:  $
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//====================================================================
// (Class) MySteppingActForTrkInfo
//
//  Assign a track information relevant to the process.
//  T.Aso
//
//  07-JUL-07  T.Aso  cleanup 
//  06-MAR-09  T.Aso Modify code for remving string operation.
//
//====================================================================

#ifndef MySteppingActForTrkInfo_h
#define MySteppingActForTrkInfo_h 1

#include "globals.hh"
#include "G4MVSteppingActionConstructor.hh"

class G4ProcessTable;
class G4VProcess;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class MySteppingActForTrkInfo : public G4MVSteppingActionConstructor
{
  public:
    MySteppingActForTrkInfo(const G4String& name="MySteppingActForTrkInfo");
   ~MySteppingActForTrkInfo() {};

    void UserSteppingAction(const G4Step*);

  public:
    virtual void ProcessAssign();

  protected:
    G4bool SetQEDProcess(const G4String& particleName, 
			 const G4String& processName);
    G4bool SetElasticProcess(const G4String& particleName, 
			     const G4String& processName);
    G4bool SetInElasticProcess(const G4String& particleName, 
			       const G4String& processName);

  private:
    G4ProcessTable*  procTable;
    G4VProcess*      procMQED;
    G4VProcess*      procMElastic;
    G4VProcess*      procMInElastic;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
