//
//
//    MyEventActForMonitorMessenger
//
//  (Description)
//     Messenger for MyEventActForMonitor
//
//    2014-02-07 T.ASO 
//
// ----------------------------------------------------------------------------

#ifndef MyEventActForMonitorMESSENGER_HH
#define MyEventActForMonitorMESSENGER_HH 1

#include "globals.hh"
#include "G4UImessenger.hh"

class MyEventActForMonitor;
class G4UIdirectory;
class G4UIcommand;

class MyEventActForMonitorMessenger: public G4UImessenger {

public:
  
  MyEventActForMonitorMessenger(const G4String& name,
                                MyEventActForMonitor* evtAction);
  
  ~MyEventActForMonitorMessenger();
  
  void SetNewValue(G4UIcommand*, G4String);
  
private:
  
  MyEventActForMonitor* fEvtAction;   
  G4UIdirectory* listDir;
  G4UIcommand* fEvtMonCmd;
};

#endif








