//
//
//    MygMocrenManagerMessenger
//
//  (Description)
//     Messenger for MygMocrenManager
//
//    Feb 13, 2007  A. Kimura
//
// ----------------------------------------------------------------------------

#ifndef MygMocrenManagerMessenger_HH
#define MygMocrenManagerMessenger_HH 1

#include "globals.hh"
#include "G4UImessenger.hh"

class MygMocrenManager;
class G4UIdirectory;
class G4UIcmdWithABool;
class G4UIcmdWithAString;

class MygMocrenManagerMessenger : public G4UImessenger {

public:
  
  MygMocrenManagerMessenger(MygMocrenManager * _gmocren);
  
  ~MygMocrenManagerMessenger();
  
  void SetNewValue(G4UIcommand*, G4String);
  
private:
  
  MygMocrenManager * fgmocren;   

  // gMocren
  G4UIdirectory* fDirgMocren;
  G4UIcmdWithABool * fCmdgMocren;
  G4UIcmdWithAString * fCmdgMocrenFile;
};

#endif








