//
//
//    MyDetectorConstructionMessenger
//
//  (Description)
//     Messenger for MyDetectorConstruction
//
//  (History)
//  2013-03-27 T.Aso Created for introducing Parallel World Geometry.
//  2014-08-06 T.Aso Verbose command.
//  2016-05-18 T.Aso Add comments of dirs
// ----------------------------------------------------------------------------

#ifndef MyDetectorConstructionMessenger_HH
#define MyDetectorConstructionMessenger_HH 1

#include "globals.hh"
#include "G4UImessenger.hh"

class MyDetectorConstruction;
class G4UIdirectory;
class G4UIcmdWithAString;
class G4UIcmdWithAnInteger;
class G4UIcmdWithoutParameter;

class MyDetectorConstructionMessenger : public G4UImessenger {

public:
  
  MyDetectorConstructionMessenger(MyDetectorConstruction * det);
  
  ~MyDetectorConstructionMessenger();
  
  void SetNewValue(G4UIcommand*, G4String);
  
private:
  
  MyDetectorConstruction * fDetectorConstruction;   

  G4UIdirectory* fDir0;
  G4UIdirectory* fDir1;
  G4UIcmdWithAString * fCmdCreatePWorld;
  G4UIcmdWithoutParameter * fCmdList;
  G4UIcmdWithAnInteger * fCmdVerbose;
};

#endif








