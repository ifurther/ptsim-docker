// $Id: MyRunActForIAEAWriter.hh,v 1.2 2006/09/15 17:04:22 kimura Exp $
// $Name:  $
// ====================================================================
//   MyRunActForIAEAWriter.hh
//
//   Created T.ASO 2012-04-08 Created.
//
// ====================================================================
#ifdef USEIAEAPHSP
//
#ifndef My_RUN_ACT_IAEAWriter_H
#define My_RUN_ACT_IAEAWriter_H

#include "globals.hh"
#include "G4MVRunActionConstructor.hh"
// ====================================================================
//
// class definition
//
// ====================================================================
class G4Run;

class MyRunActForIAEAWriter : public G4MVRunActionConstructor {

public:
  MyRunActForIAEAWriter(const G4String& name="RunActionForIAEAWriter");
  ~MyRunActForIAEAWriter();
  
  virtual void BeginOfRunAction(const G4Run* arun);
  virtual void EndOfRunAction(const G4Run* arun);

private:
};

#endif

#endif
