// ----------------------------------------------------------------------------
//
//
//    MyDetectorConstructionMessenger
//
//  (Description)
//     Messenger for MyDetectorConstruction
//
//  (History)
//  2013-03-27 T.Aso Created for introducing Parallel World Geometry.
//  2014-08-06 T.Aso Verbose command.
//  2016-05-18 T.Aso Add comments of dirs
// ----------------------------------------------------------------------------
#include "MyDetectorConstructionMessenger.hh"
#include "MyDetectorConstruction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithoutParameter.hh"

MyDetectorConstructionMessenger::MyDetectorConstructionMessenger(MyDetectorConstruction * det)
  :fDetectorConstruction(det)
{  
    fDir0 = new G4UIdirectory("/My/");
    fDir0->SetGuidance("UI commands for My detectors and actions");

    fDir1 = new G4UIdirectory("/My/DetConstruction/");
    fDir1->SetGuidance("UI commands for MyDetectorConstruction Handling");

    fCmdCreatePWorld = new G4UIcmdWithAString("/My/DetConstruction/createPW",this);
    fCmdCreatePWorld->SetGuidance("Create Parallel World with name");
    fCmdCreatePWorld->SetParameterName("paraName",false);
    fCmdCreatePWorld->SetDefaultValue("paraWorld");
    fCmdCreatePWorld->AvailableForStates(G4State_PreInit);

    fCmdList = new G4UIcmdWithoutParameter("/My/DetConstruction/listPW",this);
    fCmdList->SetGuidance("List-up registerd name of world volumes");
    fCmdList->AvailableForStates(G4State_PreInit,G4State_Idle);

    fCmdVerbose = new G4UIcmdWithAnInteger("/My/DetConstruction/verbose",this);
    fCmdVerbose->SetGuidance("Set Verbose Level");
    fCmdVerbose->SetParameterName("verbose",false);
    fCmdVerbose->SetDefaultValue(0);
    fCmdVerbose->AvailableForStates(G4State_PreInit,G4State_Idle);
}

MyDetectorConstructionMessenger::~MyDetectorConstructionMessenger()
{
  delete fDir1;
  delete fDir0;
  delete fCmdCreatePWorld;
  delete fCmdList;
  delete fCmdVerbose;
}

void MyDetectorConstructionMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  if (command == fCmdCreatePWorld) { 
    fDetectorConstruction->CreateParallelWorld(newValue);
  }else if ( command == fCmdList ){
    fDetectorConstruction->List();
  }else if ( command == fCmdVerbose ){
    fDetectorConstruction->SetVerbose(fCmdVerbose->GetNewIntValue(newValue));
  }
}






