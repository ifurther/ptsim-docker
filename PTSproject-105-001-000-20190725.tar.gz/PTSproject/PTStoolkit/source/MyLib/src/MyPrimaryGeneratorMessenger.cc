// ----------------------------------------------------------------------------
//
//
//
//    MyPrimaryGeneratorMessenger
//
//  (Description)
//    PrimaryGenerator Messenger
//
//    03, FED, 2006 T.ASO 
//
// ----------------------------------------------------------------------------
#include "MyPrimaryGeneratorMessenger.hh"
#include "MyPrimaryGeneratorAction.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAString.hh"

MyPrimaryGeneratorMessenger::MyPrimaryGeneratorMessenger(MyPrimaryGeneratorAction* primaryAction)
:fPrimaryGeneratorAction(primaryAction)
{  
 listDir = new G4UIdirectory("/My/PrimaryGenerator/");

  // Building modular PrimaryGenerator

 fSelectCmd = new G4UIcmdWithAString("/My/PrimaryGenerator/select",this);  
 fSelectCmd->SetGuidance("Select primary generator");
 fSelectCmd->SetParameterName("Generator",false);
 fSelectCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

}

MyPrimaryGeneratorMessenger::~MyPrimaryGeneratorMessenger()
{
  delete fSelectCmd;
  delete listDir;
}

void MyPrimaryGeneratorMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
 if (command == fSelectCmd) { fPrimaryGeneratorAction->SetPrimaryGenerator(newValue);} 
}






