// ----------------------------------------------------------------------------
//
//
//
//    MyTrackingActForKillTrkMessenger
//
//  (Description)
//    RunAction Messenger
//
//    03, FED, 2006 T.ASO 
//
// ----------------------------------------------------------------------------
#include "MyTrackingActForKillTrkMessenger.hh"
#include "MyTrackingActForKillTrk.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithABool.hh"

MyTrackingActForKillTrkMessenger::
MyTrackingActForKillTrkMessenger(const G4String& name,
                                 MyTrackingActForKillTrk* trackAction)
:fTrackAction(trackAction)
{  
  const  G4String& myDir = "/My/"+name+"/";
 listDir = new G4UIdirectory(myDir);
 listDir->SetGuidance("Kill specified particles in Z");

 // Building modular RunAction
 const G4String killZUpStream = myDir+"killZUpStream";
 fZUpStreamCmd = 
   new G4UIcmdWithADoubleAndUnit(killZUpStream,this);
 fZUpStreamCmd->SetGuidance("Kill particles produced at upstream");
 fZUpStreamCmd->SetParameterName("killZUpStream",false);
 fZUpStreamCmd->SetDefaultUnit("mm");
 fZUpStreamCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

 const G4String killNeutral = myDir+"killNeutral";
 fKillNeutralCmd = new G4UIcmdWithABool(killNeutral,this);
 fKillNeutralCmd->SetGuidance("Kill Neutral secondary for faster simulation");
 fKillNeutralCmd->SetParameterName("killNeutral",false);
 fKillNeutralCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

 const G4String killLepton = myDir+"killLepton";
 fKillLeptonCmd = new G4UIcmdWithABool(killLepton,this);
 fKillLeptonCmd->SetGuidance("Kill Lepton secondary for faster simulation");
 fKillLeptonCmd->SetParameterName("killLepton",false);
 fKillLeptonCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

 const G4String killSecondary = myDir+"killSecondary";
 fKillSecondaryCmd = 
   new G4UIcmdWithABool(killSecondary,this);
 fKillSecondaryCmd->SetGuidance("Kill Secondary for faster simulation");
 fKillSecondaryCmd->SetParameterName("killSecondary",false);
 fKillSecondaryCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

}

MyTrackingActForKillTrkMessenger::~MyTrackingActForKillTrkMessenger()
{
  delete fZUpStreamCmd;
  delete fKillNeutralCmd;
  delete fKillLeptonCmd;
  delete fKillSecondaryCmd;
  delete listDir;
}

void MyTrackingActForKillTrkMessenger::
SetNewValue(G4UIcommand* command,G4String newValue)
{
  if (command == fZUpStreamCmd) { 
    fTrackAction->SetKillUpStream(fZUpStreamCmd->GetNewDoubleValue(newValue));
  }else if ( command == fKillSecondaryCmd  ){
    fTrackAction->
      SetKillSecondary(fKillSecondaryCmd->GetNewBoolValue(newValue));
  }else if ( command == fKillLeptonCmd  ){
    fTrackAction->
      SetKillLepton(fKillLeptonCmd->GetNewBoolValue(newValue));
  }else if ( command == fKillNeutralCmd ){
    fTrackAction->
      SetKillNeutral(fKillNeutralCmd->GetNewBoolValue(newValue));
  }
}






