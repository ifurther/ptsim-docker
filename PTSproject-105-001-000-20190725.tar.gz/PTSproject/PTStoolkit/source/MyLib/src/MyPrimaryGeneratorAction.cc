// $Id: MyPrimaryGeneratorAction.cc,v 1.7 2009/01/09 02:41:41 aso Exp $
// $Name:  $
// ====================================================================
//   MyPrimaryGeneratorAction.cc
//
//                                         2005 Q
//
//  (Modification)
//  06-OCT-06 T.ASO
//   particleGun has replaced with G4MBeamGun which can handle
//   beam spot size with Gaussian distribution. ( see hibmc.mac )
//  1-Feb-2007 T.Aso  Introduce SetPrimaryGenerator() and Messenger.
//  30-Nov-2007 T.Aso Introduce FileEvtInterface.
//  02-Apr-2009 T.Aso G4MFocusGunEdist 
//  02-JUL-2000 T.Aso G4MFanBeam for pCT.
//  01-Sep-2010 T.Aso G4ParticleGun for general use.
//  2013-04-08 T.Aso IAEA phase space. 
//  2013-11-04 T.Aso SetRank() for G4MPI.
//  2017-03-31 T.Aso Remove SetRank() for G4MPI.
//  2019-09-09 T.Aso SpotScan/LineScan (ScanModel)
// ====================================================================
#include "MyPrimaryGeneratorAction.hh"
#include "G4MBeamGun.hh"
#include "G4MFocusGun.hh"
#include "G4MFocusGunEdist.hh"
#include "G4MFanBeam.hh"
#include "G4MScanBeamManager.hh"
#include "G4MSpotScanModel.hh"
#include "G4MLineScanModel.hh"
#include "G4MFileEvtInterface.hh"
#include "G4GeneralParticleSource.hh"
#include "G4ParticleGun.hh"

#ifdef USEIAEAPHSP
#include "G4MIAEAphspReader.hh"
#endif
// ====================================================================
//
// class description
//
// ====================================================================

////////////////////////////////////////////////////
MyPrimaryGeneratorAction::MyPrimaryGeneratorAction()
////////////////////////////////////////////////////
{
  // Alternative 
  fGenerator= new G4MBeamGun;
  //fGenerator= new G4GeneralParticleSource;
  fMessenger = new MyPrimaryGeneratorMessenger(this);
}

/////////////////////////////////////////////////////
MyPrimaryGeneratorAction::~MyPrimaryGeneratorAction()
/////////////////////////////////////////////////////
{
  delete fGenerator;
  delete fMessenger;
}

void  MyPrimaryGeneratorAction::SetPrimaryGenerator(const G4String& name){

  if ( fGenerator  ) delete fGenerator;

  if ( G4MScanBeamManager::IsExist() ){
    G4MScanBeamManager* sb = G4MScanBeamManager::GetPointer();
    delete sb;
  }
  if ( name == "BeamGun" ) {
    fGenerator = new G4MBeamGun();
    G4cout << "++ G4MBeamGun " <<G4endl;
  }else if (name == "FocusGun" ){
    fGenerator = new G4MFocusGun();
    G4cout << "++ G4MFocusGun " <<G4endl;
  }else if (name == "FocusGunEdist" ){
    fGenerator = new G4MFocusGunEdist();
    G4cout << "++ G4MFocusGunEdist " <<G4endl;
  }else if (name == "FanBeam" ){
    fGenerator = new G4MFanBeam();
    G4cout << "++ G4MFanBeam " <<G4endl;
  }else if (name == "ScanBeam" || name == "SpotScanBeam" ){
    G4MScanBeamManager* scanbeam = G4MScanBeamManager::GetPointer();
    scanbeam->SetScanModel(new G4MSpotScanModel("SpotScan"));
    fGenerator = scanbeam->GetBeamGun();
    G4cout << "++ G4MScanBeam (SpotScan) " <<G4endl;
  }else if (name == "LineScanBeam" ){
    G4MScanBeamManager* scanbeam = G4MScanBeamManager::GetPointer();
    scanbeam->SetScanModel(new G4MLineScanModel("LineScan"));
    fGenerator = scanbeam->GetBeamGun();
    G4cout << "++ G4MScanBeam (LineScan)" <<G4endl;
  }else if (name == "GPS" ){
    fGenerator = new G4GeneralParticleSource;
    G4cout << "++ G4GeneralParticleSource " <<G4endl;
  }else if (name == "ParticleGun" ){
    fGenerator = new G4ParticleGun;
    G4cout << "++ G4ParticleGun " <<G4endl;
  }else if (name == "EvtGun" ){
    fGenerator = new G4MFileEvtInterface();
    G4cout << "++ G4MFileEvtInterface " <<G4endl;
#ifdef USEIAEAPHSP
  }else if (name == "IAEAphsp" ){
    fGenerator = new G4MIAEAphspReader();
    G4cout << "++ G4MIAEAphspReader " <<G4endl;
#endif
  }else {
    G4Exception("MyPrimaryGeneratorAction::No matching primary generator.",
                "MyPrimGenAct00",FatalException,name);
  }
}
//////////////////////////////////////////////////////////////////
void MyPrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
//////////////////////////////////////////////////////////////////
{
  fGenerator-> GeneratePrimaryVertex(anEvent);
}

