// ----------------------------------------------------------------------------
//
//
//    MygMocrenManagerMessenger
//
//  (Description)
//     Messenger for MygMocrenManager
//
//    Feb 13, 2007  A. Kimura
//
// ----------------------------------------------------------------------------
#include "MygMocrenManagerMessenger.hh"
#include "MygMocrenManager.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithAString.hh"

MygMocrenManagerMessenger::MygMocrenManagerMessenger(MygMocrenManager * _gmocren)
 : fgmocren(_gmocren)
{  
    fDirgMocren = new G4UIdirectory("/My/gMocren/");
    fDirgMocren->SetGuidance("UI commands for gMocren Data Handling");

    fCmdgMocren = new G4UIcmdWithABool("/My/gMocren/use",this);
    fCmdgMocren->SetGuidance("use or not gMocren data storing");
    fCmdgMocren->SetParameterName("gmocrenuse",false);
    fCmdgMocren->SetDefaultValue(true);
    fCmdgMocren->AvailableForStates(G4State_Idle);

    fCmdgMocrenFile = new G4UIcmdWithAString("/My/gMocren/file",this);
    fCmdgMocrenFile->SetGuidance("gMocren data file name");
    fCmdgMocrenFile->SetParameterName("gmocrenfile",false);
    fCmdgMocrenFile->SetDefaultValue("dose.gdd");
    fCmdgMocrenFile->AvailableForStates(G4State_Idle);


}

MygMocrenManagerMessenger::~MygMocrenManagerMessenger()
{
  delete fDirgMocren;
  delete fCmdgMocren;
  delete fCmdgMocrenFile;
}

void MygMocrenManagerMessenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  if (command == fCmdgMocren) { fgmocren->setUse(fCmdgMocren->GetNewBoolValue(newValue));} 
  if (command == fCmdgMocrenFile) { fgmocren->setFileName(newValue);} 

}






