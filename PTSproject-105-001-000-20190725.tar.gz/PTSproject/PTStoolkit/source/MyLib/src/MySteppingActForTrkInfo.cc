//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id: MySteppingActForTrkInfo.cc,v 1.5 2008/12/16 10:47:18 aso Exp $
// GEANT4 tag $Name:  $
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//====================================================================
// (Class) MySteppingActForTrkInfo
//
//  Assign a track information relevant to the process.
//  T.Aso
//
//  07-JUL-07  T.Aso  cleanup 
//  06-MAR-09  T.Aso Modify code for removing string operation.
// 2014-03-18 T.Aso Add process names which are changed in G4.10.0. 
//
//====================================================================

#include "MySteppingActForTrkInfo.hh"

#include "G4SteppingManager.hh"
#include "G4VProcess.hh"
#include "G4MTrackInformation.hh"

#include "G4ProcessTable.hh"
#include "G4VProcess.hh"


MySteppingActForTrkInfo::MySteppingActForTrkInfo(const G4String& name)
  :G4MVSteppingActionConstructor(name),
   procTable(0),procMQED(0),procMElastic(0),procMInElastic(0){
}


void MySteppingActForTrkInfo::UserSteppingAction(const G4Step* aStep)
{
    if(!procTable){
      ProcessAssign();
      G4cout << " procMQED "<< procMQED 
             << " procMElastic "<<procMElastic
             << " procMInElastic "<< procMInElastic <<G4endl;
    }

    G4Track* aTrack = aStep->GetTrack();

    if ( aTrack->GetParentID() == 0 ){
         const G4VProcess* process = 
           aStep->GetPostStepPoint()->GetProcessDefinedStep();
         G4MTrackInformation* info = 
           (G4MTrackInformation*)(aTrack->GetUserInformation());
         if (process) {
           //        if ( process->GetProcessType() == fElectromagnetic ){
           if ( process == procMQED ) {
             info->UpdateOriginalProcessType(fMQED);
           } else if ( process == procMElastic ) {
             info->UpdateOriginalProcessType(fMHadron_Elastic);
           } else if ( process == procMInElastic ) {
             info->UpdateOriginalProcessType(fMHadron_Inelastic);
           } 
         }else{
           if ( aStep->GetTotalEnergyDeposit() ){
             info->UpdateOriginalProcessType(fMQED);
           }
         }
         //G4cout << "proces type " << process->GetProcessType()<<G4endl;
         //G4cout << " Create proc " << info->GetOriginalProcessType() << G4endl;
    }
}


void MySteppingActForTrkInfo::ProcessAssign(){
  // For Proton
  if ( !SetQEDProcess("proton","hIoni") ){
    SetQEDProcess("proton","hLowEIoni");
  }
  if ( !SetElasticProcess("proton", "hElastic") ){
    if ( !SetElasticProcess("proton", "LElastic") ){
      SetElasticProcess("proton", "hadElastic");
    }
  }
  if ( !SetInElasticProcess("proton", "ProtonInelastic") ){
      SetInElasticProcess("proton", "protonInelastic");
  }
}

G4bool MySteppingActForTrkInfo::SetQEDProcess(const G4String& particleName, 
                                       const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    procMQED = procTable->FindProcess(processName,particleName);
    if( procMQED )  return true;
    return false;
}
G4bool MySteppingActForTrkInfo::SetElasticProcess(const G4String& particleName, 
                                           const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    procMElastic = procTable->FindProcess(processName,particleName);
    if( procMElastic )  return true;
     return false;
}
G4bool MySteppingActForTrkInfo::SetInElasticProcess(const G4String& particleName, 
                                             const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    procMInElastic = procTable->FindProcess(processName,particleName);
    if( procMInElastic ) return true;
    return false;
}
