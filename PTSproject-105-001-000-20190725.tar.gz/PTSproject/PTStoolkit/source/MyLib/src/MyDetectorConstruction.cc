// $Id: MyDetectorConstruction.cc,v 1.3 2007/03/01 07:55:29 aso Exp $
// $Name:  $
// ====================================================================
//   MyDetectorConstruction.cc
//
//                                         2005 Q
// ====================================================================
#include "MyDetectorConstruction.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MMaterialFileConstruction.hh"
#include "G4Material.hh"

#include "G4MParallelWorld.hh"
#include "G4StateManager.hh"
#include "G4ApplicationState.hh"
// ====================================================================
//
// class description
//
// (HISTORY)
// 19-SEP-2006  T.Aso Intriducing MaterialFileConstrction.
// 2013-03-27   T.Aso CreateParalleWorld() method.
// 2013-03-11   T.Aso fVerbose.
// 2015-07-26   T.Aso SDandField() for future use.
// ====================================================================


////////////////////////////////////////////////
MyDetectorConstruction::MyDetectorConstruction(G4MVGeometryBuilder* builder)
////////////////////////////////////////////////
{
  materialConstructor = new G4MMaterialFileConstruction;
  ptsBuilder= builder;

  fMessenger = new MyDetectorConstructionMessenger(this);

  fVerbose = 0;
}

/////////////////////////////////////////////////
MyDetectorConstruction::~MyDetectorConstruction()
/////////////////////////////////////////////////
{
  delete ptsBuilder;
  delete fMessenger;
}

///////////////////////////////////////////////////////
 G4VPhysicalVolume* MyDetectorConstruction::Construct()
///////////////////////////////////////////////////////
{
  if ( fVerbose > 0 ) {
    G4cout << *(G4Material::GetMaterialTable()) << G4endl;  
  }
  return ptsBuilder-> Build();
}

///////////////////////////////////////////////////////                         
void MyDetectorConstruction::ConstructSDandField()
///////////////////////////////////////////////////////                         
{
  // For Geant4 Version10
  ptsBuilder-> BuildSDandField();
}


///////////////////////////////////////////////////////
 void MyDetectorConstruction::CreateParallelWorld(const G4String &pName)
///////////////////////////////////////////////////////
{
  RegisterParallelWorld(new G4MParallelWorld(pName));
}

///////////////////////////////////////////////////////
void MyDetectorConstruction::List()
///////////////////////////////////////////////////////
{
  G4ApplicationState currentState
      = G4StateManager::GetStateManager()->GetCurrentState();
  G4cout << "======== MyDetectorConstructon =========="<<G4endl;
  G4int n = GetNumberOfParallelWorld();
  G4cout << " Registered Parallel Worlds are : "<< n<<G4endl;
    G4cout << " Name, PV-address, and PVname "<<G4endl;
  for ( G4int i = 0; i < n ; i++){
    G4MParallelWorld* para = dynamic_cast<G4MParallelWorld*>(GetParallelWorld(i));
    G4String name = para->GetName();

    if ( currentState == G4State_PreInit ) {
      G4cout << name << "\t" << G4endl;
    }else{
      G4VPhysicalVolume* p = para->GetPhysWorld();
      G4cout << name << "\t" << p << "\t" << p->GetName() << G4endl;
    }
  }
  G4cout << "========================================="<<G4endl;
}

