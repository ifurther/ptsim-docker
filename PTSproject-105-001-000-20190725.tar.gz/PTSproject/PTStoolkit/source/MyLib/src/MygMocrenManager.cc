//
// 2013-11-25 T.Aso file name of MPI was changed.
// 2014-06-05 T.Aso Disable by default, because of memory leak?.
// 2017-10-13 T.Aso StoreData() w/o a argument has been comment out.
//
#include "MygMocrenManager.hh"

#include "G4MDICOMData.hh"
#include "G4TrajectoryContainer.hh"
#include "G4Trajectory.hh"
#include "G4SystemOfUnits.hh"

#include <cmath>
#include <sstream>
std::vector<G4double *> MygMocrenManager::tracks;
std::vector<G4double *> MygMocrenManager::dose;
G4bool MygMocrenManager::use = false;
G4String MygMocrenManager::filename = "dose.gdd";
MygMocrenManagerMessenger * MygMocrenManager::fMessenger = 0;

const short gMocrenCTMIN = -1024;
const short gMocrenCTMAX =  2048;

MygMocrenManager::MygMocrenManager()
  : dicomData(0) {
  if(!fMessenger)
    fMessenger = new MygMocrenManagerMessenger(this);
}
MygMocrenManager::MygMocrenManager(G4MDICOMData * _dicomData) {
  if(!fMessenger)
    fMessenger = new MygMocrenManagerMessenger(this);
  dicomData = _dicomData;
}

void MygMocrenManager::setHeader() {

  mocren.setID();
  //mocren.setNumberOfEvents();

  float vspacing[3];
  vspacing[0] = dicomData->GetXPixelSPC();
  vspacing[1] = dicomData->GetYPixelSPC();
  vspacing[2] = dicomData->GetZPixelSPC();
  mocren.setVoxelSpacing(vspacing);

}
void MygMocrenManager::setNumberOfEvents(G4int _nevent) {
  mocren.setNumberOfEvents(_nevent);
}
void MygMocrenManager::setModalityImage() {

  // voxel size
  int size[3];
  size[0] = dicomData->GetRow();
  size[1] = dicomData->GetColumn();
  size[2] = dicomData->GetSlice();
  mocren.setModalityImageSize(size);

  calcModalityImage();

  float vspacing[3];
  mocren.getVoxelSpacing(vspacing);
  float center[3] = {0.,0.,0.};
  // DICOM images have been rotated by 90 deg. around X axis
  //center[0] = dicomData->GetXdisplace() + vspacing[0]*(size[0]/2.+0.5);
  //center[1] = dicomData->GetYdisplace() + vspacing[1]*(size[1]/2.+0.5);
  center[2] = - dicomData->GetZdisplace();
  mocren.setModalityCenterPosition(center);

}
void MygMocrenManager::setDoseDistribution() {

  // Retrieve size of the calculated dose region
  int size[3];
  if(dose.size() != 0) {
    size[0] = dicomData->GetRow();
    size[1] = dicomData->GetColumn();
    size[2] = dicomData->GetSlice();
    mocren.setDoseDistSize(size);
  }
    
  // Get values of the dose distribution
  double minmax[2] = {9e9, 0.};
  int dsize = size[0]*size[1];
  if(dose.size() != 0) {
    for(int z = 0; z < size[2]; z++) {
      double * ddose = new double[dsize];
      //G4cout << "++++++++++++++++ " << dose.size() << G4endl;
      for(int i = 0; i < dsize; i++) {
        ddose[i] = (dose[z])[i];
        if(ddose[i] < minmax[0]) minmax[0] = ddose[i];
        if(ddose[i] > minmax[1]) minmax[1] = ddose[i];
        //G4cout << ddose[i] << ", ";
      }
      mocren.setDoseDist(ddose);
      //G4cout << G4endl;
    }
  } else {
    for(int i = 0; i < 3; i++) size[i] = 0;
    mocren.setDoseDistSize(size);
  }

  // set max. & min. values
  if(dose.size() != 0)
    mocren.setDoseDistMinMax(minmax);

  // set scale
  //mocren.calcScale();

  // set center of the calculated dose region
  if(dose.size() != 0) {
    float vspacing[3];
    mocren.getVoxelSpacing(vspacing);
    float center[3] = {0.,0.,0.};
    // Dose dist. region have also been rotated by 90 deg. around X axis
    //center[0] = dicomData->GetXdisplace() + vspacing[0]*(size[0]/2.+0.5);
    //center[1] = dicomData->GetYdisplace() + vspacing[1]*(size[1]/2.+0.5);
    //center[2] = -dicomData->GetZdisplace();
    mocren.setDoseDistCenterPosition(center);
  }
  
}
//
void MygMocrenManager::addDose(G4int _x, G4int _y, G4int _z, G4double _dose) {

  int size[3];

  if((G4int)(dose.size()) == 0) {

    size[0] = dicomData->GetRow();
    size[1] = dicomData->GetColumn();
    size[2] = dicomData->GetSlice();

    mocren.newDoseDist();
    mocren.setDoseDistSize(size);

    int xysize = size[0]*size[1];
    for(int z = 0; z < size[2]; z++) {
      G4double * layer = new G4double[xysize];
      for(int xy = 0; xy < xysize; xy++) layer[xy] = 0.;
      dose.push_back(layer);
    }

    /*
    G4cout << ">>>>>>>>>>>>>>>> new dose map : "
           << size[0] << ", "
           << size[1] << ", "
           << size[2] << G4endl;
    */
  } else {
    mocren.getDoseDistSize(size);
  }


  /*
  G4cout << ">>>>>>>>>>>>>>>> addDose : "
         << _x << ", "
         << _y << ", "
         << _z << "("
         << _x + _y*size[0] << ") : "
         << _dose << G4endl;
  */
  if(_x >= size[0] || _y >= size[1] || _z >= size[2]) return;

  //G4cout << (dose[_z])[_x + _y*size[0]] << " : ";
  (dose[_z])[_x + _y*size[0]] += _dose;
  //G4cout << (dose[_z])[_x + _y*size[0]] << G4endl;
}
//
unsigned long MygMocrenManager::getDoseDistLength(){
  int size[3];
  mocren.getDoseDistSize(size);
  unsigned long length = size[0]*size[1]*size[2];
  return length;
}

void MygMocrenManager::getDoseDistribution(unsigned int* sdose, unsigned long len){
  int size[3];
  mocren.getDoseDistSize(size);
  unsigned long length = size[0]*size[1]*size[2];
  G4cout << " Dose length :"<<size[0]<<","<<size[1]<<","<<size[2]
         <<" len="<<length<<G4endl;
  if ( len != length ) {
    G4cout << "@@@@@ Error in MygMocrenManager::getDoseDistibution "<<G4endl;
    return;
  }
  short * sframe = new short[size[0]*size[1]];
  int npixels = size[0]*size[1];
  for (int z = 0; z < size[2]; z++ ){
    mocren.getShortDoseDist(sframe,z);
    int ioffset = npixels*z;
    for ( int i = 0; i < npixels; i++ ){
      sdose[ioffset + i] = sframe[i];
    }
  }
  return;
}
//
void MygMocrenManager::setROI() {
// this member function (::setROI) has been implemented completely.

  mocren.newROI();

  // Retrieve size of the RoI region
  int roiImageSize[3];
  //fin >> roiImageSize[0] >> roiImageSize[1] >> roiImageSize[2];
  mocren.setROISize(roiImageSize);
    
  // Get the max. & min. values
  short roiMinMax[2];
  double roiScale;
  //fin >> roiMinMax[0] >> roiMinMax[1] >> roiScale;
  mocren.setROIMinMax(roiMinMax);
  mocren.setROIScale(roiScale);

  // Get the RoI image
  int rsize = roiImageSize[0]*roiImageSize[1];
  for(int z = 0; z < roiImageSize[2]; z++) {
    short * roi = new short[rsize];
    //for(int i = 0; i < rsize; i++) fin >> roi[i];
    mocren.setROI(roi);
  }

  // Retrieve center of the RoI region
  float roiCenter[3];
  for(int i = 0; i < 3; i++) roiCenter[i] = 0.;
  mocren.setROICenterPosition(roiCenter);
}

void MygMocrenManager::setTracks() {

  // get number of tracks
  int ntracks = (int)tracks.size();

  // get begin and end points of tracks
  std::vector<float *> ftracks;
  for(int i = 0; i < ntracks; i++) {
    G4double * dtrkpoint = tracks[i];
    float * ftrkpoint = new float[6];
    for(int j = 0; j < 6; j++) {
      ftrkpoint[j] = dtrkpoint[j];
      //G4cout << ftrkpoint[j] << ", ";
    }
    //G4cout << G4endl;
    ftracks.push_back(ftrkpoint);
  }
  mocren.setTracks(ftracks);

}
void MygMocrenManager::addTracks(G4TrajectoryContainer * & _trajCont,
                                  int _maxNumTracks) {

  static int NTRACKS = 0;

  //G4cout << "MygMocrenManager::addTracks(): n_trajectories " << _trajCont->entries() << G4endl;

  //G4cout << "MygMocrenManager::addTracks(): NTRAKCS " << NTRACKS << G4endl;
  if(NTRACKS >= _maxNumTracks) return;
 
  G4int n_trajectories = 0;
  if(_trajCont) n_trajectories = _trajCont->entries();

  //G4cout << "MygMocrenManager::addTracks(): n_trajectories " << n_trajectories << G4endl;

  // calculate the displacement of tracks
  float mspacing[3];
  mocren.getVoxelSpacing(mspacing);
  G4int msize[3];
  mocren.getModalityImageSize(msize);
  float disp[3] = {0.,0.,0.};
  disp[0] = dicomData->GetXdisplace();
  disp[1] = dicomData->GetYdisplace();
//<<<<<<< MygMocrenManager.cc
//  disp[2] = dicomData->GetZdisplace()-msize[2]*mspacing[2]/2.;
  //for(int i = 0; i < 3; i++) disp[i] = -msize[i]*mspacing[i]/2. + mcenter[i];
//=======
  disp[2] = -msize[2]*mspacing[2]/2.;

//>>>>>>> 1.4
  G4ThreeVector displace(disp[0], disp[1], disp[2]);
  // calculate acceptable region (min., max.) for storing tracks
  float mcenter[3];
  mocren.getModalityCenterPosition(mcenter);
  G4ThreeVector region[2];
  region[0][0] = - msize[0]*mspacing[0];
  region[0][1] = - msize[1]*mspacing[1];
  region[0][2] = - msize[2]*mspacing[2];
  region[1][0] =   msize[0]*mspacing[0]*2;
  region[1][1] =   msize[1]*mspacing[1]*2;
  region[1][2] =   msize[2]*mspacing[2]*2;
  /*
  G4cout << "( "
         << region[0][0] << ", "
         << region[0][1] << ", "
         << region[0][2] << " ) - ( "
         << region[1][0] << ", "
         << region[1][1] << ", "
         << region[1][2] << " )" << G4endl;
  */
  /*
  // draw region
  G4double x0 = region[0].x(), y0 = region[0].y(), z0 = region[0].z(),
         x1 = region[1].x(), y1 = region[1].y(), z1 = region[1].z();
  G4double * rpath;
  rpath = new G4double[6];
  rpath[0] = x0; rpath[1] = y0; rpath[2] = z0;
  rpath[3] = x0; rpath[4] = y1; rpath[5] = z0;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x0; rpath[1] = y1; rpath[2] = z0;
  rpath[3] = x1; rpath[4] = y1; rpath[5] = z0;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x1; rpath[1] = y1; rpath[2] = z0;
  rpath[3] = x1; rpath[4] = y0; rpath[5] = z0;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x1; rpath[1] = y0; rpath[2] = z0;
  rpath[3] = x0; rpath[4] = y0; rpath[5] = z0;
  tracks.push_back(rpath);

  rpath = new G4double[6];
  rpath[0] = x0; rpath[1] = y0; rpath[2] = z0;
  rpath[3] = x0; rpath[4] = y0; rpath[5] = z1;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x0; rpath[1] = y1; rpath[2] = z0;
  rpath[3] = x0; rpath[4] = y1; rpath[5] = z1;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x1; rpath[1] = y1; rpath[2] = z0;
  rpath[3] = x1; rpath[4] = y1; rpath[5] = z1;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x1; rpath[1] = y0; rpath[2] = z0;
  rpath[3] = x1; rpath[4] = y0; rpath[5] = z1;
  tracks.push_back(rpath);

  rpath = new G4double[6];
  rpath[0] = x0; rpath[1] = y0; rpath[2] = z1;
  rpath[3] = x0; rpath[4] = y1; rpath[5] = z1;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x0; rpath[1] = y1; rpath[2] = z1;
  rpath[3] = x1; rpath[4] = y1; rpath[5] = z1;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x1; rpath[1] = y1; rpath[2] = z1;
  rpath[3] = x1; rpath[4] = y0; rpath[5] = z1;
  tracks.push_back(rpath);
  rpath = new G4double[6];
  rpath[0] = x1; rpath[1] = y0; rpath[2] = z1;
  rpath[3] = x0; rpath[4] = y0; rpath[5] = z1;
  tracks.push_back(rpath);
  */

  //
  for(int i = 0; i < n_trajectories && i < _maxNumTracks; i++) {

    G4bool added = false;

    G4Trajectory * trj = (G4Trajectory *)(*_trajCont)[i];
    int npoints = trj->GetPointEntries();

    //short itmp = trj->GetTrackID();
    //itmp = trj->GetParentID();
    //itmp = trj->GetPDGEncoding();

    G4TrajectoryPoint * preTrp, * postTrp;
    G4ThreeVector prePt, postPt, tmpPt;
    if(npoints != 0) {
      preTrp = (G4TrajectoryPoint *)trj->GetPoint(0);
      tmpPt = preTrp->GetPosition()/mm;
      prePt[0] = tmpPt[0];
      prePt[1] = tmpPt[2];
      prePt[2] = -tmpPt[1];
      prePt -= displace;
    }
    for(int np = 1; np < npoints; np++) {

      postTrp = (G4TrajectoryPoint *)trj->GetPoint(np);
      tmpPt = postTrp->GetPosition()/mm;
      postPt[0] = tmpPt[0];
      postPt[1] = tmpPt[2];
      postPt[2] = -tmpPt[1];
      postPt -= displace;

      G4float eps = 0.01;
      G4int n = 0;
      if(std::fabs(prePt[0] - postPt[0]) <= eps) n++;
      if(std::fabs(prePt[1] - postPt[1]) <= eps) n++;
      if(std::fabs(prePt[2] - postPt[2]) <= eps) n++;
      if(n > 1) continue;

      G4double * path = new G4double[6];
      for(int p = 0; p < 3; p++) {
        path[p] = prePt[p];
        path[p+3] = postPt[p];
      }

      if(isInRegion(prePt, postPt, region)) {
        tracks.push_back(path);
        added = true;
      } else {
        delete [] path;
      }

      prePt = postPt;
    }

    if(added) {
      NTRACKS++;
      //G4cout << NTRACKS << G4endl;
      if(NTRACKS >= _maxNumTracks) return;
    }
  }
}

G4bool MygMocrenManager::isInRegion(G4ThreeVector & _pre,
                                    G4ThreeVector & _post,
                                    G4ThreeVector _region[2]) {

  if(_pre[0] >= _region[0][0] && _pre[0] <= _region[1][0] &&
     _pre[1] >= _region[0][1] && _pre[1] <= _region[1][1] &&
     _pre[2] >= _region[0][2] && _pre[2] <= _region[1][2])
    return true;

  if(_post[0] >= _region[0][0] && _post[0] <= _region[1][0] &&
     _post[1] >= _region[0][1] && _post[1] <= _region[1][1] &&
     _post[2] >= _region[0][2] && _post[2] <= _region[1][2])
    return true;

  return false;
}

void MygMocrenManager::setUse(G4bool _use) {
  G4cout << "MygMocrenManager::setUse() set " << _use << G4endl;
  use = _use;
}
G4bool MygMocrenManager::getUse() {
  return use;
}

void MygMocrenManager::setFileName(G4String _filename) {
  filename = _filename;
  //  mocren.setFileName(filename);
}


void MygMocrenManager::storeData(G4String _filename) {
  filename = _filename;
  mocren.setFileName(filename);

  mocren.storeData();
}

/* 20171013 Aso
void MygMocrenManager::storeData() {
  mocren.setFileName(filename);
  mocren.storeData();
}
*/

void MygMocrenManager::storeData(G4int rank) {
  G4String _filename;
  if ( rank > -1 ){
    //char str[3];
    //sprintf(str, "%03d", rank);
    //int pos = filename.find(".gdd");
    //_filename = filename.substr(0,pos)+"_";
    //_filename = _filename + str;
    //_filename = _filename + ".gdd";
    std::stringstream ss;
    ss << rank;
    _filename = filename+"_";
    _filename.append(ss.str());
  }else{
    _filename = filename;
  }
  G4cout << " gMocrenManager file:: " << filename <<G4endl;
  G4cout << " gMocrenManager:: " << _filename << " " << rank<<G4endl;
  mocren.setFileName(_filename);
  mocren.storeData();
}

void MygMocrenManager::calcModalityImage() {

  // get CT to density map
  std::vector<G4double *> ct2dens;
  int nct2dens = dicomData->GetNumCT2Densities();
  for(int i = 0; i < nct2dens; i++) {
    G4double * dens = new G4double[2];
    dicomData->GetCT2Densities(i, dens[0], dens[1]);
    ct2dens.push_back(dens);
  }

  // make map
  /*
  std::vector<G4double *> ct2densMap;
  int npt = dicomData->GetNumCT2Densities();
  for(int i = 0; i < npt; i++) {
    G4double * ctdens = new G4double[2];
    dicomData->GetCT2Densities(i, ctdens[0], ctdens[1]);
    ct2densMap.push_back(ctdens);
  }
  */
  std::vector<float> map;
  short mapmin = gMocrenCTMIN, mapmax = gMocrenCTMAX;
  for(int ct = mapmin; ct <= mapmax; ct++)
    map.push_back(ct2density(ct, ct2dens));//Map));
  mocren.setModalityImageDensityMap(map);

  // make image
  short minmax[2] = {32109, -32109};
  int size[3];
  mocren.getModalityImageSize(size);
  int xysize = size[0]*size[1];
  //
  std::vector<G4double> densities = dicomData->GetValues();
  std::vector<G4double>::iterator itr = densities.begin();
  for(int z = 0; z < size[2]; z++) {
    short * image = new short[xysize];
    for(int xy = 0; xy < xysize; xy++, itr++) {
      image[xy] = density2ct(*itr, ct2dens);//Map); 
      if(image[xy] < minmax[0]) minmax[0] = image[xy];
      if(image[xy] > minmax[1]) minmax[1] = image[xy];
    }
    mocren.setModalityImage(image);
  }

  // min. & max. values
  minmax[0] = gMocrenCTMIN;
  minmax[1] = gMocrenCTMAX;
  mocren.setModalityImageMinMax(minmax);

  // scale
  G4double scale = 1.;
  mocren.setModalityImageScale(scale);
}
//
float MygMocrenManager::ct2density(short _ct,
                                    std::vector<G4double *> & _map) {
  const int NPT = (int)_map.size();
  short * CT = new short[NPT];
  float * DENS = new float[NPT];
  for(int i = 0; i < NPT; i++) {
    CT[i] = (short)(_map[i])[0];
    DENS[i] = (_map[i])[1];
  }

  if(_ct <= CT[0]) return DENS[0]; //min.
  if(_ct >= CT[NPT-1]) return DENS[NPT-1]; //max.

  int x = 0;
  for(int i = 0; i < NPT - 1; i++)
    if (CT[i] <= _ct && CT[i+1] >= _ct) {
      x = i;
      break;
    }

  short a = _ct - CT[x];
  short b = CT[x+1] - _ct;
  float rvalue = (a*DENS[x+1] + b*DENS[x])/(a + b);

  delete [] CT;
  delete [] DENS;

  return rvalue;
}

short MygMocrenManager::density2ct(G4double _density,
                                    std::vector<G4double *> & _map) {

  const int NPT = (int)_map.size();
  short * CT = new short[NPT];
  float * DENS = new float [NPT];
  for(int i = 0; i < NPT; i++) {
    CT[i] = (short)(_map[i])[0];
    DENS[i] = (_map[i])[1];
  }

  if(_density <= DENS[0]) {
          if(CT[0] < gMocrenCTMIN) return gMocrenCTMIN;
          return CT[0]; //min.
  }
  if(_density >= DENS[NPT-1]) {
          if(CT[NPT-10] > gMocrenCTMAX) return gMocrenCTMAX;
          return CT[NPT-1]; //max.
  }

  int x = 0;
  for(int i = 0; i < NPT - 1; i++)
    if (DENS[i] <= _density && DENS[i+1] >= _density) {
      x = i;
      break;
    }

  double a = _density - DENS[x];
  double b = DENS[x+1] - _density;
  short rvalue = (short)((a*CT[x+1] + b*CT[x])/(a + b));

  delete [] CT;
  delete [] DENS;

  if(rvalue > gMocrenCTMAX) rvalue = gMocrenCTMAX;
  if(rvalue < gMocrenCTMIN) rvalue = gMocrenCTMIN;
  return rvalue;

}

void MygMocrenManager::setDICOMData(G4MDICOMData * _dicomData) {
  dicomData = _dicomData;
}
