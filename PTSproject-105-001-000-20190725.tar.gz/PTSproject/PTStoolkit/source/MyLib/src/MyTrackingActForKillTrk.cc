//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: MyTrackingActForKillTrack.cc,v 1.7 2007/07/05 08:10:24 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) MyTrackingActForKillTrack
//
//  Assign a track information relevant to the process.
//  T.Aso
//
//  11-MAR-07  T.Aso suppress output for debug.
//  06-MAR-09  T.Aso Modify code for remving string operation.
//
//====================================================================

#include "MyTrackingActForKillTrk.hh"
#include "G4TrackingManager.hh"
#include "G4Track.hh"
#include "G4MTrackInformation.hh"
#include "G4ProcessType.hh"
#include "G4MProcessType.hh"

#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"

#include "G4ProcessTable.hh"
#include "G4VProcess.hh"
#include "G4RegionStore.hh"

MyTrackingActForKillTrk::MyTrackingActForKillTrk(const G4String& name)
  :G4MVTrackingActionConstructor(name),
   zKillUpStream(DBL_MAX),
   bKillNeutral(false),bKillLepton(false),bKillSecondary(false)
{

  messenger = new MyTrackingActForKillTrkMessenger(name,this);
}

MyTrackingActForKillTrk::~MyTrackingActForKillTrk(){
  delete messenger;
}

void MyTrackingActForKillTrk::PreUserTrackingAction(const G4Track* aTrack)
{
  // If the track is primary particle.
  // Define TrackInformation here.
  // Otherwise, for secondary, Define at PostUserTrackingAction().
  //
  if(aTrack->GetPosition().z() > zKillUpStream ){
    G4bool kill = false;
    G4ParticleDefinition* pdef = aTrack->GetDefinition();
    if( bKillSecondary ){
      if (aTrack->GetParentID() != 0 ) kill = true;
    } else{
      if( bKillLepton ){
	if (pdef->GetLeptonNumber() != 0 ) kill = true;
      }
      if( bKillNeutral ){
	if (pdef->GetPDGCharge() == 0 ) kill = true;
      }
    }
    if ( kill ) ((G4Track*)aTrack)->SetTrackStatus(fKillTrackAndSecondaries);
  }
}

void MyTrackingActForKillTrk::PostUserTrackingAction(const G4Track*)
{
}


