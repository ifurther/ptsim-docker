// $Id: MyEventActForMonitor.cc,v 1.1 2009/03/17 09:37:54 aso Exp $
// $Name:  $
// ====================================================================
//   MyEventActForMonitor.cc
//
//  2014-02-07 T.ASO 
//  2014-03-18 T.Aso Bugfix: Remove definition of IAEAPHSP.
// ====================================================================
//
#include "MyEventActForMonitor.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include <fstream>

//////////////////////////////
MyEventActForMonitor::MyEventActForMonitor(const G4String& name)
  :G4MVEventActionConstructor(name),
   fNevtIntval(10),fFileName("nEvtMon.txt"),
   fNevToBeProcessed(0)
//////////////////////////////
{
  fMessenger = new MyEventActForMonitorMessenger(name,this);
}

///////////////////////////////
MyEventActForMonitor::~MyEventActForMonitor()
///////////////////////////////
{
  delete fMessenger;
}


/////////////////////////////////////////////////////////////
void MyEventActForMonitor::BeginOfEventAction(const G4Event* aEvent)
/////////////////////////////////////////////////////////////
{
  if( aEvent->GetEventID()==0 ){
    fNevToBeProcessed = 
      G4RunManager::GetRunManager()->GetNumberOfEventsToBeProcessed();
    std::ofstream ofs(fFileName);
    ofs << 0 << " " << fNevToBeProcessed << G4endl;
    ofs.close();
  }
}

///////////////////////////////////////////////////////////
void MyEventActForMonitor::EndOfEventAction(const G4Event* aEvent)
///////////////////////////////////////////////////////////
{
  G4int ev = aEvent->GetEventID()+1;
  if((ev == fNevToBeProcessed)||(fNevtIntval > 0 && ev%fNevtIntval==0)){
    std::ofstream ofs(fFileName);
    ofs << (aEvent->GetEventID()+1) << " "<< fNevToBeProcessed << G4endl;
    ofs.close();
  }

}
