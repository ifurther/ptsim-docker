// $Id: MyRunActForIAEAWriter.cc,v 1.3 2009/10/20 01:59:36 aso Exp $
// $Name:  $
// ====================================================================
//   MyRunActForIAEAWriter.cc
//
//  (HISTORY)
//  2013-04-08 T.Aso
//                              
// ====================================================================
#ifdef USEIAEAPHSP
//
#include "MyRunActForIAEAWriter.hh"
#include "G4MIAEAphspWriter.hh"

// ====================================================================
//
// class description
//
// ====================================================================

//////////////////////////
MyRunActForIAEAWriter::MyRunActForIAEAWriter(const G4String& name)
//////////////////////////
  :G4MVRunActionConstructor(name)
{
  G4MIAEAphspWriter::GetInstance();
}
///////////////////////////
MyRunActForIAEAWriter::~MyRunActForIAEAWriter()
///////////////////////////
{
  G4MIAEAphspWriter* iaeaWr = G4MIAEAphspWriter::GetInstanceIfExist();
  if (iaeaWr){
    delete iaeaWr;
  }
}


/////////////////////////////////////////////////////
void MyRunActForIAEAWriter::BeginOfRunAction(const G4Run* aRun )
/////////////////////////////////////////////////////
{
  G4MIAEAphspWriter* iaeaWr = G4MIAEAphspWriter::GetInstanceIfExist();
  if ( iaeaWr ) {
    iaeaWr->BeginOfRunAction(aRun);
  }
}

///////////////////////////////////////////////////
void MyRunActForIAEAWriter::EndOfRunAction(const G4Run* aRun)
///////////////////////////////////////////////////
{
  G4MIAEAphspWriter* iaeaWr = G4MIAEAphspWriter::GetInstanceIfExist();
  if ( iaeaWr ) {
    iaeaWr->EndOfRunAction(aRun);
  }
}

#endif
