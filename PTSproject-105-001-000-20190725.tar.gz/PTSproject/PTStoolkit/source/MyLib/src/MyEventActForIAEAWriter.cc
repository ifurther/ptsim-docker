// $Id: MyEventActForIAEAWriter.cc,v 1.1 2009/03/17 09:37:54 aso Exp $
// $Name:  $
// ====================================================================
//   MyEventActForIAEAWriter.cc
//
//  2013-04-08 T.ASO 
// ====================================================================
#ifdef USEIAEAPHSP
//
#include "MyEventActForIAEAWriter.hh"
#include "G4MIAEAphspWriter.hh"

//////////////////////////////
MyEventActForIAEAWriter::MyEventActForIAEAWriter(const G4String& name)
  :G4MVEventActionConstructor(name)
//////////////////////////////
{;}

///////////////////////////////
MyEventActForIAEAWriter::~MyEventActForIAEAWriter()
///////////////////////////////
{;}


/////////////////////////////////////////////////////////////
void MyEventActForIAEAWriter::BeginOfEventAction(const G4Event* aEvent)
/////////////////////////////////////////////////////////////
{
  G4MIAEAphspWriter* iaeaWr = G4MIAEAphspWriter::GetInstanceIfExist();
  if ( iaeaWr ) {
    iaeaWr->BeginOfEventAction(aEvent);
  }
}

///////////////////////////////////////////////////////////
void MyEventActForIAEAWriter::EndOfEventAction(const G4Event*)
///////////////////////////////////////////////////////////
{;}

#endif
