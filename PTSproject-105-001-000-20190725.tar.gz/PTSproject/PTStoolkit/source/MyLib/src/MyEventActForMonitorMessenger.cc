// ----------------------------------------------------------------------------
//
//
//
//    MyEventActForMonitorMessenger
//
//  (Description)
//    MyEventActForMonitor Messenger
//
//   2014-02-07 T.ASO 
//
// ----------------------------------------------------------------------------
#include "MyEventActForMonitorMessenger.hh"
#include "MyEventActForMonitor.hh"
#include "G4UIdirectory.hh"
#include "G4UIcommand.hh"

MyEventActForMonitorMessenger::
MyEventActForMonitorMessenger(const G4String& name,
                              MyEventActForMonitor* evtAction)
:fEvtAction(evtAction)
{  
  const  G4String& myDir = "/My/"+name+"/";
 listDir = new G4UIdirectory(myDir);
 listDir->SetGuidance("Create a file for monitoring current Event");

 // Building modular EventAction
 const G4String  cmdName= myDir+"eventMonitor";
 fEvtMonCmd = new G4UIcommand(cmdName,this);
 fEvtMonCmd->SetGuidance("Create a file for monitering cuurent Event");
 fEvtMonCmd->SetGuidance("Arguments: <nevent>  <filename> ");
 fEvtMonCmd->SetGuidance("<nevent>: Interval of number of event.");
 fEvtMonCmd->SetGuidance("<filename>: File name");
 G4UIparameter* param;
 param = new G4UIparameter("nevent",'i',false);
 fEvtMonCmd->SetParameter(param);
 param = new G4UIparameter("filename",'s',false);
 fEvtMonCmd->SetParameter(param);
} 

MyEventActForMonitorMessenger::~MyEventActForMonitorMessenger()
{
  delete fEvtMonCmd;
  delete listDir;
}

void MyEventActForMonitorMessenger::
SetNewValue(G4UIcommand* command,G4String newValue)
{
  if (command == fEvtMonCmd) { 
    G4int    nev;
    G4String fname;
    //
    const char* nv = (const char*)newValue;
    std::istringstream is(nv);
    is >> nev >> fname ;
    fEvtAction->SetFileName(fname);
    fEvtAction->SetEventInterval(nev);
  }
}






