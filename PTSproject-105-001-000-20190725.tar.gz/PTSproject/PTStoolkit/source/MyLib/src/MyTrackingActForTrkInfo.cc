//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: MyTrackingActForTrkInfo.cc,v 1.7 2007/07/05 08:10:24 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) MyTrackingActForTrkInfo
//
//  Assign a track information relevant to the process.
//  T.Aso
//
//  11-MAR-07  T.Aso suppress output for debug.
//  06-MAR-09  T.Aso Modify code for removing string operation.
//  2013-10-17 T.Aso Add the process identification for photons/ions.
// 2014-03-18 T.Aso Add process names which are changed in G4.10.0. 
//  2016-04-07 T.Aso Add a flag for the inheritence of trkinfo.
//====================================================================

#include "MyTrackingActForTrkInfo.hh"
#include "G4TrackingManager.hh"
#include "G4Track.hh"
#include "G4MTrackInformation.hh"
#include "G4ProcessType.hh"
#include "G4MProcessType.hh"

#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"

#include "G4ProcessTable.hh"
#include "G4VProcess.hh"
#include "G4RegionStore.hh"

MyTrackingActForTrkInfo::MyTrackingActForTrkInfo(const G4String& name)
  :G4MVTrackingActionConstructor(name),
   procTable(0),procMQED(0),procMElastic(0),procMInElastic(0),
   procMPhoto(0), procMCompt(0), procMPair(0),
   procMIonQED(0), procMIonStopping(0), 
   procMIonInElastic(0), procMRadioactiveDecay(0),
   regionROI(0),bInherit(true){
}

void MyTrackingActForTrkInfo::PreUserTrackingAction(const G4Track* aTrack)
{
  // If the track is primary particle.
  // Define TrackInformation here.
  // Otherwise, for secondary, Define at PostUserTrackingAction().
  //
  if(!procTable){
    ProcessAssign();
  }
  if(!regionROI ){
    G4RegionStore* regStore = G4RegionStore::GetInstance();
    regionROI = regStore->GetRegion("WaterPhantom",false);
    if (!regionROI) regionROI = regStore->GetRegion("DICOM",false);
  }
  if(aTrack->GetParentID()==0){ // Primary particle
      G4MTrackInformation* trackInfo = new G4MTrackInformation();
      trackInfo->SetOriginalProcessType(fMPrimary);
      G4Track*  theTrack = (G4Track*)aTrack;
      theTrack->SetUserInformation(trackInfo);
  }
}

void MyTrackingActForTrkInfo::PostUserTrackingAction(const G4Track* aTrack)
{
  G4TrackVector* secondaries = fpTrackingManager->GimmeSecondaries();
  if(secondaries)
  {
    G4MTrackInformation* info = 
        (G4MTrackInformation*)(aTrack->GetUserInformation());
    size_t nSeco = secondaries->size();
    if(nSeco>0)
    {
      for(size_t i=0;i<nSeco;i++)
      { 
        //
        // If This particle is not directry created from Primary particle,
        // let it copy the track information of parent's track information.
        //
        G4MTrackInformation* infoNew = 0;
        if ( bInherit ){
          infoNew = new G4MTrackInformation(info);
        }else{
          infoNew = new G4MTrackInformation();
        }
        infoNew->SetParentPID(aTrack->GetDefinition()->GetPDGEncoding());
        (*secondaries)[i]->SetUserInformation(infoNew);
        //
        // If This particle is directly created from Primary particle.
        // i.e The end of primary track.
        // Update the process in TrackInformation.
        //
        if (aTrack->GetParentID()==0) { 
            const G4VProcess* process = (*secondaries)[i]->GetCreatorProcess();
            //G4cout << " Process " << process->GetProcessName()<<G4endl;
            if (process ){
              //
              //  ( Default processType is not working.
              if ( process == procMQED ){
                  infoNew->SetOriginalProcessType(fMQED);
              }else if ( process == procMElastic ){
                infoNew->SetOriginalProcessType(fMHadron_Elastic);
              }else if ( process == procMInElastic ){
                infoNew->SetOriginalProcessType(fMHadron_Inelastic);
              }else if ( process == procMPhoto ){
                infoNew->SetOriginalProcessType(fMPhoto);
              }else if ( process == procMCompt ){
                infoNew->SetOriginalProcessType(fMCompt);
              }else if ( process == procMPair ){
                infoNew->SetOriginalProcessType(fMPair);
              }else if ( process == procMIonQED ){
                infoNew->SetOriginalProcessType(fMIonQED );
              }else if ( process == procMIonStopping ){
                infoNew->SetOriginalProcessType(fMIonStopping);
              }else if ( process == procMIonInElastic ){
                infoNew->SetOriginalProcessType(fMIon_Inelastic);
              }else if ( process == procMRadioactiveDecay ){
                infoNew->SetOriginalProcessType(fMRadioactiveDecay);
              } else {
                //G4cout << "MyTrackingActForTrkInfo Undefined process:" 
                //       <<process->GetProcessName() << G4endl;
                  infoNew->SetOriginalProcessType(fMUndefined);
              }
              // No Process ???
            } else { // 
              G4cerr << " This secondary does not have produced process info."
                     << G4endl;
                infoNew->SetOriginalProcessType(fMUndefined);
            }
            //infoNew->Print();
            G4Region* reg = 
              aTrack->GetVolume()->GetLogicalVolume()->GetRegion();
            if ( reg && reg == regionROI )
                infoNew->SetROI();
        }
      }
    }
  }
}

void MyTrackingActForTrkInfo::ProcessAssign(){
  // For Proton
  if ( !SetQEDProcess("proton","hIoni") ){
    SetQEDProcess("proton","hLowEIoni");
  }
  if ( !SetElasticProcess("proton", "hElastic") ){
    if ( !SetElasticProcess("proton", "LElastic") ){
      SetElasticProcess("proton", "hadElastic");
    }
  }
  if ( !SetInElasticProcess("proton", "ProtonInelastic")){
    SetInElasticProcess("proton", "protonInelastic");
  }
  //
  // For gamma
  if ( !procMPhoto ){
    procMPhoto = SetProcess("gamma","phot");
  }
  if ( !procMCompt ){
    procMCompt = SetProcess("gamma","compt");
  }
  if ( !procMPair ){
    procMPair = SetProcess("gamma","conv");
  }
  //
  // For GenericIon
  if ( !procMIonQED ){
    procMIonQED = SetProcess("GenericIon","ionIoni");
  }
  if ( !procMIonStopping ){
    procMIonStopping = SetProcess("GenericIon","nuclearStopping");
  }
  if ( !procMIonInElastic ){
    procMIonInElastic = SetProcess("GenericIon","ionInelastic");
  }
  if ( !procMRadioactiveDecay ){
    procMRadioactiveDecay = SetProcess("GenericIon","RadioactiveDecay");
  }
  
}

G4bool MyTrackingActForTrkInfo::SetQEDProcess(const G4String& particleName, 
                                       const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    procMQED = procTable->FindProcess(processName,particleName);
    if( procMQED )  return true;
    return false;
}

G4bool MyTrackingActForTrkInfo::SetElasticProcess(const G4String& particleName, 
                                           const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    procMElastic = procTable->FindProcess(processName,particleName);
    if( procMElastic )  return true;
     return false;
}

G4bool MyTrackingActForTrkInfo::SetInElasticProcess(const G4String& particleName, 
                                             const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    procMInElastic = procTable->FindProcess(processName,particleName);
    if( procMInElastic ) return true;
    return false;
}

G4VProcess* MyTrackingActForTrkInfo::SetProcess(const G4String& particleName, 
                                                const G4String& processName){
    procTable = G4ProcessTable::GetProcessTable();
    return procTable->FindProcess(processName,particleName);
}


