//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//====================================================================
// (Class) G4MDigiVolumeMerger
//
//  2016-03-11  T.Aso Created.
//
//====================================================================

#include <vector>
#include "G4DigiManager.hh"
#include "G4MDigiVolumeMerger.hh"
#include "G4MDigi.hh"

#include "G4MDICOMHit.hh"

#include "G4SystemOfUnits.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4SDManager.hh"
#include "G4DigiManager.hh"
#include "G4ios.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiVolumeMerger::G4MDigiVolumeMerger(const G4String& _name, 
                                         const G4String& _colname)
  :G4MVDigitizerConstructor(_name,_colname),
   Min_time(0.0), Max_time(DBL_MAX){
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiVolumeMerger::~G4MDigiVolumeMerger()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

void G4MDigiVolumeMerger::Digitize()
{
  // Hit
  G4SDManager* SDMan = G4SDManager::GetSDMpointer();
  if ( !SDMan->FindSensitiveDetector(fSrcSDName,false) ) return;
  //
  G4DigiManager* DigiMan = G4DigiManager::GetDMpointer();
  // Hits collection
  G4int HCID = DigiMan->GetHitsCollectionID(fSrcColName);
  //G4cout << " HCID "<<HCID<<G4endl;
  if ( HCID < 0 ) return;

  G4MDICOMHitsCollection* HC = 0;
  HC = (G4MDICOMHitsCollection*)(DigiMan->GetHitsCollection(HCID));

  //
  // Create the Digi Collection
  G4MDigitsCollection* DigitsCollection = 
    new G4MDigitsCollection(GetName(),GetCollectionName(0)); 
  StoreDigiCollection(DigitsCollection);

  std::map<G4String, G4MDigi*> keymap;
  G4MDigi* Digi=0;
  //
  if (HC){
    // Digitize HC to Digi
    for (G4int i=0;i<HC->entries();i++){
      G4double edep = (*HC)[i]->GetEnergyDeposit();
      if ( edep == 0. ) continue;
      G4int unitXID   = (*HC)[i]->GetUnitXID();
      G4int unitYID   = (*HC)[i]->GetUnitYID();
      G4int unitZID   = (*HC)[i]->GetUnitZID();
      G4int unitModID = (*HC)[i]->GetUnitModID();
      G4int unitSecID = (*HC)[i]->GetUnitSecID();
      //
      std::ostringstream ss;
      ss <<"S"<<unitSecID << "M" << unitModID
         << "X" << unitXID << "Y" << unitYID << "Z" << unitZID;
      G4String key = ss.str();

      std::map<G4String, G4MDigi*>::iterator p = keymap.find(key);
      if ( p == keymap.end()) {
        // New Entry
        Digi = new G4MDigi();
        Digi->SetUnitID(unitXID,unitYID,unitZID,unitModID,unitSecID);
        //
        keymap.insert(std::map<G4String, G4MDigi*>::value_type(key,Digi));
      }else{
        // Update
        Digi = p->second; 
      }
      // Fill
      Digi->AddEdep((*HC)[i]->GetEnergyDeposit());
      Digi->AddHit((*HC)[i]);
    }
    //
    // Sorting
   for (std::map<G4String, G4MDigi*>::iterator it = keymap.begin();
         it != keymap.end(); it++){
      if ( fVerbose ) {
        G4cout << (*it).first <<" nhit " << ((*it).second)->NHit() 
               << " major time "
               << ((*it).second)->GetMajorHit()->GetGlobalTime() <<G4endl;
      }
      ((*it).second)->ComputeSignal(Min_time, Max_time);
      DigitsCollection->insert((*it).second);
    }
  }
  //
  //G4cout << " VolumeMerger: " << DigitsCollection->entries() <<G4endl;
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
