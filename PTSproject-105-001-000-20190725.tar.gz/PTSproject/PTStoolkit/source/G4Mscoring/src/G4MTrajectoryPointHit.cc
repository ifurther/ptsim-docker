//
// ---------------------------------------------------------------
//
// G4MTrajectoryPointHit.cc
//
// ---------------------------------------------------------------
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------
#include "G4MTrajectoryPointHit.hh"

#include "G4UnitsTable.hh"

G4ThreadLocal G4Allocator<G4MTrajectoryPointHit> *aTrajectoryPointHitAllocator = 0;

G4MTrajectoryPointHit::G4MTrajectoryPointHit()
  :G4VHit(),fStepHit(0),fEdep(0),fStepL(0),fDefinedStepProcName("")
{
  fVoxelID[0] = fVoxelID[1] = fVoxelID[2] = -1;
  ///fSecTrkIDVec.clear();
}

G4MTrajectoryPointHit::G4MTrajectoryPointHit(G4ThreeVector pos, G4double ke, 
                                             G4ThreeVector mon, G4double time,
                                             G4int voxel[3],
                                             G4double edep, G4double stepL,
                                             G4double dose,
                                             G4String definedProcName)
  :G4VHit(),fEdep(edep), fStepL(stepL),fDose(dose),
   fDefinedStepProcName(definedProcName)
{
  fStepHit = new G4MStepHit(pos,ke,mon,time);
  fVoxelID[0] = voxel[0]; fVoxelID[1] = voxel[1]; fVoxelID[2] = voxel[2];
  ///fSecTrkIDVec.clear();
}

G4MTrajectoryPointHit::G4MTrajectoryPointHit(G4MStepHit* aStepHit, G4int voxel[3],
                                             G4double edep, G4double stepL,
                                             G4double dose,
                                             G4String definedProcName)
  :G4VHit(), fStepHit(aStepHit), fEdep(edep), fStepL(stepL),fDose(dose),
   fDefinedStepProcName(definedProcName)
{
  fVoxelID[0] = voxel[0]; fVoxelID[1] = voxel[1]; fVoxelID[2] = voxel[2];
  ///fSecTrkIDVec.clear();
}

G4MTrajectoryPointHit::G4MTrajectoryPointHit(const G4MTrajectoryPointHit &right)
  : G4VHit(),fStepHit(right.fStepHit),fEdep(right.fEdep),fStepL(right.fStepL),
    fDose(right.fDose),
    fDefinedStepProcName(right.fDefinedStepProcName)
    ///,fSecTrkIDVec(right.fSecTrkIDVec)
{
  fVoxelID[0] = right.fVoxelID[0];
  fVoxelID[1] = right.fVoxelID[1];
  fVoxelID[2] = right.fVoxelID[2];
}

G4MTrajectoryPointHit::~G4MTrajectoryPointHit()
{
  if ( fStepHit ) delete fStepHit;
  ///fSecTrkIDVec.clear();
}
