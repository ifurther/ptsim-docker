//========================================================================
//
// Created by A.Kimura
//
// (Modification)
// Dec.01 2005 T.Aso Add G4MProcessType for creator process for
//                   consistency with WaterPhantom.(But not filled)
//                     
// Dec.27 2005 S.Kameoka  Added a member variable 'time' and its getter/setter
//                        to store global time.
// May.24 2006 T.Aso      Add particle weight
// Sep.21 2010 T.Aso      Add Step length.
// 2012-06-07   T.Aso     retuen quantifier of GetCreatorProcessType() was modified.
// 2013-03-30   T.Aso     SystemOfUnits/PhysicalConstants.
// 2013-11-01  T.Aso      Add exitKinE to record the exit-kinetic-energy.
// 2015-06-10  T.Aso      G4Allocator for G410.
// 2015-12-14  T.Aso      Ke and time. GetByScId() for extending scoring.
// 2016-01-16  T.Aso      index number for unitModID, unitSecID, and == operator.
// 2016-01-21  T.Aso      Parent Track ID, pid
// 2016-04-07  T.Aso      Trigger bit.
// 2016-04-12  T.Aso      Trigger Position.
// 2018-04-22  T.Aso      CreatorProcessType, CreatorProcessSubType
//========================================================================
#include "G4MDICOMHit.hh"
#include "G4ios.hh"
#include "G4VVisManager.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"
#include "G4LogicalVolume.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#if G4VERSION_NUMBER >= 930

#include "G4AttDef.hh"
#include "G4AttValue.hh"
#include "G4UnitsTable.hh"
#include "G4UIcommand.hh"

std::map<G4String,G4AttDef> G4MDICOMHit::fAttDefs;

#endif

G4ThreadLocal G4Allocator<G4MDICOMHit>* G4MDICOMHitAllocator=0;

G4MDICOMHit::G4MDICOMHit()
  : G4VHit(),incidentKinE(0.), exitKinE(0.),trackID(-1),
    parentTrkID(-1), parentPID(0),
    unitXID(0), unitYID(0), unitZID(0), unitModID(0), unitSecID(0),
    EDeposit(0.),dose(0.),slength(0.),pType(fMUndefined),
    fG4CreatorProcessType(-1),fG4CreatorProcessSubType(-1)
{
  //
  trigBit.reset();
  StepPosVec.clear();
  StepDEVec.clear();
  StepMomVec.clear();
}

G4MDICOMHit::G4MDICOMHit(const G4MDICOMHit & right)
:G4VHit() {
  
  hitPoint = right.hitPoint;
  primVertex = right.primVertex;
  primMomentum = right.primMomentum;
  incidentKinE = right.incidentKinE;
  momentum = right.momentum;
  exitKinE = right.exitKinE;
  PID = right.PID;
  trackID = right.trackID;
  parentTrkID = right.parentTrkID;
  parentPID = right.parentPID;
  unitXID = right.unitXID;
  unitYID = right.unitYID;
  unitZID = right.unitZID;
  unitModID = right.unitModID;
  unitSecID = right.unitSecID;
  EDeposit = right.EDeposit;
  dose    = right.dose;
  slength    = right.slength;
  pType   = right.pType;
  trigBit = right.trigBit;
  //StepPosVec = right.StepPosVec;
  //StepDEVec = right.StepDEVec;

}

G4MDICOMHit::~G4MDICOMHit() {
  ;
}


const G4MDICOMHit& G4MDICOMHit::operator=(const G4MDICOMHit &right) {

  hitPoint = right.hitPoint;
  primVertex = right.primVertex;
  primMomentum = right.primMomentum;
  momentum = right.momentum;
  incidentKinE = right.incidentKinE;
  exitKinE = right.exitKinE;
  PID = right.PID;
  trackID = right.trackID;
  parentTrkID = right.parentTrkID;
  parentPID = right.parentPID;
  unitXID = right.unitXID;
  unitYID = right.unitYID;
  unitZID = right.unitZID;
  unitModID = right.unitModID;
  unitSecID = right.unitSecID;
  EDeposit = right.EDeposit;
  dose    = right.dose;
  slength   = right.slength;
  pType   = right.pType;
  trigBit = right.trigBit;
  //StepPosVec = right.StepPosVec;
  //StepDEVec = right.StepDEVec;

  return *this;
}

G4int G4MDICOMHit::operator==(const G4MDICOMHit &right) const {
  return 
    (  (unitXID==right.unitXID)
       &&(unitYID==right.unitYID)
       &&(unitZID==right.unitZID)
       &&(unitModID==right.unitModID)
       &&(unitSecID==right.unitSecID) );
}

void G4MDICOMHit::Draw(){
  ;
}

void G4MDICOMHit::Print() {
  ;
}

#if G4VERSION_NUMBER >= 930

const std::map<G4String,G4AttDef>* G4MDICOMHit::GetAttDefs() const
{
  // G4AttDefs have to have long life.  Use static member...
  if (fAttDefs.empty()) {
    fAttDefs["XID"] = G4AttDef("XID","X Cell ID","Physics","","G4int");
    fAttDefs["YID"] = G4AttDef("YID","Y Cell ID","Physics","","G4int");
    fAttDefs["ZID"] = G4AttDef("ZID","Z Cell ID","Physics","","G4int");
    fAttDefs["Dose"] = G4AttDef("Dose","dose deposition","Physics","","G4double");
    fAttDefs["EDeposit"] = G4AttDef("EEeposit","energy deposition","Physics","","G4double");
    fAttDefs["IncidentKineE"] = G4AttDef("IncidentKineE","Incident kinetic energy","Physics","","G4double");
  }
  return &fAttDefs;
}

#include "G4AttCheck.hh"

std::vector<G4AttValue>* G4MDICOMHit::CreateAttValues() const
{
  // Create expendable G4AttsValues for picking...
  std::vector<G4AttValue>* attValues = new std::vector<G4AttValue>;
  attValues->push_back
    (G4AttValue("XID",G4UIcommand::ConvertToString(unitXID),""));
  attValues->push_back
    (G4AttValue("YID",G4UIcommand::ConvertToString(unitYID),""));
  attValues->push_back
    (G4AttValue("ZID",G4UIcommand::ConvertToString(unitZID),""));
  attValues->push_back
    (G4AttValue("Dose",G4BestUnit(dose*gram,"Energy"),""));
  attValues->push_back
    (G4AttValue("EDeposit",G4BestUnit(EDeposit,"Energy"),""));
  attValues->push_back
    (G4AttValue("IncidentKineE",G4BestUnit(incidentKinE,"Energy"),""));
  //G4cout << "Checking...\n" << G4AttCheck(attValues, GetAttDefs());
  return attValues;
}

#endif

void G4MDICOMHit::SetHitPoint(const G4ThreeVector & _hitPoint) {
  hitPoint = _hitPoint;
}
const G4ThreeVector& G4MDICOMHit::GetHitPoint() const {
  return hitPoint;
}

void G4MDICOMHit::SetUnitPoint(const G4ThreeVector & _unitPoint) {
  unitPoint = _unitPoint;
}
const G4ThreeVector& G4MDICOMHit::GetUnitPoint() const {
  return unitPoint;
}

void G4MDICOMHit::SetPrimaryVertex(const G4ThreeVector & _primVertex) {
  primVertex = _primVertex;
}

const G4ThreeVector& G4MDICOMHit::GetPrimaryVertex() const {
  return primVertex;
}

const G4ThreeVector& G4MDICOMHit::GetPrimaryMomentum() const {
  return primMomentum;
}
void G4MDICOMHit::SetPrimaryMomentum(const G4ThreeVector & _primMomentum) {
  primMomentum = _primMomentum;
}

void G4MDICOMHit::SetMomentum(const G4ThreeVector & _momentum) {
  momentum = _momentum;
}
const G4ThreeVector& G4MDICOMHit::GetMomentum() const {
  return momentum;
}

void G4MDICOMHit::SetIncidentKinE(const G4double & _incidentKinE) {
  incidentKinE = _incidentKinE;
}
G4double G4MDICOMHit::GetIncidentKinE() const {
  return incidentKinE;
}

void G4MDICOMHit::SetExitKinE(const G4double & _exitKinE) {
  exitKinE = _exitKinE;
}
G4double G4MDICOMHit::GetExitKinE() const {
  return exitKinE;
}

void G4MDICOMHit::SetPID(const G4int & _PID) {
  PID = _PID;
}
G4int G4MDICOMHit::GetPID() const {
  return PID;
}

void G4MDICOMHit::SetTrackID(const G4int & _trackID) {
  trackID = _trackID;
}
G4int G4MDICOMHit::GetTrackID() const {
  return trackID;
}

void G4MDICOMHit::SetParentTrackID(const G4int & _parentTrkID) {
  parentTrkID = _parentTrkID;
}
G4int G4MDICOMHit::GetParentTrackID() const {
  return parentTrkID;
}

void G4MDICOMHit::SetParentPID(const G4int & _parentPID) {
  parentPID = _parentPID;
}
G4int G4MDICOMHit::GetParentPID() const {
  return parentPID;
}

void G4MDICOMHit::SetUnitID(const G4int & _unitXID,
                            const G4int & _unitYID,
                            const G4int & _unitZID) {
  unitXID = _unitXID;
  unitYID = _unitYID;
  unitZID = _unitZID;
}
void G4MDICOMHit::SetUnitXID(const G4int & _unitXID) {
  unitXID = _unitXID;
}
G4int G4MDICOMHit::GetUnitXID() const {
  return unitXID;
}
void G4MDICOMHit::SetUnitYID(const G4int & _unitYID) {
  unitYID = _unitYID;
}
G4int G4MDICOMHit::GetUnitYID() const {
  return unitYID;
}
void G4MDICOMHit::SetUnitZID(const G4int & _unitZID) {
  unitZID = _unitZID;
}
G4int G4MDICOMHit::GetUnitZID() const {
  return unitZID;
}

void G4MDICOMHit::SetEnergyDeposit(const G4double & _EDeposit) {
  EDeposit = _EDeposit;
}
G4double G4MDICOMHit::GetEnergyDeposit() const {
  return EDeposit;
}
void G4MDICOMHit::AddEnergyDeposit(const G4MDICOMHit & _aHit) {
  AddEnergyDeposit(_aHit.GetEnergyDeposit());
}
void G4MDICOMHit::AddEnergyDeposit(const G4double & _EDeposit) {
  EDeposit += _EDeposit;
}

void G4MDICOMHit::SetCreatorProcessType(const G4MProcessType type){
    pType = type;
}

G4MProcessType G4MDICOMHit::GetCreatorProcessType() const{
    return pType;
}

G4double G4MDICOMHit::GetByScId(G4int scid, const G4double unit, const G4int evno){
  switch  ( scid ){
  case EvnoScId:
    return evno;
  case TrkScId:
    return trackID/unit;
  case PidScId:
    return PID/unit;
  case EdepScId:
    return EDeposit/unit;
  case DoseScId:
    return dose/unit;
  case StepLScId:
    return slength/unit;
  case XidScId:
    return unitXID/unit;
  case YidScId:
    return unitYID/unit;
  case ZidScId:
    return unitZID/unit;
  case ModidScId:
    return unitModID/unit;
  case SecidScId:
    return unitSecID/unit;
  case WeigtScId:
    return weight/unit;
  case ProcScId:
    return (G4int)pType/unit;
  case KinEScId:
    return incidentKinE/unit;
  case XpointScId:
    return hitPoint.x()/unit;
  case YpointScId:
    return hitPoint.y()/unit;
  case ZpointScId:
    return hitPoint.z()/unit;
  case PxScId:
    return momentum.x()/unit;
  case PyScId:
    return momentum.y()/unit;
  case PzScId:
    return momentum.z()/unit;
  case TimeScId:
    return time/unit;
  case XvtxScId:
    return primVertex.x()/unit;
  case YvtxScId:
    return primVertex.y()/unit;
  case ZvtxScId:
    return primVertex.z()/unit;
    //  case ParentTrkScId:
    //    return parentTrkID/unit;
    //  case ParentPidScId:
    //    return parentPID/unit;
    //  case TrigbitScId:
    //    return ((G4int)trigBit.to_ulong());
  case TrigPosXScId:
    return trigPos.x()/unit;
  case TrigPosYScId:
    return trigPos.y()/unit;
  case TrigPosZScId:
    return trigPos.z()/unit;
  }
  return 0.0;
}

G4int G4MDICOMHit::GetByScIdI(G4int scid, G4int evno){
  switch  ( scid ){
  case EvnoScId:
    return evno;
  case TrkScId:
    return trackID;
  case PidScId:
    return PID;
  case XidScId:
    return unitXID;
  case YidScId:
    return unitYID;
  case ZidScId:
    return unitZID;
  case ModidScId:
    return unitModID;
  case SecidScId:
    return unitSecID;
  case ProcScId:
    return pType;
  case ParentTrkScId:
    return parentTrkID;
  case ParentPidScId:
    return parentPID;
  case TrigbitScId:
    return (G4int)trigBit.to_ulong();
  }
  return 0;
}

