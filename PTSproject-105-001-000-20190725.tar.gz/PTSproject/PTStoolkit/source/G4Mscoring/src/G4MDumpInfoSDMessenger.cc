//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
#include "G4MDumpInfoSDMessenger.hh"
#include "G4MDumpInfoSD.hh"

//=============================================================
//  class definition
//    Messenger for DumpInfoSD
//
//  Created by T.Aso 30-Nov-2007
//  2019-04-04 T.Aso  Command for file format. fmtCmd.
//
//
//=============================================================


G4MDumpInfoSDMessenger::G4MDumpInfoSDMessenger(G4MDumpInfoSD* sd)
  :fSD(sd) {

  fDir = new G4UIdirectory("/G4M/DumpInfo/");
  fDir->SetGuidance("UI commands for DumpInfoSD");

  //
  // DumpInfoSD
  //

  fopenCmd =new G4UIcmdWithAString("/G4M/DumpInfo/open",this);
  fopenCmd->SetGuidance("DumpInfoSD filename ");
  fopenCmd->SetParameterName("filename",false);
  fopenCmd->AvailableForStates(G4State_Init,G4State_Idle);


  fcloseCmd =new G4UIcmdWithoutParameter("/G4M/DumpInfo/close",this);
  fcloseCmd->SetGuidance("DumpInfoSD file close ");
  fcloseCmd->AvailableForStates(G4State_Init,G4State_Idle);

  fFmtCmd =new G4UIcmdWithAString("/G4M/DumpInfo/format",this);
  fFmtCmd->SetGuidance("DumpInfoSD file format ASCII or Binary ");
  fFmtCmd->SetParameterName("format",false);
  fFmtCmd->AvailableForStates(G4State_Init,G4State_Idle);

}

G4MDumpInfoSDMessenger::~G4MDumpInfoSDMessenger() {
  delete fDir;
  delete fopenCmd;
  delete fcloseCmd;
  delete fFmtCmd;
}

void G4MDumpInfoSDMessenger::SetNewValue(G4UIcommand* command, G4String newValue) {
 if ( command == fopenCmd){
     fSD->Open(newValue);
 }else if ( command == fcloseCmd ){
     fSD->Close();
 }else if ( command == fFmtCmd){
   if ( newValue == "ASCII" || newValue == "ascii" ){
     fSD->SetFileFormat(0);
   }else if ( newValue == "BINARY" || newValue == "binary" ){
     fSD->SetFileFormat(1);
   }else {
     G4cout << " Format is only available from ASCII or BINARY" <<G4endl;
   }
 }
}

G4String G4MDumpInfoSDMessenger::GetCurrentValue(G4UIcommand* command) {
  return G4String(fSD->GetFileName()+command->GetCommandName());
}
