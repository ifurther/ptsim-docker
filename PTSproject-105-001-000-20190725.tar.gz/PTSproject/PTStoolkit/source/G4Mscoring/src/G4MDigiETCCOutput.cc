//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//====================================================================
// (Class) G4MDigiETCCOutput
//
//  2017-12-25  T.Aso Created.
//
//====================================================================

#include <vector>
#include "G4DigiManager.hh"
#include "G4MDigiETCCOutput.hh"
#include "G4MDigiETCCGas.hh"
#include "G4MDigiETCCCrystal.hh"
#include "G4MDigiETCCSet.hh"

#include "G4MDICOMHit.hh"

#include "G4SystemOfUnits.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4SDManager.hh"
#include "G4DigiManager.hh"
#include "G4ios.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiETCCOutput::G4MDigiETCCOutput(const G4String& _name, 
                                     const G4String& _colname)
  :G4MVDigitizerConstructor(_name,_colname){
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiETCCOutput::~G4MDigiETCCOutput()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

void G4MDigiETCCOutput::Digitize()
{
  G4DigiManager* DigiMan = G4DigiManager::GetDMpointer();

  //
  // Digi (1)
  G4int DCID1 = DigiMan->GetDigiCollectionID(fSrcColName);
  G4cout << " Get DigiCollection name " << fSrcColName << " " <<DCID1<< G4endl;
  G4MDigiETCCSetCollection* DigiGasSetCollection = 0;
  if ( DCID1 >= 0 ) {
    DigiGasSetCollection = 
      (G4MDigiETCCSetCollection*)DigiMan->GetDigiCollection(DCID1);
  }else{
    return;
  }

  //
  // Digi (2)
  G4int DCID2 = DigiMan->GetDigiCollectionID(fSrcColName2);
  G4cout << " Get DigiCollection name " << GetCollectionName(0) << " " <<DCID2 << G4endl;
  G4MDigiETCCSetCollection* DigiCrylSetCollection = 0;
  if ( DCID2 >= 0 ) {
    DigiCrylSetCollection = 
      (G4MDigiETCCSetCollection*)DigiMan->GetDigiCollection(DCID2);
  }else{
    return;
  }
  //
  //
  //
  // (Out ) Digi
  G4int DCID = DigiMan->GetDigiCollectionID(GetCollectionName(0));
  G4cout << " ETCC GetDigiCollectionID " << GetCollectionName(0) 
         << " DCID "<< DCID <<G4endl;
  if ( DCID < 0 ) return;
  G4MDigiETCCSetCollection* DigiETCCSetCollection = 0;
  DigiETCCSetCollection = 
    (G4MDigiETCCSetCollection*)DigiMan->GetDigiCollection(DCID);
  if ( !DigiETCCSetCollection ){
    // Create the Digi Collection
    DigiETCCSetCollection =
      new G4MDigiETCCSetCollection(GetName(),GetCollectionName(0)); 
    DigiETCCSetCollection->insert(new G4MDigiETCCSet());
    StoreDigiCollection(DigiETCCSetCollection);
  }

  if ( !DigiGasSetCollection ) G4cout << " DigiGasSetCollection NULL " << G4endl;
  if ( !DigiCrylSetCollection ) G4cout << " DigiCrylSetCollection NULL " << G4endl;
  G4cout << " DigiGasSetCollection "<<  DigiGasSetCollection->GetSize() << G4endl;
  G4cout << " DigiCrylSetCollection "<<  DigiCrylSetCollection->GetSize() << G4endl;

  //====
  G4MDigiETCCSet* DigiGasSet =  (*DigiGasSetCollection)[0];
  G4MDigiETCCSet* DigiCrylSet = (*DigiCrylSetCollection)[0];
  //
  //G4MDigiETCCSet* DigiETCCSet = (*DigiETCCSetCollection)[0];
  //DigiETCCSet->SetDigiETCCGas(DigiGasSet->GetDigiETCCGas());
  //DigiETCCSet->SetDigiETCCCrystal(DigiCrylSet->GetDigiETCCCrystal());
  //====
  //
  //
  G4MDigiETCCSet* DigiETCCSet = DigiGasSet;
  G4int nGas = DigiETCCSet->NDigiETCCGas();
  G4cout << "ASO nGas" << nGas << G4endl;
  for ( G4int i = 0; i < nGas; i++){
    G4MDigiETCCGas* dgas = DigiETCCSet->GetDigiETCCGas(i);
    G4cout << i
           << " Parent VTX :" << dgas->GetParentVTX()  
           << " Parent Mon :" << dgas->GetParentMom()  
           << " Compt VTX :" << dgas->GetComptVTX() 
           << " Scat G Mom :" << dgas->GetScatGammaMom() 
           << " Rec E Mom :" << dgas->GetRecElecMom() 
           << G4endl;
  }
  //
  DigiETCCSet = DigiCrylSet;
  G4int nCrystal = DigiETCCSet->NDigiETCCCrystal();
  G4cout << "ASO nCrystal" << nCrystal << G4endl;
  for ( G4int i = 0; i < nCrystal; i++){
    G4MDigiETCCCrystal* dc = DigiETCCSet->GetDigiETCCCrystal(i);
    G4cout << i 
           << " IX :" << dc->GetXID()  
           << " IY   :" << dc->GetYID()  
           << " ISub :" << dc->GetSubID()  
           << " IMod :" << dc->GetModID()  
           << " Pos :" << dc->GetPosition()  
           << " Edep :" << dc->GetEdep()  
           << " Nsum :" << dc->GetNsum()
           << G4endl;
  }
  //

}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
