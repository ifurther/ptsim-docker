//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//====================================================================
// (Class) G4MDigiCoincidence
//
//  2016-03-11  T.Aso Created. 
//
//====================================================================

#include <vector>

#include "G4MDigiCoincidence.hh"
#include "G4MDigi.hh"
#include "G4MDigiSet.hh"

#include "G4SystemOfUnits.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4SDManager.hh"
#include "G4DigiManager.hh"
#include "G4ios.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiCoincidence::G4MDigiCoincidence(const G4String& _name, 
                                         const G4String& _colname)
  :G4MVDigitizerConstructor(_name,_colname),
   Win_time(DBL_MAX), Off_time(0.0), Win_energy(DBL_MAX),Off_energy(0.0){
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiCoincidence::~G4MDigiCoincidence()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

void G4MDigiCoincidence::Digitize()
{
  G4DigiManager* DigiMan = G4DigiManager::GetDMpointer();
  // Digi collection
  G4int DCID = DigiMan->GetDigiCollectionID(fSrcColName);
  //G4cout <<" DCID : Coin "<< DCID<<G4endl;
  if (DCID < 0 ) return;
  //
  G4MDigitsCollection* DC = 0;
  DC = (G4MDigitsCollection*)(DigiMan->GetDigiCollection(DCID));
  if ( !DC ) return;
  //
  // Create the Digi Collection
  G4MDigiSetCollection* DigiSetCollection = 
    new G4MDigiSetCollection(GetName(),GetCollectionName(0)); 
  StoreDigiCollection(DigiSetCollection);
  //
  // Time sorting.
  std::map<G4double, G4MDigi*> keymap;
  for ( G4int i = 0; i < DC->entries(); i++ ){
    G4MDigi* Digi  = (*DC)[i];
    if ( Digi->GetEdepSig() > Off_energy && 
         Digi->GetEdepSig() < (Off_energy+Win_energy)){
           G4double key  = Digi->GetTimeSig();
           keymap.insert(std::map<G4double, G4MDigi*>::value_type(key,Digi));
    }
  }
  std::vector<G4MDigi*> TSortDVec;
  for (std::map<G4double, G4MDigi*>::iterator it = keymap.begin();
       it != keymap.end(); it++){
    TSortDVec.push_back((*it).second);
  }
  //
  //
  //
  for ( G4int i = 0;  i < (G4int)TSortDVec.size(); i++){
    G4MDigi* digi0 = TSortDVec[i];
    G4double t0 = digi0->GetTimeSig();
    G4MDigiSet* DigiSet = 0;
    for ( G4int j = (i+1);  j < (G4int)TSortDVec.size(); j++){
      G4MDigi* digi1 = TSortDVec[j];
      G4double t1 = digi1->GetTimeSig();
      G4double dt = (t1-t0);
      // Coincide
      //G4cout << dt/ns << " off" <<Off_time/ns <<" tw "<<Win_time<<G4endl;
      //G4cout << digi0->GetUnitSecID()<<" "<<digi1->GetUnitSecID()<<G4endl;
      if ( digi0->GetUnitSecID() == digi1->GetUnitSecID() ) continue;
      if ( (digi0->GetUnitSecID() == 0 && digi1->GetUnitSecID() ==1 )
           || (digi0->GetUnitSecID() == 1 && digi1->GetUnitSecID() ==0 )
           ||(digi0->GetUnitSecID() == 2 && digi1->GetUnitSecID() ==3 )
           ||(digi0->GetUnitSecID() == 3 && digi1->GetUnitSecID() ==2 )
           ) {
        if ( dt > Off_time && dt < (Off_time+Win_time) ){
          // Create DigiSet
          if (!DigiSet)  {
            DigiSet = new G4MDigiSet(digi0);
            DigiSetCollection->insert(DigiSet);
          }
          // Attach coincide digi.
          DigiSet->AddDigi(digi1);
        }
      }
    }
  }
//
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
