//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
// 2017-12-25 T.Aso 
//
//========================================================================

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo.....
#include "G4MDigiETCCGas.hh"
#include "G4MDigi.hh"

G4ThreadLocal G4Allocator<G4MDigiETCCGas> *G4MDigiETCCGasAllocator = 0;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4MDigiETCCGas::G4MDigiETCCGas():G4VDigi(){
  elecTrjVec.clear();
  elecDEVec.clear();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4MDigiETCCGas::~G4MDigiETCCGas(){
  elecTrjVec.clear();
  elecDEVec.clear();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigiETCCGas::SetParent(G4int pid, const G4ThreeVector& vtx, 
                               const G4ThreeVector& mom){
  parentPID = pid; parentVTX = vtx; parentMom = mom;
}
void G4MDigiETCCGas::SetComptVTX(const G4ThreeVector& xyz){
  comptVTX = xyz;
}
void G4MDigiETCCGas::SetScatGammaMom(const G4ThreeVector& p){
  scatMom = p;
}
void G4MDigiETCCGas::SetScatGammaTrackID(G4int trackid){
  scatTrackID = trackid;
}
void G4MDigiETCCGas::SetRecElecMom(const G4ThreeVector& p){
  elecMom = p;
}
void G4MDigiETCCGas::AddRecElecTrajectory(const G4ThreeVector& xyz, 
                                         G4double de){
  elecTrjVec.push_back(xyz);
  elecDEVec.push_back(de);
}
void G4MDigiETCCGas::SetRecElecTrajectory(const std::vector<G4ThreeVector>& trjvec){
  elecTrjVec = trjvec;
}
void G4MDigiETCCGas::SetRecElecEdep(const std::vector<G4double>& devec){
  elecDEVec = devec;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigiETCCGas::Draw()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigiETCCGas::Print()
{;}
