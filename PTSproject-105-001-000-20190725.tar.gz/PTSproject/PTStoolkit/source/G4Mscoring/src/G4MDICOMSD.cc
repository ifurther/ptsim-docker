//========================================================================
//
//
// (Modification)
//  19 Dec. 2010 T.Aso Get collection ID by the full name.
// 2013-11-01  T.Aso      Add exitKinE to record the exit-kinetic-energy.
// 2015-12-14 T.Aso Add mon. and time.
//
//========================================================================
#include "G4MDICOMSD.hh"
#include "G4MDICOMHit.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4ParticleDefinition.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4ios.hh"
#include "G4SDManager.hh"
#include "G4VSolid.hh"

#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"

G4MDICOMSD::G4MDICOMSD(G4String name)
    :G4VSensitiveDetector(name),fDICOMFileName("DICOM.dat"),
   doseHCID(-1), SDName(name), doseHCollection(0),
   currentHit(0), track(0), currentPV(0),
   unitXID(0), unitYID(0), unitZID(0),
   preStepPoint(0), postStepPoint(0) {

  G4String HCName;
  collectionName.insert(HCName="dicomCollection");
}

G4MDICOMSD::~G4MDICOMSD() {
  ;
}

void G4MDICOMSD::Initialize(G4HCofThisEvent* HCE) {

  doseHCollection = new G4MDICOMHitsCollection(SDName, collectionName[0]); 
  if(doseHCID < 0){
    G4String colname = SDName+"/"+collectionName[0];
    //doseHCID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);
    doseHCID = G4SDManager::GetSDMpointer()->GetCollectionID(colname);
  }
  HCE->AddHitsCollection(doseHCID, doseHCollection);
  
  currentXID = currentYID = currentZID = -1;
  currentTrackID = -1;
}

void G4MDICOMSD::resetID() {

  currentXID = currentYID = currentZID = -1;
  currentTrackID = -1;
}


G4bool G4MDICOMSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  if(aStep == NULL) return true;

  getStepInfo(aStep);

  if(IsNewEntry()) createNewHit();
  else             updateHit();
  if(IsEndOfEntry()) resetID();

  return true;
}


void G4MDICOMSD::EndOfEvent(G4HCofThisEvent *) {
  ;
}

void G4MDICOMSD::clear() {
  ;
} 

void G4MDICOMSD::DrawAll() {
  ;
} 

void G4MDICOMSD::PrintAll() {
  ;
} 

G4bool G4MDICOMSD::IsNewEntry(){

  G4StepStatus preStatus = preStepPoint->GetStepStatus();
  if(preStatus == fGeomBoundary) { // Exactly new entry
    currentXID = unitXID;
    currentYID = unitYID;
    currentZID = unitZID;
    currentTrackID = trackID;
    //G4cout << "Geom Boundary " 
    //   << unitXID <<" "<< unitYID <<" "<<UnitZID<<G4endl;
    return true;

  } else if(unitXID == currentXID &&
            unitYID == currentYID &&
            unitZID == currentZID &&
            trackID == currentTrackID) {
    // G4cout << "Same track " 
    //     << unitXID <<" "<< unitYID <<" "<<UnitZID<<G4endl;
    return false;

  } else {
    currentXID = unitXID;
    currentYID = unitYID;
    currentZID = unitZID;
    currentTrackID = trackID;
    //    G4cout << "ID Difference " 
    //     << unitXID <<" "<< unitYID <<" "<<UnitZID<<G4endl;
    return true;

  }

}

G4bool G4MDICOMSD::IsEndOfEntry(){
  G4StepStatus postStatus = postStepPoint->GetStepStatus();  
  return (postStatus == fGeomBoundary);
}

void G4MDICOMSD::getStepInfo(G4Step * aStep) {
  preStepPoint = aStep->GetPreStepPoint();
  postStepPoint = aStep->GetPostStepPoint();
  hitPoint = preStepPoint->GetPosition();
  postPoint = postStepPoint->GetPosition();

  momentum = preStepPoint->GetMomentum();

  incidentKinE = preStepPoint->GetKineticEnergy();
  exitKinE     = postStepPoint->GetKineticEnergy();

  touchable = (G4TouchableHistory *)preStepPoint->GetTouchable();
  
  G4ThreeVector trans = touchable->GetVolume()->GetObjectTranslation();
  unitPoint.setX(trans.x());
  unitPoint.setY(trans.y());
  unitPoint.setZ(trans.z());

  //G4MDICOMConfiguration * config 
  //  = G4MDICOMManager::GetPointer()->Get("DICOM.dat");
  G4MDICOMConfiguration * config 
    = G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  G4MDICOMData * dicomData = config->GetDICOMData();
  unitXID = dicomData->GetXID(trans.x());
  unitYID = dicomData->GetYID(trans.y());
  unitZID = dicomData->GetZID(trans.z());

  track      = aStep->GetTrack();   
  PID        = track->GetDefinition()->GetPDGEncoding();
  trackID    = track->GetTrackID();
  primVertex = track->GetVertexPosition();
  EDeposit   = aStep->GetTotalEnergyDeposit();
  time       = preStepPoint->GetGlobalTime();
  currentPV  = preStepPoint->GetPhysicalVolume();
  weight     = preStepPoint->GetWeight();

  G4double volume  = aStep->GetPreStepPoint()->GetPhysicalVolume()
      ->GetLogicalVolume()->GetSolid()->GetCubicVolume();
  //G4double density = aStep->GetTrack()->GetMaterial()->GetDensity();
  G4double density = aStep->GetPreStepPoint()->GetMaterial()->GetDensity();
  dose       = EDeposit/(density*volume)*weight;

}


void G4MDICOMSD::createNewHit() {
#ifdef debug
  G4cout << " Create New Hit " 
         << " " << unitXID
         <<" "  << unitYID       
         <<" "  << unitZID <<G4endl;
  G4cout << " Create new Hit: unitPoint "
         << " " << unitPoint.x()/mm
         << " " << unitPoint.y()/mm
         << " " << unitPoint.z()/mm
         << G4endl;
  G4cout << " Create new Hit : EntryPoint"
         << " " << hitPoint.x()/mm
         << " " << hitPoint.y()/mm
         << " " << hitPoint.z()/mm
         << G4endl;
#endif

  currentHit = new G4MDICOMHit();
  currentHit->SetTrackID(trackID);
  currentHit->SetPID(PID);
  currentHit->SetUnitID(unitXID,unitYID,unitZID);
  currentHit->SetEntry(hitPoint);
  currentHit->SetExit(postPoint);
  currentHit->SetUnitPoint(unitPoint);
  currentHit->SetPrimaryVertex(primVertex);
  currentHit->SetMomentum(momentum);
  currentHit->SetIncidentKinE(incidentKinE);
  currentHit->SetExitKinE(exitKinE);
  currentHit->SetEnergyDeposit(EDeposit);  
  //currentHit->SetHitPoint(hitPoint);  
  currentHit->SetGlobalTime(time);  
  currentHit->SetWeight(weight);  
  currentHit->SetDose(dose);
  StoreHit(currentHit);
}        

void G4MDICOMSD::updateHit(){
#ifdef debug
  G4cout << " Update Hit : Point"
         << " " << postPoint.x()/mm
         << " " << postPoint.y()/mm
         << " " << postPoint.z()/mm
         << G4endl;
#endif
  currentHit->AddEnergyDeposit(EDeposit);
  currentHit->AddDose(dose);
  currentHit->SetExit(postPoint);
#ifdef debug
  G4cout << currentHit->GetEnergyDeposit()/keV << G4endl;
#endif  
} 

void G4MDICOMSD::StoreHit(G4MDICOMHit* hit){
  if (hit == 0 ) {
    G4cout << "G4MDICOMSD: hit to be stored is NULL !!" <<G4endl;
    return;
  }
  doseHCollection->insert( hit );
}
