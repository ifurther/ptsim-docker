//========================================================================
//
// Created by Kameoka based on G4MDICOMSD
//
// (Modification)
// Dec.01 2005 T.Aso Add G4MProcessType information for identify created
//                   process.
// Dec.25 2005 S.Kameoka: Modified to create a G4MDICOMHit object
//                        unique to the combination of voxelID and trackID.
// Dec.27 2005 S.Kameoka: Added member variables for charge and time.
// Aug.21 2006 T.Aso  Add member variable for particle weight.
// Jan.23 2008 T.Aso  Add member variable for dose.
// Sep.21 2010 T.Aso      Add Step length.
//  19 Dec. 2010 T.Aso Get collection ID by the full name.
// 2013-11-25 T.Aso Set ExitKinE.
// 2015-07-23 T.Aso fDepth
// 2015-12-14 T.Aso mon and time.
// 2016-01-15 T.Aso unitModID, unitSecID as a key.
// 2016-01-21 T.Aso parentTrkID,parentPID
// 2016-04-12 T.Aso Add trigger, trigger pos.
//========================================================================

#include "G4MWaterPhantomSD.hh"
#include "G4MDICOMHit.hh"
#include "G4VUserTrackInformation.hh"
#include "G4MTrackInformation.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4ParticleDefinition.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4ios.hh"
#include "G4SDManager.hh"
#include "G4VSolid.hh"

G4MWaterPhantomSD::G4MWaterPhantomSD(const G4String &name, 
                                     const G4String &colname)
  :G4VSensitiveDetector(name),
   doseHCID(-1), SDName(name), doseHCollection(0),
   currentHit(0), track(0), currentPV(0),
   unitXID(0), unitYID(0), unitZID(0),unitModID(0),unitSecID(0),
   preStepPoint(0), postStepPoint(0), bEdep(1) {

  G4String HCName;
  //collectionName.insert(HCName="WaterPhantomHitsCollection");
  collectionName.insert(HCName=colname);
  fDepth[0] = 1;
  fDepth[1] = 0;
  fDepth[2] = 2;
  fDepth[3] = 0;
  fDepth[4] = 0;
}

G4MWaterPhantomSD::~G4MWaterPhantomSD()
{
}

void G4MWaterPhantomSD::Initialize(G4HCofThisEvent* HCE) {

  doseHCollection = new G4MDICOMHitsCollection(SDName, collectionName[0]); 
  if(doseHCID < 0){
    G4String colname = SDName+"/"+collectionName[0];
    doseHCID = G4SDManager::GetSDMpointer()->GetCollectionID(colname);
  }
  HCE->AddHitsCollection(doseHCID, doseHCollection);
  
  hitmap.clear();
}

G4bool G4MWaterPhantomSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  if (! aStep) return true;
  if ( bEdep && aStep->GetTotalEnergyDeposit() == 0. ) return true;

  getStepInfo(aStep);

  if (IsNewEntry()) createNewHit();
  else              updateHit();
//   if (IsEndOfEntry()) resetID();

  return true;
}


void G4MWaterPhantomSD::EndOfEvent(G4HCofThisEvent *) {
  ;
}

void G4MWaterPhantomSD::clear() {
  ;
} 

void G4MWaterPhantomSD::DrawAll() {
  ;
} 

void G4MWaterPhantomSD::PrintAll() {
  ;
} 

G4bool G4MWaterPhantomSD::IsNewEntry()
{
  std::map<G4String, G4MDICOMHit *>::iterator p = hitmap.find(key);
  if (p == hitmap.end()) {
    return true;
  }
  currentHit = p->second;
  return false;
}

G4bool G4MWaterPhantomSD::IsEndOfEntry(){
  G4StepStatus postStatus = postStepPoint->GetStepStatus();  
  return (postStatus == fGeomBoundary);
}

void G4MWaterPhantomSD::getStepInfo(G4Step * aStep) {
  preStepPoint = aStep->GetPreStepPoint();
  postStepPoint = aStep->GetPostStepPoint();
  hitPoint = preStepPoint->GetPosition();
  postPoint = postStepPoint->GetPosition();

  momentum = postStepPoint->GetMomentum();
  incidentKinE = preStepPoint->GetKineticEnergy();

  trackInfo = aStep->GetTrack()->GetUserInformation();

  touchable = (G4TouchableHistory *)preStepPoint->GetTouchable();
  
//   G4ThreeVector trans = touchable->GetVolume()->GetObjectTranslation();
//   unitPoint.setX(trans.x());
//   unitPoint.setY(trans.y());
//   unitPoint.setZ(trans.z());

// 20150723 T.Aso 
//  unitPoint.set(touchable->GetVolume(1)->GetObjectTranslation().x(),
//                touchable->GetVolume(0)->GetObjectTranslation().y(),
//                touchable->GetVolume(2)->GetObjectTranslation().z());
//
//  unitXID = touchable->GetReplicaNumber(1);
//  unitYID = touchable->GetReplicaNumber(0);
//  unitZID = touchable->GetReplicaNumber(2);
//
// 20150723 T.Aso 
  unitPoint.set(touchable->GetVolume(fDepth[0])->GetObjectTranslation().x(),
                touchable->GetVolume(fDepth[1])->GetObjectTranslation().y(),
                touchable->GetVolume(fDepth[2])->GetObjectTranslation().z());
//
  unitXID = touchable->GetReplicaNumber(fDepth[0]);
  unitYID = touchable->GetReplicaNumber(fDepth[1]);
  unitZID = touchable->GetReplicaNumber(fDepth[2]);
  unitModID = touchable->GetReplicaNumber(fDepth[3]);
  unitSecID = touchable->GetReplicaNumber(fDepth[4]);

  track      = aStep->GetTrack();   
  PID        = track->GetDefinition()->GetPDGEncoding();
  theAtomicMass = track->GetDefinition()->GetAtomicMass();
  theAtomicNumber = track->GetDefinition()->GetAtomicNumber();
//   charge     = (G4int) (track->GetDefinition()->GetPDGCharge() /eplus);
  trackID    = track->GetTrackID();
  parentTrkID    = track->GetParentID();
  //G4cout << " parentTrkID " << parentTrkID <<G4endl;
  primVertex = track->GetVertexPosition();
  EDeposit   = aStep->GetTotalEnergyDeposit();
  time       = preStepPoint->GetGlobalTime();
  currentPV  = preStepPoint->GetPhysicalVolume();
  weight     = preStepPoint->GetWeight();

  G4double volume  = aStep->GetPreStepPoint()->GetPhysicalVolume()
      ->GetLogicalVolume()->GetSolid()->GetCubicVolume();
  G4double density = aStep->GetPreStepPoint()->GetMaterial()->GetDensity();
  dose       = EDeposit/(density*volume)*weight;

  stepL = aStep->GetStepLength();

  std::ostringstream ss;
  //ss << "X" << unitXID << "Y" << unitYID << "Z" << unitZID << "-" << trackID;
  ss << "X" << unitXID << "Y" << unitYID << "Z" << unitZID 
     << "-" << trackID
     << "M" << unitModID<<"S"<<unitSecID;
  key = ss.str();
}


void G4MWaterPhantomSD::createNewHit() {
#ifdef debug
  G4cout << " Create New Hit " 
         << " " << unitXID
         <<" "  << unitYID       
         <<" "  << unitZID <<G4endl;
  G4cout << " Create new Hit: unitPoint "
         << " " << unitPoint.x()/mm
         << " " << unitPoint.y()/mm
         << " " << unitPoint.z()/mm
         << G4endl;
  G4cout << " Create new Hit : EntryPoint"
         << " " << hitPoint.x()/mm
         << " " << hitPoint.y()/mm
         << " " << hitPoint.z()/mm
         << G4endl;
#endif
  currentHit = new G4MDICOMHit();
  currentHit->SetTrackID(trackID);
  currentHit->SetParentTrackID(parentTrkID);
  currentHit->SetPID(PID);
  currentHit->SetParentTrackID(parentTrkID);
  currentHit->SetAtomicNumber(theAtomicNumber);
  currentHit->SetAtomicMass(theAtomicMass);
  currentHit->SetGlobalTime(time);
  currentHit->SetUnitID(unitXID,unitYID,unitZID);
  currentHit->SetUnitModID(unitModID);
  currentHit->SetUnitSecID(unitSecID);
  currentHit->SetEntry(hitPoint);
  currentHit->SetExit(postPoint);
  currentHit->SetUnitPoint(unitPoint);
  currentHit->SetPrimaryVertex(primVertex);
  currentHit->SetMomentum(momentum);
  currentHit->SetIncidentKinE(incidentKinE);
  currentHit->SetEnergyDeposit(EDeposit);  
  //currentHit->SetHitPoint(hitPoint);  
  currentHit->SetWeight(weight);
  currentHit->SetDose(dose);
  currentHit->SetStepLength(stepL);
  StoreHit(currentHit);

  if ( trackInfo ) { 
    G4MTrackInformation* mTrackInfo= (G4MTrackInformation*)trackInfo;
    currentHit->SetParentPID(mTrackInfo->GetParentPID());
    currentHit->SetCreatorProcessType(mTrackInfo->GetOriginalProcessType());  
    currentHit->SetTrigBit(mTrackInfo->GetTriggerBit());  
    currentHit->SetTrigPos(mTrackInfo->GetTrgPosOut()); 

  }

  hitmap.insert(std::map<G4String, G4MDICOMHit *>::value_type(key, currentHit));
}        

void G4MWaterPhantomSD::updateHit(){
#ifdef debug
  G4cout << " Update Hit : Point"
         << " " << postPoint.x()/mm
         << " " << postPoint.y()/mm
         << " " << postPoint.z()/mm
         << G4endl;
#endif
  currentHit->AddEnergyDeposit(EDeposit);
  currentHit->AddDose(dose);
  currentHit->AddStepLength(stepL);
  currentHit->SetExitKinE(incidentKinE);
  currentHit->SetExit(postPoint);
#ifdef debug
  G4cout << currentHit->GetEnergyDeposit()/keV << G4endl;
#endif  
} 

void G4MWaterPhantomSD::StoreHit(G4MDICOMHit* hit){
  if (hit == 0) {
    G4cout << "G4MWaterPhantomSD: hit to be stored is NULL !!" <<G4endl;
    return;
  }
  doseHCollection->insert( hit );

}
