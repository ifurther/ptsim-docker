//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
#include "G4MTriggerSD.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4SDManager.hh"
#include "G4MTrackInformation.hh"
#include "G4LogicalVolume.hh"

//#include "G4MTriggerSDMessenger.hh"
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  2016-02-22
//  2017-03-15 T.Aso Threading.
//========================================================================

G4MTriggerSD::G4MTriggerSD(G4String name)
  :G4VSensitiveDetector(name) {
  fTrigMap.clear();
}

G4MTriggerSD::G4MTriggerSD(const G4MTriggerSD& right)
  :G4VSensitiveDetector(right.SensitiveDetectorName) {
  fTrigMap = right.fTrigMap;
}

G4MTriggerSD::~G4MTriggerSD() {
  fTrigMap.clear();
}

void G4MTriggerSD::Initialize(G4HCofThisEvent* ) {
}

G4bool G4MTriggerSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  G4Track* aTrack = aStep->GetTrack();
  G4MTrackInformation* info = 
    (G4MTrackInformation*)(aTrack->GetUserInformation());
  if ( !info ) return false;
  G4LogicalVolume* lv  = 
    aStep->GetPreStepPoint()->GetPhysicalVolume()->GetLogicalVolume();
  
  info->SetTriggerId(fTrigMap[lv]);
  info->SetTrgPosOut(aStep->GetPostStepPoint()->GetPosition());

  return true;
}


void G4MTriggerSD::EndOfEvent(G4HCofThisEvent *) {
}

void G4MTriggerSD::DrawAll() {
  ;
} 

void G4MTriggerSD::PrintAll() {
  ;
}

void G4MTriggerSD::SetTriggerId(G4LogicalVolume* log, G4int id){
  fTrigMap[log] = id;
}

void G4MTriggerSD::DumpTriggerId(std::ostream& out){
  for (std::map<G4LogicalVolume*,G4int>::iterator itr = fTrigMap.begin();
       itr != fTrigMap.end(); itr++){
    G4LogicalVolume* lv = itr->first;
    G4int trigid = itr->second;
    out << lv->GetName() << "¥t" << trigid <<G4endl;
  } 
}

