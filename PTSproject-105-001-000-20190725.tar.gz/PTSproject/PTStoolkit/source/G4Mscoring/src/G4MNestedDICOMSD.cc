//========================================================================
//
// Created by T.Aso Feb.27 2007  for sampling in Nested Paramerisation
//
// (Modification)
//   23-Jan-2008  T.Aso unitXID,unitYID,unitZID are obtained from touchable,
//                      in order to avoid mismatch of volume ID and 
//                      the material.
//   Sep.21 2010 T.Aso      Add Step length.
// 2013-11-25 T.Aso Add process type, incidentKinE
// 2016-03-11 T.Aso Add time, parenttrkid, parentpid                
// 2016-04-12 T.Aso Add trigger, trigger pos.
// 2016-07-14 T.Aso Add colname
// 2019-04-04 T.Aso Give full collection name for doseHCID.
//
//========================================================================
#include "G4MNestedDICOMSD.hh"
#include "G4MDICOMHit.hh"
#include "G4VUserTrackInformation.hh"
#include "G4MTrackInformation.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4ParticleDefinition.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4ios.hh"
#include "G4SDManager.hh"
#include "G4VSolid.hh"

#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"

G4MNestedDICOMSD::G4MNestedDICOMSD(const G4String& name,
                                   const G4String& colname)
    :G4VSensitiveDetector(name),fDICOMFileName("DICOM.dat"),
     doseHCID(-1), SDName(name), doseHCollection(0),
     currentHit(0), track(0), currentPV(0),
     unitXID(0), unitYID(0), unitZID(0),
     preStepPoint(0), postStepPoint(0) {

  collectionName.insert(colname);
}

G4MNestedDICOMSD::~G4MNestedDICOMSD() {
  ;
}

void G4MNestedDICOMSD::Initialize(G4HCofThisEvent* HCE) {

  doseHCollection = new G4MDICOMHitsCollection(SDName, collectionName[0]); 
  if(doseHCID < 0){
    G4String colname = SDName+"/"+collectionName[0];
    doseHCID = G4SDManager::GetSDMpointer()->GetCollectionID(colname);
  }
  HCE->AddHitsCollection(doseHCID, doseHCollection);
  
  currentXID = currentYID = currentZID = -1;
  currentTrackID = -1;
}

void G4MNestedDICOMSD::resetID() {

  currentXID = currentYID = currentZID = -1;
  currentTrackID = -1;
}


G4bool G4MNestedDICOMSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  if(aStep == NULL) return true;

  getStepInfo(aStep);

  if(IsNewEntry()) createNewHit();
  else             updateHit();
  if(IsEndOfEntry()) resetID();

  return true;
}


void G4MNestedDICOMSD::EndOfEvent(G4HCofThisEvent *) {
  ;
}

void G4MNestedDICOMSD::clear() {
  ;
} 

void G4MNestedDICOMSD::DrawAll() {
  ;
} 

void G4MNestedDICOMSD::PrintAll() {
  ;
} 

G4bool G4MNestedDICOMSD::IsNewEntry(){

  G4StepStatus preStatus = preStepPoint->GetStepStatus();
  if(preStatus == fGeomBoundary) { // Exactly new entry
    currentXID = unitXID;
    currentYID = unitYID;
    currentZID = unitZID;
    currentTrackID = trackID;
    //G4cout << "Geom Boundary " 
    //   << unitXID <<" "<< unitYID <<" "<<UnitZID<<G4endl;
    return true;

  } else if(unitXID == currentXID &&
            unitYID == currentYID &&
            unitZID == currentZID &&
            trackID == currentTrackID) {
    // G4cout << "Same track " 
    //     << unitXID <<" "<< unitYID <<" "<<UnitZID<<G4endl;
    return false;

  } else {
    currentXID = unitXID;
    currentYID = unitYID;
    currentZID = unitZID;
    currentTrackID = trackID;
    //    G4cout << "ID Difference " 
    //     << unitXID <<" "<< unitYID <<" "<<UnitZID<<G4endl;
    return true;

  }

}

G4bool G4MNestedDICOMSD::IsEndOfEntry(){
  G4StepStatus postStatus = postStepPoint->GetStepStatus();  
  return (postStatus == fGeomBoundary);
}

void G4MNestedDICOMSD::getStepInfo(G4Step * aStep) {
  preStepPoint = aStep->GetPreStepPoint();
  postStepPoint = aStep->GetPostStepPoint();
  hitPoint = preStepPoint->GetPosition();

  momentum = postStepPoint->GetMomentum();
  incidentKinE = preStepPoint->GetKineticEnergy();
  trackInfo = aStep->GetTrack()->GetUserInformation();

  touchable = (G4TouchableHistory *)preStepPoint->GetTouchable();

  G4ThreeVector org = touchable->GetVolume(3)->GetObjectTranslation();
  G4double transY   = touchable->GetVolume(0)->GetObjectTranslation().y()+org.y();
  G4double transX   = touchable->GetVolume(1)->GetObjectTranslation().x()+org.x();
  G4double transZ   = touchable->GetVolume(2)->GetObjectTranslation().z()+org.z();

  //const G4ThreeVector& posis = preStepPoint->GetPosition();
  G4ThreeVector trans(transX,transY,transZ);
  unitPoint.setX(trans.x());
  unitPoint.setY(trans.y());
  unitPoint.setZ(trans.z());

  //G4MDICOMConfiguration * config 
  //  = G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  //G4MDICOMData * dicomData = config->GetDICOMData();
  //unitXID = dicomData->GetXID(trans.x());
  //unitYID = dicomData->GetYID(trans.y());
  //unitZID = dicomData->GetZID(trans.z());
  unitXID = touchable->GetReplicaNumber(1);
  unitYID = touchable->GetReplicaNumber(0);
  unitZID = touchable->GetReplicaNumber(2);

  track      = aStep->GetTrack();   
  PID        = track->GetDefinition()->GetPDGEncoding();
  trackID    = track->GetTrackID();
  parentTrkID    = track->GetParentID();
  primVertex = track->GetVertexPosition();
  EDeposit   = aStep->GetTotalEnergyDeposit();
  time       = preStepPoint->GetGlobalTime();
  currentPV  = preStepPoint->GetPhysicalVolume();
  weight     = preStepPoint->GetWeight();

  G4double volume  = aStep->GetPreStepPoint()->GetPhysicalVolume()
      ->GetLogicalVolume()->GetSolid()->GetCubicVolume();
  //G4double density = aStep->GetTrack()->GetMaterial()->GetDensity();
  G4double density = aStep->GetPreStepPoint()->GetMaterial()->GetDensity();
  dose       = EDeposit/(density*volume)*weight;

  stepL = aStep->GetStepLength();

}


void G4MNestedDICOMSD::createNewHit() {
#ifdef debug
  G4cout << " Create New Hit " 
         << " " << unitXID
         <<" "  << unitYID       
         <<" "  << unitZID <<G4endl;
  G4cout << " Create new Hit: unitPoint "
         << " " << unitPoint.x()/mm
         << " " << unitPoint.y()/mm
         << " " << unitPoint.z()/mm
         << G4endl;
  G4cout << " Create new Hit : EntryPoint"
         << " " << hitPoint.x()/mm
         << " " << hitPoint.y()/mm
         << " " << hitPoint.z()/mm
         << G4endl;
#endif

  currentHit = new G4MDICOMHit();
  currentHit->SetTrackID(trackID);
  currentHit->SetParentTrackID(parentTrkID);
  currentHit->SetPID(PID);
  currentHit->SetUnitID(unitXID,unitYID,unitZID);
  //currentHit->SetEntry(hitPoint);
  //currentHit->setExit(ExitPoint);
  currentHit->SetGlobalTime(time);
  currentHit->SetUnitPoint(unitPoint);
  currentHit->SetPrimaryVertex(primVertex);
  currentHit->SetMomentum(momentum);
  currentHit->SetIncidentKinE(incidentKinE);
  currentHit->SetEnergyDeposit(EDeposit);  
  currentHit->SetHitPoint(hitPoint);  
  currentHit->SetWeight(weight);  
  currentHit->SetDose(dose);
  currentHit->SetStepLength(stepL);  
  StoreHit(currentHit);
  if ( trackInfo ) { 
    G4MTrackInformation* mTrackInfo= (G4MTrackInformation*)trackInfo;
    currentHit->SetParentPID(mTrackInfo->GetParentPID());
    currentHit->SetCreatorProcessType(mTrackInfo->GetOriginalProcessType());  
    currentHit->SetTrigBit(mTrackInfo->GetTriggerBit());  
    currentHit->SetTrigPos(mTrackInfo->GetTrgPosOut());  
  }
}        

void G4MNestedDICOMSD::updateHit(){
  currentHit->AddEnergyDeposit(EDeposit);
  currentHit->AddDose(dose);
  currentHit->AddStepLength(stepL);
  //currentHit->setExit(exitPoint);
#ifdef debug
  G4cout << currentHit->GetEnergyDeposit()/keV << G4endl;
#endif  
} 

void G4MNestedDICOMSD::StoreHit(G4MDICOMHit* hit){
  if (hit == 0 ) {
    G4cout << "G4MNestedDICOMSD: hit to be stored is NULL !!" <<G4endl;
    return;
  }
  doseHCollection->insert( hit );
}
