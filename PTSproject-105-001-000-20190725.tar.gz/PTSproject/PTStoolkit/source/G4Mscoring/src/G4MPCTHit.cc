//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MPCTHit.hh,v 1.1 2009/03/17 09:26:19 aso Exp $
// GEANT4 tag $Name:  $
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  23 Dec. 2010 T.Aso CreatePoint.
// 2015-12-14 T.Aso mon and time.
//
//
//========================================================================
#include "G4MPCTHit.hh"
#include "G4ios.hh"
#include "G4VVisManager.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"
#include "G4LogicalVolume.hh"

G4ThreadLocal G4Allocator<G4MPCTHit>* G4MPCTHitAllocator=0;

G4MPCTHit::G4MPCTHit()
  : G4VHit(){}

G4MPCTHit::G4MPCTHit(const G4MPCTHit & right)
:G4VHit() {
  
  createPoint     = right.createPoint;
  hitPoint     = right.hitPoint;
  KE     = right.KE;
  momentum     = right.momentum;
  PID          = right.PID;
  trackID      = right.trackID;

  weight       = right.weight;

}

G4MPCTHit::~G4MPCTHit() {}


const G4MPCTHit& G4MPCTHit::operator=(const G4MPCTHit &right) {

  createPoint     = right.createPoint;
  hitPoint     = right.hitPoint;
  KE     = right.KE;
  momentum     = right.momentum;
  PID          = right.PID;
  trackID      = right.trackID;

  weight       = right.weight;

  return *this;
}

void G4MPCTHit::Draw(){
  ;
}

void G4MPCTHit::Print() {
  ;
}

void G4MPCTHit::SetCreatePoint(const G4ThreeVector & _createPoint) {
  createPoint = _createPoint;
}
G4ThreeVector G4MPCTHit::GetCreatePoint() const {
  return createPoint;
}

void G4MPCTHit::SetHitPoint(const G4ThreeVector & _hitPoint) {
  hitPoint = _hitPoint;
}

G4ThreeVector G4MPCTHit::GetHitPoint() const {
  return hitPoint;
}

void G4MPCTHit::SetKineticEnergy(G4double _e){
  KE = _e;
}

G4double G4MPCTHit::GetKineticEnergy() const{
  return KE;
}

void G4MPCTHit::SetMomentum(const G4ThreeVector & _p) {
  momentum = _p;
}
G4ThreeVector G4MPCTHit::GetMomentum() const {
  return momentum;
}

void G4MPCTHit::SetPID(const G4int & _PID) {
  PID = _PID;
}
G4int G4MPCTHit::GetPID() const {
  return PID;
}

void G4MPCTHit::SetTrackID(const G4int & _trackID) {
  trackID = _trackID;
}
G4int G4MPCTHit::GetTrackID() const {
  return trackID;
}



