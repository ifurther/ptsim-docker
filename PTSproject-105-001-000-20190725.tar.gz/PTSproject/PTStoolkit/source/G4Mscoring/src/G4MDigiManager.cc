//
//
// class G4MDigiManager
//
// Class description:
//
//  Digi manager.
// 
// --------------------------------------------------------------------
//
// (Createrd) 
//
// (Modification)
//  2016-04-12  T.Aso
//  2016-07-14  T.Aso type.
//
// --------------------------------------------------------------------
#include "G4MDigiManager.hh"

#include "G4MDigiVolumeMerger.hh"
#include "G4MDigiCoincidence.hh"
#include "G4MDigiETCCGasMerger.hh"
#include "G4MDigiETCCCrystalMerger.hh"
#include "G4MDigiETCCOutput.hh"

G4MDigiManager* G4MDigiManager::ptrDGMgr=0;
//================================================
G4MDigiManager::G4MDigiManager()
{}

G4MDigiManager::~G4MDigiManager() {
}

G4MVDigitizerConstructor* G4MDigiManager::Create(const G4String& name, 
                                                 const G4String& type,
                                                 const G4String& srccolname,
                                                 const G4String& dstcolname,
                                                 const G4String& sdname){
  G4MVDigitizerConstructor* p =0;
  if ( type == "DigiVolMerger" ){
    p = new G4MDigiVolumeMerger(name,dstcolname);
    p->SetSrcColName(srccolname,sdname);
    return p;
    //
  }else if( type == "DigiCoincidence" ){
    p = new G4MDigiCoincidence(name,dstcolname);
    p->SetSrcColName(srccolname);
    return p;
    //
    //
  }else if( type == "DigiETCCGas" ){
    p = new G4MDigiETCCGasMerger(name,dstcolname);
    p->SetSrcColName(srccolname,sdname);
    return p;
  }else if( type == "DigiETCCCrystal" ){
    p = new G4MDigiETCCCrystalMerger(name,dstcolname);
    p->SetSrcColName(srccolname,sdname);
    return p;
  }else{
    G4cerr << "No Digi Module"<<G4endl;
    exit(-1);
  }
  //
  return 0;
}

G4MVDigitizerConstructor* G4MDigiManager::Combine(const G4String& name, 
                                                 const G4String& type,
                                                 const G4String& srccolname1,
                                                 const G4String& srccolname2,
                                                  const G4String& dstcolname){
  if( type == "DigiETCCOutput" ){
    G4MDigiETCCOutput* p = new G4MDigiETCCOutput(name,dstcolname);
    p->SetSrcColName(srccolname1);
    p->SetSrcColName2(srccolname2);
    return p;
  }else{
    G4cerr << "No Digi Module"<<G4endl;
    exit(-1);
  }
  //
  return 0;
}


