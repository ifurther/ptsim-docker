//
// ---------------------------------------------------------------
//
// G4MStepHit.cc
//
// ---------------------------------------------------------------
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------

#include "G4MStepHit.hh"

#include "G4UnitsTable.hh"

G4ThreadLocal G4Allocator<G4MStepHit> *aStepHitAllocator = 0;

G4MStepHit::G4MStepHit()
 :G4VHit()
{
  fPosition = G4ThreeVector(0.,0.,0.);
  fKinE = 0.;
  fMomentum = G4ThreeVector(0.,0.,0.);
  fGlobalTime = 0.;
}

G4MStepHit::G4MStepHit(G4ThreeVector pos, G4double ke, G4ThreeVector mon,
                       G4double time)
  :G4VHit(),fPosition(pos),fKinE(ke),fMomentum(mon),fGlobalTime(time)
{
}

G4MStepHit::G4MStepHit(const G4MStepHit &right)
  : G4VHit(),
    fPosition(right.fPosition),fKinE(right.fKinE),fMomentum(right.fMomentum),
    fGlobalTime(right.fGlobalTime)
{
}

G4MStepHit::~G4MStepHit()
{
}
