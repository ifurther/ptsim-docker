//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//====================================================================
// (Class) G4MDigiETCCGasMerger
//
//  2017-12-25  T.Aso Created.
//
//====================================================================

#include <vector>
#include "G4DigiManager.hh"
#include "G4MDigiETCCGasMerger.hh"
#include "G4MDigiETCCGas.hh"
#include "G4MDigiETCCSet.hh"

#include "G4MDICOMHit.hh"

#include "G4SystemOfUnits.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4SDManager.hh"
#include "G4DigiManager.hh"
#include "G4ios.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiETCCGasMerger::G4MDigiETCCGasMerger(const G4String& _name, 
                                         const G4String& _colname)
  :G4MVDigitizerConstructor(_name,_colname){
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiETCCGasMerger::~G4MDigiETCCGasMerger()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

void G4MDigiETCCGasMerger::Digitize()
{
  // (In) Hit
  G4SDManager* SDMan = G4SDManager::GetSDMpointer();
  if ( !SDMan->FindSensitiveDetector(fSrcSDName,false) ) return;
  //
  G4DigiManager* DigiMan = G4DigiManager::GetDMpointer();
  // Hits collection
  G4int HCID = DigiMan->GetHitsCollectionID(fSrcColName);
  //G4cout << " HCID "<<HCID<<G4endl;
  if ( HCID < 0 ) return;
  //
  G4MDICOMHitsCollection* HC = 0;
  HC = (G4MDICOMHitsCollection*)(DigiMan->GetHitsCollection(HCID));
  //
  //
  // (Out ) Digi
  G4int DCID = DigiMan->GetDigiCollectionID(GetCollectionName(0));
  G4cout << " ETCCGasMerger GetDigiCollectionID " << GetCollectionName(0) 
         << " DCID "<< DCID <<G4endl;
  if ( DCID < 0 ) return;

  G4MDigiETCCSetCollection* DigiETCCSetCollection = 0;
  DigiETCCSetCollection = 
    (G4MDigiETCCSetCollection*)DigiMan->GetDigiCollection(DCID);
  if ( !DigiETCCSetCollection ){
    // Create the Digi Collection
    DigiETCCSetCollection =
      new G4MDigiETCCSetCollection(GetName(),GetCollectionName(0)); 
    StoreDigiCollection(DigiETCCSetCollection);
  }
  //
  //
  //====
  if ( DigiETCCSetCollection->GetSize() == 0 ){
    G4MDigiETCCSet* digiETCCSet = new G4MDigiETCCSet();
    DigiETCCSetCollection->insert(digiETCCSet);
  }
  G4MDigiETCCSet* DigiETCCSet = (*DigiETCCSetCollection)[0];
  //
  if (HC){
    //
    // Digitize HC to Digi
    // ( Recoil Electron )
    for (G4int i=0;i<HC->entries();i++){
      G4int pid = (*HC)[i]->GetPID();
      G4int parentPID = (*HC)[i]->GetParentPID();
      G4int creProcType = (*HC)[i]->GetG4CreatorProcessType();
      G4int creProcSubType = (*HC)[i]->GetG4CreatorProcessSubType();
      G4cout << " pid " << pid << " parentPID " << parentPID
             << " processId " << creProcType
             << " proSubId  " << creProcSubType
             << G4endl;
      // Search recoil electron from gamma interaction.
      if ( pid == 11 && parentPID == 22) {
        G4MDigiETCCGas* digiGas = new G4MDigiETCCGas();
        digiGas->SetComptVTX((*HC)[i]->GetPrimaryVertex());
        digiGas->SetScatGammaTrackID((*HC)[i]->GetParentTrackID());
        digiGas->SetRecElecMom((*HC)[i]->GetMomentum());
        digiGas->SetRecElecTrajectory((*HC)[i]->GetStepPosVec());
        digiGas->SetRecElecEdep((*HC)[i]->GetStepDEVec());
        //
        // Gamma
        for (G4int ip=0; ip<HC->entries(); ip++){
          if ( (*HC)[ip]->GetPID() == 22 && 
               ((*HC)[ip]->GetTrackID() == digiGas->GetScatGammaTrackID())){
            G4int gamParentPID = (*HC)[ip]->GetParentPID();
            G4ThreeVector gamParentVTX = (*HC)[ip]->GetPrimaryVertex();
            G4ThreeVector gamParentMom = (*HC)[ip]->GetPrimaryMomentum();
            digiGas->SetParent(gamParentPID,gamParentVTX, gamParentMom);
            for ( G4int istep = 0; istep < (*HC)[ip]->GetNStepVec(); istep++){
              if ( digiGas->GetComptVTX() == (*HC)[ip]->GetStepPosVec(istep) ){
                const G4ThreeVector& scatMom = (*HC)[ip]->GetStepMomVec(istep);
                digiGas->SetScatGammaMom(scatMom);
                break;
              }
            }
            break;
          }
        }
        //
        DigiETCCSet->AddDigiETCCGas(digiGas);
        //
      }
    }
  }
  //====
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
