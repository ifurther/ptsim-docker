//
// ---------------------------------------------------------------
//
// G4MTrajectoryHit.cc
//
// ---------------------------------------------------------------
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------
#include "G4MTrajectoryHit.hh"

#include "G4UnitsTable.hh"

G4ThreadLocal G4Allocator<G4MTrajectoryHit> *aTrajectoryHitAllocator = 0;

G4MTrajectoryHit::G4MTrajectoryHit()
  :G4VHit(),fTrackID(0), fPID(0), fWeight(1.),fCreatorProcessName("")
{
  fSecTrkIDVec.clear();
  const G4String trajName = "TrajectoryHit";
  const G4String trajPointName = "TrajectoryPointHit";
  fTrajPointHitsCollection = 
    new G4MTrajPointHitsCollection(trajName,trajPointName);
}

G4MTrajectoryHit::G4MTrajectoryHit(G4int trkid, G4int pid,G4double w,
                                   G4int parentTrkid,
                                   const G4String& creatorProcessName)
  :G4VHit(), fTrackID(trkid), fPID(pid), fWeight(w),
   fCreatorProcessName(creatorProcessName),
   fParentTrackID(parentTrkid)
{
  fSecTrkIDVec.clear();
  const G4String trajName = "TrajectoryHit";
  const G4String trajPointName = "TrajectoryPointHit";
  fTrajPointHitsCollection = 
    new G4MTrajPointHitsCollection(trajName,trajPointName);
}

G4MTrajectoryHit::G4MTrajectoryHit(const G4MTrajectoryHit &right)
  : G4VHit(),fTrackID(right.fTrackID), fPID(right.fPID),
    fWeight(right.fWeight),
    fSecTrkIDVec(right.fSecTrkIDVec)
{
  G4cerr << "G4MTrajectoryHit::Dummy Constructor"<< G4endl;
}

G4MTrajectoryHit::~G4MTrajectoryHit()
{
  fSecTrkIDVec.clear();
  delete fTrajPointHitsCollection;
}
