//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//=============================================================
// class desccription:
//
//  This class is exclusively used for DumpSD.
//
//  Created by T.Aso 30-Nov-2007
//
//
//
//=============================================================
//
//
#include "G4MParticleInfo.hh"

G4MParticleInfo::G4MParticleInfo(G4ParticleDefinition* pp)
    :theParticle(pp),position(0.0,0.0,0.0),time(0.0),
     momentum(0.0,0.0,0.0),polarization(0.0,0.0,0.0)
{;}

G4MParticleInfo::~G4MParticleInfo()
{;}
