//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
// 2016-04-07 T.Aso For DigiSet 
//
//========================================================================

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo.....
#include "G4MDigiSet.hh"
#include "G4MDigi.hh"
#include "G4MDigiId.hh"

G4ThreadLocal G4Allocator<G4MDigiSet> *G4MDigiSetAllocator = 0;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiSet::G4MDigiSet()
  :G4VDigi()
{
  DigiVec.clear();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiSet::~G4MDigiSet()
{
  DigiVec.clear();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4MDigiSet::G4MDigiSet(G4MDigi* digi)
  :G4VDigi()
{
  DigiVec.clear();
  DigiVec.push_back(digi);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiSet::G4MDigiSet(const G4MDigiSet& right)
  :G4VDigi()
{
  DigiVec = right.DigiVec;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
const G4MDigiSet& G4MDigiSet::operator=(const G4MDigiSet& right)
{
  DigiVec = right.DigiVec;

  return *this;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
int G4MDigiSet::operator==(const G4MDigiSet& right) const
{ 
  if ( DigiVec == right.DigiVec ) return true;
  return false; // dummy
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigiSet::Draw()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigiSet::Print()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4double G4MDigiSet::GetByDcId(G4int dcid, const G4double unit, const G4int evno){
  switch  ( dcid ){
  case EvnoDcId:
    return evno;
  case NhitDcId:  // ??
    return NDigi();
  case EdepDcId:
    return GetDigi()->GetEdep()/unit;
  case EdepSigDcId:
    return GetDigi()->GetEdepSig()/unit;
  case XidDcId:
    return GetDigi()->GetUnitXID()/unit;
  case YidDcId:
    return GetDigi()->GetUnitYID()/unit;
  case ZidDcId:
    return GetDigi()->GetUnitZID()/unit;
  case ModidDcId:
    return GetDigi()->GetUnitModID()/unit;
  case SecidDcId:
    return GetDigi()->GetUnitSecID()/unit;
  case XpointDcId:
    return (GetDigi()->GetGlobalPosSig()).x()/unit;
  case YpointDcId:
    return (GetDigi()->GetGlobalPosSig()).y()/unit;
  case ZpointDcId:
    return (GetDigi()->GetGlobalPosSig()).z()/unit;
  case TimeDcId:
    return GetDigi()->GetTime()/unit;
  case TimeSigDcId:
    return GetDigi()->GetTimeSig()/unit;
  case Secid1DcId:
    return GetDigi(1)->GetUnitSecID()/unit;
  case EdepSig1DcId:
    if ( NDigi() > 0 ) return GetDigi(1)->GetEdepSig()/unit;
  case Xpoint1DcId:
    if ( NDigi() > 0 ) return (GetDigi(1)->GetGlobalPosSig()).x()/unit;
    return 0.;
  case Ypoint1DcId:
    if ( NDigi() > 0 ) return (GetDigi(1)->GetGlobalPosSig()).y()/unit;
    return 0.;
  case Zpoint1DcId:
    if ( NDigi() > 0 ) return (GetDigi(1)->GetGlobalPosSig()).z()/unit;
    return 0.;
  case TimeSig1DcId:
    if ( NDigi() > 0 ) return GetDigi(1)->GetTimeSig()/unit;
  }
    //
  return 0.0;
}

G4int G4MDigiSet::GetByDcIdI(G4int dcid, G4int evno){
  switch  ( dcid ){
  case EvnoDcId:
    return evno;
  case XidDcId:
    return GetDigi()->GetUnitXID();
  case YidDcId:
    return GetDigi()->GetUnitYID();
  case ZidDcId:
    return GetDigi()->GetUnitZID();
  case ModidDcId:
    return GetDigi()->GetUnitModID();
  case SecidDcId:
    return GetDigi()->GetUnitSecID();
  }
  return 0;
}


