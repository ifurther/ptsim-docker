//
//
// class G4MSDManager
//
// Class description:
//
//  SD manager.
// 
// --------------------------------------------------------------------
//
// (Createrd) 
//
// (Modification)
//  2016-04-12  T.Aso
//  2016-07-16  T.Aso geometry depth index.
//
// --------------------------------------------------------------------
#include "G4MSDManager.hh"
#include "G4SDManager.hh"
#include "G4LogicalVolume.hh"
//
#include "G4MDetectorSD.hh"
#include "G4MTriggerSD.hh"

G4MSDManager* G4MSDManager::ptrSDMgr= 0;
//================================================

G4MSDManager::G4MSDManager()
{}

G4MSDManager::~G4MSDManager() {
}

void G4MSDManager::CreateSD(G4String& sdname, G4String& colname, 
                            G4bool flgedep,
                            G4int dep_x, G4int dep_y, G4int dep_z, 
                            G4int dep_m, G4int dep_s){
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector* sd = SDman->FindSensitiveDetector(sdname,false);
  if ( sd ){
    G4cout <<"%%%G4MSDManager::CreateSD "<<sdname
           <<" has already exist. " <<G4endl;    
    return;
  }
  G4MDetectorSD* detSD = new G4MDetectorSD(sdname, colname);
  detSD->SetZeroEdep(flgedep);
  detSD->SetDepth(dep_x, dep_y, dep_z, dep_m, dep_s);
  SDman->AddNewDetector(detSD);
}

void G4MSDManager::SetDepthSD(G4String& sdname,
                              G4int dep_x, G4int dep_y, G4int dep_z, 
                              G4int dep_m, G4int dep_s){
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector* sd =SDman->FindSensitiveDetector(sdname,false);
  if ( sd ){
    G4MDetectorSD* detSD = dynamic_cast<G4MDetectorSD*>(sd);
    detSD->SetDepth(dep_x, dep_y, dep_z, dep_m, dep_s);
  }
}

void G4MSDManager::SetEdepSD(G4String& sdname, G4bool flgedep){
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector* sd = SDman->FindSensitiveDetector(sdname,false);
  if ( sd ){
    G4MDetectorSD* detSD = dynamic_cast<G4MDetectorSD*>(sd);
    detSD->SetZeroEdep(flgedep);
  }
}

void G4MSDManager::SetStepSD(G4String& sdname, G4bool flgstep){
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector* sd = SDman->FindSensitiveDetector(sdname,false);
  if ( sd ){
    G4MDetectorSD* detSD = dynamic_cast<G4MDetectorSD*>(sd);
    detSD->SetSaveStep(flgstep);
  }
}

void G4MSDManager::AttachSD(G4String& sdname, G4LogicalVolume* lv){
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector* sd = SDman->FindSensitiveDetector(sdname,false);
  if ( !sd ) {
    // dummy
    G4cout <<"%%%G4MSDManager::AttachSD No SD "<<sdname<<G4endl;
    return;
  }
  lv->SetSensitiveDetector(sd);
}

void G4MSDManager::DetachSD(G4LogicalVolume* lv){
  lv->SetSensitiveDetector(0);
}

void G4MSDManager::AttachTrgSD(G4String& sdname, G4LogicalVolume* lv,
                                  G4int id){
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector* sd = SDman->FindSensitiveDetector(sdname,false);
  G4MTriggerSD* trgSD=0;
  if ( sd ){
    trgSD = dynamic_cast<G4MTriggerSD*>(sd);
  }else{
    trgSD = new G4MTriggerSD(sdname);
    SDman->AddNewDetector(trgSD);
  }
  trgSD->SetTriggerId(lv, id);
  lv->SetSensitiveDetector(trgSD);
}

void G4MSDManager::Show() {
}

