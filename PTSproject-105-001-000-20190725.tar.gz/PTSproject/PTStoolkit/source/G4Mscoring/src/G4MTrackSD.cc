//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
// 2015-06-11 T.Aso Created.
//////////////////////////////////////////////////////////////////////////
#include "G4MTrackSD.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4SDManager.hh"

#include "G4ThreeVector.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  2015-01-12 T.Aso Created
//                     
//
//========================================================================

G4MTrackSD::G4MTrackSD(const G4String& name, 
                       const G4String& hitsCollectionName)
  :G4VSensitiveDetector(name), fHitsCollection(NULL) 
{
  collectionName.insert(hitsCollectionName);
}

G4MTrackSD::~G4MTrackSD() {
}

void G4MTrackSD::Initialize(G4HCofThisEvent* hce) {
  fHitsCollection
    = new G4MTrackHitsCollection(SensitiveDetectorName,collectionName[0]);
  G4int hcID = 
    G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);
  hce->AddHitsCollection(hcID, fHitsCollection);
}

G4bool G4MTrackSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  if(aStep == NULL) return true;

  G4Track* aTrack = aStep->GetTrack();
  G4int trkID = aTrack->GetTrackID(); 
  G4int pid   = aTrack->GetDefinition()->GetPDGEncoding();
  G4int parentTrkID = aTrack->GetParentID();
  //
  G4StepPoint*       preSP = aStep->GetPreStepPoint();
  const G4ThreeVector& pos = preSP->GetPosition();
  G4double              ke = preSP->GetKineticEnergy();
  const G4ThreeVector& mon = preSP->GetMomentum();
  //
  G4MTrackHit* newHit =
    new G4MTrackHit(trkID,pid,pos,ke,mon,parentTrkID);
  //
  fHitsCollection->insert( newHit );
  //
  return true;
}


void G4MTrackSD::EndOfEvent(G4HCofThisEvent *) {

}

