/////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
// 2015-06-11 T.Aso Created.
//////////////////////////////////////////////////////////////////////////
#include "G4MTrajectorySD.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4SDManager.hh"
#include "G4VProcess.hh"
#include "G4LogicalVolume.hh"
#include "G4VSolid.hh"

#include "G4ThreeVector.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4MTrajectoryPointHit.hh"
#include "G4MStepHit.hh"
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  2015-01-12 T.Aso Created
//                     
//
//========================================================================

G4MTrajectorySD::G4MTrajectorySD(const G4String& name, 
                                 const G4String& hitsCollectionName)
  :G4VSensitiveDetector(name), fHitsCollection(NULL) 
{
  fDepth[0] = 2;  //x
  fDepth[1] = 1;  //y
  fDepth[2] = 0;  //z
  collectionName.insert(hitsCollectionName);
}

G4MTrajectorySD::~G4MTrajectorySD() {
  if ( fHitsCollection ) delete fHitsCollection;
}

void G4MTrajectorySD::Initialize(G4HCofThisEvent* hce) {
  fHitsCollection
    = new G4MTrajectoryHitsCollection(SensitiveDetectorName,
                                       collectionName[0]);
  G4int hcID = 
    G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);
  hce->AddHitsCollection(hcID, fHitsCollection);
}

G4bool G4MTrajectorySD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  if(aStep == NULL) return true;

  //
  // TrajectoryHit
  //
  G4Track* aTrack = aStep->GetTrack();
  G4int trkID = aTrack->GetTrackID(); 
  G4int pid   = aTrack->GetDefinition()->GetPDGEncoding();
  G4int parentTrkID = aTrack->GetParentID();
  const G4VProcess* process = aTrack->GetCreatorProcess();
  G4String creatorProcName;
  if ( process ) {
    creatorProcName = process->GetProcessName();
  }else{
    creatorProcName = "none";
  }
  //
  // TrajectoryPointHit
  //
  G4StepPoint*       preSP = aStep->GetPreStepPoint();
  const G4ThreeVector& prePos = preSP->GetPosition();
  G4double              ke = preSP->GetKineticEnergy();
  const G4ThreeVector& mon = preSP->GetMomentum();
  G4double            globalTime = preSP->GetGlobalTime();
  //
  G4TouchableHistory* touchable 
    = (G4TouchableHistory *)preSP->GetTouchable();
  G4int voxelID[3] = {touchable->GetReplicaNumber(fDepth[2]),
                      touchable->GetReplicaNumber(fDepth[1]),
                      touchable->GetReplicaNumber(fDepth[0])};
  G4double de     = aStep->GetTotalEnergyDeposit();
  G4double stepL  = aStep->GetStepLength();
  G4double volume  = preSP->GetPhysicalVolume()
                     ->GetLogicalVolume()->GetSolid()->GetCubicVolume();
  G4double density = preSP->GetMaterial()->GetDensity();
  G4double dose  = de/(density*volume);
  G4double weight = preSP->GetWeight();
  //
  G4StepPoint*       posSP = aStep->GetPostStepPoint();
  //const G4ThreeVector& postPos = posSP->GetPosition();
  const G4VProcess* stepProcess = posSP->GetProcessDefinedStep();
  G4String definedStepProcName;
  if ( stepProcess ){
    definedStepProcName = stepProcess->GetProcessName();
  }else{
    definedStepProcName = "none";
  }
  //
  //
  G4MTrajectoryHit* currentHit = 0;
  G4int lastIndex = fHitsCollection->entries()-1;
  if ( trkID != (*fHitsCollection)[lastIndex]->GetTrackID() ){
    // New Track.
    currentHit = 
      new G4MTrajectoryHit(trkID,pid,parentTrkID,weight, creatorProcName);
    fHitsCollection->insert( currentHit );
  }else{
    currentHit = (*fHitsCollection)[lastIndex];
  }
  //
  // During stepping
  G4MTrajectoryPointHit* trjPointHit = 
    new G4MTrajectoryPointHit(prePos,ke,mon,globalTime,voxelID,
                              de,stepL,dose,definedStepProcName);
  currentHit->InsertTrajPointHit(trjPointHit);
  //
  //
  // Termination of the track.
  if ( ! ((aTrack->GetTrackStatus() == fAlive) || 
          (aTrack->GetTrackStatus() == fStopButAlive)) ){
    // End of Track.
    const G4TrackVector* secondary = aStep->GetSecondary();
    for ( size_t i = 0; i < secondary->size(); i++){
      currentHit->AppendSecTrkID((*secondary)[i]->GetTrackID());
    }
  }
  //
  return true;
}


void G4MTrajectorySD::EndOfEvent(G4HCofThisEvent *) {

}

