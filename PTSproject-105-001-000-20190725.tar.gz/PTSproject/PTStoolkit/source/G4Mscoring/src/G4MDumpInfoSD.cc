//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
#include "G4MDumpInfoSD.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4ios.hh"
#include "G4SDManager.hh"

#include "G4MDumpInfoSDMessenger.hh"

#include "G4MParticleInfo.hh"

#include "G4MFileNameManager.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  30-Nov-2007 T.Aso Created for dump particle information.  
//  19-Mar-2008 T.Aso File IO in EndOfEventAction is performed
//                    Only if the file is opened. 
//                    Add method : 
//                        G4MDumpMap& GetDumpMap();
//                    User will be able to access the stored particle 
//                    information in UserEventAction via SensitiveDetector.
// 2013-03-30   T.Aso     SystemOfUnits/PhysicalConstants.
// 2017-03-15   T.Aso  Threading.
//  2-17-03-31 T.Aso Using FileNameManager.
//  2019-04-04 T.Aso Add fileformat.
//========================================================================

G4MDumpInfoSD::G4MDumpInfoSD(G4String name)
  :G4VSensitiveDetector(name),fileName("DumpInfo.data"),fileFormat(0) {
    fMessenger = new G4MDumpInfoSDMessenger(this);
}

G4MDumpInfoSD::~G4MDumpInfoSD() {
    Close();
    if ( fMessenger ) delete fMessenger;
}

void G4MDumpInfoSD::Initialize(G4HCofThisEvent* ) {
    currentTrkID = -1;
}

G4bool G4MDumpInfoSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  if(aStep == NULL) return true;
  if(aStep->GetPreStepPoint()->GetStepStatus() != fGeomBoundary ) return true;
  G4Track* aTrack = aStep->GetTrack();
  G4int trkID = aTrack->GetTrackID(); 
  if ( currentTrkID == trkID ) return true;
  G4MDumpMap::iterator it = HPmap.find(trkID);
  if ( it != HPmap.end() ) return true;

  G4MParticleInfo* p = new G4MParticleInfo(aTrack->GetDefinition());
  p->SetPosition(aTrack->GetPosition());
  p->SetTime(aTrack->GetGlobalTime());
  p->SetMomentum(aTrack->GetMomentum());
  p->SetPolarization(aTrack->GetPolarization());
  //G4cout << "%%%% G4MDumpInfoSD " << trkID <<G4endl;
  HPmap[trkID] = p;
  currentTrkID = trkID;

  return true;
}


void G4MDumpInfoSD::EndOfEvent(G4HCofThisEvent *) {

    if ( !outputFile.is_open() ) {
      Open(fileName);
    }
    if ( fileFormat == 0 ){ // ASCII
      outputFile << HPmap.size() << G4endl;
    } else {
      G4int np = (G4int)HPmap.size();
      outputFile.write((char*)&np,sizeof(G4int));
    }

      for ( G4MDumpMap::iterator it = HPmap.begin(); it !=HPmap.end() ; it++){
        G4MParticleInfo* p = (*it).second;

        G4ThreeVector& position          = p->GetPosition();
        G4double       time              = p->GetTime();
        G4ThreeVector& polar             = p->GetPolarization();
        G4ThreeVector& mom               = p->GetMomentum();
        G4ParticleDefinition* particle   = p->GetParticle();

        position       /= mm;
        time           /= nanosecond;
        mom            /= MeV;
        G4int    pdg    = particle->GetPDGEncoding();
        G4double mass   = particle->GetPDGMass()/MeV;
        G4double charge = particle->GetPDGCharge();

        if ( fileFormat == 0 ){ // ASCII
          outputFile << position.x() <<" "<<position.y()<<" "<<position.z()<<" " 
                     << time <<" "<<mass<<" "<<pdg<<" "<<charge <<" "
                     << mom.x()<<" "<<mom.y()<<" "<<mom.z()<<" "
                     << polar.x()<<" "<<polar.y()<<" "<<polar.z()
                     << G4endl;
        }else{
          G4float fx = (G4float)position.x();
          G4float fy = (G4float)position.y();
          G4float fz = (G4float)position.z();
          G4float ft = (G4float)time;
          G4float fm = (G4float)mass;
          G4int   fpdg = (G4int)pdg;
          G4int   fchg = (G4int)charge;
          G4float fpx = (G4float)mom.x();
          G4float fpy = (G4float)mom.y();
          G4float fpz = (G4float)mom.z();
          outputFile.write((char*)&fx,sizeof(G4float));
          outputFile.write((char*)&fy,sizeof(G4float));
          outputFile.write((char*)&fz,sizeof(G4float));
          outputFile.write((char*)&ft,sizeof(G4float));
          outputFile.write((char*)&fm,sizeof(G4float));
          outputFile.write((char*)&fpdg,sizeof(G4int));
          outputFile.write((char*)&fchg,sizeof(G4int));
          outputFile.write((char*)&fpx,sizeof(G4float));
          outputFile.write((char*)&fpy,sizeof(G4float));
          outputFile.write((char*)&fpz,sizeof(G4float));
        }
      }
      clear();
}

void G4MDumpInfoSD::clear() {
     // clear G4MVEvtParticles
  for (G4MDumpMap::iterator it = HPmap.begin(); it !=HPmap.end(); it++)
    { delete it->second; }
  HPmap.clear();
}

void G4MDumpInfoSD::DrawAll() {
  ;
} 

void G4MDumpInfoSD::PrintAll() {
  ;
}


void  G4MDumpInfoSD::Open(G4String& fname){
    if ( outputFile.is_open() ) outputFile.close();
    
    //G4String name = GetFullFileName(fname);
    G4MFileNameManager fnm;
    G4String name = fnm.GetFullFileName(fname);
    name = fnm.GetFullFileName(name);
    const char* fn = name.data();
    if ( fileFormat == 0 ) { // ASCII mode
      outputFile.open((char*)fn);
    }else { // Binary mode
      outputFile.open((char*)fn, std::ios::out|std::ios::binary|std::ios::trunc);
    }
    fileName = fname;
}

void  G4MDumpInfoSD::Close(){
    if ( outputFile.is_open() ) outputFile.close();
}


