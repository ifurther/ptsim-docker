//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//========================================================================
//
// Created by T.Aso from G4MWaterPhantomSD
//
// (Modification)
// 2016-04-07 T.Aso For Digis 
//
//========================================================================

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo.....
#include "G4MDigi.hh"
#include "G4MDICOMHit.hh"
#include "G4MDigiId.hh"

G4ThreadLocal G4Allocator<G4MDigi> *G4MDigiAllocator = 0;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigi::G4MDigi()
  :unitXID(-1),unitYID(-1),unitZID(-2),
   unitModID(-1), unitSecID(-1),
   Edeposit(0.0),MaxEdepHitId(0),EdepSig(0.),GlobalPosSig(0.,0.,0.)
{
  HitVec.clear();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigi::~G4MDigi()
{
  HitVec.clear();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigi::G4MDigi(const G4MDigi& right)
  :G4VDigi()
{
  unitXID = right.unitXID;
  unitYID = right.unitYID;
  unitZID = right.unitZID;
  unitModID = right.unitModID;
  unitSecID = right.unitSecID;
  Edeposit  = right.Edeposit;
  MaxEdepHitId = right.MaxEdepHitId;

  HitVec = right.HitVec;

  EdepSig = right.EdepSig;
  GlobalPosSig = right.GlobalPosSig;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
const G4MDigi& G4MDigi::operator=(const G4MDigi& right)
{
  unitXID = right.unitXID;
  unitYID = right.unitYID;
  unitZID = right.unitZID;
  unitModID = right.unitModID;
  unitSecID = right.unitSecID;
  Edeposit  = right.Edeposit;
  MaxEdepHitId = right.MaxEdepHitId;

  HitVec = right.HitVec;

  EdepSig = right.EdepSig;
  GlobalPosSig = right.GlobalPosSig;

  return *this;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
int G4MDigi::operator==(const G4MDigi& right) const
{ 
  return ( unitXID == right.unitXID 
           && unitYID == right.unitYID 
           && unitZID == right.unitZID 
           && unitModID == right.unitModID 
           && unitSecID == right.unitSecID );
}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigi::Draw()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigi::Print()
{;}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4double G4MDigi::GetEdep(){
  return Edeposit;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void  G4MDigi::AddEdep(G4double edep){ 
  Edeposit+=edep; 
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4MDICOMHit* G4MDigi::GetMajorHit(){
  if ( HitVec.size() > 0 ){
    return HitVec[MaxEdepHitId];
  }
  return 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigi::AddHit(G4MDICOMHit* hit){
  HitVec.push_back(hit);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
void G4MDigi::ComputeSignal(G4double tstart, G4double twindow){
  MaxEdepSigId = 0;
  G4double mxEdep = 0.;
  EdepSig = 0;
  GlobalPosSig.set(0.,0.,0.);
  for(size_t i = 0; i < HitVec.size(); i++){
    G4MDICOMHit* hit = HitVec[i];
    G4double t = hit->GetGlobalTime();
    if ( t > tstart && t < tstart+twindow ){
      G4double de = hit->GetEnergyDeposit();
      G4ThreeVector gp = hit->GetHitPoint();
      EdepSig += de; 
      GlobalPosSig += (gp*de);
      if ( mxEdep < de ) { MaxEdepSigId = i; };
    }
  }
  GlobalPosSig /= EdepSig;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
G4double G4MDigi::GetTime(){ 
  return GetMajorHit()->GetGlobalTime();
}

G4double G4MDigi::GetTimeSig(){ 
  return GetHit(MaxEdepSigId)->GetGlobalTime();
}

G4double G4MDigi::GetByDcId(G4int dcid, const G4double unit, const G4int evno){
  switch  ( dcid ){
  case EvnoDcId:
    return evno;
  case NhitDcId:
    return NHit();
  case EdepDcId:
    return Edeposit/unit;
  case EdepSigDcId:
    return EdepSig/unit;
  case XidDcId:
    return unitXID/unit;
  case YidDcId:
    return unitYID/unit;
  case ZidDcId:
    return unitZID/unit;
  case ModidDcId:
    return unitModID/unit;
  case SecidDcId:
    return unitSecID/unit;
  case XpointDcId:
    return GlobalPosSig.x()/unit;
  case YpointDcId:
    return GlobalPosSig.y()/unit;
  case ZpointDcId:
    return GlobalPosSig.z()/unit;
  case TimeDcId:
    return GetTime()/unit;
  case TimeSigDcId:
    return GetTimeSig()/unit;
  }
    //
  return 0.0;
}

G4int G4MDigi::GetByDcIdI(G4int dcid, G4int evno){
  switch  ( dcid ){
  case EvnoDcId:
    return evno;
  case XidDcId:
    return unitXID;
  case YidDcId:
    return unitYID;
  case ZidDcId:
    return unitZID;
  case ModidDcId:
    return unitModID;
  case SecidDcId:
    return unitSecID;
  }
  return 0;
}

