//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MPCTSD.hh,v 1.1 2009/03/17 09:26:19 aso Exp $
// GEANT4 tag $Name:  $
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  19 Dec. 2010 T.Aso Get collection ID by the full name.
//  23 Dec. 2010 T.Aso CreatePoint.
//  2015-12-14 T.Aso mon and time.
// 
//                     
//
//========================================================================
#include "G4MPCTSD.hh"
#include "G4MPCTHit.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4ParticleDefinition.hh"
#include "G4VTouchable.hh"
#include "G4TouchableHistory.hh"
#include "G4ios.hh"
#include "G4SDManager.hh"


G4MPCTSD::G4MPCTSD(G4String name)
  :G4VSensitiveDetector(name),
   pCTHCID(-1), SDName(name), pCTHCollection(0)
{
  G4String HCName;
  collectionName.insert(HCName="pCTCollection");
}

G4MPCTSD::~G4MPCTSD() {
  ;
}

void G4MPCTSD::Initialize(G4HCofThisEvent* HCE) {

  pCTHCollection = new G4MPCTHitsCollection(SDName, collectionName[0]); 
  if(pCTHCID < 0){
    G4String colname = SDName+"/"+collectionName[0];
    //pCTHCID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]);
    pCTHCID = G4SDManager::GetSDMpointer()->GetCollectionID(colname);
  }
  HCE->AddHitsCollection(pCTHCID, pCTHCollection);

}

G4bool G4MPCTSD::ProcessHits(G4Step * aStep, G4TouchableHistory *) {

  G4StepPoint* preStepPoint = aStep->GetPreStepPoint();
  G4StepStatus preStatus = preStepPoint->GetStepStatus();
  if(preStatus != fGeomBoundary) return true;
  G4Track*  track = aStep->GetTrack();   
  G4MPCTHit* hit = new G4MPCTHit();

  hit->SetCreatePoint( track->GetVertexPosition() );
  hit->SetHitPoint( preStepPoint->GetPosition() );
  hit->SetKineticEnergy( preStepPoint->GetKineticEnergy() );
  hit->SetMomentum( track->GetMomentum() );
  hit->SetPID( track->GetDefinition()->GetPDGEncoding() );
  hit->SetTrackID( track->GetTrackID() );
  hit->SetWeight(  preStepPoint->GetWeight() );

  pCTHCollection->insert( hit );

  return true;
}


void G4MPCTSD::EndOfEvent(G4HCofThisEvent *) {
  ;
}

void G4MPCTSD::clear() {
  ;
} 

void G4MPCTSD::DrawAll() {
  ;
} 

void G4MPCTSD::PrintAll() {
  ;
} 
