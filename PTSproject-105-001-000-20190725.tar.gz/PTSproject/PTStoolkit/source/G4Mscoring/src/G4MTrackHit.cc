//
// ---------------------------------------------------------------
//
// G4MTrackHit.cc
//
// ---------------------------------------------------------------
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------

#include "G4MTrackHit.hh"

#include "G4UnitsTable.hh"

G4ThreadLocal G4Allocator<G4MTrackHit> *aTrackHitAllocator = 0;

G4MTrackHit::G4MTrackHit()
  :G4VHit(),fTrackID(-1),fPID(0),
   fStepHit(0),fParentTrackID(-1),fParentPID(0)
{}

G4MTrackHit::G4MTrackHit(G4int trkid, G4int pid, 
                         G4ThreeVector pos, G4double ke, G4ThreeVector mon,
                         G4int parentTrkid, G4int parentPid)
  :G4VHit(),
   fTrackID(trkid),fPID(pid),
   fParentTrackID(parentTrkid),fParentPID(parentPid)
{
  fStepHit = new G4MStepHit(pos,ke,mon);
}

G4MTrackHit::G4MTrackHit(G4int trkid, G4int pid, G4MStepHit* aStepHit,
                         G4int parentTrkid, G4int parentPid)
  :G4VHit(),
   fTrackID(trkid),fPID(pid),fStepHit(aStepHit),
   fParentTrackID(parentTrkid),fParentPID(parentPid)
{ }

G4MTrackHit::G4MTrackHit(const G4MTrackHit &right)
 : G4VHit()
{
  fTrackID       = right.fTrackID;
  fPID           = right.fPID;
  fStepHit       = right.fStepHit;
  fParentTrackID = right.fParentTrackID;
  fParentPID     = right.fParentPID;
}

G4MTrackHit::~G4MTrackHit()
{
  if ( fStepHit ) delete fStepHit;
}
