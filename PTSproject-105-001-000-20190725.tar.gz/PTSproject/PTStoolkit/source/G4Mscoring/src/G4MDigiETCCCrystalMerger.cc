//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//====================================================================
// (Class) G4MDigiETCCCrystalMerger
//
//  2017-12-25  T.Aso Created.
//
//====================================================================

#include <vector>
#include "G4DigiManager.hh"
#include "G4MDigiETCCCrystalMerger.hh"
#include "G4MDigiETCCCrystal.hh"
#include "G4MDigiETCCSet.hh"

#include "G4MDICOMHit.hh"

#include "G4SystemOfUnits.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4SDManager.hh"
#include "G4DigiManager.hh"
#include "G4ios.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiETCCCrystalMerger::G4MDigiETCCCrystalMerger(const G4String& _name, 
                                         const G4String& _colname)
  :G4MVDigitizerConstructor(_name,_colname){
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

G4MDigiETCCCrystalMerger::~G4MDigiETCCCrystalMerger()
{
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

void G4MDigiETCCCrystalMerger::Digitize()
{
  // (In) Hit
  G4SDManager* SDMan = G4SDManager::GetSDMpointer();
  if ( !SDMan->FindSensitiveDetector(fSrcSDName,false) ) return;
  //
  G4DigiManager* DigiMan = G4DigiManager::GetDMpointer();
  // Hits collection
  G4int HCID = DigiMan->GetHitsCollectionID(fSrcColName);
  //G4cout << " HCID "<<HCID<<G4endl;
  if ( HCID < 0 ) return;
  //
  G4MDICOMHitsCollection* HC = 0;
  HC = (G4MDICOMHitsCollection*)(DigiMan->GetHitsCollection(HCID));

  //
  // (Out ) Digi
  G4int DCID = DigiMan->GetDigiCollectionID(GetCollectionName(0));
  G4cout << "ETCCCrystalMerger GetDigiCollectionID " << GetCollectionName(0)
         << " DCID "<< DCID <<G4endl;
  if ( DCID < 0 ) return;
  G4MDigiETCCSetCollection* DigiETCCSetCollection = 0;
  DigiETCCSetCollection = 
      (G4MDigiETCCSetCollection*)DigiMan->GetDigiCollection(DCID);
  if ( !DigiETCCSetCollection ){
    // Create the Digi Collection
    DigiETCCSetCollection =
      new G4MDigiETCCSetCollection(GetName(),GetCollectionName(0)); 
    StoreDigiCollection(DigiETCCSetCollection);
  }
  //
  //
  //====
  if ( DigiETCCSetCollection->GetSize() == 0 ){
    G4MDigiETCCSet* digiETCCSet = new G4MDigiETCCSet();
    DigiETCCSetCollection->insert(digiETCCSet);
  }
  G4MDigiETCCSet* DigiETCCSet = (*DigiETCCSetCollection)[0];
  //
  std::map<G4String, G4MDigiETCCCrystal*> keymap;
  G4MDigiETCCCrystal* DigiCrystal=0;
  //
  if (HC){
    // Digitize HC to Digi
    for (G4int i=0;i<HC->entries();i++){
      G4double edep = (*HC)[i]->GetEnergyDeposit();
      if ( edep == 0. ) continue;
      G4int unitXID   = (*HC)[i]->GetUnitXID();
      G4int unitYID   = (*HC)[i]->GetUnitYID();
      G4int unitSubID   = (*HC)[i]->GetUnitZID();
      G4int unitModID   = (*HC)[i]->GetUnitSecID();
      //
      std::ostringstream ss;
      ss <<"M"<<unitModID << "S" << unitSubID
         << "X" << unitXID << "Y" << unitYID;
      G4String key = ss.str();

      std::map<G4String, G4MDigiETCCCrystal*>::iterator p = keymap.find(key);
      if ( p == keymap.end()) {
        // New Entry
        DigiCrystal = new G4MDigiETCCCrystal();
        DigiCrystal->SetUnitID(unitXID,unitYID,unitSubID,unitModID);
        const G4ThreeVector& pos = (*HC)[i]->GetEntry();
        DigiCrystal->SetPosition(pos);
        //
        keymap.insert(std::map<G4String, 
                      G4MDigiETCCCrystal*>::value_type(key,DigiCrystal));
      }else{
        // Update
        DigiCrystal = p->second; 
      }
      // Fill
      DigiCrystal->AddEdep((*HC)[i]->GetEnergyDeposit());
    }
  }
  //====
  for (std::map<G4String, G4MDigiETCCCrystal*>::iterator it = keymap.begin();
       it != keymap.end(); it++){
    if ( fVerbose ) {
        G4cout << (*it).first <<" nhit " << ((*it).second)->GetNsum() 
               <<" de : " << ((*it).second)->GetEdep() <<G4endl;
    }
    DigiETCCSet->AddDigiETCCCrystal((*it).second);
  }

}
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
