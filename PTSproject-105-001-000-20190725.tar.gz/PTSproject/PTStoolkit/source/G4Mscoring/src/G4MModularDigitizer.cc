//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularDigitizer.cc,v 1.1 2009/03/17 09:29:34 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularDigitizer
//
//  2016-03-11  T.Aso Created.
//
//====================================================================
//
#include "G4MModularDigitizer.hh"
#include "G4DigiManager.hh"

G4MModularDigitizer::G4MModularDigitizer(G4String name)
  :G4VDigitizerModule(name){
  digitizerVector = new G4MDigitizerConstVector();
}

G4MModularDigitizer::~G4MModularDigitizer(){
  G4MDigitizerConstVector::iterator itr;
  for (itr = digitizerVector->begin(); 
       itr!= digitizerVector->end(); ++itr){
    delete (*itr);
  }
  digitizerVector->clear();
  delete digitizerVector;
}


void G4MModularDigitizer::RegisterDigitizer(G4MVDigitizerConstructor* digitizer)
{

  digitizerVector->push_back(digitizer);
  G4DigiManager* DigiMan = G4DigiManager::GetDMpointer();
  DigiMan->AddNewModule(digitizer);
}

void G4MModularDigitizer::Digitize()
{
  //G4cout << " Digitizer " << G4endl;
  G4MDigitizerConstVector::iterator itr;
  for (itr = digitizerVector->begin(); 
       itr!= digitizerVector->end(); ++itr){
    //G4cout << " Digitizer " << (*itr)->GetName()<<G4endl;
    (*itr)->Digitize();
  }
}
