//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
// 2017-12-25 T.Aso For DigiETCCGas
//
//========================================================================

#ifndef G4MDigiETCCGas_h
#define G4MDigiETCCGas_h 1

#include "G4VDigi.hh"
#include "G4TDigiCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

class G4MDigi;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
class G4MDigiETCCGas : public G4VDigi
{

public:
  
  G4MDigiETCCGas();
  ~G4MDigiETCCGas();

  inline void* operator new(size_t);
  inline void  operator delete(void*);
  
  void Draw();
  void Print();

public:
  void SetParent(G4int pid, const G4ThreeVector& vtx, 
                 const G4ThreeVector& mom);
  void SetComptVTX(const G4ThreeVector& xyz);
  void SetScatGammaTrackID(G4int trackid);
  void SetScatGammaMom(const G4ThreeVector& p);
  void SetRecElecMom(const G4ThreeVector& p);
  void AddRecElecTrajectory(const G4ThreeVector& xyz, G4double de);
  void SetRecElecTrajectory(const std::vector<G4ThreeVector>& trjvec);
  void SetRecElecEdep(const std::vector<G4double>& devec);
  //
  G4int GetParentPID() const { return parentPID;};
  const G4ThreeVector& GetParentVTX() const { return parentVTX;};
  const G4ThreeVector& GetParentMom() const { return parentMom;};
  const G4ThreeVector& GetComptVTX() const { return comptVTX; };
  G4int  GetScatGammaTrackID() const { return scatTrackID;};
  const G4ThreeVector&  GetScatGammaMom() const { return scatMom;};
  const G4ThreeVector&  GetRecElecMom() const { return elecMom;};
  const std::vector<G4ThreeVector>& GetRecElecTrajectory() const {return elecTrjVec;};
  const G4ThreeVector& GetRecElecTrajectory(G4int i) const {return elecTrjVec[i];};
  const std::vector<G4double>& GetRecElecEdep() const {return elecDEVec;};
  G4double GetRecElecEdep(G4int i) const {return elecDEVec[i];};
  G4int NRecElecTrj() const { return (G4int)elecTrjVec.size();};

private:
  // TPC Gas----
  // Primary Gamma-ray
  G4int parentPID;
  G4ThreeVector parentVTX;
  G4ThreeVector parentMom;
  // Interaction point
  G4ThreeVector comptVTX;
  // Scatter Gamma-ray
  G4int scatTrackID;
  G4ThreeVector scatMom;
  // Recoil Electron
  G4ThreeVector elecMom;
  std::vector<G4ThreeVector> elecTrjVec;
  std::vector<G4double> elecDEVec;
};
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

typedef G4TDigiCollection<G4MDigiETCCGas> G4MDigiETCCGasCollection;
extern G4ThreadLocal G4Allocator<G4MDigiETCCGas> *G4MDigiETCCGasAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void* G4MDigiETCCGas::operator new(size_t)
{
  if (!G4MDigiETCCGasAllocator)
    G4MDigiETCCGasAllocator = new G4Allocator<G4MDigiETCCGas>;
  return (void*) G4MDigiETCCGasAllocator->MallocSingle();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void G4MDigiETCCGas::operator delete(void* aDigiETCCGas)
{
  G4MDigiETCCGasAllocator->FreeSingle((G4MDigiETCCGas*) aDigiETCCGas);
}

#endif






