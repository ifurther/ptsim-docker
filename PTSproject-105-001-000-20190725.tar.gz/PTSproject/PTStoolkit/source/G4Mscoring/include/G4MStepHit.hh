//
//---------------------------------------------------------------
//
// G4MStepHit.hh
//
// 2015-06-11 T.Aso Created.
//
// ---------------------------------------------------------------

#ifndef G4MStepHit_h
#define G4MStepHit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "globals.hh"                // Include from 'global'
#include "G4ThreeVector.hh"          // Include from 'geometry'
#include "G4Allocator.hh"            // Include from 'particle+matter'

////////////////////////
class G4MStepHit : public G4VHit
//////////////////////// 
{

//--------
public: // without description
//--------

// Constructor/Destructor
   G4MStepHit();
   G4MStepHit(G4ThreeVector pos, G4double ke, G4ThreeVector mom, G4double time=0.);
   G4MStepHit(const G4MStepHit &right);
   virtual ~G4MStepHit();

// Operators
   inline void *operator new(size_t);
   inline void operator delete(void *aTrajectoryPoint);
   inline int operator==(const G4MStepHit& right) const
   { return (this==&right); };

// Get/Set functions
   inline void SetPosition(G4ThreeVector& pos) 
   { fPosition=pos; };
   inline const G4ThreeVector& GetPosition() const
   { return fPosition; };

   inline void SetKineticEnergy(G4double ke) 
   { fKinE=ke; };
   inline const G4double& GetKineticEnergy() const
   { return fKinE; };

   inline void SetMomentum(G4ThreeVector& mon) 
   { fMomentum=mon; };
   inline const G4ThreeVector& GetMomentum() const
   { return fMomentum; };

   inline void SetGlobalTime(G4double time) 
   { fGlobalTime=time; };
   inline const G4double& GetGlobalTime() const
   { return fGlobalTime; };


//---------
   private:
//---------

// Member data
   G4ThreeVector fPosition;
   G4double      fKinE;
   G4ThreeVector fMomentum;
   G4double      fGlobalTime;

};

typedef G4THitsCollection<G4MStepHit> G4MStepHitsCollection;

extern G4ThreadLocal
G4Allocator<G4MStepHit> *aStepHitAllocator;

inline void* G4MStepHit::operator new(size_t)
{
if (!aStepHitAllocator)
  { aStepHitAllocator = new G4Allocator<G4MStepHit>; }
  return (void *) aStepHitAllocator->MallocSingle();
}

inline void G4MStepHit::operator delete(void *aStepHitPoint)
{
  if ( !aStepHitAllocator){
    aStepHitAllocator = new G4Allocator<G4MStepHit>;
  }
  aStepHitAllocator->FreeSingle((G4MStepHit *) aStepHitPoint);
}

#endif
