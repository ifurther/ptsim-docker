//
//---------------------------------------------------------------
//
// G4MTrajectoryHit.hh
//
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------

#ifndef G4MTrajectoryHit_h
#define G4MTrajectoryHit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "globals.hh"                // Include from 'global'
#include "G4ThreeVector.hh"          // Include from 'geometry'
#include "G4Allocator.hh"            // Include from 'particle+matter'

#include "G4MTrajectoryPointHit.hh"

typedef std::vector<G4int>  G4MSecondaryTrkIDVec;

////////////////////////
class G4MTrajectoryHit : public G4VHit
//////////////////////// 
{

//--------
public: // without description
//--------

// Constructor/Destructor
   G4MTrajectoryHit();
   G4MTrajectoryHit(G4int trkid, G4int pid, G4double w,
                   G4int parentTrkid,
                   const G4String& creatorProcessName="");
   G4MTrajectoryHit(const G4MTrajectoryHit &right);
   virtual ~G4MTrajectoryHit();

// Operators
   inline void *operator new(size_t);
   inline void operator delete(void *aTrajectoryHit);
   inline int operator==(const G4MTrajectoryHit& right) const
   { return (this==&right); };

// Get/Set functions
   inline void SetTrackID(G4int trkid) 
   { fTrackID = trkid; };
   inline const G4int& GetTrackID() const
   { return fTrackID; };
  
   inline void SetPID(G4int pid) 
   { fPID = pid; };
   inline const G4int& GetPID() const
   { return fPID; };

   inline void SetWeight(G4double w) 
   { fWeight = w; };
   inline const G4double& GetWeight() const
   { return fWeight; };

   inline void SetParentTrackID(G4int parentTrkid) 
   { fParentTrackID = parentTrkid; };
   inline const G4int& GetParentTrackID() const
   { return fParentTrackID; };

   inline void SetCreatorProcessName(const G4String& creatorProcName) 
   { fCreatorProcessName = creatorProcName; };
   inline const G4String& GetCreatorProcessName() const
   { return fCreatorProcessName; };

  //
   inline G4int GetTrajPointHitEntries() const
   { return fTrajPointHitsCollection->entries(); };

   inline const G4MTrajectoryPointHit* GetTrajPointHit(G4int i) const
   { return (*fTrajPointHitsCollection)[i]; };

   inline void  InsertTrajPointHit(G4MTrajectoryPointHit* trajPointHit)
   { fTrajPointHitsCollection->insert(trajPointHit); };

   inline void AppendSecTrkID(G4int trkid)
   { fSecTrkIDVec.push_back(trkid); };

   inline const G4MSecondaryTrkIDVec& GetSecondartTrkIDVec() const
   { return fSecTrkIDVec; };

//---------
   private:
//---------
// Member data
  G4int fTrackID;
  G4int fPID;
  G4double fWeight;
  G4String fCreatorProcessName;
  G4int fParentTrackID;
  G4MSecondaryTrkIDVec fSecTrkIDVec;

  G4MTrajPointHitsCollection* fTrajPointHitsCollection;
};

typedef G4THitsCollection<G4MTrajectoryHit> G4MTrajectoryHitsCollection;

extern G4ThreadLocal
G4Allocator<G4MTrajectoryHit> *aTrajectoryHitAllocator;

inline void* G4MTrajectoryHit::operator new(size_t)
{
  if (!aTrajectoryHitAllocator)
  { aTrajectoryHitAllocator = new G4Allocator<G4MTrajectoryHit>; }
  return (void *) aTrajectoryHitAllocator->MallocSingle();
}

inline void G4MTrajectoryHit::operator delete(void *aTrajectoryHit)
{
  if ( !aTrajectoryHitAllocator){
    aTrajectoryHitAllocator = new G4Allocator<G4MTrajectoryHit>;
  }
  aTrajectoryHitAllocator->FreeSingle((G4MTrajectoryHit *) aTrajectoryHit);
}

#endif
