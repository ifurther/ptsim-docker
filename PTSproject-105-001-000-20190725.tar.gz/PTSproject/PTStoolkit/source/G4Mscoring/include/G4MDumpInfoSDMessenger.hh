//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
#ifndef G4MDUMPINFOSDMESSENGER_HH
#define G4MDUMPINFOSDMESSENGER_HH

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithoutParameter.hh"

class G4MDumpInfoSD;

//=============================================================
//  class definition
//    Messenger for DumpInfoSD
//
//  Created by T.Aso 30-Nov-2007
//  2019-04-04 T.Aso  Command for file format. fmtCmd.
//
//
//=============================================================

class G4MDumpInfoSDMessenger : public G4UImessenger{
  public:

    G4MDumpInfoSDMessenger(G4MDumpInfoSD* d);
    ~G4MDumpInfoSDMessenger();

    virtual void SetNewValue(G4UIcommand* command, G4String newValue);
    virtual G4String GetCurrentValue(G4UIcommand* command);

  private:
    G4UIdirectory* fDir;

    // DumpInfoSD
    G4UIcmdWithAString*       fopenCmd;
    G4UIcmdWithoutParameter*  fcloseCmd;
    G4UIcmdWithAString*  fFmtCmd;

    G4MDumpInfoSD *fSD;
};
#endif
