//========================================================================
// 
// Created by T.Aso
//
// (Modification)
// 2016-04-07 T.Aso TriggerBit 
//========================================================================
#ifndef G4MTrigBit_h
#define G4MTrigBit_h 1

#include <bitset>
typedef std::bitset<32> G4MTrigBit;

#endif
