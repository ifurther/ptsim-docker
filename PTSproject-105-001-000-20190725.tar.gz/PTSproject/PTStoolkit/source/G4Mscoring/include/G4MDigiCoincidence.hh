//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MDigiCoincidence,v 1.1 2006/08/22 08:09:37 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MDigiCoincidence
//
//  2016-03-11  T.Aso Created.
//
//====================================================================


#ifndef G4MDigiCoincidence_h
#define G4MDigiCoincidence_h 1

#include "G4MVDigitizerConstructor.hh"
#include "globals.hh"

class G4MDigiCoincidence : public G4MVDigitizerConstructor {

  public:
    G4MDigiCoincidence(const G4String& _name="", 
                        const G4String& _colname="");
    virtual ~G4MDigiCoincidence();

    virtual void Digitize();

  public:
    //
    void SetOffsetTime(G4double time){ Off_time = time; };
    G4double GetOffsetTime(){ return Off_time; };
    //
    void SetWindowTime(G4double tw){ Win_time = tw; };
    G4double GetWindow(){ return Win_time; };
    //
    void SetCoincidenceTime(G4double tw, G4double offset=0.)
    { Win_time = tw; Off_time = offset; };

    void SetCoincidenceEnergy(G4double ew, G4double offset=0.)
    { Win_energy = ew; Off_energy = offset; };

  protected:

  private:
   G4double  Win_time;
   G4double  Off_time;

   G4double  Win_energy;  
   G4double  Off_energy;

};


#endif
