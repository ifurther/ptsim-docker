//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MPCTHit.hh,v 1.1 2009/03/17 09:26:19 aso Exp $
// GEANT4 tag $Name:  $
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  23 Dec. 2010 T.Aso CreatePoint.
//  2015-06-05 T.Aso G4Allocator for G410.
//  2015-12-14 T.Aso Add Ke, mon.
//
//========================================================================
#ifndef G4MPCTHit_h
#define G4MPCTHit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"
//
class G4MPCTHit : public G4VHit {
public:

  G4MPCTHit();
  G4MPCTHit(const G4MPCTHit & right);
  ~G4MPCTHit();

  const G4MPCTHit & operator=(const G4MPCTHit & right);
  //G4int operator==(const G4MPCTHit & right) const;

  inline void * operator new(size_t);
  inline void operator delete(void * aHit);

  void Draw();
  void Print();

private:
  G4ThreeVector createPoint;
  G4ThreeVector hitPoint;
  G4double KE;
  G4ThreeVector momentum;
  G4int PID;
  G4int trackID;

  G4double weight;


public:
  void SetCreatePoint(const G4ThreeVector & _createPoint);
  G4ThreeVector GetCreatePoint() const;

  void SetHitPoint(const G4ThreeVector & _hitPoint);
  G4ThreeVector GetHitPoint() const;

  void SetKineticEnergy(G4double _e);
  G4double GetKineticEnergy() const;

  void SetMomentum(const G4ThreeVector & _p);
  G4ThreeVector GetMomentum() const;

  void SetPID(const G4int & _PID);
  G4int GetPID() const;

  void SetTrackID(const G4int & _trackID);
  G4int GetTrackID() const;

  void SetWeight(G4double w) { weight = w; }
  G4double GetWeight() const { return weight; }
  

};

typedef G4THitsCollection<G4MPCTHit> G4MPCTHitsCollection;

extern G4ThreadLocal G4Allocator<G4MPCTHit>* G4MPCTHitAllocator;

inline void * G4MPCTHit::operator new(size_t)
{
  if ( !G4MPCTHitAllocator ){
    G4MPCTHitAllocator = new G4Allocator<G4MPCTHit>;
  }
  void * aHit;
  aHit = (void *) G4MPCTHitAllocator->MallocSingle();
  return aHit;
}

inline void G4MPCTHit::operator delete(void * aHit)
{
  if ( !G4MPCTHitAllocator ){
    G4MPCTHitAllocator = new G4Allocator<G4MPCTHit>;
  }
  //
  G4MPCTHitAllocator->FreeSingle((G4MPCTHit *) aHit);
}

#endif


