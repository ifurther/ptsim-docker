//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
// 2015-06-11 T.Aso Created.
//////////////////////////////////////////////////////////////////////////
#ifndef G4MTrajectorySD_h
#define G4MTrajectorySD_h 1

#include "G4VSensitiveDetector.hh"
#include "G4MTrajectoryHit.hh"

class G4Step;
class G4HCofThisEvent;

//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  2015-01-02 T.Aso Created.
//
//========================================================================

class G4MTrajectorySD : public G4VSensitiveDetector {
public:
   G4MTrajectorySD(const G4String& name, 
             const G4String& hitsollectionName);
   virtual ~G4MTrajectorySD();

  virtual void Initialize(G4HCofThisEvent * HCE);
  virtual G4bool ProcessHits(G4Step * aStep, G4TouchableHistory * ROhist);
  virtual void EndOfEvent(G4HCofThisEvent * HCE);

public:
  void SetDepth(G4int depx, G4int depy, G4int depz)
  { fDepth[0]=depx; fDepth[1]=depy, fDepth[2]=depz; };

private:

  G4int fDepth[3];
  
  G4MTrajectoryHitsCollection* fHitsCollection;
};

#endif

