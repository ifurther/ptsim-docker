//
//---------------------------------------------------------------
//
// G4MTrajectoryPointHit.hh
//
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------

#ifndef G4MTrajectoryPointHit_h
#define G4MTrajectoryPointHit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "globals.hh"                // Include from 'global'
#include "G4ThreeVector.hh"          // Include from 'geometry'
#include "G4Allocator.hh"            // Include from 'particle+matter'

#include "G4MStepHit.hh"

///typedef std::vector<G4int>  G4MTrjSecTrkIDVec;

////////////////////////
class G4MTrajectoryPointHit : public G4VHit
//////////////////////// 
{

//--------
public: // without description
//--------

// Constructor/Destructor
   G4MTrajectoryPointHit();
   G4MTrajectoryPointHit(G4ThreeVector pos, G4double ke, G4ThreeVector mon,
                         G4double time, G4int voxel[3],
                         G4double edep, G4double stepL,G4double dose,
                         G4String definedProcName);
   G4MTrajectoryPointHit(G4MStepHit* aStepHit, G4int voxel[3],
                         G4double edep, G4double stepL, G4double dose,
                         G4String definedProcName);
   G4MTrajectoryPointHit(const G4MTrajectoryPointHit &right);
   virtual ~G4MTrajectoryPointHit();

// Operators
   inline void *operator new(size_t);
   inline void operator delete(void *aTrajectoryPoint);
   inline int operator==(const G4MTrajectoryPointHit& right) const
   { return (this==&right); };

// Get/Set functions
   inline void SetPosition(G4ThreeVector& pos) 
  { fStepHit->SetPosition(pos); };
   inline const G4ThreeVector& GetPosition() const
  { return fStepHit->GetPosition(); };

   inline void SetKineticEnergy(G4double ke) 
  { fStepHit->SetKineticEnergy(ke); };
   inline const G4double& GetKineticEnergy() const
  { return fStepHit->GetKineticEnergy(); };

   inline void SetMomentum(G4ThreeVector& mon) 
  { fStepHit->SetMomentum(mon); };
   inline const G4ThreeVector& GetMomentum() const
  { return fStepHit->GetMomentum(); };

   inline void SetGlobalTime(G4double time) 
  { fStepHit->SetGlobalTime(time); };
   inline const G4double& GetGlobaleTime() const
  { return fStepHit->GetGlobalTime(); };

  inline const G4MStepHit* GetStepHit()const
  { return fStepHit; };
  inline void GetVoxelID(G4int voxelID[3]) const
  { voxelID[0] = fVoxelID[0]; 
    voxelID[1] = fVoxelID[1]; 
    voxelID[2] = fVoxelID[2]; };
  inline const G4double& GetEnergyDepisit() const
  { return fEdep; };
  inline const G4double& GetStepLength() const
  { return fStepL; };
  //
  inline const G4String& GetDefinedStepProcessName() const
  { return fDefinedStepProcName; };

  ///  inline void AppendSecTrkID(G4int trkid)
  ///  { fSecTrkIDVec.push_back(trkid); };

  ///  inline const G4MTrjSecTrkIDVec& GetSecondartTrkIDVec() const
  ///  { return fSecTrkIDVec; };

//---------
   private:
//---------

// Member data
   G4MStepHit* fStepHit;
   G4int fVoxelID[3];
   G4double  fEdep, fStepL, fDose;
   G4String fDefinedStepProcName;
  ///   G4MTrjSecTrkIDVec fSecTrkIDVec;

 };

typedef G4THitsCollection<G4MTrajectoryPointHit> G4MTrajPointHitsCollection;

extern G4ThreadLocal
G4Allocator<G4MTrajectoryPointHit> *aTrajectoryPointAllocator;

inline void* G4MTrajectoryPointHit::operator new(size_t)
{
  if (!aTrajectoryPointAllocator)
  { aTrajectoryPointAllocator = new G4Allocator<G4MTrajectoryPointHit>; }
  return (void *) aTrajectoryPointAllocator->MallocSingle();
}

inline void G4MTrajectoryPointHit::operator delete(void *aTrajectoryPoint)
{
  if ( !aTrajectoryPointAllocator){
    aTrajectoryPointAllocator = new G4Allocator<G4MTrajectoryPointHit>;
  }
  aTrajectoryPointAllocator->FreeSingle((G4MTrajectoryPointHit *) aTrajectoryPoint);
}

#endif
