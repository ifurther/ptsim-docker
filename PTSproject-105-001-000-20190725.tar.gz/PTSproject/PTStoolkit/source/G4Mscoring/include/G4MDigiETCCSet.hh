//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
// 2017-12-25 T.Aso For DigiETCCSet
//
//========================================================================

#ifndef G4MDigiETCCSet_h
#define G4MDigiETCCSet_h 1

#include "G4VDigi.hh"
#include "G4TDigiCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"
#include "G4MDigiETCCGas.hh"
#include "G4MDigiETCCCrystal.hh"

class G4MDigi;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

class G4MDigiETCCSet : public G4VDigi
{

public:
  G4MDigiETCCSet();
  ~G4MDigiETCCSet();
  G4MDigiETCCSet(const G4MDigiETCCSet&);
  G4MDigiETCCSet(G4MDigi*);
  const G4MDigiETCCSet& operator=(const G4MDigiETCCSet&);
  int operator==(const G4MDigiETCCSet&) const;
  
  inline void* operator new(size_t);
  inline void  operator delete(void*);
  
  void Draw();
  void Print();

public:
  void     Clear();
  //
  void     AddDigiETCCGas(G4MDigiETCCGas* dc){ ETCCGasVec.push_back(dc);};
  G4int    NDigiETCCGas(){ return (G4int)ETCCGasVec.size(); };
  G4MDigiETCCGas* GetDigiETCCGas(G4int i) { return ETCCGasVec[i]; };
  void  SetDigiETCCGas(const std::vector<G4MDigiETCCGas*>& v){ ETCCGasVec=v; };
  const std::vector<G4MDigiETCCGas*>& GetDigiETCCGas(){ return ETCCGasVec; };
  //
  void     AddDigiETCCCrystal(G4MDigiETCCCrystal* dc){ ETCCCrystalVec.push_back(dc);};
  G4int    NDigiETCCCrystal(){ return (G4int)ETCCCrystalVec.size(); };
  G4MDigiETCCCrystal* GetDigiETCCCrystal(G4int i) { return ETCCCrystalVec[i]; };
  void  SetDigiETCCCrystal(const std::vector<G4MDigiETCCCrystal*>& v){ ETCCCrystalVec=v; };
  const std::vector<G4MDigiETCCCrystal*>& GetDigiETCCCrystal(){ return ETCCCrystalVec; };

private:
  // TPC Gas----
  // Primary Gamma-ray
  std::vector<G4MDigiETCCGas*> ETCCGasVec;
  //
  // Crystal
  std::vector<G4MDigiETCCCrystal*> ETCCCrystalVec;
 
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

typedef G4TDigiCollection<G4MDigiETCCSet> G4MDigiETCCSetCollection;

extern G4ThreadLocal G4Allocator<G4MDigiETCCSet> *G4MDigiETCCSetAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void* G4MDigiETCCSet::operator new(size_t)
{
  if (!G4MDigiETCCSetAllocator)
    G4MDigiETCCSetAllocator = new G4Allocator<G4MDigiETCCSet>;
  return (void*) G4MDigiETCCSetAllocator->MallocSingle();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void G4MDigiETCCSet::operator delete(void* aDigiETCCSet)
{
  G4MDigiETCCSetAllocator->FreeSingle((G4MDigiETCCSet*) aDigiETCCSet);
}

#endif






