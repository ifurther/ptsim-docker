#ifndef G4MWATERPHANTOMSD_HH
#define G4MWATERPHANTOMSD_HH

#include "G4VSensitiveDetector.hh"
#include "G4MDICOMHit.hh"
#include "G4MProcessType.hh"
#include "G4ThreeVector.hh"
#include <map>

//========================================================================
//
// Created by Kameoka based on G4MDICOMSD
//
// (Modification)
// Dec.01 2005 T.Aso Add G4MProcessType information for identify created
//                   process.
// Dec.25 2005 S.Kameoka: Modified to create a G4MDICOMHit object
//                        unique to the combination of voxelID and trackID.
// Dec.27 2005 S.Kameoka: Added member variables for charge and time.
// Aug.21 2006 T.Aso  Add member variable for particle weight.
// Jan.23 2008 T.Aso  Add member variable for dose.
// Sep.21 2010 T.Aso      Add Step length.
// 2013-10-29 T.Aso Flag bEdep.
// 2015-07-23 T.Aso Touchable depth
// 2015-12-14 T.Aso Ke and time.
// 2016-01-21 T.Aso parentTrkID
// 2016-01-21 T.Aso trigger bit, pos.
// 2016-07-16 T.Aso Default hitcol name.
//========================================================================

class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;

class G4MWaterPhantomSD : public G4VSensitiveDetector {
public:
  G4MWaterPhantomSD(const G4String &name,
                    const G4String &colname="HitsCollection");
  ~G4MWaterPhantomSD();

  void Initialize(G4HCofThisEvent * HCE);
  G4bool ProcessHits(G4Step * aStep, G4TouchableHistory * ROhist);
  void EndOfEvent(G4HCofThisEvent * HCE);
  void clear();
  void DrawAll();
  void PrintAll();

  G4bool IsNewEntry();
  G4bool IsEndOfEntry();

  void SetZeroEdep(G4bool b = true) { bEdep = b; }; 
  G4bool GetZeroEdep() { return bEdep; }; 

  void SetDepth(G4int d_x, G4int d_y, G4int d_z, G4int d_m=0, G4int d_s=0) 
  { fDepth[0] = d_x; fDepth[1] = d_y; fDepth[2] = d_z;
    fDepth[3] = d_m; fDepth[4] = d_s; }; 
  G4int GetDepth(G4int i)
  { return fDepth[i];};

private:
  G4int    doseHCID;
  G4String SDName;
  G4MDICOMHitsCollection * doseHCollection;

  G4MDICOMHit *       currentHit;
  G4Track *           track;
  G4VPhysicalVolume * currentPV;

  G4int fDepth[5];

  G4int PID;
  G4int theAtomicNumber;
  G4int theAtomicMass;
  G4int unitXID;
  G4int unitYID;
  G4int unitZID;
  G4int unitModID;
  G4int unitSecID;
  G4int trackID;
  G4int parentTrkID;

  G4StepPoint *        preStepPoint;
  G4StepPoint *        postStepPoint;
  G4TouchableHistory * touchable;
  G4double             EDeposit;
  G4double time;
  G4ThreeVector        hitPoint;
  G4ThreeVector        postPoint;
  G4ThreeVector        unitPoint;
  G4ThreeVector        primVertex;
  G4ThreeVector        momentum;
  G4double             incidentKinE;

  G4double  weight;

  G4double dose;

  G4double stepL;

  G4VUserTrackInformation* trackInfo;

  std::map<G4String, G4MDICOMHit *> hitmap;
  G4String key;

  G4bool bEdep;

private:
  void getStepInfo(G4Step * aStep);
  void createNewHit();
  void updateHit();
  void StoreHit(G4MDICOMHit * ahit);

};

#endif
