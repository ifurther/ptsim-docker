//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
#ifndef G4MDumpInfoSD_h
#define G4MDumpInfoSD_h 1

#include "G4VSensitiveDetector.hh"
#include <fstream>
#include <map>

class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;
class G4MParticleInfo;
class G4MDumpInfoSDMessenger;

//========================================================================
//
// Created by T.Aso
//
// (Modification)
//  30-Nov-2007 T.Aso Created for dump particle information.  
//  19-Mar-2008 T.Aso File IO in EndOfEventAction is performed
//                    Only if the file is opened. 
//                    Add method : 
//                        G4MDumpMap& GetDumpMap();
//                    User will be able to access the stored particle 
//                    information in UserEventAction via SensitiveDetector.
//  2017-03-15 T.Aso File IO for multithreading.
//  2-17-03-31 T.Aso Using FileNameManager.
//  2019-04-04 T.Aso Add fileformat.
//========================================================================

typedef std::map<int,G4MParticleInfo*>  G4MDumpMap;
class G4MDumpInfoSD : public G4VSensitiveDetector {
public:
   G4MDumpInfoSD(G4String name);
  ~G4MDumpInfoSD();

  void Initialize(G4HCofThisEvent * HCE);
  G4bool ProcessHits(G4Step * aStep, G4TouchableHistory * ROhist);
  void EndOfEvent(G4HCofThisEvent * HCE);
  void clear();
  void DrawAll();
  void PrintAll();

public:
    G4String& GetFileName(){return fileName;};
    G4MDumpMap& GetDumpMap(){ return HPmap; };
    void SetFileName(G4String& fname){ fileName = fname;};
    void Open(G4String& fname);
    void Close();

    void SetFileFormat(G4int flg){fileFormat = flg;};

private:
  G4String fileName;
  G4int    currentTrkID;
  std::ofstream outputFile;
  G4MDumpMap HPmap;
  G4int  fileFormat;  // 0=ASCII, 1=binary

  G4MDumpInfoSDMessenger* fMessenger ;
    
};

#endif

