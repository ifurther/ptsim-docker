//
//
// class G4MDigiMManager
//
// Class description:
//
//  Private Digi manager.
// 
// --------------------------------------------------------------------
//
// (Createrd) 
//
// (Modification)
//  2016-04-12  T.Aso
//  2016-07-14  T.Aso type.
// --------------------------------------------------------------------
//
#ifndef G4MDigiMANAGER_HH
#define G4MDigiMANAGER_HH

#include "globals.hh"                // Include from 'global'
class G4MVDigitizerConstructor;

class G4MDigiManager {
  public:
    static G4MDigiManager* GetPointer();

    virtual ~G4MDigiManager();

    static G4bool IsExist();

    G4MVDigitizerConstructor* Create(const G4String& name, 
                                     const G4String& type,
                                     const G4String& srccolname,
                                     const G4String& dstcolname,
                                     const G4String& sdname="");

    G4MVDigitizerConstructor* Combine(const G4String& name, 
                                     const G4String& type,
                                     const G4String& srccolname1,
                                     const G4String& srccolname2,
                                      const G4String& dstcolname);

  private:
    G4MDigiManager();
    static G4MDigiManager *ptrDGMgr;
};

// ====================================================================
// inline definition
// ====================================================================
inline G4MDigiManager* G4MDigiManager::GetPointer()
{
  if(!ptrDGMgr)  ptrDGMgr= new G4MDigiManager();
  return ptrDGMgr;
}

inline G4bool G4MDigiManager::IsExist()
{
  if ( ptrDGMgr ) return TRUE;
  else            return FALSE;
}
#endif 
