//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
// 2016-04-07 T.Aso For Digis 
//
//========================================================================
#ifndef G4MDigi_h
#define G4MDigi_h 1

#include "G4VDigi.hh"
#include "G4TDigiCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

class G4MDICOMHit;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

class G4MDigi : public G4VDigi
{

public:
  
  G4MDigi();
  ~G4MDigi();
  G4MDigi(const G4MDigi&);
  const G4MDigi& operator=(const G4MDigi&);
  int operator==(const G4MDigi&) const;
  
  inline void* operator new(size_t);
  inline void  operator delete(void*);
  
  void Draw();
  void Print();

public:
  void SetUnitID(G4int xid, G4int yid, G4int zid=-1,
                 G4int mid=-1, G4int sid=-1)
  {unitXID = xid; unitYID=yid; unitZID=zid; unitModID=mid; unitSecID=sid;};
  G4int GetUnitXID(){ return unitXID; };
  G4int GetUnitYID(){ return unitYID; };
  G4int GetUnitZID(){ return unitZID; };
  G4int GetUnitModID(){ return unitModID; };
  G4int GetUnitSecID(){ return unitSecID; };

  void ClearHitVec() { HitVec.clear(); };
  void AddHit(G4MDICOMHit* hit);
  G4int NHit(){ return (G4int)HitVec.size(); }
  G4MDICOMHit* GetHit(G4int i) { return HitVec[i]; };
  G4MDICOMHit* GetMajorHit();

  void     AddEdep(G4double edep);
  void     SetEdep(G4double edep){ Edeposit=edep; };
  G4double GetEdep();

  G4double GetTime();  // Major

  //
  void ComputeSignal(G4double tstart=0., G4double twindow=DBL_MAX);

  G4double GetEdepSig(){ return EdepSig; };
  G4ThreeVector& GetGlobalPosSig() { return GlobalPosSig; };
  G4double GetTimeSig();

  G4double GetByDcId(G4int dcid, const G4double unit=1.0, const G4int evno=0);
  G4int    GetByDcIdI(G4int dcid, const G4int evno=0);

private:
  G4int unitXID, unitYID, unitZID;
  G4int unitModID, unitSecID;

  G4double Edeposit;
  G4int    MaxEdepHitId;

  std::vector<G4MDICOMHit*> HitVec;

  //
  //  Filled by ComputeSignal()
  G4double      EdepSig;
  G4ThreeVector GlobalPosSig;
  G4int         MaxEdepSigId;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

typedef G4TDigiCollection<G4MDigi> G4MDigitsCollection;

extern G4ThreadLocal G4Allocator<G4MDigi> *G4MDigiAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void* G4MDigi::operator new(size_t)
{
  if (!G4MDigiAllocator)
    G4MDigiAllocator = new G4Allocator<G4MDigi>;
  return (void*) G4MDigiAllocator->MallocSingle();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void G4MDigi::operator delete(void* aDigi)
{
  G4MDigiAllocator->FreeSingle((G4MDigi*) aDigi);
}

#endif






