#ifndef G4MNestedDICOMSD_h
#define G4MNestedDICOMSD_h 1

#include "G4VSensitiveDetector.hh"
#include "G4MDICOMHit.hh"
#include "G4MProcessType.hh"

class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;

//========================================================================
//
// Created by T.Aso Feb.27 2007  for sampling in Nested Paramerisation
//
// (Modification)
// 
// Sep.21 2010 T.Aso      Add Step length.
// 2013-11-25 T.Aso Add process type, incidentKinE
// 2016-03-11 T.Aso Add time, parenttrkid, parentpid
// 2017-07-16 T.Aso Default collection name.
//
//========================================================================

class G4MNestedDICOMSD : public G4VSensitiveDetector {
public:
  G4MNestedDICOMSD(const G4String& name, 
                   const G4String& colname="HitsCollection");
  ~G4MNestedDICOMSD();

  void Initialize(G4HCofThisEvent * HCE);
  void resetID();
  G4bool ProcessHits(G4Step * aStep, G4TouchableHistory * ROhist);
  void EndOfEvent(G4HCofThisEvent * HCE);
  void clear();
  void DrawAll();
  void PrintAll();

  G4bool IsNewEntry();
  G4bool IsEndOfEntry();

  void SetDICOMFile(const G4String& file){fDICOMFileName=file;};

private:
  G4String fDICOMFileName;
  G4int    doseHCID;
  G4String SDName;
  G4MDICOMHitsCollection * doseHCollection;

  G4MDICOMHit *       currentHit;
  G4Track *           track;
  G4VPhysicalVolume * currentPV;

  G4int PID;
  G4int unitXID, currentXID;
  G4int unitYID, currentYID;
  G4int unitZID, currentZID;
  G4int trackID, currentTrackID;
  G4int parentTrkID;

  G4double weight;

  G4double dose;

  G4double stepL;

  G4VUserTrackInformation* trackInfo;

  G4StepPoint *        preStepPoint;
  G4StepPoint *        postStepPoint;
  G4TouchableHistory * touchable;
  G4double             EDeposit;
  G4double time;
  G4ThreeVector        hitPoint;
  G4ThreeVector        unitPoint;
  G4ThreeVector        primVertex;
  G4ThreeVector        momentum;
  G4double             incidentKinE;

private:
  void getStepInfo(G4Step * aStep);
  void createNewHit();
  void updateHit();
  void StoreHit(G4MDICOMHit * ahit);

};

#endif

