//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
//========================================================================
//
// Created by T.Aso
//
// (Modification)
// 2017-12-25 T.Aso For DigiETCCGas
//
//========================================================================

#ifndef G4MDigiETCCCrystal_h
#define G4MDigiETCCCrystal_h 1

#include "G4VDigi.hh"
#include "G4TDigiCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

class G4MDigi;
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

class G4MDigiETCCCrystal : public G4VDigi
{

public:
  
  G4MDigiETCCCrystal();
  ~G4MDigiETCCCrystal();

  inline void* operator new(size_t);
  inline void  operator delete(void*);
  
  void Draw();
  void Print();

public:

  void SetUnitID(G4int ix, G4int iy, G4int isub, G4int imod)
  { fIx = ix; fIy = iy; fIsub = isub; fImod = imod;};
  void SetPosition(const G4ThreeVector& xyz)
  { fXyz = xyz;  };
  void SetEdep(G4double de)
  { fDe = de; fNsum=0;};
  void AddEdep(G4double de)
  { fDe += de; fNsum++;};

  G4int GetXID() const { return fIx; };
  G4int GetYID() const { return fIy; };
  G4int GetSubID() const { return fIsub; };
  G4int GetModID() const { return fImod; };
  const G4ThreeVector& GetPosition() const { return fXyz; };
  G4double GetEdep() const { return fDe;};
  G4int GetNsum() const { return fNsum; };

private:
  // TPC Crystal----
  G4int fIx, fIy, fIsub, fImod;
  G4ThreeVector fXyz;
  G4double      fDe;
  G4int         fNsum;
};
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
typedef G4TDigiCollection<G4MDigiETCCCrystal> G4MDigiETCCCrystalCollection;
extern G4ThreadLocal G4Allocator<G4MDigiETCCCrystal> *G4MDigiETCCCrystalAllocator;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void* G4MDigiETCCCrystal::operator new(size_t)
{
  if (!G4MDigiETCCCrystalAllocator)
    G4MDigiETCCCrystalAllocator = new G4Allocator<G4MDigiETCCCrystal>;
  return (void*) G4MDigiETCCCrystalAllocator->MallocSingle();
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

inline void G4MDigiETCCCrystal::operator delete(void* aDigiETCCCrystal)
{
  G4MDigiETCCCrystalAllocator->FreeSingle((G4MDigiETCCCrystal*) aDigiETCCCrystal);
}

#endif
