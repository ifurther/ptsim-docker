//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MVDigitizerConstructor.hh,v 1.1 2006/08/22 08:09:37 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MVDigitizerConstructor
//
//  Digitizer module.
//  2016-03-11 T.Aso
//
//====================================================================


#ifndef G4MVDigitizerConstructor_h
#define G4MVDigitizerConstructor_h 1

#include "G4VDigitizerModule.hh"
#include "globals.hh"
#include "G4MDICOMHit.hh"
#include "G4MDigi.hh"

class G4MVDigitizerConstructor : public G4VDigitizerModule {

  public:
    G4MVDigitizerConstructor(const G4String& _name="", 
                             const G4String& _destcolname="");
    virtual ~G4MVDigitizerConstructor();

    virtual void Digitize()=0;

  public:
    void SetVerbose(G4int v=0){fVerbose = v; };
    void SetSrcColName(const G4String& name, const G4String& sdname="")
    { fSrcColName = name; fSrcSDName = sdname ;}
    const G4String& GetSrcColName(){return fSrcColName;}
  //

  protected:  
    G4int     fVerbose;
    G4String  fSrcColName;
    G4String  fSrcSDName;  // if Src is HitCollection
};

#endif
