//
//---------------------------------------------------------------
//
// G4MTrackHit.hh
//
// 2015-06-11 T.Aso Created.
// ---------------------------------------------------------------

#ifndef G4MTrackHit_h
#define G4MTrackHit_h 1

#include "G4VHit.hh"
#include "G4THitsCollection.hh"
#include "globals.hh"                // Include from 'global'
#include "G4ThreeVector.hh"          // Include from 'geometry'
#include "G4Allocator.hh"            // Include from 'particle+matter'

#include "G4MStepHit.hh"

////////////////////////
class G4MTrackHit : public G4VHit
//////////////////////// 
{

//--------
public: // without description
//--------

// Constructor/Destructor
   G4MTrackHit();
   G4MTrackHit(G4int trkid, G4int pid, 
               G4ThreeVector pos, G4double ke, G4ThreeVector mon,
               G4int parentTrkid=0, G4int parentPid=0);
   G4MTrackHit(G4int trkid, G4int pid, 
               G4MStepHit* aStepHit=0,
               G4int parentTrkid=0, G4int parentPid=0);
   G4MTrackHit(const G4MTrackHit &right);
   virtual ~G4MTrackHit();

// Operators
   inline void *operator new(size_t);
   inline void operator delete(void *aTrackHit);
   inline int operator==(const G4MTrackHit& right) const
   { return (this==&right); };

// Get/Set functions
   inline void SetTrkID(G4int trkid) 
   { fTrackID=trkid; };
   inline const G4int& GetTrkID() const
   { return fTrackID; };

   inline void SetPID(G4int pid) 
   { fPID=pid; };
   inline const G4int& GetPID() const
   { return fPID; };

   inline void SetParentTrkID(G4int parentid) 
   { fParentTrackID=parentid; };
   inline const G4int& GetParentTrkID() const
   { return fParentTrackID; };

   inline void SetParentPID(G4int parentPID) 
   { fParentPID=parentPID; };
   inline const G4int& GetParentPID() const
   { return fParentPID; };

   inline void SetPosition(G4ThreeVector& pos) 
  { fStepHit->SetPosition(pos); };
   inline const G4ThreeVector& GetPosition() const
  { return fStepHit->GetPosition(); };

   inline void SetKineticEnergy(G4double ke) 
  { fStepHit->SetKineticEnergy(ke); };
   inline const G4double& GetKineticEnergy() const
  { return fStepHit->GetKineticEnergy(); };

   inline void SetMomentum(G4ThreeVector& mon) 
  { fStepHit->SetMomentum(mon); };
   inline const G4ThreeVector& GetMomentum() const
  { return fStepHit->GetMomentum(); };

//---------
   private:
//---------

// Member data
   G4int fTrackID;
   G4int fPID;

   G4MStepHit* fStepHit;

   G4int fParentTrackID;
   G4int fParentPID;

};

typedef G4THitsCollection<G4MTrackHit> G4MTrackHitsCollection;

extern G4ThreadLocal
G4Allocator<G4MTrackHit> *aTrackHitAllocator;

inline void* G4MTrackHit::operator new(size_t)
{
  if (!aTrackHitAllocator)
  { aTrackHitAllocator = new G4Allocator<G4MTrackHit>; }
  return (void *) aTrackHitAllocator->MallocSingle();
}

inline void G4MTrackHit::operator delete(void *aTrackHit)
{
  if ( !aTrackHitAllocator){
    aTrackHitAllocator = new G4Allocator<G4MTrackHit>;
  }
  aTrackHitAllocator->FreeSingle((G4MTrackHit *) aTrackHit);
}

#endif
