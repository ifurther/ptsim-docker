#ifndef G4MDICOMSD_h
#define G4MDICOMSD_h 1

#include "G4VSensitiveDetector.hh"
#include "G4MDICOMHit.hh"

class G4Step;
class G4HCofThisEvent;
class G4TouchableHistory;

//========================================================================
//
// Created by A.Kimura
//
// (Modification)
// Dec.01 2005 T.Aso Add SetDICOMFile() method to change DICOMFile name.
// 2015-12-14  T.Aso      Add Momentum and time.
//                        
//
//========================================================================

class G4MDICOMSD : public G4VSensitiveDetector {
public:
  G4MDICOMSD(G4String name);
  ~G4MDICOMSD();

  void Initialize(G4HCofThisEvent * HCE);
  void resetID();
  G4bool ProcessHits(G4Step * aStep, G4TouchableHistory * ROhist);
  void EndOfEvent(G4HCofThisEvent * HCE);
  void clear();
  void DrawAll();
  void PrintAll();

  G4bool IsNewEntry();
  G4bool IsEndOfEntry();

  void SetDICOMFile(const G4String& file){fDICOMFileName=file;};

private:
  G4String fDICOMFileName;
  G4int    doseHCID;
  G4String SDName;
  G4MDICOMHitsCollection * doseHCollection;

  G4MDICOMHit *       currentHit;
  G4Track *           track;
  G4VPhysicalVolume * currentPV;

  G4int PID;
  G4int unitXID, currentXID;
  G4int unitYID, currentYID;
  G4int unitZID, currentZID;
  G4int trackID, currentTrackID;

  G4double weight;

  G4double dose;

  G4StepPoint *        preStepPoint;
  G4StepPoint *        postStepPoint;
  G4TouchableHistory * touchable;
  G4double             EDeposit;
  G4double             time;
  G4ThreeVector        hitPoint;
  G4ThreeVector        postPoint;
  G4ThreeVector        unitPoint;
  G4ThreeVector        primVertex;
  G4ThreeVector        momentum;
  G4double             incidentKinE;
  G4double             exitKinE;

private:
  void getStepInfo(G4Step * aStep);
  void createNewHit();
  void updateHit();
  void StoreHit(G4MDICOMHit * ahit);

};

#endif

