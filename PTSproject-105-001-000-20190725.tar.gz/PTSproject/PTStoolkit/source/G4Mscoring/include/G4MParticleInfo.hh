//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
#ifndef G4MParticleInfo_h
#define G4MParticleInfo_h 1

#include "globals.hh"
#include "G4ParticleDefinition.hh"
#include "G4ThreeVector.hh"

//=============================================================
// class desccription:
//
//  This class is exclusively used for DumpSD.
//
//  Created by T.Aso 30-Nov-2007
//
//
//
//=============================================================
//
//

class G4MParticleInfo 
{
  public:

    G4MParticleInfo(G4ParticleDefinition* pp);
    ~G4MParticleInfo();

  private:
      G4ParticleDefinition * theParticle;
      G4ThreeVector position; 
      G4double      time;
      G4ThreeVector momentum; 
      G4ThreeVector polarization; 

  public:
    inline G4ParticleDefinition * GetParticle() {return theParticle;};
    inline G4ThreeVector& GetPosition(){return position;};
    inline G4double GetTime() {return time;};
    inline G4ThreeVector& GetMomentum() {return momentum;};
    inline G4ThreeVector& GetPolarization()  {return polarization;};

    inline void SetParticle(G4ParticleDefinition* p ) {theParticle=p;};
    inline void SetPosition(const G4ThreeVector& p ) {position=p;};
    inline void SetTime(G4double  t) {time = t;};
    inline void SetMomentum(const G4ThreeVector& m) { momentum = m;};
    inline void SetPolarization(const G4ThreeVector& p) { polarization=p;};
};



#endif

