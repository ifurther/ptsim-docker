//
//
// class G4MSDMManager
//
// Class description:
//
//  Private SD manager.
// 
// --------------------------------------------------------------------
//
// (Createrd) 
//
// (Modification)
//  2016-04-12  T.Aso
//  2016-07-16  T.Aso geometry depth index.
// --------------------------------------------------------------------
//
#ifndef G4MSDMANAGER_HH
#define G4MSDMANAGER_HH

#include "globals.hh"                // Include from 'global'
class G4LogicalVolume;

class G4MSDManager {
  public:
    static G4MSDManager* GetPointer();

    virtual ~G4MSDManager();

    static G4bool IsExist();

    void CreateSD(G4String& sdname, G4String& colname, G4bool flgedep=true,
                  G4int dep_x=0, G4int dep_y=0, G4int dep_z=0, 
                  G4int dep_m=0, G4int dep_s=0);
    void SetDepthSD(G4String& sdname, 
                  G4int dep_x=0, G4int dep_y=0, G4int dep_z=0, 
                  G4int dep_m=0, G4int dep_s=0);
    void SetEdepSD(G4String& sdname,G4bool flgedep=true);

    void SetStepSD(G4String& sdname,G4bool flgstep=true);

    void AttachSD(G4String& sdname, G4LogicalVolume* lv);
    void DetachSD(G4LogicalVolume* lv);
    void AttachTrgSD(G4String& sdname, G4LogicalVolume* lv, G4int id=0);
    void Show();

  private:
    G4MSDManager();
    static G4MSDManager *ptrSDMgr;
};

// ====================================================================
// inline definition
// ====================================================================
inline G4MSDManager* G4MSDManager::GetPointer()
{
  if(!ptrSDMgr)  ptrSDMgr= new G4MSDManager();
  return ptrSDMgr;
}

inline G4bool G4MSDManager::IsExist()
{
  if ( ptrSDMgr ) return TRUE;
  else            return FALSE;
}
#endif /* G4MSDMANAGER_HH */
