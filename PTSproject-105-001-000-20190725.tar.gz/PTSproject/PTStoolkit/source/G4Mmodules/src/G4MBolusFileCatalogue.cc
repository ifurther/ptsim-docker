//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MBolus.
// 
//  (History)
//   22-JAN-07   T.Aso
//   10-Aug-10   T.Aso  File format was modified. 
//                      Introduce drillPicth for smearing. Originally,
//                      this was used for NCC, but now it moved to 
//                      standard.
//---------------------------------------------------------------------
//
#include "G4MBolusFileCatalogue.hh"
#include "G4MBolus.hh"
#include <fstream>

G4MBolusFileCatalogue::G4MBolusFileCatalogue(const G4String& name,
					     const G4String& filename)
  :G4MVBolusCatalogue(name),fDefaultFileName(filename){
  fDrillPitch = 0.0;
}

G4MBolusFileCatalogue::~G4MBolusFileCatalogue()
{}

void G4MBolusFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDxyzBolus,
			    fMatBolus,fNx,fNy,fx0,fy0,fPitchX,fPitchY,
			    theThickness);
}

void G4MBolusFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio(pname);
  if(!fileio) { 
    G4cerr << "File Not Found " << pname << G4endl;
  }else{
    theThickness.clear();

    G4int verbose = fModule->GetVerbose();
    
    G4double dx,dy,dz;
    fileio >> dx >> dy >> dz;  // Full size of Bolus frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    dz *= ( mm/2. );
    fDxyzBolus.setX(dx);
    fDxyzBolus.setY(dy);
    fDxyzBolus.setZ(dz);
    
    fileio>>   fMatBolus;       // Material of Bolus
    fileio >> fNx >> fNy ;      // Dimension of drill hole.

    fileio >> fx0 >> fy0;       // Offset of first point.
    fx0 *= mm;
    fy0 *= mm;

    fileio >> fPitchX >> fPitchY;  // Drill pitch in x,y (mm)
    fPitchX *= mm;
    fPitchY *= mm;

    fileio >> fDrillPitch;
    fDrillPitch *= mm;

    G4double t;
    for ( G4int iy = 0; iy < fNy; iy++){
	for ( G4int ix = 0; ix < fNx; ix++){
	    fileio >> t;
	    t *= mm;
	    theThickness.push_back(t);
	    if ( verbose > 0 ) G4cout << t <<  " " ;
	}
	if ( verbose > 0 ) G4cout << G4endl;
    }
    fileio.close();
    if ( fDrillPitch > fPitchX || fDrillPitch > fPitchY ) Smearing();
  }
}

void G4MBolusFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyzBolus,fMatBolus,
			    fNx,fNy,fx0,fy0,fPitchX,fPitchY,
			    theThickness);
   fModule->ReBuild();
}

void G4MBolusFileCatalogue::Smearing(){
  G4int verbose = fModule->GetVerbose();
  //
  // Smearing Drill hole with drill size.
  //
  G4double xpitch = fPitchX;
  G4double ypitch = fPitchY;
  G4int iXSmear = (G4int)(fDrillPitch/xpitch/2.);
  G4int iYSmear = (G4int)(fDrillPitch/ypitch/2.);
  //
  //
   std::vector<G4double> tmpVec(theThickness.begin(),theThickness.end());
   G4int nx = fNx;
   G4int ny = fNy;
   G4double dZ = fDxyzBolus.z() * 2.;
   for ( G4int iy = 0; iy < ny; iy++){
     for ( G4int ix = 0; ix < nx; ix++){
       // Examimed center.
       G4int index = iy*nx+ix;
       G4double ThisHeight = tmpVec[index];
       if ( ThisHeight >= dZ ) continue;
       // Smearing region
       for ( G4int j = -iYSmear; j <=iYSmear; j++){
	 if (iy + j < 0 || iy + j >= ny) continue;  //!!!
	 for ( G4int i = -iXSmear; i <=iXSmear ; i++){
	   if (ix + i < 0 || ix + i >= nx) continue; //!!!
	   G4int jndex = ( iy+j )*nx+(ix+i);
	   if ( tmpVec[jndex] > tmpVec[index] ) {
	     if ( theThickness[jndex] > tmpVec[index] ){
	       if ( verbose > 0 ) {
	       G4cout << " Bolus Smear "<< index <<" " << jndex
		      << " org "<<tmpVec[jndex]
		      << " from "<<theThickness[jndex] 
		      << " to "  <<tmpVec[index] <<G4endl;
	       }
	       theThickness[jndex] = tmpVec[index];
	     }
	   } // 
	 }   // loop 3x3 j (y)
       }     // loop 3x3 i (x)
     } // loop (ix) 
   }   // loop (iy)
   //G4cout << " iXSmear " << iXSmear << " iYSmear "<< iYSmear<<G4endl;
}



 
