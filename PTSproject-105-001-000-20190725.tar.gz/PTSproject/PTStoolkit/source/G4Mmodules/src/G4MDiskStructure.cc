//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shaped structure 
//
// (HISTORY)  
//   22-JAN-07 T.Aso Add VisAttributes
//
//---------------------------------------------------------------------
//
#include "G4MDiskStructure.hh"
#include "G4Tubs.hh"
#include "G4PVPlacement.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MDiskStructure::G4MDiskStructure(const G4String &name) 
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MDiskStructure::G4MDiskStructure(const G4String &name,
				   const std::vector<G4double>& DRs,
				   const std::vector<G4double>& DZs,
				   const std::vector<G4double>& Zs,
				   const std::vector<G4String> &mats)
  : G4MVBeamModule(name,G4ThreeVector(0.0,DRs[0],DZs[0])),
    fDrs(DRs),fDzs(DZs),fZs(Zs),fMatNames(mats),
    fCatalogue(NULL)
{
    for ( G4int i = 0; i < (G4int)fDrs.size(); i++){
	fStartAngles.push_back(0.*degree);
	fEndAngles.push_back(360.*degree);
    }
}

G4MDiskStructure::G4MDiskStructure(G4MVDiskStructureCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MDiskStructure::~G4MDiskStructure()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MDiskStructure::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MDiskStructure::SetAllParameters(const std::vector<G4double>& DRs,
					const std::vector<G4double>& DZs,
					const std::vector<G4double>& Zs,
					const std::vector<G4String> &mats)
{
   fDrs=DRs;
   fDzs=DZs;
   fZs=Zs;
   fMatNames=mats;
   fStartAngles.clear();
   fEndAngles.clear();
   for ( G4int i = 0; i < (G4int)fDrs.size(); i++){
       fStartAngles.push_back(0.*degree);
       fEndAngles.push_back(360.*degree);
   }
   fEnvelopeSize.set(0.0,fDrs[0],fDzs[0]);
}

void G4MDiskStructure::SetAllParameters(const std::vector<G4double>& DRs,
					const std::vector<G4double>& DZs,
					const std::vector<G4double>& StartAng,
					const std::vector<G4double>& EndAng,
					const std::vector<G4double>& Zs,
					const std::vector<G4String>& mats)
{
   fDrs = DRs;
   fZs  = DZs;
   fZs  = Zs;
   fMatNames = mats;
   fStartAngles = StartAng;
   fEndAngles   = EndAng;
   fEnvelopeSize.set(0.0,fDrs[0],fDzs[0]);
}

G4VPhysicalVolume* G4MDiskStructure::buildEnvelope(G4LogicalVolume *worldlog)
{
  if (fMatNames.empty()) {
    G4Exception("G4MDiskStructure::buildEnvelope()","G4MDiskSt00",
		FatalException,"vector fMatNames is empty");
  }
  G4Material *matEnv = G4Material::GetMaterial(fMatNames[0]);

  if (fDrs.empty()) {
    G4Exception("G4MDiskStructure::buildEnvelope()","G4MDiskSt00",
		FatalException,"vector fDrs is empty");
  }
  G4Tubs *solEnv = new G4Tubs(GetName(), 0, fDrs[0], fDzs[0], 0, twopi);

  G4LogicalVolume *logEnv = new G4LogicalVolume(solEnv,
						matEnv,
						GetName());

  logEnv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(
						   GetRotation(),
						   GetTranslation(),
						   logEnv,
						   GetName(),
						   worldlog,
						   false,
						   0);
  return physical;
}

void G4MDiskStructure::buildNode(G4VPhysicalVolume* physvol)
{
  G4LogicalVolume *logMother = physvol->GetLogicalVolume();

  if (fDrs.size() != fMatNames.size())
    G4Exception("G4MDiskStructure::buildEnvelope()","G4MDiskSt00",
                FatalException,"vectors fDrs and fMatNames do not match in size");
  
  for (size_t i = 1; i < fDrs.size(); ++i) {
    G4Material *mat = G4Material::GetMaterial(fMatNames[i]);
    G4Tubs *solid =
      new G4Tubs(GetName(), 0, fDrs[i], fDzs[i], 
		 fStartAngles[i], fEndAngles[i]);
    G4LogicalVolume *lv = new G4LogicalVolume(solid,
					      mat,
					      GetName());
    new G4PVPlacement(0, G4ThreeVector(0, 0, fZs[i]), lv, 
		      GetName(), logMother,false, 0);

    if (i==1) lv->SetVisAttributes(new G4VisAttributes(G4Colour(0.95,0.95,0.95)));
    else if (i==2)lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));
    else if (i==3)lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));
    logMother = lv;
  }
}
