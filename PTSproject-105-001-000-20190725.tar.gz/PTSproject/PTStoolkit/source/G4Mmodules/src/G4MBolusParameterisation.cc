//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
//---------------------------------------------------------------------
// (Description)
//    Class for parameterisation of G4MBolus.
//    This class realizes Bolus structure using parameterisation.
//    The Air(Drill) hole is parameterised.
//
// (HISTORY)
// 2012-06-06  T.Aso  direction of axis in x,y.
//
//---------------------------------------------------------------------
//
#include "G4MBolusParameterisation.hh"
#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"

//#define debug
//#define pdebug

//
G4MBolusParameterisation::
G4MBolusParameterisation(G4int nx, G4int ny,
			 G4double xpit,G4double ypit, G4double zpit,
			 G4double x0, G4double y0, G4Material* mat,
			 G4int ixdir, G4int iydir):
  fpX(NULL),fpY(NULL),fpZ(NULL),fvalZ(NULL){
  fx0 = x0;
  fy0 = y0;
  fNx = nx;
  fNy = ny;
  fxPitch  =xpit;
  fyPitch  =ypit;
  fzPitch  =zpit;

  fNofVolume = 0;
  fmat = mat;

  xdir = ixdir;
  ydir = iydir;
}

G4MBolusParameterisation::~G4MBolusParameterisation(){
  delete fpX;
  delete fpY;
  delete fpZ;
  delete fvalZ;
}

void G4MBolusParameterisation::SetPitch(G4double px, G4double py,G4double pz){
  fxPitch = px;
  fyPitch = py;
  fzPitch = pz;
}

void G4MBolusParameterisation::SetNxy(G4int nx, G4int ny){
  fNx = nx;
  fNy = ny;
}


void G4MBolusParameterisation::CalculateActiveVolume(std::vector<G4double>& zval){

  // zval must be a FULL thickness of Polythylene.
  // But Parameterisation do Air image.
  if ( (G4int)zval.size() != (fNx*fNy)  ) {
    G4Exception("G4MBolusParameterisation::SetZValue","G4MBolusParam00",
		FatalException,"Array Length Missmatch");
  }

  G4int n = zval.size();
  G4int nActive=0;
  for ( G4int i = 0; i < n ; i++ ) if ( zval[i] < fzPitch ) nActive++;
  fpX=new G4double[nActive];
  fpY=new G4double[nActive];
  fpZ=new G4double[nActive];
  fvalZ = new G4double[nActive];

  fNofVolume = 0;
  for ( G4int i = 0; i < n ; i++) {
    G4double zAirThick = fzPitch - zval[i];
    if ( zAirThick > 0. ) {  
      fpX[fNofVolume]= fx0 + (i%fNx)*fxPitch*xdir;
      fpY[fNofVolume]= fy0 + (i/fNx)*fyPitch*ydir;
      fpZ[fNofVolume]= +(fzPitch-zAirThick)/2.;    // Air Position.
      fvalZ[fNofVolume]=zAirThick;
#ifdef debug
      G4cout << "xdir " <<xdir<<" ydir "<<ydir<<G4endl;
      G4cout << fNofVolume <<" "<<fpX[fNofVolume]/mm
	     <<" "<<fpY[fNofVolume]/mm << " " << fpZ[fNofVolume]/mm
	     <<" "<<fvalZ[fNofVolume]/mm << G4endl;
#endif
      fNofVolume++;
    }
  }
}

G4int G4MBolusParameterisation::GetNofActiveVolume(){ return fNofVolume; }

void G4MBolusParameterisation::ComputeTransformation
(const G4int copyNo,  G4VPhysicalVolume* physVol)const{
  G4ThreeVector position(fpX[copyNo],fpY[copyNo],fpZ[copyNo]);
  physVol->SetTranslation(position);
}

void G4MBolusParameterisation::ComputeDimensions(G4Box & boxel, 
					       const G4int copyNo,
					       const G4VPhysicalVolume*) const{
  boxel.SetXHalfLength(fxPitch/2.);
  boxel.SetYHalfLength(fyPitch/2.);
  boxel.SetZHalfLength(fvalZ[copyNo]/2.);
}

G4Material* G4MBolusParameterisation::ComputeMaterial (const G4int, 
						       G4VPhysicalVolume*,
						       const G4VTouchable*)
{
  return fmat;
}

