//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for TubsMonitor
// 
//  (History)
//   06-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
//
#include "G4MTubsMonitorFileCatalogue.hh"
#include "G4MTubsMonitor.hh"
#include <fstream>

G4MTubsMonitorFileCatalogue::
G4MTubsMonitorFileCatalogue(const G4String& name,
			    const G4String& fileName)
  :G4MVTubsMonitorCatalogue(name),fDefaultFileName(fileName),fVerbose(0){
}

G4MTubsMonitorFileCatalogue::~G4MTubsMonitorFileCatalogue()
{}

void G4MTubsMonitorFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fRin,fRout,fDz,fMaterial,fZ,fMasterMat);
}

void G4MTubsMonitorFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File not found "+pname;
    G4Exception("G4MTubsMonitorFileCatalogue::Prepare()","G4MTubsMonFileCata00",
		FatalException,msg);
  }else{
    G4int nPlate = 0;
    // Master Volume's Material.
    fileio >> fMasterMat >> nPlate;
    fRin.clear();
    fRout.clear();
    fDz.clear();
    fMaterial.clear();
    fZ.clear();
    G4double rin,rout,dz,z;
    G4String mat;
    if (fVerbose > 0 ) G4cout << fMasterMat << " " << nPlate <<G4endl;
    for ( G4int i = 0; i < nPlate; i++){
      fileio >> mat >> rin >> rout >> dz >> z ;
      if ( fVerbose > 0 ) {
	G4cout << mat <<" "<<rin<<" "<<rout<<" "<<dz<<" "<<z<<G4endl;
      }
      rin  *= mm;
      rout *= mm;
      dz   *= (mm/2.);  // Full width to half width.
      z    *= mm;
      fRin.push_back(rin);
      fRout.push_back(rout);
      fDz.push_back(dz);
      fMaterial.push_back(mat);
      fZ.push_back(z);
    }
  }
}

void G4MTubsMonitorFileCatalogue::Apply(){
  fModule->SetAllParameters(fRin,fRout,fDz,fMaterial,fZ,fMasterMat);
  fModule->ReBuild();
}
