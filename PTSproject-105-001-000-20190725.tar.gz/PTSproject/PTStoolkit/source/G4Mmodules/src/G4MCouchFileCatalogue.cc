//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------//
//  (Desctiption)
//   This is a class for catalogue of parameters for Couch
// 
//  (History)
// 2014-02-07 T.Aso Created.
// 2014-03-11 T.Aso Suppress stdout.
//
//---------------------------------------------------------------------//
//
#include "G4MCouchFileCatalogue.hh"
#include "G4MCouch.hh"
#include <fstream>

G4MCouchFileCatalogue::
G4MCouchFileCatalogue(const G4String& name,
                             const G4String& fileName)
  :G4MVCouchCatalogue(name),fDefaultFileName(fileName)
{}

G4MCouchFileCatalogue::~G4MCouchFileCatalogue()
{}

void G4MCouchFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fDxyz,fY,fMaterial);
}

void G4MCouchFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File Not Found " + pname;
    G4Exception("G4MCouchFileCatalogue::Prepare()","G4MBoxStructFileCata00",
                FatalException,msg);
  }else{
    G4int nPlate = 0;
    // Number of Plate
    fileio >> nPlate;
    fDxyz.clear();
    fY.clear();
    fMaterial.clear();
    G4double dx,dy,dz,y;
    G4String mat;
    for ( G4int i = 0; i < nPlate; i++){
      fileio >> mat >> dx >> dy >> dz >> y ;
      //G4cout << mat <<" "<<dx<<" " <<dy<<" "<<dz<<" "<<y<<G4endl;
      dx *= (mm/2.);
      dy *= (mm/2.);
      dz   *= (mm/2.);  // Full width to half width.
      y    *= mm;
      G4ThreeVector dxyz(dx,dy,dz);
      fDxyz.push_back(dxyz);
      fY.push_back(y);
      fMaterial.push_back(mat);
    }
  }
}

void G4MCouchFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyz,fY,fMaterial);
  fModule->ReBuild();
}
