//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    DICOM Module for Nested Parameterisation with ROI material 
//   assignment.
//
// (HISTORY)
//  2012-06-29 T.Aso Copied from G4MNestedDICOM
//  2012-07-02 T.Aso Construct a patient geometry using CT images and
//                   ROI. G4MDICOMRTS is requested.
//  2013-03-26 T.Aso G4MDICOMRTS was moved to G4MVDICOM.
//  2014-02-04 T.Aso Row and Column was fixed to represent Y and X.
//  2015-06-25 T.Aso SetLabel(False),override=false.
//  2016-12-21 T.Aso PrepareDICOM(), GetLabelVec().
//   2017-03--15 T.Aso Threading                    
// 2019-04-04 T.Aso SDName was replaced from "G4MDICOM" to the beam module name.
// -----------------------------------------------------------------
// 
#include "G4MNestedROIDICOM.hh"

#include "G4MDICOMHandler.hh"
#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"
#include "G4MDICOMCT2Density.hh"
#include "G4MDICOMROISelector.hh"

#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Element.hh"
#include "G4Transform3D.hh"
#include "G4PVReplica.hh" 
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4Element.hh"
#include "G4SDManager.hh"

#include "G4VisAttributes.hh"

#include "G4MDicomNestedROIParameterisation.hh"

#include "G4MNestedDICOMSD.hh"

#include <cmath>

G4MNestedROIDICOM::G4MNestedROIDICOM(G4String name) 
  :G4MVDICOM(name)
{}

G4MNestedROIDICOM::G4MNestedROIDICOM(G4MVDICOMCatalogue* catalogue)
  : G4MVDICOM(catalogue->GetName())
{}

G4MNestedROIDICOM::~G4MNestedROIDICOM()
{}

void G4MNestedROIDICOM::buildNode(G4VPhysicalVolume* physvol) {
  //-- Open DICOM Handler---------------------------------------
  G4MDICOMConfiguration* config=
    G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  //--------------------------------------------------------------

  //std::vector<short> label;
  G4bool  override=false;
  SetLabel(false); // Outline extraction set to false.
  //G4MDICOMData* dicomData = PrepareDICOM(label,override);
  G4MDICOMData* dicomData = PrepareDICOM(override);
  std::vector<short>& label = GetLabelVec();
  //
  G4MDICOMCTROI2Material* matList = PrepareMatListROI();
  //
  //20130314 T.Aso replaced with the material of envelope.
  //G4Material* air = G4Material::GetMaterial("Air");//Dummy material.
  //
  G4MDicomNestedROIParameterisation*
    param = new G4MDicomNestedROIParameterisation(dicomData,label,matList,
                                                  fDicomRTS,fEnvMat);

  // ------------------------------------------------
  //CT-Density (Prepare For Dose Calculation) 
  G4MDICOMCT2Density filterDensity(fFileCT2Density);
  config->DoFiltering(filterDensity);   
  //G4Material* air = G4Material::GetMaterial("Air");
  //G4MDICOMROISelector filterROISelector(fDicomRTS,air->GetDensity()/(g/cm3));
  //filterROISelector.SetROINumber(1);
  //filterROISelector.SetROINumber(5);
  //filterROISelector.SetROINumber(6);
  //filterROISelector.SetROINumber(7);
  //filterROISelector.SetROINumber(8);
  //filterROISelector.SetROINumber(9);
  //filterROISelector.SetROINumber(10);
  //config->DoFiltering(filterROISelector);
  // ------------------------------------------------
  //
  dicomData->ShowParameters();
  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double sliceThickness = dicomData->GetZPixelSPC();
  G4int    totalRows      = dicomData->GetRow(); 
  G4int    totalColumns   = dicomData->GetColumn();
  G4int    totalSlices    = dicomData->GetSlice();
  G4double tissueX        = (xPixelSpacing/2.) *mm;
  G4double tissueY        = (yPixelSpacing/2.) *mm;
  G4double tissueZ        = (sliceThickness/2.) *mm;
  //
  G4ThreeVector dxyz      = dicomData->GetDxyz()*mm;
  G4double dX             = dxyz.x();
  G4double dY             = dxyz.y();
  G4double dZ             = dxyz.z();


  G4cout << "**** Nested ROI DICOM "<<G4endl;
  G4cout << "* G4MDicom NestedVolume Half length (mm)" 
         << " x " << dX/mm 
         << " y " << dY/mm
         << " z " << dZ/mm << " mm" << G4endl;
  G4cout << " row " << totalRows << " column " << totalColumns
         << " slice " << totalSlices<<G4endl;
  //
  //
  //
  G4String nestName(GetName()+"Nest");
  //
  G4LogicalVolume* logNest = physvol->GetLogicalVolume();
  //
  G4String nestZName(GetName()+"NestZ");
  G4Box* nestZ = new G4Box(nestZName, dX, dY, tissueZ);
  G4LogicalVolume* logNestZ = new G4LogicalVolume(nestZ, fEnvMat, nestZName);
  //logNestZ->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.0,0.0)));
  logNestZ->SetVisAttributes(G4VisAttributes::Invisible);
  //G4PVReplica* zReplica =
  new G4PVReplica(nestZName,logNestZ,logNest,kZAxis,totalSlices,sliceThickness);
  //
  G4String nestXName(GetName()+"NestX");
  G4Box* nestX = new G4Box(nestXName, tissueX, dY, tissueZ);
  G4LogicalVolume* logNestX = new G4LogicalVolume(nestX, fEnvMat, nestXName);
  //logNestX->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));
  logNestX->SetVisAttributes(G4VisAttributes::Invisible);
  //G4PVReplica* xReplica =
  //new G4PVReplica(nestXName,logNestX,logNestZ,kXAxis,totalRows,xPixelSpacing);
  new G4PVReplica(nestXName,logNestX,logNestZ,kXAxis,totalColumns,xPixelSpacing);
  //
  //
  G4cout << " G4MDicom Tissue Half length (mm)" 
         << " x " << tissueX/mm 
         << " y " << tissueY/mm
         << " z " << tissueZ/mm << G4endl;
  //
  //
  G4String voxelName(GetName()+"Voxel");
  G4Box* voxel = new G4Box(voxelName, tissueX, tissueY, tissueZ);
  G4LogicalVolume* logVoxel = new G4LogicalVolume(voxel, fEnvMat, voxelName);
  //logVoxel->SetVisAttributes(G4VisAttributes::Invisible);
  G4cout << " G4MDicom NofVolume " << param->GetNofVolume() <<G4endl;
  //
  //G4VPhysicalVolume* physVoxel = 
  new G4PVParameterised(voxelName,
                        logVoxel,
                        logNestX,
                        kUndefined,
                        param->GetNofVolume(), 
                        param );
  G4cout << " G4MDicom NofVolume " << param->GetNofVolume() <<G4endl;
  fSdLVList.push_back(logVoxel);
}

void G4MNestedROIDICOM::BuildInSDandField() {
  G4String SDName = GetName();
  SetSensitive(SDName, fSdLVList[0]);
}


void G4MNestedROIDICOM::SetSensitive(G4String& SDName, G4LogicalVolume* logical) {
  G4SDManager * SDMan = G4SDManager::GetSDMpointer();

  G4VSensitiveDetector * dicomSD = SDMan->FindSensitiveDetector(SDName,false);
  if ( !dicomSD ){
      G4cout << "++ G4MNestedROIDICOM::  Create Sensitive Detector "
             <<SDName<<G4endl;
      dicomSD = new G4MNestedDICOMSD(SDName);
      SDMan->AddNewDetector(dicomSD);
  }
  ((G4MNestedDICOMSD*)dicomSD)->SetDICOMFile(fDICOMFileName);

  logical->SetSensitiveDetector(dicomSD);
}

G4MDICOMCTROI2Material* G4MNestedROIDICOM::PrepareMatListROI(){
  //G4Material* air = G4Material::GetMaterial("Air");
  fmatListROI = new G4MDICOMCTROI2Material(fFileCT2Density,fParamType);
  fmatListROI->SetDensityResol(fDensResol);  // Add 17-MAR-2009.
  fmatListROI->SetCTWindow(fValueMin, fEnvMat, fValueMax);
  fmatListROI->CreateMaterial();

  return fmatListROI;
}

