//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    BeamGun for two focusing beam.
//    This was created for NCC beamline.
//
//  (HISTORY)
//  11-JAN-07  T.ASO Modify for CLHEP2.0
//   5-APR-07  T.ASO Remove Random Engine setting.
//  10-AUG-07  K.FUJISAKA Focus beamline setting. 
//  24-DEC-08  T.Aso Remove emittance setting
//
//---------------------------------------------------------------------
// G4MFocusGun
//
#include "G4MFocusGun.hh"
#include "G4MFocusGunMessenger.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4Event.hh"
#include "G4ios.hh"

G4MFocusGun::G4MFocusGun()
  :G4ParticleGun()
{ 
  theFocusMessenger = new G4MFocusGunMessenger(this);
}

G4MFocusGun::~G4MFocusGun()
{
  delete theFocusMessenger;
}

void G4MFocusGun::GeneratePrimaryVertex(G4Event* evt)
{
  if(particle_definition==0) return;

  //######### Set Position ##########
  G4double  sX = particle_position.x();//Beam-Position_X
  G4double  sY = particle_position.y();//Beam-Position_Y
  G4double  sZ = particle_position.z();//Beam-Position_Z

  //######### Set dx,dy(sZ-FocusX,Y) ##########
  G4double Delta_x = sZ-FocusX;//Distance Z-X_Focus
  G4double Delta_y = sZ-FocusY;//Distance Z-Y_Focus

  //######### Set Shoot Position sX,sY  ##########
  sX = CLHEP::RandGauss::shoot(sX,std::abs(SigmaX * Delta_x));
  sY = CLHEP::RandGauss::shoot(sY,std::abs(SigmaY * Delta_y));

  //######### Set Beam parameter (Not Changed)##########
  // create a new vertex
  G4PrimaryVertex* vertex = 
    new G4PrimaryVertex(G4ThreeVector(sX,sY,sZ),particle_time);

  // Energy Flactuation
  G4double kineticE =  particle_energy;
  if ( beamdE > 0. ) kineticE = CLHEP::RandGauss::shoot(kineticE,beamdE);

  // create new primaries and set them to the vertex
  G4double mass =  particle_definition->GetPDGMass();
  G4double energy = kineticE + mass;
  G4double pmom = std::sqrt(energy*energy-mass*mass);
  //
  G4double px = pmom* particle_momentum_direction.x();
  G4double py = pmom* particle_momentum_direction.y();
  G4double pz = pmom* particle_momentum_direction.z();

  //########### Set Beam Direction ###############
  // r1-X_slope,r2-Y_slope 
  G4double r1,r2;
  //isocenter < X,Y_Focus <= particle_Position
  if(Delta_x != 0.0 && Delta_y != 0.0){
    r1 = sX/Delta_x;   //X_slope
    r2 = sY/Delta_y;   //Y_slope
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;          //Z-Direction -1
    px = r1*pz;        //
    py = r2*pz;        //
  }
  else if(Delta_x == 0.0 && Delta_y == 0.0){ 
    //X,Y_Focus = particle_position
    r1 = CLHEP::RandGauss::shoot(0.0,SigmaX);
    r2 = CLHEP::RandGauss::shoot(0.0,SigmaY);
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;          //Z-Direction -1
    px = r1*pz;        //
    py = r2*pz;        //
  }
  else if(Delta_y == 0.0){ 
    //isocenter < Y_Focus = particle_Position 
    r1 = sX/Delta_x;   //X_slope
    r2 = CLHEP::RandGauss::shoot(0.0,SigmaY);
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;          //Z-Direction -1
    px = r1*pz;        //
    py = r2*pz;        //
  }
  else if(Delta_x == 0.0){ 
    //isocenter < X_Focus = particle_Position
    r1 = CLHEP::RandGauss::shoot(0.0,SigmaX);
    r2 = sY/Delta_y;   //Y_slope
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;          //Z-Direction -1
    px = r1*pz;        //
    py = r2*pz;        //
  }
  else{}               //isocentr 

  //############ Set Beam ###############
  for( G4int i=0; i<NumberOfParticlesToBeGenerated; i++ )
  {
    G4PrimaryParticle* particle =
      new G4PrimaryParticle(particle_definition,px,py,pz);
    particle->SetMass( mass );
    particle->SetCharge( particle_charge );
    particle->SetPolarization(particle_polarization.x(),
                              particle_polarization.y(),
                              particle_polarization.z());
    vertex->SetPrimary( particle );
  }

  evt->AddPrimaryVertex( vertex );
}
