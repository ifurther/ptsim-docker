//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Class Description)
//    Base class for beam module's paramters.
//    The concreate class derived from this calss has a set of 
//    parameters for a beam module.
//
// (HISTORY)
// 05 Oct. 2005 T.Aso
// 
//
// -----------------------------------------------------------------
//
#include "G4MVBolusCatalogue.hh"

G4MVBolusCatalogue::G4MVBolusCatalogue(const G4String& name)
  :G4MVParamCatalogue(name){}

 
