//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MVGeometryBuilder
//
//  (HISTORY)
// 2014-08-07 T.Aso  Version commands.
// 2015-07-26 T.Aso  SDandField() for future use.
//---------------------------------------------------------------------
//
#include "G4MVGeometryBuilder.hh"
#include "G4MTKVersion.hh"
//
#include "G4RunManager.hh"

#include "G4GeometryManager.hh"
#include "G4PhysicalVolumeStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4SolidStore.hh"

G4MVParticleTherapySystem* G4MVGeometryBuilder::fSystem=0;
G4MVGeometryBuilder::G4MVGeometryBuilder(const G4String& appVers,
                                         const G4String& appDate):
  fG4MAppVersion(appVers),fG4MAppDate(appDate)
{
  fMessenger = new G4MGeometryMessenger(this);
}

G4MVGeometryBuilder::~G4MVGeometryBuilder() {
  if ( fSystem ) delete fSystem;
  delete fMessenger;
}

G4VPhysicalVolume* G4MVGeometryBuilder::Build() {
  return fSystem->BuildSystem();
}

void G4MVGeometryBuilder::BuildSDandField() {
  fSystem->BuildSDandField();
}

void G4MVGeometryBuilder::CleanUpSystem() {
  G4GeometryManager::GetInstance()->OpenGeometry();
  // Clean Up old System
  delete fSystem;
  // Clean old geometry, if any
  G4PhysicalVolumeStore::GetInstance()->Clean();
  G4LogicalVolumeStore::GetInstance()->Clean();
  G4SolidStore::GetInstance()->Clean();
}

void G4MVGeometryBuilder::SetSystem(G4String& sysName) {
  CleanUpSystem();
  fSystem = SystemSelection(sysName);
  fSystem->Setup();
}

void G4MVGeometryBuilder::ChangeSystem(G4String& sysName) {
  SetSystem(sysName);
  G4RunManager* runManager = G4RunManager::GetRunManager();
  runManager->DefineWorldVolume(fSystem->BuildSystem());
}

const G4String& G4MVGeometryBuilder::GetSystemName() const {
  return fSystem->GetName();
}

G4MVParticleTherapySystem* G4MVGeometryBuilder::GetSystem() {
  return fSystem;
}

void G4MVGeometryBuilder::TKVersion(std::ostream& out){
  out << "PTStoolkit version:  "<< G4MToolkitVers <<G4endl;
  out << "PTStoolkit release date: "<< G4MToolkitDate <<G4endl;
}

void G4MVGeometryBuilder::AppVersion(std::ostream& out){
  if ( fSystem ){
    out << "Application (System) Name :  " << GetSystemName() << G4endl;
  }else{
    out << "Application (System) Name : System has not Selected "<< G4endl;
  }
  out << "Application (System) version : " << fG4MAppVersion <<G4endl;
  out << "Application (System) release date: "<<fG4MAppDate <<G4endl;
}

void G4MVGeometryBuilder::LinkedG4Version(std::ostream& out){
  out << "Geant4 version :  " << G4Version << G4endl;
  out << "Geant4 release date: "<< G4Date <<G4endl;
}

void G4MVGeometryBuilder::RunSummary(std::ostream& out){
  LinkedG4Version(out);
  AppVersion(out);
  TKVersion(out);
  fSystem->ModuleList(1,out);
  fSystem->ModuleList(2,out);
}
