//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MPCTBoxDetector
//
// (HISTORY)
//   Created for PortonCT study. T.Aso
//   19 Dec. 2010 T.Aso Add file catalogue constructor.
//   2013-07-03 T.Aso Set Envelope size.
//   2015-12-14 T.Aso Use G4MWaterPhantomSD.
//   2017-03--15 T.Aso Threading
// -----------------------------------------------------------------
//
//                    
// 
#include "G4MPCTBoxDetector.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"
#include "G4Material.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
// --

//#include "G4MPCTSD.hh"
#include "G4MWaterPhantomSD.hh"

//##ModelId=42F3E51B009C
G4MPCTBoxDetector::G4MPCTBoxDetector(const G4String& name,
                                      G4double dx, G4double dy, G4double dz,
                                     G4String mat)
  :G4MVBeamModule(name,G4ThreeVector(dx,dy,dz)),fCatalogue(NULL),
   fdx(dx),fdy(dy),fdz(dz),fMaterial(mat){
}

G4MPCTBoxDetector::G4MPCTBoxDetector(const G4String& name) 
  :G4MVBeamModule(name),fCatalogue(NULL),fMaterial("Air")
{
}

G4MPCTBoxDetector::G4MPCTBoxDetector(G4MVPCTBoxDetectorCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}


//##ModelId=42F3E524036B
G4MPCTBoxDetector::~G4MPCTBoxDetector() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MPCTBoxDetector::SetAllParameters(G4double dx, G4double dy, G4double dz,
                                         G4String& mat){
  fdx=dx;
  fdy=dy;
  fdz=dz;
  fMaterial = mat;
  SetEnvelopeSize(dx,dy,dz);
}

void G4MPCTBoxDetector::SetAllParameters(G4ThreeVector& dxyz,G4String& mat){
  fdx=dxyz.x();
  fdy=dxyz.y();
  fdz=dxyz.z();
  fMaterial = mat;
  SetEnvelopeSize(dxyz);
}

void G4MPCTBoxDetector::SetSize(G4double dx, G4double dy, G4double dz){
  fdx=dx;
  fdy=dy;
  fdz=dz;
  SetEnvelopeSize(dx,dy,dz);
}

G4VPhysicalVolume* G4MPCTBoxDetector::buildEnvelope(G4LogicalVolume* worldlog) {
  G4Material* mat = G4Material::GetMaterial(fMaterial);

  G4VSolid* solid = new G4Box(GetName(), fdx,fdy,fdz);
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,                      // Solid 
                                 mat,                           // Material
                                 GetName()                      // Name
                         );

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),
                   GetTranslation(),
                   logical,                      // Logical volume  
                   GetName(),                       // Name
                   worldlog,  // Mother  volume 
                   false,                         // Not used 
                   0);                            // Copy number  

  fSdLVList.push_back(logical);

  return physical;

}

void G4MPCTBoxDetector::buildNode(G4VPhysicalVolume*) {
}

void G4MPCTBoxDetector::BuildInSDandField() {
  /// Sensitive Detector
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector *pctsd = sdm->FindSensitiveDetector(GetName(),false);
  if ( !pctsd ) {
    G4cout << "++ G4MPCTBoxDetector::  Create Sensitive Detector "
           <<GetName()<<G4endl;
    //pctsd = new G4MPCTSD(GetName());
    const G4String colName = "HitsCollection";
    G4MWaterPhantomSD* wsd = new G4MWaterPhantomSD(GetName(),colName);
    wsd->SetDepth(0,0,0);
    wsd->SetZeroEdep(false);
    sdm->AddNewDetector(wsd);
    pctsd = wsd;
  }
  // Logical name
  for (G4int i = 0; i < (G4int)fSdLVList.size(); i++){
       fSdLVList[i]->SetSensitiveDetector(pctsd);
  }
}
