//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
//---------------------------------------------------------------------
// (Description)
//    Class for parameterisation of G4MPTCollimator.
//    This class realizes PTCollimator structure using parameterisation.
//    The Air(Drill) hole is parameterised.
//
// (HISTORY)
//   2012-06-06 T.Aso 
//   2012-09-10 T.Aso the vector type of theMap was modified from G4int
//                   to short.
//
//---------------------------------------------------------------------
//
#include "G4MPTCollimatorParameterisation.hh"
#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"

//#define debug
//#define pdebug

G4MPTCollimatorParameterisation::
G4MPTCollimatorParameterisation(G4int nx, G4int ny,
                                std::vector<short>& map,
                                G4double xpitch,
                                G4double ypitch,
                                G4double x0,
                                G4double y0,
                                G4Material* mat,
                                G4int ixdir,G4int iydir)
  :fNx(nx),fNy(ny),theMap(map),fxPitch(xpitch),fyPitch(ypitch),
   fx0(x0),fy0(y0),fmat(mat),fxdir(ixdir),fydir(iydir),
   fpX(NULL),fpY(NULL),fpZ(NULL),fNofVolume(0){}

G4MPTCollimatorParameterisation::~G4MPTCollimatorParameterisation(){
  delete fpX;
  delete fpY;
  delete fpZ;
}

void G4MPTCollimatorParameterisation::SetPitch(G4double px, G4double py){
  fxPitch = px;
  fyPitch = py;
}

void G4MPTCollimatorParameterisation::SetNxy(G4int nx, G4int ny){
  fNx = nx;
  fNy = ny;
}

void G4MPTCollimatorParameterisation::CalculateActiveVolume(){

  // zval must be a FULL thickness of Polythylene.
  // But Parameterisation do Air image.
  if ( (G4int)theMap.size() != (fNx*fNy)  ) {
    G4Exception("G4MPTCollimatorParameterisation::SetZValue","G4MPTCollimatorParam00",
                FatalException,"Array Length Missmatch");
  }

  G4int n = theMap.size();
  G4int nActive=0;
  for ( G4int i = 0; i < n ; i++ ) if ( theMap[i] > 0 ) nActive++;
  fpX=new G4double[nActive];
  fpY=new G4double[nActive];

  fNofVolume = 0;
  for ( G4int i = 0; i < n ; i++) {
    if ( theMap[i] > 0 ) {  
      fpX[fNofVolume]= fx0 + (i%fNx)*fxPitch*fxdir;
      fpY[fNofVolume]= fy0 + (i/fNx)*fyPitch*fydir;
#ifdef debug
      G4cout << "xdir " <<fxdir<<" ydir "<<fydir<<G4endl;
      G4cout << fNofVolume <<" "<<fpX[fNofVolume]/mm
             <<" "<<fpY[fNofVolume]/mm << G4endl;
#endif
      fNofVolume++;
    }
  }
}

G4int G4MPTCollimatorParameterisation::GetNofActiveVolume(){ return fNofVolume; }

void G4MPTCollimatorParameterisation::ComputeTransformation
(const G4int copyNo,  G4VPhysicalVolume* physVol)const{
  G4ThreeVector position(fpX[copyNo],fpY[copyNo],0.0);
  physVol->SetTranslation(position);
}

void G4MPTCollimatorParameterisation::ComputeDimensions(G4Box & boxel, 
                                               const G4int ,
                                               const G4VPhysicalVolume*) const{
  boxel.SetXHalfLength(fxPitch/2.);
  boxel.SetYHalfLength(fyPitch/2.);
}

G4Material* G4MPTCollimatorParameterisation::ComputeMaterial (const G4int, 
                                                       G4VPhysicalVolume*,
                                                       const G4VTouchable*)
{
  return fmat;
}
