//---------------------------------------------------------------------
//
// (Description)
//    Tet class for defining a new Module 
//
// (HISTORY)  
//   2017-11-14  S.Ogasawara (NITTC Aso lab)
//   2018-03-10  T.Aso Clean up and Modify code.
//
//---------------------------------------------------------------------
//


#include "G4MTetParameterisation.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4Tet.hh"

G4MTetParameterisation::G4MTetParameterisation(const G4String& fileList,
                                               G4MDICOMCTROI2Material* matList)
  :G4VPVParameterisation(),fFileList(fileList),fMatListROI(matList),fNTet(0),
   fVisFlag(true), itmpCopy(-1), itdata(-1), icopy(-1)
{
  if ( fVisFlag ) {
    fColor.clear();
    fColor.push_back(new G4VisAttributes(G4Colour(1.0,0.0,0.0,1.0)));
    fColor.push_back(new G4VisAttributes(G4Colour(0.0,1.0,0.0,1.0)));
    fColor.push_back(new G4VisAttributes(G4Colour(0.0,0.0,1.0,1.0)));
    fColor.push_back(new G4VisAttributes(G4Colour(1.0,1.0,0.0,1.0)));
    fColor.push_back(new G4VisAttributes(G4Colour(0.0,1.0,1.0,1.0)));
    fColor.push_back(new G4VisAttributes(G4Colour(1.0,0.0,1.0,1.0)));
    fColor.push_back(new G4VisAttributes(G4Colour(1.0,1.0,1.0,1.0)));
  }

}

G4MTetParameterisation::~G4MTetParameterisation() {
  ClearData();
  //
  if ( fMatListROI ) delete fMatListROI;
  fColor.clear();
}

void G4MTetParameterisation::ClearData(){
  std::vector<G4MTetData*>::iterator itr;
  for (itr = fTetDataVec.begin();
       itr!= fTetDataVec.end(); ++itr){
    delete (*itr);
  }
  fTetDataVec.clear();
  itmpCopy=-1;
  itdata=-1;
  icopy=-1;
}

void G4MTetParameterisation::ReadFileList(){
  std::ifstream ifs(fFileList);
  if(!ifs) {
    G4cout <<fFileList << G4endl;
    G4Exception("G4MTetParametarisation",".dat file open fail",
                FatalException,"file open failed");  
  }
  //
  //
  G4String fline,fname;
  G4int matid;
  G4double ox,oy,oz;
  std::stringstream ss;
  //
  ClearData();
  fNTet = 0;
  //
  G4int Nline;
  std::getline(ifs,fline);
  ss.clear();
  ss<<fline;
  ss>> Nline;
  for ( G4int i = 0; i < Nline; i++){
    if ( std::getline(ifs,fline)){
      if(fline[0]=='#' || fline[0] == '\n') continue;
      ss.clear();
      ss<<fline;
      ss>>fname>>ox>>oy>>oz>>matid;
      G4ThreeVector oxyz(ox*mm,oy*mm,oz*mm);
      //
      G4MTetData* tdata = new G4MTetData(fname,oxyz,matid, fNTet);
      G4int ntet = CreateSolid(tdata);
      fTetDataVec.push_back(tdata);
      //
      fNTet += ntet;
    }
  }
}

G4int G4MTetParameterisation::CreateSolid(G4MTetData* tdata){
  //read .dat file
  std::ifstream ifs(tdata->GetName());
  G4cout << tdata->GetName() << " reading " 
         << (tdata->GetOffset())/mm<< G4endl;  
  if(!ifs) {
    G4Exception("G4MTetParametarisation::createSolid",
                ".tet file read failed",
                FatalException,"file read failed");
  }
  G4ThreeVector& offset = tdata->GetOffset();
  G4double ox = offset.x();
  G4double oy = offset.y();
  G4double oz = offset.z();
  //
  G4int ntet;
  G4String fline;
  std::stringstream ss;
  G4double tet[12];
  G4double hu;
  //
  ifs>>ntet;
  for ( G4int i = 0; i < ntet; i++){
    ifs>>tet[0]>>tet[1]>>tet[2]
       >>tet[3]>>tet[4]>>tet[5]
       >>tet[6]>>tet[7]>>tet[8]
       >>tet[9]>>tet[10]>>tet[11]
       >>hu;
    if ( i < 10 ){
      G4cout<<tet[0]<<" "<<tet[1]<<" "<<tet[2]
            <<" "<<tet[3]<<" "<<tet[4]<<" "<<tet[5]
            <<" "<<tet[6]<<" "<<tet[7]<<" "<<tet[8]
            <<" "<<tet[9]<<" "<<tet[10]<<" "<<tet[11]
            <<" "<<hu<<G4endl;
    }

    for( G4int j = 0; j<12; j++){ tet[j] *= mm;}
    // 
    for( G4int j=0;j<12;j+=3){
      tet[j]+=ox;
      tet[j+1]+=oy;
      tet[j+2]+=oz;
    } 
    //
    G4int ihu = std::round(hu);
    tdata->AddTet(tet,ihu);
  }//while
  G4cout << "total " << ntet << " Tetras read complete." << G4endl;
   
  return ntet;
}

void G4MTetParameterisation::SearchIndex(const G4int copyNo, 
                                         G4int& it, G4int& ic){
  if ( itmpCopy == copyNo ) {
    it = itdata;
    ic = icopy;
    return;
  }else{
    itmpCopy = copyNo;
    for ( size_t i = 0; i < fTetDataVec.size(); i++){
      if ( copyNo < fTetDataVec[i]->GetNend() ){
        itdata = i;
        icopy = copyNo - fTetDataVec[i]->GetNoff();
        it = itdata;
        ic = icopy;
        return;
      }
    }
  }
}

G4VSolid* G4MTetParameterisation::ComputeSolid(const G4int copyNo, 
                                               G4VPhysicalVolume*){
  //G4cout << " ComputeSolid  "<<G4endl;
  G4int it, ic;
  SearchIndex(copyNo, it, ic);
  return fTetDataVec[it]->GetTet(ic);
}

G4Material*  G4MTetParameterisation::ComputeMaterial(const G4int copyNo,
                                                     G4VPhysicalVolume* physVol,
                                                     const G4VTouchable*) {
  //G4cout << " ComputeMaterial  "<<G4endl;
  G4int it, ic;
  SearchIndex(copyNo, it, ic);
  //G4int it = GetTetDataIndex();
  //G4int ic = GetTetDataCopyNo();
  //
  G4int matID = fTetDataVec[it]->GetMatID();
  G4Material* mat = fMatListROI->GetMaterial(fTetDataVec[it]->GetHU(ic),
                                             matID);

  /*
  G4cout << " SearchIndex " << it << " " << ic
         <<" " << fTetDataVec[it]->GetHU(ic)
         <<" " << fTetDataVec[it]->GetMatID() 
         <<" " << mat->GetName() << " " << mat->GetDensity()/(g/cm3)
         <<G4endl;
  */

  if ( fVisFlag ){
    //
    //set geometry color
    if ( matID >= 0 && matID < (G4int)fColor.size() ){
      physVol->GetLogicalVolume()->SetVisAttributes(fColor[matID]);;
    }else{
      physVol->GetLogicalVolume()->SetVisAttributes(fColor[0]);      
    }
  }

  if ( !mat ) {
    G4cout << " material null " << ic << " " <<fTetDataVec[it]->GetMatID()<<G4endl;
  }
  return mat;
}

void G4MTetParameterisation::ComputeTransformation(const G4int , 
                                        G4VPhysicalVolume* ) const {
  //G4cout << " ComputeTransform  "<<G4endl;
}

void G4MTetParameterisation::GetTetInfo(G4int copyNo, 
                                        G4ThreeVector& pos,
                                        G4double& volume,
                                        G4double&  density){
  //G4cout << " GetTetInfo 1 " <<G4endl;
  G4Material* mat = GetTetInfo(copyNo, pos, volume);
  //G4cout << " GetTetInfo 2 " << mat << G4endl;
  density = mat->GetDensity();
}

G4Material* G4MTetParameterisation::GetTetInfo(G4int copyNo, 
                                               G4ThreeVector& pos,
                                               G4double& vol){
  G4int it, ic;
  SearchIndex(copyNo, it, ic);
  G4Tet* tet = (G4Tet*)(fTetDataVec[it]->GetTet(ic));
  //
  std::vector<G4ThreeVector> v = tet->GetVertices();
  pos.set(0,0,0);
  for (size_t i = 0; i < v.size(); i++){
    pos += v[i];
  }
  pos = pos/v.size();
  //G4cout << " pos " << pos <<G4endl;
  //
  vol = tet->GetCubicVolume();
  //G4cout << " vol " << vol <<G4endl;
  //
  return fMatListROI->GetMaterial(fTetDataVec[it]->GetHU(ic),
                                  fTetDataVec[it]->GetMatID());
}

const G4ThreeVector& G4MTetParameterisation::GetDxyz(){
  G4ThreeVector minxyz; 
  G4ThreeVector maxxyz;
  minxyz = fTetDataVec[0]->GetMin();
  maxxyz = fTetDataVec[0]->GetMax();
  for ( size_t i = 1; i < fTetDataVec.size(); i++){
    G4ThreeVector& tmin = fTetDataVec[i]->GetMin();
    G4ThreeVector& tmax = fTetDataVec[i]->GetMax();
    if ( minxyz.x() > tmin.x()) minxyz.setX(tmin.x());
    if ( minxyz.y() > tmin.y()) minxyz.setY(tmin.y());
    if ( minxyz.z() > tmin.z()) minxyz.setZ(tmin.z());
    if ( maxxyz.x() < tmax.x()) maxxyz.setX(tmax.x());
    if ( maxxyz.y() < tmax.y()) maxxyz.setY(tmax.y());
    if ( maxxyz.z() < tmax.z()) maxxyz.setZ(tmax.z());
  }

  G4double dx,dy,dz;
  G4double dx0 = std::fabs(minxyz.x());
  G4double dx1 = std::fabs(maxxyz.x());
  if ( dx0 > dx1 ) { dx = dx0;}
  else { dx = dx1; }
  G4double dy0 = std::fabs(minxyz.y());
  G4double dy1 = std::fabs(maxxyz.y());
  if ( dy0 > dy1 ) { dy=dy0;}
  else { dy=dy1; }
  G4double dz0 = std::fabs(minxyz.z());
  G4double dz1 = std::fabs(maxxyz.z());
  if ( dz0 > dz1 ) { dz=dz0;}
  else { dz=dz1; }

  envDxyz.set(dx,dy,dz);
  return envDxyz;
}
