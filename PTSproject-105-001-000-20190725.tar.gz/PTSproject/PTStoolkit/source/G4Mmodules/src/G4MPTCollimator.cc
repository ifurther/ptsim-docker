//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    PTCollimator Module
//  (HISTORY)
// 2012-06-06 T.Aso
// 2012-06-07 T.Aso Modify Dump(),drawLine, paint to remove warnings
// 2012-09-10 T.Aso Graphics functions such as drawline, paint, 
//                     scanline are moved to G4MGLUtil class.
// 2012-11-22 T.Aso Information of Dump() was modified.
// 2013-03-30 T.Aso Redefinition of fMatName inside a method was removed,
//                  because the variable has already been a class member.
// 2014-03-31   T.Aso Optimaization of Parameterisation was modified
//                    from fZAxis to fUndefined. Because of error when
//                    installing in parallel world.
//
// -----------------------------------------------------------------
//
#include "G4MPTCollimator.hh"
#include "G4PVParameterised.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"
#include "G4MGLUtil.hh"
#include <fstream>

G4MPTCollimator::G4MPTCollimator(const G4String& name, 
                                 const G4ThreeVector& dxyz,
                                 const G4String& mat,
                                 G4double dx,G4double dy,
                                 std::vector<G4double>& xvec,
                                 std::vector<G4double>& yvec,
                                 G4int xdir, G4int ydir )
  :G4MVBeamModule(name,dxyz),fMatName(mat),
   theXVec(xvec), theYVec(yvec),
   fdx(dx),fdy(dy),
   fxdir(xdir),fydir(ydir),
   fParameterisation(NULL), fCatalogue(NULL){
   theMap.clear();
}

G4MPTCollimator::G4MPTCollimator(const G4String& name)
  :G4MVBeamModule(name),fMatName("Brass"),
   fdx(0),fdy(0),fxdir(1),fydir(1),
   fParameterisation(NULL),fCatalogue(NULL){
  theIxVec.clear();
  theIyVec.clear();
  theMap.clear();
}

G4MPTCollimator::G4MPTCollimator(G4MVPTCollimatorCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fParameterisation(NULL),
   fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MPTCollimator::~G4MPTCollimator() {
  theIxVec.clear();
  theIyVec.clear();
  theMap.clear();
  //
  delete fParameterisation;
  if ( fCatalogue ) delete fCatalogue;
}


void G4MPTCollimator::SetAllParameters(const G4ThreeVector& dxyz,
                                       const G4String& mat,
                                       G4double dx, G4double dy,
                                       std::vector<G4double>& xvec,
                                       std::vector<G4double>& yvec,
                                       G4int xdir, G4int ydir){
    SetEnvelopeSize(dxyz);
    fMatName = mat;
    fdx = dx;
    fdy = dy;
    theXVec = xvec;
    theYVec = yvec;
    fxdir = xdir;
    fydir = ydir;
    theMap.clear();

    FillPixelParam();
}


void G4MPTCollimator::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MPTCollimator::Dump(std::ostream& out){
  out << fnx<<","<<fny<<G4endl;
  out << fdx/mm<<","<<fdy/mm<<G4endl;
  //
  //Modified by y.maeda(2012/11/12)         
  out << fx0/mm<<","<<fy0/mm<<G4endl;
  out << fxdir<<","<<fydir<<G4endl;
  //
  for ( G4int iy = 0; iy < fny; iy++ ){
    for ( G4int ix = 0; ix < fnx; ix++ ){
      G4int id = iy*fnx+ix;
      out << theMap[id] ;
    }
    out << G4endl;
  }
  //
  //Modified by y.maeda(2012/11/12)                                           
  out << G4endl;
  out << "Original Input"<<G4endl;
  out << (G4int)theXVec.size()<<G4endl;
  for ( G4int i = 0; i < (G4int)theXVec.size(); i++){
    out<<theXVec[i]<<"  "<<theYVec[i]<<G4endl;
  }
  out << G4endl;
  //
}
void G4MPTCollimator::SetXYVector(std::vector<G4double>& v){
  theXVec.clear();
  theYVec.clear();
  G4int n = (G4int)v.size();
  if ( n%2 != 0 ) {
    G4Exception("G4MPTCollimator::SetXYVector()",
                "G4MPTCollimator00",FatalException," Number of item missmatch. ");
  }
  for ( G4int i = 0; i < n/2; i++ ){
    theXVec.push_back(v[2*i]);
    theYVec.push_back(v[2*i+1]);
  }
}

void G4MPTCollimator::FillPixelParam(){
  //
  if ( theXVec.size() <= 0 || theYVec.size() <= 0 ) return;
  //
  // Search area of x,y 
  //
  G4double margin=5.5;
  G4double xmin, xmax;
  G4double ymin, ymax;
  xmin = xmax = theXVec[0];
  ymin = ymax = theYVec[0];
  //
  for ( G4int i = 0; i < (G4int)theXVec.size(); i++){
    if ( xmin > theXVec[i] ) xmin = theXVec[i];
    if ( xmax < theXVec[i] ) xmax = theXVec[i];
    if ( ymin > theYVec[i] ) ymin = theYVec[i];
    if ( ymax < theYVec[i] ) ymax = theYVec[i];
  }
  fx0 = xmin-(fdx*margin);
  fy0 = ymin-(fdy*margin);
  G4double fx1 = xmax+(fdx*margin);
  G4double fy1 = ymax+(fdy*margin);
  //
  fnx = (G4int)((fx1 - fx0 )/fdx)+1;
  fny = (G4int)((fy1 - fy0 )/fdy)+1;
  //
  // Fill IxVec and IyVec (Pixel position conversion)
  // 
  theIxVec.clear();
  theIyVec.clear();
  for ( G4int i = 0; i < (G4int)theXVec.size(); i++){
    theIxVec.push_back((G4int)((theXVec[i]-fx0)/fdx));
    theIyVec.push_back((G4int)((theYVec[i]-fy0)/fdy));
  }
  //
  // Create map 
  //
  theMap.clear();
  for ( G4int iy = 0; iy < fny; iy++){
    for ( G4int ix = 0; ix < fnx; ix++){
      theMap.push_back(0);
    }
  }
  for ( G4int i = 0; i < (G4int)theIxVec.size(); i++){
    G4int ix = theIxVec[i];
    G4int iy = theIyVec[i];
    G4int id = iy*fnx+ix;
    theMap[id] = 1;
  }
  if (fVerbose > 0){
    G4cout <<"-PTCollimator::Initial points-----"<<G4endl;
    Dump(G4cout);
  }

  //
  // Graphics Utility
  G4MGLUtil glu;

  G4int ix0 = theIxVec[0];
  G4int iy0 = theIyVec[0];
  for ( G4int i = 1; i < (G4int)theIxVec.size(); i++){
    G4int ix1 = theIxVec[i];
    G4int iy1 = theIyVec[i];
    glu.drawLine(ix0,iy0,ix1,iy1,theMap,fnx,fny);
    ix0 = ix1;
    iy0 = iy1;
  }

  if (fVerbose > 0){
    G4cout <<"-PTCollimator::Lines-----"<<G4endl;
    Dump(G4cout);
  }

  // 
  // Start point (Under construction)
  ix0 = fnx/2;
  iy0 = fny/2;
  //
  //G4cout << " fnx fny "<< fnx <<","<<fny<<G4endl;
  //G4int id = iy0*fnx+ix0;  
  //theMap[id]=5;
  //
  glu.paint(ix0, iy0, theMap, fnx, fny);

  if (fVerbose > 0){
    G4cout <<"-PTCollimator::Paints-----"<<G4endl;
    Dump(G4cout);
  }
}

G4VPhysicalVolume* G4MPTCollimator::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* mat = G4Material::GetMaterial(fMatName);
  G4VSolid* solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,       // Solid 
                                 mat,         // Material
                                 GetName());  // Name

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                      GetRotation(),
                      GetTranslation(),
                      logical,   // Logical volume  
                      GetName(), // Name
                      worldlog,  // Mother  volume 
                      false,     // Not used 
                      0);        // Copy number  

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,0.3,0.3,0.8));
  logical->SetVisAttributes(visAttr);

  return physical;
}

void G4MPTCollimator::buildNode(G4VPhysicalVolume* physvol) {
  //------ Drill Hole
  // dummy values for G4Box -- will be modified by parameterised volume. 
  const G4String drillName = GetName()+"Drill";
  G4VSolid* solDrill =  new G4Box(drillName,
                                  fdx/2.,fdy/2.,GetDZ());
  G4Material* hole= G4Material::GetMaterial("Air");
  G4LogicalVolume* logDrill = new G4LogicalVolume(solDrill,hole,drillName);
  fParameterisation = 
    new G4MPTCollimatorParameterisation(fnx,fny,theMap,
                                        fdx,fdy,
                                        fx0,fy0,hole,fxdir,fydir);
  fParameterisation->CalculateActiveVolume();
  G4int nofvolume = fParameterisation->GetNofActiveVolume();
  
  if ( nofvolume > 0 ){
      //G4VPhysicalVolume *phys = 
      new G4PVParameterised(drillName,
                            logDrill,
                            physvol->GetLogicalVolume(),
                            //kZAxis,
                            kUndefined,
                            nofvolume,
                            fParameterisation);
  }


  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,1.0,1.0));
  logDrill->SetVisAttributes(visAttr);

}

