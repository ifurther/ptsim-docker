//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shape component
//
// (HISTORY)  
// 2011. Sep. Kawashima and Aso (TNCT).
//
//
//---------------------------------------------------------------------
//
#include "G4MRotatingRangeModulator.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include "G4UnionSolid.hh"
#include <iostream>

G4MRotatingRangeModulator::G4MRotatingRangeModulator(const G4String &name, G4double eDRout, G4double dz,
		 const G4String &mat)
  : G4MVBeamModule(name,G4ThreeVector(0.,eDRout,dz)),
    fMatName(mat),fCatalogue(NULL)
{}

G4MRotatingRangeModulator::G4MRotatingRangeModulator(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MRotatingRangeModulator::G4MRotatingRangeModulator(G4MVRotatingRangeModulatorCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MRotatingRangeModulator::~G4MRotatingRangeModulator()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MRotatingRangeModulator::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MRotatingRangeModulator::SetAllParameters(G4double eDRin, G4double eDRout, G4double dz,const G4String &mat){

  SetEnvelopeSize(eDRin,eDRout,dz);
  fMatName=mat;
}

void G4MRotatingRangeModulator::resetAll(){
  NofTrack.clear();//
  NofFan.clear();//

  offset.clear();//
  direction.clear();//

  innerRadius.clear();//
  outerRadius.clear();//
  offsetAngle.clear();//

  segDZ.clear();
  segPhi.clear();
  segMatName.clear();
}

G4VPhysicalVolume* G4MRotatingRangeModulator::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(fMatName);
  if ( !mat ) {
    G4String mess = "material " + fMatName + " is NULL ";
    G4Exception("G4MRotatingRangeModulator::buildEnvelope()","G4MRotatingRangeMon00",
		FatalException,mess);
  }
  G4Tubs *solid = new G4Tubs(GetName(), GetDRin(), GetDRout(), GetDZ(), 0, twopi);
  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());
  lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));
  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
						  GetTranslation(),
						  lv,
						  GetName(),
						  worldlog,
						  false,
						  0);
  return physical;
}

void G4MRotatingRangeModulator::buildNode(G4VPhysicalVolume* physVol)
{
  G4int TrkOffset = 0;
  G4int SegOffset = 0;
  
  for(G4int part=0; part<NofPart; part++){
    for(G4int track=TrkOffset; track<NofTrack[part]+TrkOffset; track++){
      //G4int track = trk + TrkOffset;
      G4double PhiOffset = offsetAngle[track];
      for(G4int segment=SegOffset; segment<NofFan[track]+SegOffset; segment++){
	//G4int segment = seg + SegOffset;
	
	// The segment has no thickness, it is not constructed.
	if( segDZ[segment] != 0){
	  
	  // Material of this Segment
	  G4Material *segMat = G4Material::GetMaterial(segMatName[segment]);
	  if( !segMat ){
	    G4String mess = "material " + segMatName[segment] + " ### is NULL."; 
	    G4Exception("G4MRotatingRangeModulator::buildEnvelope()","G4MRotatingRangeMon00",
			FatalException,mess);
	  }

	  // Construction of a Segment
	  G4Tubs *solSeg = new G4Tubs("aSegment",
				      innerRadius[track],
				      outerRadius[track],
				      segDZ[segment],
				      PhiOffset,
				      segPhi[segment]);
	  G4LogicalVolume *logSeg = new G4LogicalVolume(solSeg, segMat, "aSegment");
	  logSeg->SetVisAttributes(new G4VisAttributes(G4Colour(0.0, 1.0, 1.0)));

	  G4double delta;
	  if( direction[part] == 1 )
	    delta = -segDZ[segment] + offset[part];
	  else if( direction[part] == 0 )
	    delta = offset[part];
	  else 
	    delta = segDZ[segment] + offset[part];
	  
	  new G4PVPlacement(0, // rotation with respect to its mother volume
			    G4ThreeVector(0,0,delta), // translation with respect to its mother volume
			    logSeg, // the associated Logical Volume
			    "rotatingrangemodulator", // string identifier for this volume
			    physVol->GetLogicalVolume(), // the associated mother volume
			    false, // for future use
			    0); // integer which identifies this placement
	} // segment
	PhiOffset += segPhi[segment];
      }
      SegOffset += NofFan[track];
    } // track
    TrkOffset += NofTrack[part];
  } // part
}
