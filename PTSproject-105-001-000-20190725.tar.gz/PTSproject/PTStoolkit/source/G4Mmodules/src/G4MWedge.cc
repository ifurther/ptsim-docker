//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Wedge Module
//  (HISTORY)
// 2016-11-06 T.Aso
// -----------------------------------------------------------------
//
#include "G4MWedge.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4ExtrudedSolid.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"
#include <fstream>
#include <algorithm>

G4MWedge::G4MWedge(const G4String& name, 
                                     const G4ThreeVector& dxyz,
                                     const G4String& mat,
                                     std::vector<G4TwoVector>& polygon,
                                     G4int dir)
  :G4MVBeamModule(name,dxyz),fMatName(mat),
   theXYVec(polygon),
   fdir(dir),fCatalogue(NULL){
}

G4MWedge::G4MWedge(const G4String& name)
  :G4MVBeamModule(name),fMatName("G4_Al"),fdir(1),
   fCatalogue(NULL){
   theXYVec.clear();
}

G4MWedge::G4MWedge(G4MVWedgeCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()), fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MWedge::~G4MWedge() {
  theXYVec.clear();
  //
  if ( fCatalogue ) delete fCatalogue;
}


void G4MWedge::SetAllParameters(const G4ThreeVector& dxyz,
                                       const G4String& mat,
                                       std::vector<G4TwoVector>& polygon,
                                       G4int dir){
    SetEnvelopeSize(dxyz);
    fMatName = mat;
    theXYVec = polygon;
    fdir = dir;
}


void G4MWedge::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MWedge::Dump(std::ostream& out){
  out << GetEnvelopeSize()/mm <<G4endl;
  out << theXYVec.size() <<G4endl;
  //
  //
  for ( G4int i = 0; i < (G4int)theXYVec.size(); i++){
    out << theXYVec[i]/mm << G4endl;
  }
  out << fdir << G4endl;
  //
}

void G4MWedge::SetXYVector(std::vector<G4double>& v){
  theXYVec.clear();
  G4int n = (G4int)v.size();
  for ( G4int i = 0; i < n/2; i++){
    theXYVec.push_back(G4TwoVector(v[2*i],v[2*i+1]));
  }
}

G4VPhysicalVolume* G4MWedge::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* mat = G4Material::GetMaterial("G4_AIR");
  G4VSolid* solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,       // Solid 
                                 mat,         // Material
                                 GetName());  // Name
  G4VPhysicalVolume* physical  = new G4PVPlacement(
                      GetRotation(),
                      GetTranslation(),
                      logical,   // Logical volume  
                      GetName(), // Name
                      worldlog,  // Mother  volume 
                      false,     // Not used 
                      0);        // Copy number  

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(0.5,0.5,0.5,0.2));
  logical->SetVisAttributes(visAttr);

  return physical;
}

void G4MWedge::buildNode(G4VPhysicalVolume* physvol) {
  std::vector<G4TwoVector> xyPolygon;
  G4bool theSamePoint = false;
  if ( theXYVec[0] == theXYVec[theXYVec.size()-1]){
    //G4cout << " Same <<<<<< " <<G4endl;
    theSamePoint = true;
  }
  //
  for ( G4int i = 0; i < (G4int)theXYVec.size(); i++){
    //G4cout << theXYVec[i]/mm << G4endl;
    if ( i == (G4int)theXYVec.size()-1 && theSamePoint ) break;
    xyPolygon.push_back(theXYVec[i]);
  }

  //------Wedge
  const G4String wedgeName = GetName()+"Com";
  G4TwoVector offset0(0.,0.);
  G4double    scale = 1.0;
  G4VSolid* solWedge =  new G4ExtrudedSolid(wedgeName,
                                           xyPolygon,GetDY(),
                                           offset0,scale, offset0, scale);

  //G4cout << "****" << fMatName << G4endl;
  G4Material* wedgemat= G4Material::GetMaterial(fMatName);
  G4LogicalVolume* logWedge = new G4LogicalVolume(solWedge,wedgemat,wedgeName);

  //G4VPhysicalVolume* physical  = 
  G4RotationMatrix* rotM = new G4RotationMatrix();
  rotM->rotateX(-90.*degree);
  new G4PVPlacement(rotM,
                    G4ThreeVector(0,0,0),
                    logWedge,
                    GetName(),
                    physvol->GetLogicalVolume(),
                    false,
                    0);

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.0,0.3,0.3,1.0));
  logWedge->SetVisAttributes(visAttr);

}

