//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MLineScanModel
//
//  (HISTORY)
//  2018-09-09 T.Aso Created.
//
//---------------------------------------------------------------------
//
#include "G4MLineScanModel.hh"
#include "G4MScanBeamManager.hh"
#include "CLHEP/Random/Randomize.h"
#include "G4SystemOfUnits.hh"
#include <fstream>

G4MLineScanModel::G4MLineScanModel(const G4String& name)
  :G4MVScanModel(name) {
}

G4MLineScanModel::~G4MLineScanModel(){
  fEIDVec.clear();  // EnergyID
  fXYSVec.clear();       // XY-Start
  fXYEVec.clear();       // XY-End
  fDoseVec.clear();  // Dose
  fProbVec.clear();  // Probability
}

void G4MLineScanModel::ReadScanFile(G4String& filename){
  // Open file
  std::ifstream ifs;
  ifs.open(filename.c_str());
  //
  if(!ifs) { 
    const G4String& msg =  "Scan File Not Found " + filename;
    G4Exception("G4MLineScanModel::ReadScanFile()","G4MLineScanModel00",
                FatalException,msg);
  }else{
    // Clear Vectors.
    Clear();
    // Read parameters  ( Assume space separated file. )
    G4int n;
    ifs >> n;
    //
    G4int   id;
    G4double xs, ys, xe, ye, d;
    //
    for ( G4int i = 0; i < n; i++){
      ifs >> id >> xs >> ys >> xe >> ye >> d;  
      xs *= mm;
      ys *= mm;
      xe *= mm;
      ye *= mm;
      d *= gray;
      fEIDVec.push_back(id); 
      fXYSVec.push_back(G4TwoVector(xs,ys));
      fXYEVec.push_back(G4TwoVector(xe,ye));
      fDoseVec.push_back(d);
    }
  }    
  ifs.close();
  //
}

void G4MLineScanModel::CalculateProbability(){
  G4double total = 0;
  fProbVec.clear();
  for ( size_t i = 0; i < fDoseVec.size();  i++){
    G4double energy = fpSBMgr->GetEIDEnergy(fEIDVec[i]);
    // Gy to Number of particle 
    G4TwoVector l = fXYSVec[i] - fXYEVec[i];
    G4double WNpar = fDoseVec[i]*l.r()/fpSBMgr->GetWeight(energy);
    if ( fVerbose > 2 ){
      G4cout << " ene "<<energy/MeV<<" dose "<<fDoseVec[i]/gray
             << " w "<< fpSBMgr->GetWeight(energy)/gray<<G4endl;
      G4cout << " l "<< l.r();
      G4cout << " WNpar "<<WNpar<<G4endl;
    }
    total += WNpar;
    fProbVec.push_back(total);
  }
  //
  // Normalize to 1.
  for ( size_t i = 0; i < fProbVec.size();  i++){
    fProbVec[i] /= total;
  }
}

G4double G4MLineScanModel::GetXcoord(G4int index){
  G4double dx = (fXYEVec[index].x()-fXYSVec[index].x());
  if ( dx == 0.0 ) {
    return fXYSVec[index].x();
  }else{
    G4double rl  = CLHEP::RandFlat::shoot();
    if ( dx >= 0.0 ) {
      return fXYSVec[index].x()+dx*rl;
    }else{
      return fXYEVec[index].x()+dx*rl;
    }
  }
}
G4double G4MLineScanModel::GetYcoord(G4int index){
  G4double dy = (fXYEVec[index].y()-fXYSVec[index].y());
  if ( dy == 0.0 ) {
    return fXYSVec[index].y();
  }else{
    G4double rl  = CLHEP::RandFlat::shoot();
    if ( dy >= 0.0 ) {
      return fXYSVec[index].y()+dy*rl;
    }else{
      return fXYEVec[index].y()+dy*rl;
    }
  }
}

const G4TwoVector& G4MLineScanModel::GetCoord(G4int index){
  G4double dx = (fXYEVec[index].x()-fXYSVec[index].x());
  G4double rl  = CLHEP::RandFlat::shoot();
  G4double XCoord = fXYSVec[index].x()+dx*rl;
  G4double YCoord = 0.0;
  //
  G4double dy = (fXYEVec[index].y()-fXYSVec[index].y());
  if ( dy == 0.0 ) { // Simple line mode Y=Fixed.
    YCoord = fXYSVec[index].y();
  }else{
  //  
  //  Functional Line mode Y=Variable.
    if ( dx == 0.0 ) { // Y = Uniform Randomization 
      rl  = CLHEP::RandFlat::shoot();
      YCoord = fXYSVec[index].y()+dy*rl;
    }else{ // Y = Functional Randomization
      G4double a = dy/dx;
      YCoord = a*(XCoord-fXYSVec[index].x())+fXYSVec[index].y();
    }
  }
  //
  fSpotCoord.set( XCoord, YCoord );
  return fSpotCoord;
}

G4double G4MLineScanModel::GetX(G4int index, G4int i){
  if ( i == 0 ) {
    return fXYSVec[index].x();
  }else{
    return fXYEVec[index].x();
  }
}

G4double G4MLineScanModel::GetY(G4int index, G4int i){
  if ( i == 0 ) {
    return fXYSVec[index].y();
  }else{
    return fXYEVec[index].y();
  }
}

void G4MLineScanModel::Clear(){
  fEIDVec.clear();
  fXYSVec.clear();
  fXYEVec.clear();
  fDoseVec.clear(); 
  fProbVec.clear();
}





