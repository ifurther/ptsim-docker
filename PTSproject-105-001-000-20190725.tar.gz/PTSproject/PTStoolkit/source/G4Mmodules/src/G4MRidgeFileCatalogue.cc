//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for  RidgeFilter.
// 
//  (History)
//   04-Oct-05   T.Aso
//   22-JAN-07   T.Aso Cleanup code and use SetAllParameters().
//   2014-05-19   T.Aso Type_id.(Dummy).   
//   2017-02-20   T.Aso Fatal exception in file open.
//   
//
//---------------------------------------------------------------------
//
#include "G4MRidgeFileCatalogue.hh"
#include "G4MRidgeFilter.hh"
#include <vector>
#include <fstream>
#include <sstream>

G4MRidgeFileCatalogue::G4MRidgeFileCatalogue(const G4String& name, 
                                             const G4String& fileName)
  :G4MVRidgeFilterCatalogue(name),fDefaultFileName(fileName){
}

G4MRidgeFileCatalogue::~G4MRidgeFileCatalogue()
{;}

void G4MRidgeFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(material,num_of_bars,pitch,bar_len,fxFin,fzFin);
}

void G4MRidgeFileCatalogue::Prepare(G4String& pname){
  char description[512];

  G4String fileName = pname;
  std::ifstream ifs;
  ifs.open(fileName.c_str());
  //
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MRidgeFileCatalogue::Prepare()","G4MRigeFileCata00",
                FatalException,msg);
  }
  //
  ifs.getline(description,512); // typeID
  std::istringstream sin(description);
  sin >> type_id;
  //
  ifs.getline(description,512); // description
  ifs.getline(description,512); // pid
  ifs.getline(description,512); // beamE and typeSCT
  ifs.getline(description,512); // Nominal Module/ WEP / Av

  ifs.getline(description,512); // material
  std::istringstream sin0(description);
  sin0 >> material;

  ifs.getline(description,512); // number of bars
  std::istringstream sin1(description);
  sin1 >> num_of_bars;
 
  ifs.getline(description,512); //Bar length 
  std::istringstream sin2(description);
  sin2 >> bar_len;
  bar_len = bar_len*mm;

  ifs.getline(description,512); // Pitch
  std::istringstream sin3(description);
  sin3 >> pitch;
  pitch = pitch*mm;

  ifs.getline(description,512); // Single/Double
  ifs.getline(description,512); // Number of steps
  std::istringstream sin4(description);
  sin4 >> num_of_steps;

  G4double x,h;
  fxFin.clear();
  fzFin.clear();
  for (G4int i=0; i < num_of_steps; i++ ){
    ifs.getline(description,512);
    std::istringstream sin5(description);
    sin5 >> x >> h;
    fxFin.push_back(x*mm);
    fzFin.push_back(h*mm);
  }
  ifs.close();
}


void G4MRidgeFileCatalogue::Apply(){
    fModule->SetAllParameters(material,num_of_bars,pitch,bar_len,fxFin, fzFin);
    fModule->ReBuild();
}
