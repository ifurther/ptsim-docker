//
// -----------------------------------------------------------------
// (Class Description)
//    Base class for beam module's paramters.
//    The concreate class derived from this calss has a set of 
//    parameters for a beam module.
//
// -----------------------------------------------------------------
//
// 05 Oct. 2005 T.Aso
// 
//
//
#include "G4MVDiskCollimatorCatalogue.hh"


G4MVDiskCollimatorCatalogue::G4MVDiskCollimatorCatalogue(const G4String& name)
  :G4MVParamCatalogue(name){}

 
