// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4M MLC.
// 
//  (History)
//   06-Oct-05   T.Aso
//   22-JAN-07   T.Aso Modify Visualization attributes.
//   24-APR-07   T.Aso Bug fix for material assignment of leafs.
//
//---------------------------------------------------------------------
//
#include "G4MMLCXVFileCatalogue.hh"
#include "G4MMLCXV.hh"
#include <fstream>

G4MMLCXVFileCatalogue::G4MMLCXVFileCatalogue(const G4String& name,
                                           const G4String& fileName)
  :G4MVMLCXVCatalogue(name),fDefaultFileName(fileName){
}

G4MMLCXVFileCatalogue::~G4MMLCXVFileCatalogue()
{ }

void G4MMLCXVFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fFrameDxyz,fMatMLC,fNLeafPair,fLeafDxyz,fy0Leaf,
                            theThicknessVector,thePositionVector);
}

void G4MMLCXVFileCatalogue::Prepare(G4String& pname){
  G4String fileName = pname;  
  std::ifstream ifs;
  ifs.open(fileName.c_str());

  if(!ifs) { 
    const G4String& msg =  "MLCXV File Not Found " + pname;
    G4Exception("G4MMLCXVFileCatalogue::Prepare()","G4MMLCXVFileCata00",
                FatalException,msg);
  }else{
    //G4int verbose = fModule->GetVerbose();
    G4int verbose = 1;
    if ( verbose > 0 ) G4cout << "MLCXV File open " << pname << G4endl;
    theThicknessVector.clear();
    thePositionVector.clear();

    G4double dxf,dyf,dzf;
    ifs >> dxf >> dyf>>dzf;    // Frame Full size
    if ( verbose > 0 ) G4cout << dxf << " " <<dyf<< " " <<dzf<<G4endl;
    fFrameDxyz.setX(dxf * mm/2.);
    fFrameDxyz.setY(dyf * mm/2.);
    fFrameDxyz.setZ(dzf * mm/2.);    
    

    ifs >> fMatFrame;             // Frame Material 
    ifs >> fMatMLC;               // Leaf Material 
    ifs >> fNLeafPair;            // Number of Leaf pair
    if ( verbose > 0 ) {
      G4cout << fMatFrame << " " <<fMatMLC<< " " <<fNLeafPair<<G4endl;
    }

    G4double dxl,dyl,dzl;
    ifs >> dxl >> dyl >> dzl;   // Leaf Full Size
    if ( verbose > 0 ) G4cout << dxl << " " <<dyl<< " " <<dzl<<G4endl;
    fLeafDxyz.setX(dxl * mm/2.);
    fLeafDxyz.setY(-1.0); // dummy
    fLeafDxyz.setZ(dzl * mm/2.);    

    ifs >> fy0Leaf ;              // y0 offset of first leaf
    if ( verbose > 0 ) G4cout << fy0Leaf << G4endl;
    fy0Leaf *= mm; 

    theThicknessVector.assign( fNLeafPair*2, 0.*mm);
    thePositionVector.assign( fNLeafPair*2, 0.*mm);
    for ( G4int i = 0; i < fNLeafPair; i++){ 
        G4double dythick,dxleft,dxright;
        if ( dyl < 0. ) {  // Variable.
          ifs >> dythick>> dxleft >> dxright;  // Leaf Position in [mm]
        }else{ // All leafs are same size.
          ifs >> dxleft >> dxright;  // Leaf Position in [mm]
          dythick = dyl;
        }
        if ( verbose > 0 ) G4cout<<dythick<<" " << dxleft << " " <<dxright << G4endl;
        dythick /=2.;
        dythick *=mm;
        dxleft  *= mm;
        dxright *= mm;
        theThicknessVector[i] = dythick;
        theThicknessVector[i+fNLeafPair] = dythick;
        thePositionVector[i] = dxleft;
        thePositionVector[i+fNLeafPair] = dxright;
    }
  }
}

void G4MMLCXVFileCatalogue::Apply(){
  fModule->SetAllParameters(fFrameDxyz,fMatMLC,fNLeafPair,fLeafDxyz,fy0Leaf,
                            theThicknessVector,
                            thePositionVector);
   fModule->ReBuild();
}


