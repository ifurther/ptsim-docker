//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//  Module for Propeller type component
//
// (HISTORY)
//  T.ASO
//  22-JAN-2007  T.Aso Add Visualization attributes.
// 2014-05-24 T.Aso using stringstream.
//
//---------------------------------------------------------------------
//
#include "G4MPropellerBlades.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4RotationMatrix.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include <sstream>

G4MPropellerBlades::G4MPropellerBlades(const G4String &name, 
                                       G4double radius,
                                       std::vector<G4double>& angles, 
                                       std::vector<G4double>& DZs, 
                                       G4int nfin, const G4String &mat)
    : G4MVBeamModule(name), fBladeAngle(angles),fBladedZ(DZs),
      fnFin(nfin), matName(mat), fCatalogue(NULL)
{
    G4double dZ =0.;
    for ( G4int i = 0; i < (G4int)fBladedZ.size(); i++){
        dZ +=  fBladedZ[i];
    }
    fEnvelopeSize.set(0.0,radius,dZ*2.); //For placing 
}

G4MPropellerBlades::G4MPropellerBlades(const G4String &name)
    : G4MVBeamModule(name), fCatalogue(NULL)
{}

G4MPropellerBlades::G4MPropellerBlades(G4MVPropellerBladesCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MPropellerBlades::~G4MPropellerBlades()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MPropellerBlades::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MPropellerBlades::SetAllParameters(G4double radius, 
                                          std::vector<G4double>& angles, 
                                          std::vector<G4double>& DZs, 
                                          G4int nfin,const G4String &mat){
    fBladeAngle = angles;
    fBladedZ = DZs;
    G4double dZ =0.;
    for ( G4int i = 0; i < (G4int)fBladedZ.size(); i++){
        dZ +=  fBladedZ[i];
    }
    fEnvelopeSize.set(0.0,radius,dZ*2.);
    fnFin = nfin;
    matName=mat;
}

G4VPhysicalVolume* G4MPropellerBlades::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(fMasterMat);

  G4double dR = fEnvelopeSize.y();
  G4double dZ = fEnvelopeSize.z();
  G4Tubs *solid = new G4Tubs(GetName(), 0,  dR, dZ*2., 0, twopi);
    
  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName()); 

  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                   lv,
                                                   GetName(),
                                                   worldlog,
                                                   false,
                                                   0);

    
  //G4VisAttributes* visAtt = new G4VisAttributes(G4Colour(0.1,0.1,0.1,0.1));
  //visAtt->SetVisibility(true);
  //lv->SetVisAttributes(visAtt);
  lv->SetVisAttributes(G4VisAttributes::Invisible);

  return physical;
}

void G4MPropellerBlades::buildNode(G4VPhysicalVolume* physvol )
{
   G4double AngleStep  = 360.*degree / (G4double)fnFin;

   G4double dR= fEnvelopeSize.y();
   G4double z = -fEnvelopeSize.z();  
   std::stringstream os;
   for(G4int i=0; i<(G4int)fBladedZ.size(); i++){
    G4Material* matCom=G4Material::GetMaterial(matName);
    os.str("");
    os << "BladeCom" << i;
    //G4String comName="BladeCom"+i;
    G4String comName= os.str();
    G4VSolid* solCom= new G4Tubs(GetName(),0,dR,fBladedZ[i],
                                 -fBladeAngle[i]/2., +fBladeAngle[i]);
    G4LogicalVolume* logCom=new G4LogicalVolume(solCom,matCom,comName);
    logCom->SetVisAttributes(new G4VisAttributes(G4Colour(0.0,0.0,1.0)));
   
    z+=fBladedZ[i];      
    for ( G4int jfin =0; jfin < fnFin; jfin++){
        G4double startAngle = AngleStep*jfin;
        G4RotationMatrix* rot = new G4RotationMatrix();
        rot->rotateZ(startAngle);
        //G4VPhysicalVolume* phyCom=
        new G4PVPlacement(rot,G4ThreeVector(0.,0.,z),logCom,
                          comName,physvol->GetLogicalVolume(),false,jfin);
    }
    z+=fBladedZ[i];        
  }

}
