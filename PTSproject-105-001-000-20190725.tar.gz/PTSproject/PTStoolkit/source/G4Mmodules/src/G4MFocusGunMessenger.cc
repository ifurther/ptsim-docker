//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//---------------------------------------------------------------------
//  G4MFocusGunMessenger
//
//  Modified 
//  By W.Takase
//  24-DEC-08  T.Aso Remove emittance setting
//  2013-03-30 T.Aso PhysicalConstants/SystemOfUnits.
//
//---------------------------------------------------------------------
//
//
#include "G4MFocusGunMessenger.hh"
#include "G4MFocusGun.hh"
#include "G4ParticleDefinition.hh"
#include "G4Proton.hh"
#include "G4ThreeVector.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4ParticleTable.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include <sstream>
#include <fstream>

G4MFocusGunMessenger::G4MFocusGunMessenger(G4MFocusGun * fPtclGun)
  :fParticleGun(fPtclGun)
{
  gunDirectory = new G4UIdirectory("/G4M/Beam/");
  gunDirectory->SetGuidance("Beam Gun control commands.");

  eflucCmd = new G4UIcmdWithADoubleAndUnit("/G4M/Beam/energyfluc",this);
  eflucCmd->SetGuidance("Set Energy fluctuation of the Beam.");
  eflucCmd->SetParameterName("dE",false);
  eflucCmd->SetDefaultUnit("MeV");
  eflucCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  beamFileCmd = new G4UIcmdWithAString("/G4M/Beam/file",this);
  beamFileCmd->SetGuidance("File name for setting Beam parameters from file");
  beamFileCmd->SetParameterName("FileName",false);
  beamFileCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  focusDistXCmd = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/FocusDistanceX",this);
  focusDistXCmd->SetGuidance("Foucus point of X in Z");
  focusDistXCmd->SetParameterName("Z-Position",false);
  focusDistXCmd->SetDefaultUnit("mm");
  focusDistXCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  focusDistYCmd = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/FocusDistanceY",this);
  focusDistYCmd->SetGuidance("Foucus point of Y in Z");
  focusDistYCmd->SetParameterName("Z-Position",false);
  focusDistYCmd->SetDefaultUnit("mm");
  focusDistYCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  spExpandXCmd  = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/SpatialExpanseX",this);
  spExpandXCmd->SetGuidance("Sigma of beam for focusing");
  spExpandXCmd->SetParameterName("Expanse of beam in X ",false);
  spExpandXCmd->SetDefaultUnit("mrad");
  spExpandXCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  spExpandYCmd  = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/SpatialExpanseY",this);
  spExpandYCmd->SetGuidance("Sigma of beam for focusing");
  spExpandYCmd->SetParameterName("Expanse of beam in Y ",false);
  spExpandYCmd->SetDefaultUnit("mrad");
  spExpandYCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // set initial value to G4MBeamGun
  fParticleGun->SetParticleDefinition( G4Proton::Proton() );
  fParticleGun->SetParticleMomentumDirection( G4ThreeVector(0.0,0.0,-1.0) );
  fParticleGun->SetParticleEnergy( 200.0*MeV );
  fParticleGun->SetParticlePosition(G4ThreeVector(0.*mm, 0.*mm, 3000.0*mm));
  fParticleGun->SetParticleTime( 0.0*ns );
  fParticleGun->SetFocusDistanceX( 0.0*mm );
  fParticleGun->SetFocusDistanceY( 0.0*mm );
  fParticleGun->SetSpatialExpanseX( 0.0*mrad );
  fParticleGun->SetSpatialExpanseY( 0.0*mrad );
  //
}

G4MFocusGunMessenger::~G4MFocusGunMessenger()
{
  delete eflucCmd;
  delete gunDirectory;
  delete beamFileCmd;
  delete focusDistXCmd;
  delete focusDistYCmd;
  delete spExpandXCmd;
  delete spExpandYCmd;
}

void G4MFocusGunMessenger::SetNewValue(G4UIcommand * command,G4String newValues)
{
  if ( command == eflucCmd ) {
    fParticleGun->SetEnergyFluctuation(eflucCmd->GetNewDoubleValue(newValues)); 
  }
  else if (command == beamFileCmd ) {
    char chline[512];
    G4String filename = newValues;// newValues should be a exact file name.
    std::ifstream ifs;
    ifs.open(filename.c_str());

    ifs.getline(chline,512);  //energy ID
    ifs.getline(chline,512);  //description

    ifs.getline(chline,512);  //particle ID
    std::istringstream iss1(chline);
    G4int particleID;
    iss1 >> particleID;
    G4ParticleDefinition* pdef = 
      G4ParticleTable::GetParticleTable()->FindParticle(particleID);
    fParticleGun->SetParticleDefinition(pdef);

    ifs.getline(chline,512);  //particle energy / energy spread
    std::istringstream iss2(chline);
    G4double particleEN;
    G4double ENspread;
    iss2 >> particleEN >> ENspread;
    fParticleGun->SetParticleEnergy(particleEN*MeV);
    fParticleGun->SetEnergyFluctuation(ENspread);

    //angular variance /spatial covaliance /spatial variance
    ifs.getline(chline,512);  
    std::istringstream iss3(chline);
    G4double angularv;  //angular variance
    G4double angulars;  //angular-spatial covaliance
    iss3 >> angularv >> angulars;

    ifs.getline(chline,512);  //spatial variance in X and Y
    std::istringstream iss4(chline);
    G4double spatialx;  //spatial variance
    G4double spatialy;  //spatial variance
    iss4 >> spatialx >> spatialy ; // Not Used in FocusGun
    ifs.close();
  }
  else if ( command == focusDistXCmd ) {
    fParticleGun->
      SetFocusDistanceX(focusDistXCmd->GetNewDoubleValue(newValues));
  }
  else if ( command == focusDistYCmd ) {
    fParticleGun->
      SetFocusDistanceY(focusDistYCmd->GetNewDoubleValue(newValues));
  }
  else if ( command == spExpandXCmd ) {
    fParticleGun->
      SetSpatialExpanseX(spExpandXCmd->GetNewDoubleValue(newValues));
  }
  else if ( command == spExpandYCmd ) {
    fParticleGun->
      SetSpatialExpanseY(spExpandYCmd->GetNewDoubleValue(newValues));
  }
}

G4String G4MFocusGunMessenger::GetCurrentValue(G4UIcommand * command)
{
  G4String cv;
  
  if ( command==eflucCmd )
  { cv = 
      eflucCmd->ConvertToString(fParticleGun->GetEnergyFluctuation(),"MeV");}
  return cv;
}


