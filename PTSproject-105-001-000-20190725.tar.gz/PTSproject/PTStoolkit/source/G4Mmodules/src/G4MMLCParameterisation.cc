//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MMLCParameterisation
//
//  (HISTORY)
//  2013-03-30 T.Aso PhysicalConstants/SystemOfUnits.
//
//---------------------------------------------------------------------
//
#include "G4MMLCParameterisation.hh"
#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"


G4MMLCParameterisation::G4MMLCParameterisation(G4int nleafpair, 
                                               G4double dxleaf,
                                               G4double dyleaf,
                                               G4double dzleaf,
                                               G4double y0leaf,
                                               G4Material* mat):
  fNofVolume(0),fNLeafPair(nleafpair),
  fdxLeaf(dxleaf),fdyLeaf(dyleaf),fdzLeaf(dzleaf), 
  fy0(y0leaf),fmat(mat)
{
  fpX.clear();
  fpY.clear();
  fdX.clear();
}

G4MMLCParameterisation::~G4MMLCParameterisation(){
  fpX.clear();
  fpY.clear();
  fdX.clear();
}


void G4MMLCParameterisation::CalculateActiveVolume(std::vector<G4double>& xval){
  // xval represents a set of leaf position.
  // Leaf positions are given ...
  // xval is  from -x,-y to -x,+y, then +x,-y to +x,+y.
  if ( (G4int)xval.size() != fNLeafPair*2 ) {
    G4cerr << "G4MMLCParameterisation::Xvalues: Size Length Missmatch"<<G4endl;
    exit(-1);
  }

  G4int n = fNLeafPair;
  G4int nActive=0;
  for (G4int i = 0; i < n ; i++) if ( xval[i]!=xval[n+i] ) nActive++;
  fpX.resize(nActive);
  fpY.resize(nActive);
  fdX.resize(nActive);

  fNofVolume = 0;
  for ( G4int i = 0; i < n ; i++) {
    if ( xval[i] != xval[n+i] ) {
      fpX[fNofVolume]= (xval[i]+xval[n+i])/2.;
      fpY[fNofVolume]= fy0 + i*fdyLeaf*2.;
      fdX[fNofVolume]= (xval[n+i] - xval[i])/2.;
      G4cout <<"++MLC:" <<i<<" ( "<<xval[i]/mm<<" , "<<xval[n+i]<<" )"
             <<" pX "<<fpX[fNofVolume]/mm
             <<" pY "<<fpY[fNofVolume]/mm << " dX " << fdX[fNofVolume]/mm
             <<" dummy dx " << fdxLeaf<<G4endl;

      fNofVolume++;
    }

  }
}

void G4MMLCParameterisation::
ComputeTransformation(const G4int copyNo,  G4VPhysicalVolume* physVol)const
{
  G4ThreeVector position(fpX[copyNo],fpY[copyNo],0.*mm);
  physVol->SetTranslation(position);
}

void G4MMLCParameterisation::ComputeDimensions(G4Box & boxel, 
                                               const G4int copyNo,
                                               const G4VPhysicalVolume*) const
{
  boxel.SetXHalfLength(fdX[copyNo]);
  boxel.SetYHalfLength(fdyLeaf);
  boxel.SetZHalfLength(fdzLeaf);
}

G4Material* G4MMLCParameterisation::ComputeMaterial (const G4int , 
                                                     G4VPhysicalVolume*,
                                                     const G4VTouchable*)
{
  return fmat;
}

