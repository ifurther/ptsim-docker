//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Tet class for defining a new Module 
//
// (HISTORY)  
//   2017-11-14  S.Ogasawara (NITTC Aso lab)
//   2018-03-10  T.Aso Clean up and Modify code.
//
//---------------------------------------------------------------------
//
#include "G4MTetModule.hh"
#include "G4MVTetModuleCatalogue.hh"
#include "G4Material.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Box.hh"
#include "G4PhysicalConstants.hh"
#include "G4MTetParameterisation.hh"

//---------------------------------------------------------------------
G4MTetModule::G4MTetModule(const G4String& name)
  : G4MVBeamModule(name),fEnvMat(0),fFileList(""),fFileCT2Dens(""),
    fFileRoi2Mat(""),fCatalogue(0),fParam(0),fEnvelopePhys(0)
{}
//---------------------------------------------------------------------
G4MTetModule::G4MTetModule(G4MVTetModuleCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fEnvMat(0),fCatalogue(catalogue),
    fParam(0),fEnvelopePhys(0){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}
//---------------------------------------------------------------------
G4MTetModule::~G4MTetModule()
{
  if ( fParam ) delete fParam;
  if ( fCatalogue ) delete fCatalogue;
}
//---------------------------------------------------------------------
void G4MTetModule::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}
//---------------------------------------------------------------------
void G4MTetModule::SetAllParameters(const G4String& fileList, 
                                    const G4String& fileCT2Dens,
                                    const G4String& fileRoi2Mat){
  fFileList = fileList;
  fFileCT2Dens = fileCT2Dens;
  fFileRoi2Mat = fileRoi2Mat;
}
//---------------------------------------------------------------------
void G4MTetModule::Dump(std::ostream& out){
  out << "G4MTetModule:: Bounding Box (half./mm) " << fEnvelopeSize/mm << G4endl;
  if ( flang == 1 && fParam ){
    G4ThreeVector pos;
    G4double volume=0.0;
    G4double density=0.0;
    out << "G4MTetModule::Dump() "<< fParam->GetNoOfActive() << G4endl;
    for ( G4int i = 0; i < fParam->GetNoOfActive(); i++){
      //
      fParam->GetTetInfo(i,pos,volume,density);
      out << i <<","
          <<pos.x()/mm<<","
          <<pos.y()/mm<<","
          <<pos.z()/mm<<","
          <<volume/cm3<<","
          <<density/(g/cm3)<<G4endl;
    }
  }
}
//---------------------------------------------------------------------
G4MDICOMCTROI2Material* G4MTetModule::PrepareMatListROI(){
  G4MDICOMCTROI2Material* matListROI = 
    new G4MDICOMCTROI2Material(fFileCT2Dens,fFileRoi2Mat);
  matListROI->SetDensityResol(fDensResol);
  matListROI->SetCTWindow(fHUMin,fEnvMat,fHUMax);
  matListROI->CreateMaterial();
  return matListROI;
}
//---------------------------------------------------------------------
G4VPhysicalVolume* G4MTetModule::buildEnvelope(G4LogicalVolume* worldlog)
{
  //
  //  Envelope of this Beam Module.
  //
  //
  // Material (example)
  fEnvMat = 0;
  // A material is assigned to Air in Mass geometry. 
  if ( worldlog->GetName() == "Room"){
    fEnvMat = G4Material::GetMaterial(fMatAir);
  }
  // 
  // Solid  (Dummy)
  G4ThreeVector dxyz(50.*cm,50.*cm,50.*cm);
  SetEnvelopeSize(dxyz);
  G4Box *solid = new G4Box(GetName(),dxyz.x(),dxyz.y(),dxyz.z());
  //
  // LogicalVolume (example)
  G4LogicalVolume* logicEnv = new G4LogicalVolume(solid, fEnvMat, GetName());
  //
  // PhysicslVolume (example) 
  //    The rotation and position can be modified by UI commands.
  fEnvelopePhys = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                  logicEnv,
                                                  GetName(),
                                                  worldlog,
                                                  false,
                                                  0,
                                                  true);
  return fEnvelopePhys;
}
//---------------------------------------------------------------------
void G4MTetModule::buildNode(G4VPhysicalVolume* physvol){
  //
  //  Define sub-components inside the envelope
  //
  G4LogicalVolume *logMother = physvol->GetLogicalVolume();

  G4cout << "prepare matlistROI..." << G4endl;
  G4MDICOMCTROI2Material* matList = PrepareMatListROI();
  G4cout << "prepare matlistROI Complete!" << G4endl;

  if ( fParam ) { delete fParam; };
  fParam = new G4MTetParameterisation(fFileList, matList);
  fParam->ReadFileList();
  ModifyEnvelope(fParam);

  // Dummy Tet
  G4double tet[12]={0,0,0,100,0,0,0,100,0,0,0,100};
  G4ThreeVector p0(tet[0],tet[1],tet[2]);
  G4ThreeVector p1(tet[3],tet[4],tet[5]);
  G4ThreeVector p2(tet[6],tet[7],tet[8]);
  G4ThreeVector p3(tet[9],tet[10],tet[11]);
  G4Tet* solidTet = new G4Tet("TetDummy",p0,p1,p2,p3);
  //
  G4LogicalVolume* logicTet =                         
    new G4LogicalVolume(solidTet,          //its solid
                        G4Material::GetMaterial(fMatAir), //its material
                        "TetDummy");            //its name
  //
  //G4cout << " TetModule GetNoOfActive()" << fParam->GetNoOfActive() << G4endl;
  //
  new G4PVParameterised("Tet",logicTet,logMother,kUndefined,
                        fParam->GetNoOfActive(),
                        fParam);
  //G4cout << " TetModule EndOfBuildNode " <<G4endl;
}
//---------------------------------------------------------------------
void G4MTetModule::ModifyEnvelope(G4MTetParameterisation* param){
  if (!fEnvelopePhys) {
    G4Exception("G4MTetModule::ModifyEnvelope()","G4MTetModule00",
                JustWarning,"No physVol for Envelope");
  }
  G4VSolid* solid = fEnvelopePhys->GetLogicalVolume()->GetSolid();
  if( solid->GetEntityType() != "G4Box" ){
    const G4String& msg ="G4MTet: - Solid type is not supported.";
    G4Exception("G4MTet::ModifyEnvelope()","G4MTet00",
                JustWarning,msg);
  }
  const G4ThreeVector& dxyz = param->GetDxyz();
  //G4cout << "G4MTetModuule:: " << dxyz << G4endl;
  G4Box* box = (G4Box*)(solid);
  box->SetXHalfLength(dxyz.x());
  box->SetYHalfLength(dxyz.y());
  box->SetZHalfLength(dxyz.z());
  fEnvelopeSize.set(dxyz.x(),dxyz.y(),dxyz.z());
  //G4cout << "G4MTetModule " <<G4endl;
  //
}
