//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for PCTTubeDetector
// 
// (HISTORY)
// 19 Dec. 2010 T.Aso
//
//---------------------------------------------------------------------
//
//
#include "G4MPCTTubeDetectorFileCatalogue.hh"
#include "G4MPCTTubeDetector.hh"
#include <fstream>

G4MPCTTubeDetectorFileCatalogue::
G4MPCTTubeDetectorFileCatalogue(const G4String& name,
			    const G4String& fileName)
  :G4MVPCTTubeDetectorCatalogue(name),fDefaultFileName(fileName),fVerbose(0){
}

G4MPCTTubeDetectorFileCatalogue::~G4MPCTTubeDetectorFileCatalogue()
{}

void G4MPCTTubeDetectorFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fRin,fRout,fDz,fMaterial);
}

void G4MPCTTubeDetectorFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File not found "+pname;
    G4Exception("G4MPCTTubeDetectorFileCatalogue::Prepare()",
		"G4MPCTTubeDetFileCata00",FatalException,msg);
  }else{
    fileio >> fRin >> fRout >> fDz ;
    fileio >> fMaterial ;
    if ( fVerbose > 0 ) {
      G4cout << fMaterial <<" "<<fRin<<" "<<fRout<<" "<<fDz<<G4endl;
    }
    fRin  *= mm;
    fRout *= mm;
    fDz   *= (mm/2.);  // Full width to half width.
  }
}

void G4MPCTTubeDetectorFileCatalogue::Apply(){
  fModule->SetAllParameters(fRin,fRout,fDz,fMaterial);
  fModule->ReBuild();
}
