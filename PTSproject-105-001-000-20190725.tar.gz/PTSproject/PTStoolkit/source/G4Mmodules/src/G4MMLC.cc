//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//   Class for MLC Beam Module.
//    G4MMLC(const G4String& name, const G4ThreeVector& dxyz, 
//	     const G4String& matMLC, 
//	     G4int nyleaf, G4double y0leaf, G4double dyleaf,
//	     std::vector<G4double>& leafposition)
//    name : Module Name
//    dxyz : Half length Size of MLC envelope
//    matMLC: Matrial name of MLC
//    nyleaf:  Number of leaf pair, namly total nyleaf*2 for left and right.
//    y0leaf:  y offset of first leaf. First leaf must be start from -Y.
//    dyleaf:  half length of a leaf thickness.
//    leafposition:  Position of leafs, i.e the open edge of ridges.
//
//       Numbering of leaf for leaf position.
//   +Y
//    |__ +X 
//             nyleaf-1   2*nyleaf-1
//                .         .
//                .         .
//                2       nyleaf+2
//                1       nyleaf+1
//                0       nyleaf+0
//
//
//  (HISTORY)
//   06-OCT-ASO   Add desctiption.
//
//---------------------------------------------------------------------
//
#include "G4MMLC.hh"

#include "G4PVParameterised.hh"
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MMLC::G4MMLC(const G4String& name, 
	       const G4ThreeVector& dxyz, const G4String& matMLC,
	       G4int nyleaf, G4double y0leaf, G4double dyleaf,
	       std::vector<G4double>& leafposition) 
  :G4MVBeamModule(name,dxyz),fMatMLC(matMLC),fMatHole("Air"),
   fNLeafPair(nyleaf),fy0Leaf(y0leaf),fDyLeaf(dyleaf),
   thePositionVector(leafposition),fCatalogue(NULL)
{}

G4MMLC::G4MMLC(const G4String& name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MMLC::G4MMLC(G4MVMLCCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MMLC::~G4MMLC() {
  thePositionVector.clear();
  if ( fCatalogue ) delete fCatalogue;
}

void G4MMLC::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MMLC::SetAllParameters(const G4ThreeVector& dxyz, 
			      const G4String& matMLC,
			      G4int nyleaf, G4double y0leaf, G4double dyleaf,
			      std::vector<G4double>& leafposition) 
{
   fEnvelopeSize=dxyz;
   fMatMLC=matMLC;
   fMatHole="Air";
   fNLeafPair=nyleaf;
   fy0Leaf=y0leaf;
   fDyLeaf=dyleaf;
   thePositionVector=leafposition;
}

void G4MMLC::SetMatMLC(const G4String& mat) {
  fMatMLC = mat;
}

void G4MMLC::SetLeafPosition(std::vector<G4double>& xleafpos) {
  thePositionVector = xleafpos;
}

G4VPhysicalVolume* G4MMLC::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* matMLC = G4Material::GetMaterial(fMatMLC);
  G4VSolid* solid = 
    new G4Box(GetName(),fEnvelopeSize.x(),fEnvelopeSize.y(),fEnvelopeSize.z());
  G4LogicalVolume* logical = new G4LogicalVolume(
				 solid,          // Solid 
                                 matMLC,         // Material
				 GetName());     // Name

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(0.5,1.0,0.5));
  logical->SetVisAttributes(visAttr);

  G4VPhysicalVolume* physical  = new G4PVPlacement(
  	             GetRotation(),
  	             GetTranslation(),
                     logical,                     // Logical volume  
                      GetName(),                  // Name
                     worldlog,                    // Mother  volume 
                     false,                       // Not used 
                     0);                          // Copy number  
  return physical;
}

void G4MMLC::buildNode(G4VPhysicalVolume* physvol) {

  //-----  MLC "Air" Window
  G4VSolid* solhole =  new G4Box(fMatHole,
			        fEnvelopeSize.x(),fDyLeaf,fEnvelopeSize.z());

  G4Material* matHole= G4Material::GetMaterial(fMatHole);
  G4LogicalVolume* loghole = new G4LogicalVolume(solhole,matHole,"hole");
  fParameterisation = 
    new G4MMLCParameterisation(fNLeafPair,
			       fEnvelopeSize.x(),fDyLeaf,fEnvelopeSize.z(),
			       fy0Leaf,
			       matHole);
  fParameterisation->CalculateActiveVolume(thePositionVector);
  G4int nofvolume = fParameterisation->GetNofActiveVolume();
  if ( nofvolume > 0 ) {
    G4VPhysicalVolume *phys = 
      new G4PVParameterised(GetName(),
			    loghole,
			    physvol->GetLogicalVolume(),
			    kZAxis,
			    nofvolume,
			    fParameterisation);
    fParamPhysVol = phys;
  }
}

