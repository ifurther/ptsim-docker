//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MWobblerFieldX
//
//  (HISTORY)
//   2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#include "G4MWobblerFieldX.hh"

G4MWobblerFieldX::G4MWobblerFieldX(G4double amp, G4double ang)
  : G4MVWobblerField(amp,ang)
{
  G4double B[3];
  B[0] = 0;
  B[1] = amp*cos(ang);
  B[2] = 0;
  SetFieldValue(B);
}

G4MWobblerFieldX::G4MWobblerFieldX(const G4MWobblerFieldX& right)
  :G4MVWobblerField(right){
}

G4MWobblerFieldX* G4MWobblerFieldX::Copy(){
  return new G4MWobblerFieldX(*this);
}

G4MWobblerFieldX::~G4MWobblerFieldX() {
}

void G4MWobblerFieldX::calcField() {
  G4double B[3];
  B[0] = 0;
  B[1] = GetAmplitude()*cos(GetAngle());
  B[2] = 0;
  SetFieldValue(B);
}

