//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   04-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MPolyConesFileCatalogue.hh"
#include "G4MPolyCones.hh"
#include <fstream>
#include <sstream>

G4MPolyConesFileCatalogue::G4MPolyConesFileCatalogue(const G4String& name,
					   const G4String& fileName)
  :G4MVPolyConesCatalogue(name),fDefaultFileName(fileName){
}

G4MPolyConesFileCatalogue::~G4MPolyConesFileCatalogue()
{}

void G4MPolyConesFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fMaterial,fRin,fRout,fThickness,
			    NofCone,
			    material,
			    NofPlane,
			    rInner,
			    rOuter,
			    zPlane);
}

void G4MPolyConesFileCatalogue::Prepare(G4String& pname){

  material.clear();
  NofPlane.clear();
  zPlane.clear();
  rInner.clear();
  rOuter.clear();
  /////////////////////////////////////////////////////////////////
  std::ifstream ifs;
  G4String filename = pname;

  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MPolyConesFileCatalogue::Prepare()","G4MPolyConFileCata00",
		FatalException,msg);
  }else{
    ifs.getline(chline,512);  //scatterer ID
    ifs.getline(chline,512);  //description

    ifs.getline(chline,512);  //Envelope
    std::istringstream iss1(chline);
    iss1 >> fMaterial >> fRin >> fRout >> fThickness;
    fRin = fRin*mm;
    fRout = fRout*mm;
    fThickness = fThickness*mm /2.;

    ///////////////// for polycones

    ifs.getline(chline,512);  //number of polycone
    std::istringstream iss4(chline);
    iss4 >> NofCone;
    
    for(G4int cID=0; cID<NofCone; cID++){

      // material
      ifs.getline(chline,512);
      std::istringstream iss5(chline);
      G4String matName;
      iss5 >> matName;
      material.push_back(matName);
      
      // number of plane
      ifs.getline(chline,512);
      std::istringstream iss6(chline);
      G4int nPlane;
      iss6 >> nPlane;
      NofPlane.push_back(nPlane);
      
      for(G4int pID=0; pID<nPlane; pID++){
	// rInner, rOuter, zPlane
	ifs.getline(chline,512);
	std::istringstream iss7(chline);
	G4double rIn;
	G4double rOut;
	G4double zPl;
	iss7 >> zPl >> rIn >> rOut;
	rIn *= mm;
	rOut*= mm;
	zPl *= mm;
	rInner.push_back(rIn);
	rOuter.push_back(rOut);
	zPlane.push_back(zPl);
      }
    }
  }
  ifs.close();
}

void G4MPolyConesFileCatalogue::Apply(){
  fModule->SetAllParameters(fMaterial,fRin,fRout,fThickness,
			    NofCone,
			    material,
			    NofPlane,
			    rInner,
			    rOuter,
			    zPlane);
}







 
