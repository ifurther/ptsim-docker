//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Class Description)
//    Base class for beam modules.
//
// (HISTORY)
// 05 Oct. 2005 T.Aso
// 05 Oct. 2005 T.Aso Modified to include G4MVParamCatalogue
//                    Add method  ReBuild(), ApplyFromCatalogue().
//                    Add overload method for 
//                       SetRotation(G4ThreeVector&).
// 22 Nov. 2006 T.Aso Suppress warning at ReBuild().
// 10 Sep. 2010 T.Aso Add Verbose. Initialize fOffset.
// 2012-06-06   T.Aso Add Dump().
// 2013-10-24   T.Aso flang variable for Language in Dump().
// 2014-03-31   T.Aso Call DeRegister() when cleanup volume.
//                    Add UpdateRegion() for forcing update in PW.
// 2015-02-26   T.Aso copy a productionCuts of world to a beam module
//                    in UpdateRegion().
// 2015-06-11   T.Aso Modify UpdateRegion() to avoid a warnning.
// 2015-07-26   T.Aso GetName().
// 2017-02-20   T.Aso Commented removing fpRotation.
// 2017-03-15 T.Aso Threading
// 2018-04-22 T.Aso fMatAir for common material name of air.
// -----------------------------------------------------------------
//
#include "G4MVBeamModule.hh"
#include "G4RunManager.hh"
#include "G4RegionStore.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4ProductionCuts.hh"
#include "G4ProductionCutsTable.hh"

G4MVBeamModule::G4MVBeamModule(const G4String& name, 
                               const G4ThreeVector& translation, 
                               const G4RotationMatrix& rotation) 
  :fEnvelopeSize(0,0,0),fOffset(0,0,0),fType(0),fVerbose(0),flang(0),
   fName(name),fTranslation(translation),fPhysVol(0) {
  fpRotation = new G4RotationMatrix(rotation);
  fSdLVList.clear();
  fFieldLVList.clear();
  fMatAir = "G4_AIR";
}

G4MVBeamModule::G4MVBeamModule(const G4String& name )
:fEnvelopeSize(0,0,0),fOffset(0,0,0),fVerbose(0),
 fName(name),fPhysVol(0)  {
  fpRotation = new G4RotationMatrix();
  fSdLVList.clear();
  fFieldLVList.clear();
  fMatAir = "G4_AIR";
}

G4MVBeamModule::G4MVBeamModule(const G4String& name, const G4ThreeVector& dxyz)
: fEnvelopeSize(dxyz),
  fOffset(0,0,0),fVerbose(0),fName(name),fPhysVol(0){
  fpRotation = new G4RotationMatrix();
  fSdLVList.clear();
  fFieldLVList.clear();
  fMatAir = "G4_AIR";
}

G4MVBeamModule::~G4MVBeamModule() {
  if ( fPhysVol ) {
    delete fPhysVol;
  }
  //if ( fpRotation ){
  //  delete fpRotation;
  //}
  fpRotation = 0;
  //
  fSdLVList.clear();
  fFieldLVList.clear();
}

const G4String G4MVBeamModule::GetName(G4int i){
  std::ostringstream oss;
  oss << GetName() << i;
  return oss.str();
}
const G4String G4MVBeamModule::GetName(G4String& name, G4int i)const{
  std::ostringstream oss;
  oss << name<< i;
  return oss.str();
}


void G4MVBeamModule::SetTranslation(const G4ThreeVector& trans) {
  fTranslation = trans;
  if( fPhysVol ) {
    fPhysVol->SetTranslation(trans);
    G4RunManager::GetRunManager()->GeometryHasBeenModified();
  }
}

void G4MVBeamModule::SetRotation(const G4RotationMatrix& rot) {
  *fpRotation = rot;  
  if( fPhysVol ) {
    fPhysVol->SetRotation(fpRotation);
    G4RunManager::GetRunManager()->GeometryHasBeenModified();
  }
}

void G4MVBeamModule::SetRotation(const G4ThreeVector& rot) {
  G4RotationMatrix rm;
  rm.rotateX(rot.x());
  rm.rotateY(rot.y());
  rm.rotateZ(rot.z());
  SetRotation(rm);
}

void G4MVBeamModule::PlaceAtDownZEdge(G4double zedge ){
  fTranslation.setX(fOffset.x());
  fTranslation.setY(fOffset.y());
  fTranslation.setZ(zedge+fEnvelopeSize.z()+fOffset.z());
  if( fPhysVol ) {
    fPhysVol->SetTranslation(fTranslation);
    G4RunManager::GetRunManager()->GeometryHasBeenModified();
  }
}

void G4MVBeamModule::PlaceAtUpZEdge(G4double zedge){
  fTranslation.setX(fOffset.x());
  fTranslation.setY(fOffset.y());
  fTranslation.setZ(zedge-fEnvelopeSize.z()+fOffset.z());
  if( fPhysVol ) {
    fPhysVol->SetTranslation(fTranslation);
    G4RunManager::GetRunManager()->GeometryHasBeenModified();
  }
}

void G4MVBeamModule::PlaceAtCenterZ(G4double z){
  fTranslation.setX(fOffset.x());
  fTranslation.setY(fOffset.y());
  fTranslation.setZ(z+fOffset.z());
  if( fPhysVol ) {
    fPhysVol->SetTranslation(fTranslation);
    G4RunManager::GetRunManager()->GeometryHasBeenModified();
  }
}

void G4MVBeamModule::CleanUpVolumes() {
  if ( fPhysVol ) {
    cleanUpDaughters(fPhysVol);
    G4LogicalVolume* mother = fPhysVol->GetMotherLogical();
    mother->RemoveDaughter(fPhysVol);
    G4LogicalVolume* l = fPhysVol->GetLogicalVolume();
    G4LogicalVolumeStore::GetInstance()->DeRegister(l);
    delete fPhysVol;
    fPhysVol=NULL;
  } else {
    G4cout << "@@@ PhysicalVolume is not exists ..." << GetName() << G4endl;
  }
}


void G4MVBeamModule::CleanUpRegion() {
  G4Region* reg = fPhysVol->GetLogicalVolume()->GetRegion();
  if ( reg ) {
    G4cout << " *** Remove G4Region ; "<<reg->GetName() <<G4endl;
    G4RegionStore::GetInstance()->DeRegister(reg);
  }
}


void G4MVBeamModule::cleanUpDaughters(G4VPhysicalVolume* physVol){
  G4LogicalVolume* myLog = physVol->GetLogicalVolume();
  G4int N = myLog->GetNoDaughters();
  for ( G4int i = 0; i < N ; i++){
    G4VPhysicalVolume* p = myLog->GetDaughter(i);
    cleanUpDaughters(p);
    G4LogicalVolume* l = p->GetLogicalVolume();
    G4LogicalVolumeStore::GetInstance()->DeRegister(l);
    myLog->RemoveDaughter(p);
  }
}

G4VPhysicalVolume* G4MVBeamModule::BuildIn(G4LogicalVolume* worldlog) {
  if( !fPhysVol ){
    fSdLVList.clear();
    fFieldLVList.clear();
    fPhysVol = buildEnvelope(worldlog);
    G4cout << "==>> Constructing ..." << GetName() << G4endl;    
    buildNode(fPhysVol);
#if !defined(G4MULTITHREADED)
     BuildInSDandField();
#endif
  } else {
    G4cout << "@@@ PhysicalVolume already exists ..." << GetName() << G4endl; 
  }
    return fPhysVol;
}

void G4MVBeamModule::ReBuild(){
  if ( fPhysVol ){
    G4LogicalVolume* world = fPhysVol->GetMotherLogical();
    CleanUpVolumes();
    BuildIn(world);
  } else {
    //G4cout << "G4MVBeamModule::Rebuild - "<<fName<< " is not installed"
    //<<G4endl;
  }
}

void G4MVBeamModule::UpdateRegion(){
  G4Region* aReg =  
    G4RegionStore::GetInstance()->FindOrCreateRegion(GetName());
  G4ProductionCuts* prodCuts = aReg->GetProductionCuts();
  if ( !prodCuts ) {
    // Copy world's productinCuts.
    G4Region* worldReg =  
      G4RegionStore::GetInstance()->FindOrCreateRegion("Room");
    const G4ProductionCuts* p = worldReg->GetProductionCuts();
    if ( p ) {
      prodCuts = new G4ProductionCuts((*p));
    }else{
      prodCuts = new G4ProductionCuts(
        *(G4ProductionCutsTable::GetProductionCutsTable()->GetDefaultProductionCuts()));
    }
    //
    aReg->SetProductionCuts(prodCuts);
  }
  G4LogicalVolume* logical = fPhysVol->GetLogicalVolume();
  logical->SetRegion(aReg);
  aReg->AddRootLogicalVolume(logical);
}

void G4MVBeamModule::ApplyFromCatalogue(G4String&){}



