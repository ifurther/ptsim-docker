//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for PolyCones shape component
//
// (HISTORY)  
// 2014-03-11 T.Aso suppress stdout.
// 2015-12-14 T.Aso support rotaton.
//
//---------------------------------------------------------------------
//
#include "G4MSPolyCone.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include <iostream>

G4MSPolyCone::G4MSPolyCone(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MSPolyCone::G4MSPolyCone(G4MVSPolyConeCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MSPolyCone::~G4MSPolyCone()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MSPolyCone::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MSPolyCone::SetAllParameters(const G4String& mat,
                                    G4int& nplane, 
                                    std::vector<G4double>& v_rin,
                                    std::vector<G4double>& v_rout,
                                    std::vector<G4double>& v_zplane){
  fMatName=mat;
  NofPlane = nplane;
  zPlane.clear();
  rInner.clear();
  rOuter.clear();
  G4double rin=DBL_MAX, rout=-DBL_MAX, dz=-DBL_MAX;
  for ( G4int i = 0; i < nplane; i++ ){
    if ( v_rin[i] < rin ) rin = v_rin[i];
    if ( v_rout[i] > rout ) rout = v_rout[i];
    if ( std::abs(v_zplane[i]) > dz ) dz = std::abs(v_zplane[i]);
  }

  SetEnvelopeSize(rin,rout,dz);
  fMatName = mat;
  NofPlane = nplane;
  rInner  = v_rin;
  rOuter  = v_rout;
  zPlane  = v_zplane;
}


G4VPhysicalVolume* G4MSPolyCone::buildEnvelope(G4LogicalVolume* worldlog)
{

  G4Material *mat = G4Material::GetMaterial(fMatName);
  if ( !mat ) {
      G4String mess = "material " + fMatName +" is NULL ";
      G4Exception("G4MSPolyCone::buildEnvelope()","G4MPolyCon00",
                  FatalException,mess);
  }
  static const G4int N = 30;
  G4double zArray[N];
  G4double riArray[N];
  G4double roArray[N];

  if (fVerbose > 0 ) G4cout << "----" << NofPlane<< G4endl;
  if (fVerbose > 0 ) G4cout << "z    rin      rout " << G4endl;
  for(G4int nop=0; nop<NofPlane; nop++){
    if (fVerbose > 0 ) G4cout << zPlane[nop]<<" "
                              << rInner[nop]<<" "
                              << rOuter[nop]<<" " <<G4endl;
    zArray[nop] = zPlane[nop];
    riArray[nop] = rInner[nop];
    roArray[nop] = rOuter[nop];
  }
    //G4cout << "----" <<G4endl;

  G4Polycone *pCone = new G4Polycone(GetName(),
                                     0.,
                                     twopi,
                                     NofPlane,
                                     zArray,
                                     riArray,
                                     roArray);
    
  G4LogicalVolume *logCone = new G4LogicalVolume(pCone, mat, GetName());
   logCone->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));

   G4VPhysicalVolume* physical =
     new G4PVPlacement(GetRotation(), // rotation with respect to its mother volume
                       GetTranslation(), // translation with respect to its mother volume
                       logCone, // the associated Logical Volume
                       GetName(), // string identifier for this volume
                       worldlog, // the associated mother volume
                       false, // for future use
                       0); // integer which identifies this placement

  return physical;
}

void G4MSPolyCone::buildNode(G4VPhysicalVolume*)
{ }

