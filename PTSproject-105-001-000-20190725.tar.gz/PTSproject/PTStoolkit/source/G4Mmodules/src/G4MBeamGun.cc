//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// (Description)
//    BeamGun for simple beam with spot size.
//    This was created for HIBMC beamline.
//
//  (HISTORY)
//  11-JAN-07  T.ASO Modify for CLHEP2.0
//   5-APR-07  T.ASO Remove Random Engine setting.
//   2014-02-07 T.Aso   SetEnergyFluctByPercent(const G4double perc).
//   2016-01-14 T.Aso   AngleSigma for angluar variances.
//---------------------------------------------------------------------
//   
#include "G4MBeamGun.hh"
#include "G4MBeamGunMessenger.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4Event.hh"
#include "G4ios.hh"

G4MBeamGun::G4MBeamGun()
    :G4ParticleGun(),gaussSpot(true),beamSpot(0.,0.,0.),
     beamdE(0.),beamEmit(0.,0.,0.),angX(0.),angY(0.)
{ 
  theBeamMessenger = new G4MBeamGunMessenger(this);
}

G4MBeamGun::~G4MBeamGun()
{
  delete theBeamMessenger;
}

void G4MBeamGun::SetEnergyFluctByPercent(const G4double perc){
  beamdE = particle_energy * perc;
}

void G4MBeamGun::GeneratePrimaryVertex(G4Event* evt)
{
  if(particle_definition==0) return;
  G4double sX = particle_position.x();
  G4double sY = particle_position.y();
  G4double sZ = particle_position.z();

  // Initial beam position including Spot Size randomaization.
  G4double beamSpotX = beamSpot.x();
  G4double beamSpotY = beamSpot.y();
  G4double beamSpotZ = beamSpot.z();
  if ( gaussSpot ){
    if ( beamSpotX > 0. ) sX = CLHEP::RandGauss::shoot(sX,beamSpotX);
    if ( beamSpotY > 0. ) sY = CLHEP::RandGauss::shoot(sY,beamSpotY);
    if ( beamSpotZ > 0. ) sZ = CLHEP::RandGauss::shoot(sZ,beamSpotZ);
  }else{
    if ( beamSpotX > 0. ) sX += CLHEP::RandFlat::shoot(-beamSpotX,beamSpotX);
    if ( beamSpotY > 0. ) sY += CLHEP::RandFlat::shoot(-beamSpotY,beamSpotY);
    if ( beamSpotZ > 0. ) sZ += CLHEP::RandFlat::shoot(-beamSpotZ,beamSpotZ);
  }
  // create a new vertex
  G4PrimaryVertex* vertex = 
    new G4PrimaryVertex(G4ThreeVector(sX,sY,sZ),particle_time);

  // Energy Flactuation
  G4double kineticE =  particle_energy;
  if ( beamdE > 0. ) kineticE = CLHEP::RandGauss::shoot(kineticE,beamdE);

  // Emittance
  if ( angX > 0. || angY > 0. ){
    G4double px,py,pz,theta,phi;
    px = CLHEP::RandGauss::shoot(0.0,angX);
    py = CLHEP::RandGauss::shoot(0.0,angY);
    theta = std::sqrt (px*px + py*py);
    phi = 0.0;
    if (theta != 0.) {
      phi = std::acos(px/theta);
      if ( py < 0.) phi = -phi;
    } 
    px = -std::sin(theta) * std::cos(phi);
    py = -std::sin(theta) * std::sin(phi);
    pz = -std::cos(theta);
    particle_momentum_direction.set(px,py,pz);
    //G4cout << px <<" "<<py<<" "<<pz<<G4endl;
  }

  // create new primaries and set them to the vertex
  G4double mass =  particle_definition->GetPDGMass();
  G4double energy = kineticE + mass;
  G4double pmom = std::sqrt(energy*energy-mass*mass);
  G4double px = pmom* particle_momentum_direction.x();
  G4double py = pmom* particle_momentum_direction.y();
  G4double pz = pmom* particle_momentum_direction.z();

  // Generate particles
  for( G4int i=0; i<NumberOfParticlesToBeGenerated; i++ )
  {
    G4PrimaryParticle* particle =
      new G4PrimaryParticle(particle_definition,px,py,pz);
    particle->SetMass( mass );
    particle->SetCharge( particle_charge );
    particle->SetPolarization(particle_polarization.x(),
                               particle_polarization.y(),
                               particle_polarization.z());
    vertex->SetPrimary( particle );
  }

  evt->AddPrimaryVertex( vertex );
}


