//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Jaw type module
// 
//  (History)
//   2015-12-14   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MJawFileCatalogue.hh"
#include "G4MJaw.hh"
#include <fstream>
#include <sstream>

G4MJawFileCatalogue::G4MJawFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVJawCatalogue(name),fDefaultFileName(fileName){
}

G4MJawFileCatalogue::~G4MJawFileCatalogue()
{}

void G4MJawFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDxyzBlock,
                            fBlkMat,
                            fSourceDist,
                            fAperture,
                            fZpos,
                            fDir);
}

void G4MJawFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MJawFileCalalogue::Prepare()","G4MJawFileCata00",
                FatalException,msg);
  }else{
    ifs.getline(chline,512);  // 
    std::istringstream iss1(chline);
    G4double fx,fy,fz;
    iss1 >> fx >> fy >> fz;   // Full Size
    fDxyzBlock.setX(fx*mm/2.);
    fDxyzBlock.setY(fy*mm/2.);
    fDxyzBlock.setZ(fz*mm/2.);

    ifs.getline(chline,512);  //material
    std::istringstream iss3(chline);
    iss3 >> fBlkMat;

    ifs.getline(chline,512); // SourceDist and Aperture
    std::istringstream iss4(chline);
    iss4 >> fSourceDist >> fAperture;

    ifs.getline(chline,512); // Z Position
    std::istringstream iss5(chline);
    iss5 >> fZpos;

    ifs.getline(chline,512); // Direction
    std::istringstream iss6(chline);
    iss6 >> fDir;
  }
  ifs.close();
}

void G4MJawFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyzBlock,
                            fBlkMat,
                            fSourceDist,
                            fAperture,
                            fZpos,
                            fDir);
   fModule->ReBuild();
}







 
