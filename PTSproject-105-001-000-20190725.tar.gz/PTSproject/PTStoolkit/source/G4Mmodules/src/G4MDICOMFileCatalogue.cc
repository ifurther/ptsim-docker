//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   01-Sep-10   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MDICOMFileCatalogue.hh"
#include "G4MVDICOM.hh"
#include <fstream>
#include <sstream>

G4MDICOMFileCatalogue::G4MDICOMFileCatalogue(const G4String& name,
					   const G4String& fileName)
  :G4MVDICOMCatalogue(name),fDefaultFileName(fileName){
}

G4MDICOMFileCatalogue::~G4MDICOMFileCatalogue()
{}

void G4MDICOMFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDICOMFileName,fRemeshSize,fAirCTValue,
			    fCTCutOff,fFileCT2Density,fGantry,
			    fParamType, 1);
  fModule->SetRemeshBin(fRemeshBin);
  fModule->SetXmin(fXmin);
  fModule->SetXmax(fXmax);
  fModule->SetYmin(fYmin);
  fModule->SetYmax(fYmax);
  fModule->SetTrim(fTrim);
  fModule->SetMinValue(fValueMin);
  fModule->SetMaxValue(fValueMax);
  fModule->SetDensityResol(fDensResol);
  fModule->SetIsocenter(fIsocenter);
  fModule->SetCouchAngle(fCouchAngle);
}

void G4MDICOMFileCatalogue::Prepare(G4String& pname){
  /////////////////////////////////////////////////////////////////
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MDICOMFileCatalogue::Prepare()","G4MDICOMFileCata00",
		FatalException,msg);
  }else{
    ifs.getline(chline,512);  //DICOM File list
    std::istringstream iss1(chline);
    iss1 >> fDICOMFileName;

    ifs.getline(chline,512);  //CT2Density LUT
    std::istringstream iss2(chline);
    iss2 >> fFileCT2Density;

    ifs.getline(chline,512);  // Material Assignment
    std::istringstream iss3(chline);
    iss3 >> fParamType;

    ifs.getline(chline,512);  // CT Min. Max.
    std::istringstream iss4(chline);
    iss4 >> fValueMin >> fValueMax;

    ifs.getline(chline,512);  // CT Cut off, CTAir
    std::istringstream iss5(chline);
    iss5 >> fCTCutOff >> fAirCTValue;

    ifs.getline(chline,512);  // Density Resolution
    std::istringstream iss6(chline);
    iss6 >> fDensResol;
    fDensResol *= (g/cm3);

    ifs.getline(chline,512);  // Reformation in 3D
    std::istringstream iss7(chline);
    iss7 >> fRemeshSize;
    fRemeshSize *= mm;

    ifs.getline(chline,512);  // Reformation in 2D
    std::istringstream iss8(chline);
    iss8 >> fRemeshBin;

    ifs.getline(chline,512);  // Valid Window in X
    std::istringstream iss9(chline);
    iss9 >> fXmin >> fXmax;
    fXmin *= mm;
    fXmax *= mm;

    ifs.getline(chline,512);  // Valid Window in Y
    std::istringstream iss10(chline);
    iss10 >> fYmin >> fYmax;
    fYmin *= mm;
    fYmax *= mm;

    ifs.getline(chline,512);  // Triming flag
    std::istringstream iss11(chline);
    G4String trim;
    iss11 >> trim;
    if ( trim == "trim" || trim == "Trim" || trim == "TRIM"){
      fTrim = true;
    }else{
      fTrim = false;
    }

    ifs.getline(chline,512);  // Isocenter postion
    std::istringstream iss12(chline);
    G4double x,y,z;
    iss12 >> x >> y >> z;
    fIsocenter.setX(x*mm);
    fIsocenter.setY(y*mm);
    fIsocenter.setZ(z*mm);

    ifs.getline(chline,512);  // Gantry Angle
    std::istringstream iss13(chline);
    iss13 >> fGantry;
    fGantry *= deg;

    ifs.getline(chline,512);  // Couch Angle
    std::istringstream iss14(chline);
    iss14 >> fCouchAngle;
    fCouchAngle *= deg;

  }
  ifs.close();
}

void G4MDICOMFileCatalogue::Apply(){
  fModule->SetAllParameters(fDICOMFileName,fRemeshSize,fAirCTValue,
			    fCTCutOff,fFileCT2Density,fGantry,
			    fParamType, 1);
  fModule->SetRemeshBin(fRemeshBin);
  fModule->SetXmin(fXmin);
  fModule->SetXmax(fXmax);
  fModule->SetYmin(fYmin);
  fModule->SetYmax(fYmax);
  fModule->SetTrim(fTrim);
  fModule->SetMinValue(fValueMin);
  fModule->SetMaxValue(fValueMax);
  fModule->SetDensityResol(fDensResol);
  fModule->SetIsocenter(fIsocenter);
  fModule->SetCouchAngle(fCouchAngle);
}







 
