//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MRoom
//
//  (HISTORY)
//
//---------------------------------------------------------------------
//
#include "G4MRoom.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MRoom::G4MRoom(const G4String name, const G4ThreeVector dxyz)
  :G4MVBeamModule(name,dxyz) ,fMatName("Air"),fCatalogue(NULL)
{}

G4MRoom::G4MRoom(const G4String name)
  :G4MVBeamModule(name) ,fCatalogue(NULL)
{}

G4MRoom::G4MRoom(G4MVRoomCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MRoom::~G4MRoom() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MRoom::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MRoom::SetAllParameters(const G4ThreeVector dxyz)
{
  fEnvelopeSize=dxyz;
}

G4VPhysicalVolume* G4MRoom::buildEnvelope(G4LogicalVolume*) {
  //Experimental Hall. 
  G4Material* mat = G4Material::GetMaterial(fMatName);
  
  G4VSolid* solid = new G4Box(GetName(), 
                              fEnvelopeSize.x(),
                              fEnvelopeSize.y(),
                              fEnvelopeSize.z());

  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,             // Solid 
                                 mat,               // Material
                                 GetName());        // Name

  //logical->SetVisAttributes(G4VisAttributes::Invisible);

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   0,
                   G4ThreeVector(),
                   logical,                      // Logical volume  
                   GetName(),                    // Name
                   0,                            // Mother  volume 
                   false,                        // Not used 
                   0);                           // Copy number  
  return physical;
}

void G4MRoom::buildNode(G4VPhysicalVolume* ) {}

