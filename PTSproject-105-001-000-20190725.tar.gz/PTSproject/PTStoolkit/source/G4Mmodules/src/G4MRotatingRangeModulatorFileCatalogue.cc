//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   04-Oct-05   T.Aso
//   2011. Sep. Kawashima and Aso (TNCT).
//  2013-03-30 T.Aso Duplicated variable.
//             - for loop counter i -> j (NofT) in Prepare() method.
//             - "thickness" was redefined insode for loop (NofF) 
//              in Prepare(). 
//
//---------------------------------------------------------------------
//
#include "G4MRotatingRangeModulatorFileCatalogue.hh"
#include "G4MRotatingRangeModulator.hh"
#include <fstream>
#include <sstream>
#include <iostream>

G4MRotatingRangeModulatorFileCatalogue::G4MRotatingRangeModulatorFileCatalogue(const G4String& name,
                                           const G4String& fileName)
  :G4MVRotatingRangeModulatorCatalogue(name),fDefaultFileName(fileName){
}

G4MRotatingRangeModulatorFileCatalogue::~G4MRotatingRangeModulatorFileCatalogue()
{}

void G4MRotatingRangeModulatorFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(Rin, Rout,dZ,material);
}

void G4MRotatingRangeModulatorFileCatalogue::Prepare(G4String& pname){
  std::ifstream ifs;
  G4String filename = pname;
   
  ifs.open(filename.c_str());  //file open
  
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MRotatingRangeModulatorFileCatalogue::Prepare()",
                "G4MRotRangeFileCata00",FatalException,msg);
  }else{
    fModule->resetAll();
    /////////////////////////////////////////////////////////
    ifs.getline(chline,512);  // ID
    ifs.getline(chline,512);  //description

    ///////////////////////////
    // parameters of an envelope
    ////////////////////////////
    ifs.getline(chline,512);  // Material, Rin, Rout and Thickness
    std::istringstream iss1(chline);
    G4double thickness;
    iss1 >> material >> Rin >> Rout >> thickness;
    //G4cout << material<<","<<Rin<<","<<Rout<<G4endl;
    Rin *= mm;
    Rout *= mm;
    dZ = thickness*mm /2.;

    ///////////////////////////
    // Number of Parts
    ////////////////////////////
    ifs.getline(chline,512);  // Number of Parts
    std::istringstream iss2(chline);
    G4int NofP;
    iss2 >> NofP;
    fModule->SetNofPart(NofP);

    ///////////////////////////
    // Loop over all Parts
    ////////////////////////////
    for(G4int i=0; i<NofP; i++){
      ifs.getline(chline,512); // Z Offset and Direction of this Part
      std::istringstream iss6(chline);
      G4double offset;
      G4int direction;
      iss6 >> offset >> direction;
      offset *= mm;
      fModule->AddOffset(offset);
      fModule->AddDirection(direction);

      ifs.getline(chline,512);  // Number of Tracks
      std::istringstream iss4(chline);
      G4int NofT;
      iss4 >> NofT;
      fModule->AddNofTrack(NofT);

      ///////////////////////////
      // Loop over all Tracks in the part.
      ////////////////////////////
      for(G4int j=0; j<NofT; j++){
        ifs.getline(chline,512);  // Inner Radius and Outer Radius
        std::istringstream iss5(chline);
        G4double innerR;
        G4double outerR;
        iss5 >> innerR >> outerR;
        innerR *= mm;
        outerR *= mm;

        fModule->AddInnerRadius(innerR);
        fModule->AddOuterRadius(outerR);
        
        ifs.getline(chline,512);  // OffsetAngle of this Track
        std::istringstream iss7(chline);
        G4double OffsetPhi;
        iss7 >> OffsetPhi;
        OffsetPhi = OffsetPhi * degree;
        fModule->AddOffsetAngle(OffsetPhi);
        
        ifs.getline(chline,512);
        std::istringstream iss8(chline); // Number of Segments
        G4int NofF;
        iss8 >> NofF;
        fModule->AddNofFan(NofF);       

        ///////////////////////////
        // Loop over all Segments in the track.
        ////////////////////////////
        for(G4int k=0; k<NofF; k++){
          ifs.getline(chline,512);  // Material Name, Phi, and Thickness of this Segment
          std::istringstream iss9(chline);
          G4String matName;
          G4double phi;
          //G4double thickness;
          iss9 >> matName >> phi >> thickness;
          //G4cout << matName<<","<<phi<<","<<thickness<<G4endl;
          thickness = thickness * mm / 2.;      
          phi = phi * degree;
          fModule->AddFanMaterialName(matName);
          fModule->AddFanPhi(phi);
          fModule->AddFanDZ(thickness);
        }
      }
    }
  }
  ifs.close();
}

void G4MRotatingRangeModulatorFileCatalogue::Apply(){
  fModule->SetAllParameters(Rin, Rout,dZ,material);
}
