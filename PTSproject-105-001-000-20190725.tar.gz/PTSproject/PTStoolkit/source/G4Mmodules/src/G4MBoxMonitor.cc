//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MBoxMonitor
//
// (HISTORY)
//   06-Oct-05   T.Aso
//   22-JAN-07   T.Aso  Add Visualization Attrbutes.
//          
// -----------------------------------------------------------------          
//                    
#include "G4MBoxMonitor.hh"
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"
#include "G4MVBoxMonitorCatalogue.hh"

G4MBoxMonitor::G4MBoxMonitor(const G4String& name,
			       const std::vector<G4double>& dx,
			       const std::vector<G4double>& dy,
			       const std::vector<G4double>& dz,
			       const std::vector<G4String>& mat,
			       const std::vector<G4double>& pos,
			       const G4String& masterMat)
  :G4MVMonitor(name),fCatalogue(NULL){
  SetAllParameters(dx,dy,dz,mat,pos,masterMat);
}

G4MBoxMonitor::G4MBoxMonitor(const G4String& name)
  :G4MVMonitor(name),fCatalogue(NULL){
}

G4MBoxMonitor::G4MBoxMonitor(G4MVBoxMonitorCatalogue* catalogue)
  :G4MVMonitor(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MBoxMonitor::~G4MBoxMonitor() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MBoxMonitor::ApplyFromCatalogue(G4String& newValue) {
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBoxMonitor::SetAllParameters(const std::vector<G4double>& dx,
				      const std::vector<G4double>& dy,
				      const std::vector<G4double>& dz,
				      const std::vector<G4String>& mat,
				      const std::vector<G4double>& pos,
				      const G4String& masterMat){
  // Initialize parameters.
  fDx       = dx;
  fDy       = dy;
  fDz        = dz;
  fMaterial  = mat;
  fZ         = pos;
  fMasterMat = masterMat;

  // search for smallest/biggest one
  G4double xmaximum = DBL_MIN;
  G4double ymaximum = DBL_MIN;
  G4double zminimum = DBL_MAX;
  G4double zmaximum = DBL_MIN;
  G4int N = fZ.size();
  for ( G4int i = 0; i < N; i++){
    if ( fDx[i] > xmaximum ) xmaximum = fDx[i]; 
    if ( fDy[i] > ymaximum ) ymaximum = fDy[i]; 
    if ( ( fZ[i]+fDz[i] ) > zmaximum ) {
      zmaximum = fZ[i]+fDz[i]; 
    }
    if ( ( fZ[i]-fDz[i] ) < zminimum ) {
      zminimum = fZ[i]-fDz[i]; 
    }
  }
  fZoffset = (zmaximum+zminimum)/2.;
  fEnvelopeSize.set(xmaximum,ymaximum,(zmaximum-zminimum)/2.);
}

G4VPhysicalVolume* G4MBoxMonitor::buildEnvelope(G4LogicalVolume* worldlog) {
  // --- Master Volume 
  //
  G4Material* matMaster = G4Material::GetMaterial(fMasterMat);
  
  G4VSolid* solMaster   = new G4Box(GetName(),
				    fEnvelopeSize.x(),
				    fEnvelopeSize.y(),
				    fEnvelopeSize.z());

  G4LogicalVolume* logMaster = new G4LogicalVolume(
	   		         solMaster,                  // Solid 
                                 matMaster,                  // Material
                                 GetName());                 // Name

  logMaster->SetVisAttributes(new G4VisAttributes(G4Colour(0.0,1.0,0.0)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(
  		      GetRotation(),
		      GetTranslation(),
		      logMaster,                      // Logical volume  
                      GetName(),                      // Name
		      worldlog,                       // Mother  volume 
		      false,                          // Not used 
		      0);                             // Copy number  
  return physical;
}

void G4MBoxMonitor::buildNode(G4VPhysicalVolume* physvol) {

  //---  Component inside Master Volume ---
  G4int nCom = fZ.size();
  for (G4int i = 0; i < nCom ; i++){
    G4Material* matCom = G4Material::GetMaterial(fMaterial[i]);
    G4String comName = fMaterial[i]+"Com";
    G4VSolid* solCom = 
      new G4Box(comName,fDx[i],fDy[i],fDz[i]);
    G4LogicalVolume* logCom = new G4LogicalVolume(
				 solCom,                 // Solid 
                                 matCom,                 // Material
				 comName                 // Name
				 );        
    logCom->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));

    G4double z = fZ[i] - fZoffset;
    //G4VPhysicalVolume* phyCom  = 
	new G4PVPlacement(
			  0,                        // No rotation
			  G4ThreeVector(0.,0.,z),   // Positon at (0,0,z)
			  logCom,                   // Logical volume  
			  comName,                  // Name
			  physvol->GetLogicalVolume(), // Mother  volume 
			  false,                    // Not used 
			  0);                       // Copy number 
  } 
}

