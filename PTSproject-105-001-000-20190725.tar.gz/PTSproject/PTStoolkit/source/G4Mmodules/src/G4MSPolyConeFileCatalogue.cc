//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   04-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MSPolyConeFileCatalogue.hh"
#include "G4MSPolyCone.hh"
#include <fstream>
#include <sstream>

G4MSPolyConeFileCatalogue::G4MSPolyConeFileCatalogue(const G4String& name,
                                           const G4String& fileName)
  :G4MVSPolyConeCatalogue(name),fDefaultFileName(fileName){
}

G4MSPolyConeFileCatalogue::~G4MSPolyConeFileCatalogue()
{}

void G4MSPolyConeFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fMaterial,
                            NofPlane,
                            rInner,
                            rOuter,
                            zPlane);
}

void G4MSPolyConeFileCatalogue::Prepare(G4String& pname){
  zPlane.clear();
  rInner.clear();
  rOuter.clear();
  /////////////////////////////////////////////////////////////////
  std::ifstream ifs;
  G4String filename = pname;

  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MSPolyConeFileCatalogue::Prepare()","G4MPolyConFileCata00",
                FatalException,msg);
  }else{
    ifs.getline(chline,512);  //scatterer ID
    ifs.getline(chline,512);  //description

    ifs >> fMaterial;
    ifs >> NofPlane;
    G4double rin, rout,zp;
    for ( G4int i = 0; i < NofPlane;  i++){
      //ifs.getline(chline,512);  
      //std::istringstream iss1(chline);
      //iss1 >> zp >> rin >> rout;
      ifs >> zp >> rin >> rout;
      G4cout << zp << " " << rin << " " <<rout<<G4endl;
      rin *= mm;
      rout *= mm;
      zp *= mm;
      
      rInner.push_back(rin);
      rOuter.push_back(rout);
      zPlane.push_back(zp);
    }
  }
  ifs.close();
}

void G4MSPolyConeFileCatalogue::Apply(){
  fModule->SetAllParameters(fMaterial,
                            NofPlane,
                            rInner,
                            rOuter,
                            zPlane);
}







 
