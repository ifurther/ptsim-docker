//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    DICOM Module for Nested Parameterisation
//
// (HISTORY)
// 27 Feb. 2007 T.Aso Copied from G4DICOM and modified for 
//                    NestedParameterisation.
// 13 Jun. 2007 T.Aso Introduce G4MDicomNestedWaterParameterisation.
// 25 Jul. 2007 T.Aso The position of inner envelope was moved with 
//                    respect to the offset of CT image.
//                    This is requested from NCC.
// 20 Mar. 2008 T.Aso Offset of CT image was removed.
// 16 Dec. 2008 T.Aso Remesh2D introduced.
// 18 Mar. 2009 T.Aso Density resolution for creating materials
//                    in DICOM.
// 09 Sep. 2009 T.Aso PrepareDICOM() introduced.
// 10 Sep. 2009 T.Aso PrepareMatList() introduced.
//  14 Sep. 09 T.Aso  Mask information for outline extraction in DICOM data
//                    was implemented for material assignment.
// 2013-03-27 T.Aso Default material for envelope (Air) was replaced to
//                  fEnvMat variable. This is for switching the material
//                  in layered geometries in parallel world geometry.
//  2014-02-04 T.Aso Row and Column was fixed to represent Y and X. 
//  2014-03-04 T.Aso Reactivate CT2Density filter.
//  2014-03-11 T.Aso fVerbose.
// 2016-12-21 T.Aso PrepareDICOM(), GetLabelVec().
// 2016-03-15 T.Aso for threading.
// 2019-04-04 T.Aso SDName was replaced from "G4MDICOM" to the beam module name.
// -----------------------------------------------------------------
// 
#include "G4MNestedDICOM.hh"

#include "G4MDICOMHandler.hh"
#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"
#include "G4MDICOMCT2Density.hh"
#include "G4MDICOMCT2Material.hh"

#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Element.hh"
#include "G4Transform3D.hh"
#include "G4PVReplica.hh" 
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4Element.hh"
#include "G4SDManager.hh"

#include "G4VisAttributes.hh"

#include "G4MDicomNestedWaterParameterisation.hh"

#include "G4MNestedDICOMSD.hh"

#include <cmath>

G4MNestedDICOM::G4MNestedDICOM(G4String name) 
  :G4MVDICOM(name)
{}

G4MNestedDICOM::G4MNestedDICOM(G4MVDICOMCatalogue* catalogue)
  : G4MVDICOM(catalogue->GetName())
{}

G4MNestedDICOM::~G4MNestedDICOM() {}

void G4MNestedDICOM::buildNode(G4VPhysicalVolume* physvol) {
  
  //-- Open DICOM Handler---------------------------------------
  G4MDICOMConfiguration* config=
    G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  //--------------------------------------------------------------

  //std::vector<short> label;
  G4bool  override=TRUE;
  //G4MDICOMData* dicomData = PrepareDICOM(label,override);
  G4MDICOMData* dicomData = PrepareDICOM(override);
  std::vector<short>& label = GetLabelVec();
  G4MDICOMCT2Material* matList = PrepareMatList();
  //
  // 20130313 ASO replace with fEnvMat.
  //G4Material* air = G4Material::GetMaterial("Air");//Dummy material.
  //
  G4MDicomNestedWaterParameterisation*  param = 
    new G4MDicomNestedWaterParameterisation(dicomData,label,matList,fEnvMat);
  param->SetVis(fVis);
  // ------------------------------------------------
  //CT-Density (Prepare For Dose Calculation)
  G4MDICOMCT2Density filterDensity(fFileCT2Density);
  config->DoFiltering(filterDensity);   
  //
  dicomData->ShowParameters();
  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double sliceThickness = dicomData->GetZPixelSPC();
  G4int    totalRows      = dicomData->GetRow(); 
  G4int    totalColumns   = dicomData->GetColumn();
  G4int    totalSlices    = dicomData->GetSlice();
  G4double tissueX        = (xPixelSpacing/2.) *mm;
  G4double tissueY        = (yPixelSpacing/2.) *mm;
  G4double tissueZ        = (sliceThickness/2.) *mm;
  //
  G4ThreeVector dxyz      = dicomData->GetDxyz()*mm;
  G4double dX             = dxyz.x();
  G4double dY             = dxyz.y();
  G4double dZ             = dxyz.z();


  G4cout << "**** Nested DICOM "<<G4endl;
  G4cout << "* G4MDicom NestedVolume Half length (mm)" 
         << " x " << dX/mm 
         << " y " << dY/mm
         << " z " << dZ/mm << " mm" << G4endl;
  G4cout << " row " << totalRows << " column " << totalColumns
         << " slice " << totalSlices<<G4endl;
  //
  //
  //
  G4String nestName(GetName()+"Nest");
  //
  G4LogicalVolume* logNest = physvol->GetLogicalVolume();
  //
  G4String nestZName(GetName()+"NestZ");
  G4Box* nestZ = new G4Box(nestZName, dX, dY, tissueZ);
  G4LogicalVolume* logNestZ = new G4LogicalVolume(nestZ, fEnvMat, nestZName);
  //logNestZ->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.0,0.0)));
  logNestZ->SetVisAttributes(G4VisAttributes::Invisible);
  //G4PVReplica* zReplica =
  new G4PVReplica(nestZName,logNestZ,logNest,kZAxis,totalSlices,sliceThickness);
  //
  G4String nestXName(GetName()+"NestX");
  G4Box* nestX = new G4Box(nestXName, tissueX, dY, tissueZ);
  G4LogicalVolume* logNestX = new G4LogicalVolume(nestX, fEnvMat, nestXName);
  //logNestX->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));
  logNestX->SetVisAttributes(G4VisAttributes::Invisible);
  //
  //G4PVReplica* xReplica =
  //new G4PVReplica(nestXName,logNestX,logNestZ,kXAxis,totalRows,xPixelSpacing);
  // T.Aso 20140204
  new G4PVReplica(nestXName,logNestX,logNestZ,kXAxis,totalColumns,xPixelSpacing);
  //
  //
  G4cout << " G4MDicom Tissue Half length (mm)" 
         << " x " << tissueX/mm 
         << " y " << tissueY/mm
         << " z " << tissueZ/mm << G4endl;
  //
  //
  G4String voxelName(GetName()+"Voxel");
  G4Box* voxel = new G4Box(voxelName, tissueX, tissueY, tissueZ);
  G4LogicalVolume* logVoxel = new G4LogicalVolume(voxel, fEnvMat, voxelName);
  logVoxel->SetVisAttributes(G4VisAttributes::Invisible);
  if ( fVerbose > 0 ){
    G4cout << " G4MDicom NofVolume " << param->GetNofVolume() <<G4endl;
  }
  //
  //G4VPhysicalVolume* physVoxel = 
  new G4PVParameterised(voxelName,
                        logVoxel,
                        logNestX,
                        kUndefined,
                        param->GetNofVolume(), 
                        param );
  //G4cout << " G4MDicom NofVolume " << param->GetNofVolume() <<G4endl;
  // Sensitive Detector
  fSdLVList.push_back(logVoxel);
}

void G4MNestedDICOM::BuildInSDandField() {
  G4String SDName = GetName();
  SetSensitive(SDName, fSdLVList[0]);
}

void G4MNestedDICOM::SetSensitive(G4String& SDName, G4LogicalVolume* logical) {
  G4SDManager * SDMan = G4SDManager::GetSDMpointer();

  G4VSensitiveDetector * dicomSD = SDMan->FindSensitiveDetector(SDName,false);
  if ( !dicomSD ){
      G4cout << "++ G4MNestedDICOM::  Create Sensitive Detector "
             <<SDName<<G4endl;
      dicomSD = new G4MNestedDICOMSD(SDName);
      SDMan->AddNewDetector(dicomSD);
  }
  ((G4MNestedDICOMSD*)dicomSD)->SetDICOMFile(fDICOMFileName);

  logical->SetSensitiveDetector(dicomSD);
}

