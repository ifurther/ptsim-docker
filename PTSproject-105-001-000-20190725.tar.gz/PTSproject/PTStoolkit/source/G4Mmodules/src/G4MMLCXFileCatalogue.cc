//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4M MLC.
// 
//  (History)
//   06-Oct-05   T.Aso
//   22-JAN-07   T.Aso Modify Visualization attributes.
//   24-APR-07   T.Aso Bug fix for material assignment of leafs.
//
//---------------------------------------------------------------------
//
#include "G4MMLCXFileCatalogue.hh"
#include "G4MMLCX.hh"
#include <fstream>

G4MMLCXFileCatalogue::G4MMLCXFileCatalogue(const G4String& name,
					   const G4String& fileName)
  :G4MVMLCXCatalogue(name),fDefaultFileName(fileName){
}

G4MMLCXFileCatalogue::~G4MMLCXFileCatalogue()
{ }

void G4MMLCXFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fFrameDxyz,fMatMLC,fNLeafPair,fLeafDxyz,fy0Leaf,
			    thePositionVector);
}

void G4MMLCXFileCatalogue::Prepare(G4String& pname){
  G4String fileName = pname;  
  std::ifstream ifs;
  ifs.open(fileName.c_str());

  if(!ifs) { 
    const G4String& msg =  "MLCX File Not Found " + pname;
    G4Exception("G4MMLCXFileCatalogue::Prepare()","G4MMLCXFileCata00",
		FatalException,msg);
  }else{
    G4int verbose = fModule->GetVerbose();
    if ( verbose > 0 ) G4cout << "MLCX File open " << pname << G4endl;
    thePositionVector.clear();

    G4double dxf,dyf,dzf;
    ifs >> dxf >> dyf >> dzf;    // Frame Full size
    if ( verbose > 0 ) G4cout << dxf << " " <<dyf<< " " <<dzf<<G4endl;
    fFrameDxyz.setX(dxf * mm/2.);
    fFrameDxyz.setY(dyf * mm/2.);
    fFrameDxyz.setZ(dzf * mm/2.);    
    

    ifs >> fMatFrame;             // Frame Material 
    ifs >> fMatMLC;               // Leaf Material 
    ifs >> fNLeafPair;            // Number of Leaf pair
    if ( verbose > 0 ) {
      G4cout << fMatFrame << " " <<fMatMLC<< " " <<fNLeafPair<<G4endl;
    }

    G4double dxl,dyl,dzl;
    ifs >> dxl >> dyl >> dzl;   // Leaf Full Size
    if ( verbose > 0 ) G4cout << dxl << " " <<dyl<< " " <<dzl<<G4endl;
    fLeafDxyz.setX(dxl * mm/2.);
    fLeafDxyz.setY(dyl * mm/2.);
    fLeafDxyz.setZ(dzl * mm/2.);    

    ifs >> fy0Leaf ;              // y0 offset of first leaf
    if ( verbose > 0 ) G4cout << fy0Leaf << G4endl;
    fy0Leaf *= mm; 

    thePositionVector.assign( fNLeafPair*2, 0.*mm);
    for ( G4int i = 0; i < fNLeafPair; i++){ 
	G4double dxleft,dxright;
	ifs >> dxleft >> dxright;  // Leaf Position in [mm]
	if ( verbose > 0 ) G4cout << dxleft << " " <<dxright << G4endl;
	dxleft  *= mm;
	dxright *= mm;
	thePositionVector[i] = dxleft;
	thePositionVector[i+fNLeafPair] = dxright;
    }
  }
}

void G4MMLCXFileCatalogue::Apply(){
  fModule->SetAllParameters(fFrameDxyz,fMatMLC,fNLeafPair,fLeafDxyz,fy0Leaf,
			    thePositionVector);
   fModule->ReBuild();
}


