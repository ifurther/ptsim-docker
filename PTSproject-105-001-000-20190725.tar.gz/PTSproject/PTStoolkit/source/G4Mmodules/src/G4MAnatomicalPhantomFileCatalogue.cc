//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   04-Oct-05   T.Aso
//   2011. Sep. Kawashima and Aso (TNCT).
//
//---------------------------------------------------------------------
//
#include "G4MAnatomicalPhantomFileCatalogue.hh"
#include "G4MAnatomicalPhantom.hh"
#include <fstream>
#include <sstream>
#include <iostream>

G4MAnatomicalPhantomFileCatalogue::G4MAnatomicalPhantomFileCatalogue(const G4String& name,
					   const G4String& fileName)
  :G4MVAnatomicalPhantomCatalogue(name),fDefaultFileName(fileName){
}

G4MAnatomicalPhantomFileCatalogue::~G4MAnatomicalPhantomFileCatalogue()
{}

void G4MAnatomicalPhantomFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  //  fModule->SetAllParameters(Rin, Rout,dZ,material);
}

void G4MAnatomicalPhantomFileCatalogue::Prepare(G4String& pname){
  std::ifstream ifs;
  G4String filename = pname;
  char chline[512];

  ifs.open(filename.c_str());  //file open
  
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MAnatomicalPhantomFileCatalogue::Prepare()",
		"G4MAnatomCata00",
		FatalException,msg);
  }else{
    ifs.getline(chline,512);  // ID
    ifs.getline(chline,512);  //description

    ///////////////////////////
    // parameters of an envelope
    ////////////////////////////
    {    
      ifs.getline(chline,512);
      std::istringstream iss(chline);
      G4String Material;
      G4double xRadius;
      G4double yRadius;
      G4double FullThickness;
      G4String EShapeName;
      iss >> Material >> xRadius >> yRadius >> FullThickness >> EShapeName;
      xRadius *= mm;
      yRadius *= mm;
      G4double HalfThickness = FullThickness * mm / 2.0;
      fModule->SetEnvelopeParameter(Material, xRadius, yRadius, HalfThickness, EShapeName);
    }

    ///////////////////////////
    // Number of Node
    ////////////////////////////
    G4int NofNode;
    {
      ifs.getline(chline,512);  // Number of Parts
      std::istringstream iss(chline);
      iss >> NofNode;
    }

    ///////////////////////////
    // Each Node
    ///////////////////////////
    for(G4int i=0; i<NofNode; i++)
      {
	ifs.getline(chline,512);
	std::istringstream iss(chline);
	G4String Material;
	G4double posRadius;
	G4double posAngle;
	G4double nodeRadius;
	G4bool Exist;
	iss >> Material >> posRadius >> posAngle >> nodeRadius >> Exist;
	posRadius *= mm;
	posAngle *= degree;
	nodeRadius *= mm;
	Node node(posRadius, posAngle, nodeRadius, Material, Exist);
	fModule->AddNode(node);
      }
    
  }
  ifs.close();
}

void G4MAnatomicalPhantomFileCatalogue::Apply(){
  //  fModule->SetAllParameters(Rin, Rout,dZ,material);
}
