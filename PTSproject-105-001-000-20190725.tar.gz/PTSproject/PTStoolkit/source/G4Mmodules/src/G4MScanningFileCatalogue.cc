//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Scanning Magnet
// 
//  (History)
//   22-Jan-07   T.Aso
//   16-Feb-09   T.Aso B-field calculation for carbonion.
//   2014-11-23  T.Aso  Move the calcuation of b-field algorithm to 
//                     G4MScanningMagnet.
//
//---------------------------------------------------------------------
//
#include "globals.hh"
#include "G4MScanningFileCatalogue.hh"
#include "G4MScanningMagnet.hh"
#include "G4MScanningFieldX.hh"
#include "G4MScanningFieldY.hh"
//
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"
#include "G4NucleiProperties.hh"
#include "G4ParticleDefinition.hh"
#include <fstream>

G4MScanningFileCatalogue::G4MScanningFileCatalogue(const G4String& name,
                                                     const G4String& fileName)
  :G4MVScanningMagnetCatalogue(name),fDefaultFileName(fileName){
}

G4MScanningFileCatalogue::~G4MScanningFileCatalogue()
{}

void G4MScanningFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  G4MVScanningField* field = NULL;
  if     (fRasterDir == 1) field = new G4MScanningFieldX(0.0,fIsign);
  else if(fRasterDir == 2) field = new G4MScanningFieldY(0.0,fIsign);
  else G4cout << "@@@ G4MScanningFileCatalogue: Has no field. ! "<<G4endl; 
  //
  fModule->SetAllParameters(fMatFrame,fDxyzframe,fMatfield,fDxyzfield,field);
  fModule->SetPidForBField(fParticleID);
  fModule->SetEnergyForBField(fParticleE);
  fModule->SetZCentroidForBField(fPositionZ);
  fModule->SetFieldByDist(fTargetPos);
  fModule->SetTranslation(G4ThreeVector(0.,0.,fPositionZ));
}

void G4MScanningFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio;
  G4String filename = pname;
  fileio.open(filename.c_str());  //file open
  if(!fileio) { 
     G4String mes = "File Not Found " + pname;
     G4Exception("G4MScanningFileCatalogue::Prepare()","G4MScanFileCata00",
                 FatalException,mes);
  }

    G4double dx,dy,dz;
    fileio >> dx >> dy >> dz;  // Full size of Frame
    //G4cout  <<  dx << dy <<dz;  // Full size of Frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    dz *= ( mm/2. );
    fDxyzframe.setX(dx);
    fDxyzframe.setY(dy);
    fDxyzframe.setZ(dz);
    
    fileio>>   fMatFrame;       // Material of Frame

    G4double dxx,dyy,dzz;
    fileio >> dxx >> dyy >> dzz;  // Full size of Gap
    dxx *= ( mm/2. );
    dyy *= ( mm/2. );
    dzz *= ( mm/2. );
    fDxyzfield.setX(dxx);
    fDxyzfield.setY(dyy);
    fDxyzfield.setZ(dzz);

    fileio>>   fMatfield;       // Material of Field

    // Particle ID ,  Energy,   Position
    fileio >> fParticleID >>  fParticleE  >>  fPositionZ;
    fParticleE *= MeV;
    fPositionZ  *= mm;

    // Target position at Isocenter.
    fileio >> fTargetPos; //  Traget Position (mm)
    fTargetPos *= mm;

    fileio >> fRasterDir >> fIsign ;  // Raster Direction and Bfield sign.

    fileio.close();
}

void G4MScanningFileCatalogue::Apply(){
  //G4MVScanningField* field = fModule->GetMagField();  
  //if (field ) field->SetMagField(fFieldValue);
  fModule->SetAllParameters(fMatFrame,fDxyzframe,fMatfield,fDxyzfield);
  fModule->SetPidForBField(fParticleID);
  fModule->SetEnergyForBField(fParticleE);
  fModule->SetZCentroidForBField(fPositionZ);
  fModule->SetFieldByDist(fTargetPos);
  fModule->SetTranslation(G4ThreeVector(0.,0.,fPositionZ));
  fModule->ReBuild();
}
