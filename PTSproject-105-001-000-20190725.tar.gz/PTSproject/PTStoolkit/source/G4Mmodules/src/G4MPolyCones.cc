//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for PolyCones shape component
//
// (HISTORY)  
// 2014-03-11 T.Aso suppress stdout.
//
//---------------------------------------------------------------------
//
#include "G4MPolyCones.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include "G4UnionSolid.hh"
#include <iostream>

G4MPolyCones::G4MPolyCones(const G4String &name, G4double dr, G4double dz,
                 const G4String &mat)
  : G4MVBeamModule(name,G4ThreeVector(0.,dr,dz)),
    fMatName(mat),fCatalogue(NULL)
{}

G4MPolyCones::G4MPolyCones(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MPolyCones::G4MPolyCones(G4MVPolyConesCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MPolyCones::~G4MPolyCones()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MPolyCones::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MPolyCones::SetAllParameters(G4double dr, G4double dz,const G4String &mat){
  SetEnvelopeSize(0.0,dr,dz);
  fMatName=mat;
}

void G4MPolyCones::SetAllParameters(const G4String& mat,
                                    G4double rin, G4double rout,G4double dz, 
                                    G4int ncone,
                                    std::vector<G4String>& conemat, 
                                    std::vector<G4int>& nplane, 
                                    std::vector<G4double>& v_rin,
                                    std::vector<G4double>& v_rout,
                                    std::vector<G4double>& v_zplane){
  material.clear();
  NofPlane.clear();
  zPlane.clear();
  rInner.clear();
  rOuter.clear();

  SetEnvelopeSize(rin,rout,dz);
  fMatName = mat;
  NofCone = ncone;
  material = conemat;
  NofPlane = nplane;
  rInner  = v_rin;
  rOuter  = v_rout;
  zPlane  = v_zplane;
}


G4VPhysicalVolume* G4MPolyCones::buildEnvelope(G4LogicalVolume* worldlog)
{

  G4Material *mat = G4Material::GetMaterial(fMatName);
  if ( !mat ) {
      G4String mess = "material " + fMatName +" is NULL ";
      G4Exception("G4MPolyCones::buildEnvelope()","G4MPolyCon00",
                  FatalException,mess);
  }
  G4double dr = GetDR();
  G4double dz = GetDZ();
  
  G4Tubs *solid = new G4Tubs(GetName(), 0, dr, dz, 0, twopi);
  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());
  lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));
  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                   lv,
                                                   GetName(),
                                                   worldlog,
                                                   false,
                                                   0);
  return physical;
}

void G4MPolyCones::buildNode(G4VPhysicalVolume* physVol)
{ 
  G4LogicalVolume *logVol = physVol->GetLogicalVolume();
  
  G4int pOffset = 0;
  for(G4int noc=0; noc<NofCone; noc++){

  G4Material *mat = G4Material::GetMaterial(material[noc]);
    if ( !mat ) {
      G4String mess = "material " + material[noc] +" is NULL ";
      G4Exception("G4MPolyCones::buildEnvelope()","G4MPolyCon00",
                  FatalException,mess);
    }
    G4double zArray[N];
    G4double riArray[N];
    G4double roArray[N];

    if (fVerbose > 0 ) G4cout << "----" << NofPlane[noc] << G4endl;
    for(G4int nop=0; nop<NofPlane[noc]; nop++){
      G4int OffsetNop = nop + pOffset;
      zArray[nop] = zPlane[OffsetNop];
      riArray[nop] = rInner[OffsetNop];
      roArray[nop] = rOuter[OffsetNop];
      
    }
    //G4cout << "----" <<G4endl;

    G4Polycone *pCone = new G4Polycone("polycone",
                                       0.,
                                       twopi,
                                       NofPlane[noc],
                                       zArray,
                                       riArray,
                                       roArray);
    
    G4LogicalVolume *logCone = new G4LogicalVolume(pCone, mat, "logCone");
    logCone->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));
    
    new G4PVPlacement(0, // rotation with respect to its mother volume
                      G4ThreeVector(0,0,0), // translation with respect to its mother volume
                      logCone, // the associated Logical Volume
                      "polycone", // string identifier for this volume
                      logVol, // the associated mother volume
                      false, // for future use
                      0); // integer which identifies this placement

    ////////
    pOffset += NofPlane[noc];
  }
}

