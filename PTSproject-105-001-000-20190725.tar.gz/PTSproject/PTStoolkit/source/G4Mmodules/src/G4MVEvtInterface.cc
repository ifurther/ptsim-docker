//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
//---------------------------------------------------------------------
//  G4MVEvtInterface
//
//  (HISTROY)
//   29-Nov-2007  T.ASO  Create.
//  2015-12-14 T.Aso particle_position is renamed to particle_position_ev.
//  2017-03-31 T.Aso verbose.
//   2019-04-04 T.Aso File format ASCII/Binary.
//---------------------------------------------------------------------
//
#include "G4Types.hh"

#include "G4ios.hh"
#include "G4MVEvtInterface.hh"
#include "G4PrimaryVertex.hh"
#include "G4PrimaryParticle.hh"
#include "G4Event.hh"

G4MVEvtInterface::G4MVEvtInterface()
 :verbose(0),fileFormat(0)
{
    fMessenger = new G4MEvtIFMessenger(this) ;
    HPlist.clear();
}

G4MVEvtInterface::~G4MVEvtInterface()
{
    if (fMessenger) delete fMessenger;
}

void G4MVEvtInterface::GeneratePrimaryVertex(G4Event* evt)
{
    getParticleInfo();
    if ( verbose > 0 ) G4cout << " %%%% EvtInterface " << HPlist.size() << G4endl; 
    // check if there is at least one particle
    if( HPlist.size() == 0 ) return; 

    for( size_t ii=0; ii< HPlist.size(); ii++ ){
      G4MEvtParticle* p = HPlist[ii];
      G4ThreeVector& particle_position_ev = p->GetPosition();
      G4double&      particle_time_ev     = p->GetTime();
      if ( verbose > 0 ){
        G4cout << " %%%% EvtInterface " << particle_position_ev 
               <<" " << particle_time_ev << G4endl;
      }
      //
      // create G4PrimaryVertex object
      G4PrimaryVertex* vertex = 
        new G4PrimaryVertex(particle_position_ev,particle_time_ev);

      // put initial particles to the vertex
      G4PrimaryParticle* particle = p->GetTheParticle();
      vertex->SetPrimary( particle );
      evt->AddPrimaryVertex( vertex );
      //G4cout << " %%%% EvtInterface " << particle_position_ev << G4endl;
    }

    // clear G4MVEvtParticles
    for(size_t iii=0;iii<HPlist.size();iii++)
    { delete HPlist[iii]; }
    HPlist.clear();

}

