//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    PTCollimatorEx Module
//  (HISTORY)
// 2014-04-08 T.Toshito and T.Aso
//            Patient collimator using G4ExtrudedSolid
// 2014-04-10 T.Aso Add SetXYVector(v) for compatibility.
// 2014-04-10 T.Aso Remove last coord. point if it is same as first one.
//
// -----------------------------------------------------------------
//
#include "G4MPTCollimatorEx.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4ExtrudedSolid.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"
#include <fstream>
#include <algorithm>

G4MPTCollimatorEx::G4MPTCollimatorEx(const G4String& name, 
                                     const G4ThreeVector& dxyz,
                                     const G4String& mat,
                                     std::vector<G4TwoVector>& polygon,
                                     G4int dir)
  :G4MVBeamModule(name,dxyz),fMatName(mat),
   theXYVec(polygon),
   fdir(dir),fCatalogue(NULL){
}

G4MPTCollimatorEx::G4MPTCollimatorEx(const G4String& name)
  :G4MVBeamModule(name),fMatName("Brass"),fdir(1),
   fCatalogue(NULL){
  theXYVec.clear();
}

G4MPTCollimatorEx::G4MPTCollimatorEx(G4MVPTCollimatorExCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()), fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MPTCollimatorEx::~G4MPTCollimatorEx() {
  theXYVec.clear();
  //
  if ( fCatalogue ) delete fCatalogue;
}


void G4MPTCollimatorEx::SetAllParameters(const G4ThreeVector& dxyz,
                                       const G4String& mat,
                                       std::vector<G4TwoVector>& polygon,
                                       G4int dir){
    SetEnvelopeSize(dxyz);
    fMatName = mat;
    theXYVec = polygon;
    fdir = dir;
}


void G4MPTCollimatorEx::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MPTCollimatorEx::Dump(std::ostream& out){
  out << GetEnvelopeSize()/mm <<G4endl;
  out << theXYVec.size() <<G4endl;
  //
  //
  for ( G4int i = 0; i < (G4int)theXYVec.size(); i++){
    out << theXYVec[i]/mm << G4endl;
  }
  out << fdir << G4endl;
  //
}

void G4MPTCollimatorEx::SetXYVector(std::vector<G4double>& v){
  theXYVec.clear();
  G4int n = (G4int)v.size();
  for ( G4int i = 0; i < n/2; i++){
    theXYVec.push_back(G4TwoVector(v[2*i],v[2*i+1]));
  }
}

G4VPhysicalVolume* G4MPTCollimatorEx::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* mat = G4Material::GetMaterial(fMatName);
  G4VSolid* solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,       // Solid 
                                 mat,         // Material
                                 GetName());  // Name
  G4VPhysicalVolume* physical  = new G4PVPlacement(
                      GetRotation(),
                      GetTranslation(),
                      logical,   // Logical volume  
                      GetName(), // Name
                      worldlog,  // Mother  volume 
                      false,     // Not used 
                      0);        // Copy number  

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,0.3,0.3,0.8));
  logical->SetVisAttributes(visAttr);

  return physical;
}

void G4MPTCollimatorEx::buildNode(G4VPhysicalVolume* physvol) {
  std::vector<G4TwoVector> xyPolygon;
  G4bool theSamePoint = false;
  if ( theXYVec[0] == theXYVec[theXYVec.size()-1]){
    //G4cout << " Same <<<<<< " <<G4endl;
    theSamePoint = true;
  }
  //
  for ( G4int i = 0; i < (G4int)theXYVec.size(); i++){
    //G4cout << theXYVec[i]/mm << G4endl;
    if ( i == (G4int)theXYVec.size()-1 && theSamePoint ) break;
    xyPolygon.push_back(theXYVec[i]);
  }
  //for ( G4int i = 0; i < (G4int)xyPolygon.size(); i++){
  //  G4cout << xyPolygon[i]/mm << G4endl;
  //}
  //
  // The oder of xy-vector should be clockwise.
  if ( fdir < 0 ){
    std::reverse(xyPolygon.begin(),xyPolygon.end());
  }
  //if ( xyPolygon[0] == xyPolygon[xyPolygon.size()-1]){
  //  std::vector<G4TwoVector>::iterator endItr = xyPolygon.end();
  //  xyPolygon.erase(endItr);
  //  G4cout << "==== PTCol Remove Last entry === " <<G4endl;
  //  for ( G4int i = 0; i < (G4int)xyPolygon.size(); i++){
  //    G4cout << xyPolygon[i]/mm << G4endl;
  //  }
  //}

  //------ Drill Hole
  const G4String drillName = GetName()+"Drill";
  G4TwoVector offset0(0.,0.);
  G4double    scale = 1.0;
  G4VSolid* solDrill =  new G4ExtrudedSolid(drillName,
                                           xyPolygon,GetDZ(),
                                           offset0,scale, offset0, scale);

  G4Material* hole= G4Material::GetMaterial("Air");
  G4LogicalVolume* logDrill = new G4LogicalVolume(solDrill,hole,drillName);

  //G4VPhysicalVolume* physical  = 
  new G4PVPlacement(0,
                    G4ThreeVector(0,0,0),
                    logDrill,
                    GetName(),
                    physvol->GetLogicalVolume(),
                    false,
                    0);

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,1.0,1.0));
  logDrill->SetVisAttributes(visAttr);

}

