//
//
// class G4MScanBeamManager
//
// Class description:
//
// 
// --------------------------------------------------------------------
//
// (Createrd) 
//  2014-11-23  T.Aso Manager class for a beam scanning mode.
//
// (Modification)
//  2016-01-14  T.Aso ReadEIDFileWithAngSigma() for angle variance.
//  2017-04-03  T.Aso ThreadLocal.
//
#include "G4MScanBeamManager.hh"
#include "G4MScanBeamMessenger.hh"
#include "CLHEP/Random/Randomize.h"
#include "G4SystemOfUnits.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4MVScanModel.hh"
#include "G4TwoVector.hh"
#include "G4MBeamGun.hh"
#include "G4MScanningMagnet.hh"
#include <fstream>

G4ThreadLocal G4MScanBeamManager* G4MScanBeamManager::ptrScanMgr= 0;
//================================================

G4MScanBeamManager::G4MScanBeamManager():fVerbose(0),
                                         fSMX(0),fSMY(0),
                                         fNofEvToBeProcessed(0),
                                         fCounter(0)
{
  fScanModel = 0;
  fBeamGun = new G4MBeamGun();
  //G4cout <<" **** G4MScanBeamManager::G4MScanBeamManager() called" << G4endl;
  fMessenger = new G4MScanBeamMessenger(this);
  //
  //
  //fEIDVec.clear();
  //fXVec.clear();
  //fYVec.clear();
  //fDoseVec.clear(); 
  //fProbVec.clear();
  fEVec.clear(); 
  fWeightVec.clear(); 
}

G4MScanBeamManager::~G4MScanBeamManager() {
  //G4cout <<" **** G4MScanBeamManager::~G4MScanBeamManager() called" << G4endl;
  //
  //
  //fEIDVec.clear();
  //fXVec.clear();
  //fYVec.clear();
  //fDoseVec.clear(); 
  //fProbVec.clear();
  fEVec.clear(); 
  fWeightVec.clear(); 
  delete fMessenger;
  if ( fScanModel ) delete fScanModel;
}

void G4MScanBeamManager::SetScanModel(G4MVScanModel* model){
  //if ( fScanModel ) delete fScanModel;
  fScanModel = model;
  fScanModel->SetScanBeamManager(this);
}

void G4MScanBeamManager::SetBeamGun(G4MBeamGun* gene){
  fBeamGun = gene;
}

void G4MScanBeamManager::SetScanningMagnet(G4String& smxName, 
                                           G4String& smyName){
  //
  G4MVParticleTherapySystem* system= G4MVGeometryBuilder::GetSystem();
  fSMX = dynamic_cast<G4MScanningMagnet*>(system->GetModule(smxName)); 
  fSMY = dynamic_cast<G4MScanningMagnet*>(system->GetModule(smyName)); 
  if ( !fSMX || !fSMY ){
    const G4String& msg =  "Scanning Magnet Not Found ";
    G4Exception("G4MScanBeamManager::ReadEIDFile()","G4MScanManager00",
                FatalException,msg);
  }
}

void G4MScanBeamManager::ReadEIDFile(G4String& filename){
  //G4cout <<" **** G4MScanBeamManager::ReadEIDFile() called "
  //       <<filename << G4endl;
  //
  // fill vectors from a file.

  // Open file
  std::ifstream ifs;
  ifs.open(filename.c_str());
  //
  if(!ifs) { 
    const G4String& msg =  "EID File Not Found " + filename;
    G4Exception("G4MScanBeamManager::ReadEIDFile()","G4MScanManager00",
                FatalException,msg);
  }else{
    // Clear Vectors.
    ClearEID();
    // Read parameters  ( Assume space separated file. )
    G4int n;
    ifs >> n;
    //
    fEIDEneVec.resize(n);
    fEIDSigEVec.resize(n);
    fEIDSigXVec.resize(n);
    fEIDSigYVec.resize(n);
    G4int id;
    G4double e,se, sx, sy;
    for ( G4int i = 0; i < n; i++){
      ifs >> id >> e >> se >> sx >> sy;  
      e *= MeV;
      se *= MeV;
      sx *= mm;
      sy *= mm;
      //
      fEIDEneVec[id]=e;
      fEIDSigEVec[id]=se;
      fEIDSigXVec[id]=sx;
      fEIDSigYVec[id]=sy;
    }
  }    
  ifs.close();
  //
}

void G4MScanBeamManager::ReadEIDFileWithAngSigma(G4String& filename){
  //G4cout <<" **** G4MScanBeamManager::ReadEIDFileWithAngSig() called "
  //       <<filename << G4endl;
  //
  // fill vectors from a file.

  // Open file
  std::ifstream ifs;
  ifs.open(filename.c_str());
  //
  if(!ifs) { 
    const G4String& msg =  "EID File Not Found " + filename;
    G4Exception("G4MScanBeamManager::ReadEIDFile()","G4MScanManager00",
                FatalException,msg);
  }else{
    // Clear Vectors.
    ClearEID();
    // Read parameters  ( Assume space separated file. )
    G4int n;
    ifs >> n;
    //
    fEIDEneVec.resize(n);
    fEIDSigEVec.resize(n);
    fEIDSigXVec.resize(n);
    fEIDSigYVec.resize(n);
    fEIDAngSXVec.resize(n);
    fEIDAngSYVec.resize(n);
    G4int id;
    G4double e,se, sx, sy, asx, asy;
    for ( G4int i = 0; i < n; i++){
      ifs >> id >> e >> se >> sx >> sy >> asx >> asy;  
      e *= MeV;
      se *= MeV;
      sx *= mm;
      sy *= mm;
      asx *= mrad;
      asy *= mrad;
      //
      fEIDEneVec[id]=e;
      fEIDSigEVec[id]=se;
      fEIDSigXVec[id]=sx;
      fEIDSigYVec[id]=sy;
      fEIDAngSXVec[id]=asx;
      fEIDAngSYVec[id]=asy;
    }
  }    
  ifs.close();
  //
}

void G4MScanBeamManager::ReadScanFile(G4String& filename){
  //G4cout <<" **** G4MScanBeamManager::ReadScanFile() called "
  //       <<filename << G4endl;
  //
  // fill vectors from a file.
  fCounter = 0;
  // Replace T.Aso
  if ( fScanModel ) {
    fScanModel->ReadScanFile(filename);
  } else {
    const G4String& msg =  "Scan Mode Not Assigned ";
    G4Exception("G4MScanBeamManager::ReadScanFile()","G4MScanManager00",
                FatalException,msg);
  }
  /*
  //
  // Open file
  std::ifstream ifs;
  ifs.open(filename.c_str());
  //
  if(!ifs) { 
    const G4String& msg =  "Scan File Not Found " + filename;
    G4Exception("G4MScanBeamManager::ReadScanFile()","G4MScanManager00",
                FatalException,msg);
  }else{
    // Clear Vectors.
    Clear();
    // Read parameters  ( Assume space separated file. )
    G4int n;
    ifs >> n;
    //
    G4int   id;
    G4double x, y, d;
    //
    for ( G4int i = 0; i < n; i++){
      ifs >> id >> x >> y >> d;  
      x *= mm;
      y *= mm;
      d *= gray;
      fEIDVec.push_back(id); 
      fXVec.push_back(x);
      fYVec.push_back(y);
      fDoseVec.push_back(d);
    }
  }    
  ifs.close();
  //
  */
}

void G4MScanBeamManager::ReadDoseWeightFile(G4String& filename){
  //G4cout <<" **** G4MScanBeamManager::ReadDoseWeightFile() called "<<filename << G4endl;
  //
  // fill vectors from a file.

  // Open file
  std::ifstream ifs;
  ifs.open(filename.c_str());
  //
  if(!ifs) { 
    const G4String& msg =  "DoseWeight File Not Found " + filename;
    G4Exception("G4MScanBeamManager::ReadDoseWeightFile()","G4MScanManager00",
                FatalException,msg);
  }else{
    // Clear Vectors.
    fEVec.clear();
    fWeightVec.clear();
    // Read parameters  ( Assume space separated file. )
    //  [Gy/primary]
    G4int n;
    ifs >> n;
    //
    G4double e, d;
    //
    for ( G4int i = 0; i < n; i++){    
      ifs >> e >> d;  
      e *=MeV;
      d *= gray;
      fEVec.push_back(e);
      fWeightVec.push_back(d);
    }
  }    
  ifs.close();
  //
}

G4double G4MScanBeamManager::GetWeight(G4double e){
  for ( size_t i = 1; i < fEVec.size();  i++){
    if ( fEVec[i-1] <= e && e <= fEVec[i] ){
      G4double a = (fWeightVec[i] - fWeightVec[i-1]) / (fEVec[i] - fEVec[i-1]);
      G4double w = fWeightVec[i-1] + a * ( e - fEVec[i-1] );
      return w;
    }
  }
  return -1.0;
}

G4double G4MScanBeamManager::GetWeight(G4int index){
  return fWeightVec[index];
}

void G4MScanBeamManager::CalculateProbability(){
  // Replace by T.Aso
  if ( fScanModel ) {
    fScanModel->CalculateProbability();
  } else {
    const G4String& msg =  "Scan Mode Not Assigned ";
    G4Exception("G4MScanBeamManager::CalculateProbability()","G4MScanManager00",
                FatalException,msg);
  }
  /*
  //
  G4double total = 0;
  fProbVec.clear();
  for ( size_t i = 0; i < fDoseVec.size();  i++){
    G4double energy = fEIDEneVec[fEIDVec[i]];
    G4double WNpar = fDoseVec[i]/GetWeight(energy); // Gy to Number of particle
    if ( fVerbose > 2 ){
      G4cout << " ene "<<energy/MeV<<" dose "<<fDoseVec[i]/gray
             << " w "<<GetWeight(energy)/gray<<G4endl;
      G4cout << " WNpar "<<WNpar<<G4endl;
    }
    total += WNpar;
    fProbVec.push_back(total);
  }
  //
  // Normalize to 1.
  for ( size_t i = 0; i < fProbVec.size();  i++){
    fProbVec[i] /= total;
  }
  */
}

void G4MScanBeamManager::AppendEID(G4double energy, 
                                   G4double sigX, G4double sigY,
                                   G4double angSX, G4double angSY){
  fEIDEneVec.push_back(energy);
  fEIDSigXVec.push_back(sigX);
  fEIDSigYVec.push_back(sigY);
  if ( angSX >= 0. ) fEIDAngSXVec.push_back(angSX);
  if ( angSY >= 0. ) fEIDAngSYVec.push_back(angSY);
}

void G4MScanBeamManager::ClearEID(){
  //G4cout <<" **** G4MScanBeamManager::ClearEID() called. " << G4endl;
  // Clear vectors.
  //
  //
  fEIDEneVec.clear();  // Energy 
  fEIDSigXVec.clear();  // SigmaX
  fEIDSigYVec.clear();  // SigmaY
  fEIDAngSXVec.clear();  // SX of angle
  fEIDAngSYVec.clear();  // SY of angle
}

void G4MScanBeamManager::Clear(){
  //G4cout <<" **** G4MScanBeamManager::Clear() called. " << G4endl;
  // Clear vectors.
  //
  //fEIDVec.clear();
  //fXVec.clear();
  //fYVec.clear();
  //fDoseVec.clear(); 
  //fProbVec.clear();
}

G4int G4MScanBeamManager::SampleSeq(G4int nevProcessed){
  //G4cout <<" **** G4MScanBeamManager::SampleSeq called. " << G4endl;
  G4long index = -1;
  G4double frac = -1;
  //
  if ( nevProcessed >= 0 ){
    frac = ((G4double)nevProcessed)/fNofEvToBeProcessed;
  }else{
    frac  = CLHEP::RandFlat::shoot();
  }
  if ( fVerbose > 2 ){
  G4cout << "  nevProcessed = " <<nevProcessed 
         <<"  fNofEvToBeProcessed = "<< fNofEvToBeProcessed
         <<"  frac = "<< frac
         <<G4endl;
  }
  //
  //for ( size_t i = fCounter; i < fProbVec.size(); i++){
  for ( size_t i = fCounter; i < fScanModel->GetSize(); i++){
    //if ( frac < fProbVec[i]  ) {
    if ( frac < fScanModel->GetProb(i)  ) {
      index = i ;
      break;
    }
  }
  if ( fVerbose > 2 ){
    G4cout <<" index = "<<index <<"   fCounter = "<<fCounter<<G4endl;
  }
  //if ( fCounter > fProbVec.size() ){
  if ( fCounter > fScanModel->GetSize() ){
    G4cerr << "G4MScanBeamManager::SampleSeq fCounter Overflow"<<G4endl;
  }else{
    fCounter = index;
  }
  SetPrimaryParam(index);
  SetScanMagnetParam(index);
  return index;
}

void G4MScanBeamManager::SetPrimaryParam(G4long seq){
  //G4cout <<" **** G4MScanBeamManager::SetPrimary called. " << seq<<G4endl;
  if ( seq < 0 ) return;
  // Primary beam condition
  //G4int beamid = fEIDVec[seq];
  G4int beamid = fScanModel->GetEID(seq);
  //
  G4double ene = fEIDEneVec[beamid];
  G4double se = fEIDSigEVec[beamid];
  G4double sx =  fEIDSigXVec[beamid];
  G4double sy =  fEIDSigYVec[beamid];
  G4double ax = 0.0;
  G4double ay = 0.0;
  //G4cout << " ScanBeamManager::Size "<<fEIDEneVec.size()<<" "<<fEIDAngSXVec.size()<<G4endl;
  if ( fEIDEneVec.size() == fEIDAngSXVec.size() ){
    ax = fEIDAngSXVec[beamid];
    ay = fEIDAngSYVec[beamid];
    //G4cout << " ScanBeamManager:: "<<ax<<" "<<ay<<G4endl;
  }
  //
  fBeamGun->SetParticleEnergy(ene);
  fBeamGun->SetEnergyFluctuation(se);
  fBeamGun->SetSpotSize(G4ThreeVector(sx,sy,0.0));
  //
  fBeamGun->SetAngleSigma(ax,ay);

  // Magnet condition
  if (fSMX) fSMX->SetEnergyForBField(ene);
  if (fSMY) fSMY->SetEnergyForBField(ene);
}

void G4MScanBeamManager::SetScanMagnetParam(G4long seq){
  //G4cout <<" **** G4MScanBeamManager::SetScanMagnet called. " << seq<<G4endl;
  if ( seq < 0 ) return;
  // Scan Magnet condition
  //if ( fSMX ) fSMX->SetFieldByDist(fXVec[seq]);
  //if ( fSMY ) fSMY->SetFieldByDist(fYVec[seq]);
  const G4TwoVector& SpotCoord = fScanModel->GetCoord(seq);
  if ( fSMX ) fSMX->SetFieldByDist(SpotCoord.x());
  if ( fSMY ) fSMY->SetFieldByDist(SpotCoord.y());
  
}

void G4MScanBeamManager::Show(std::ostream& out) {
  out << "******* G4MScanBeamManager Parameters *****************"<<G4endl;  
  //  G4long nentry =   fProbVec.size();
  G4long nentry =   fScanModel->GetSize();
  for (G4int i = 0; i < nentry;  i++  ){
    out << "SEQ= "<< i<<" EID="<<fScanModel->GetEID(i)
        <<" (X,Y)=("
        <<fScanModel->GetX(i,0)/mm<<","
        <<fScanModel->GetY(i,0)/mm<<")"
        <<" (X,Y)=("
        <<fScanModel->GetX(i,1)/mm<<","
        <<fScanModel->GetY(i,1)/mm<<")"
        << " Dose="<<fScanModel->GetDose(i)/gray
        <<" P="<<fScanModel->GetProb(i) << G4endl;
  }
  out << "*******************************************************"<<G4endl;
}

void G4MScanBeamManager::ShowEWeight(std::ostream& out) {
  out << "******* G4MScanBeamManager Parameters *****************"<<G4endl;  
  G4long nentry =   fEVec.size();
  for (G4int i = 0; i < nentry;  i++  ){
    out << " Eenergy(MeV)= "<<fEVec[i]/MeV
        << " Dose (gray)= "<< fWeightVec[i]/gray <<G4endl;
  }
  out << "*******************************************************"<<G4endl;
}

void G4MScanBeamManager::ShowEID(std::ostream& out) {
  out << "******* G4MScanBeamManager Parameters *****************"<<G4endl;  
  G4long nentry =   fEIDEneVec.size();
  for (G4int i = 0; i < nentry;  i++  ){
    out << "EID = "<< i<<" Eenergy(MeV)="<<fEIDEneVec[i]/MeV
        << " SigX(mm)=" << fEIDSigXVec[i]/mm
        << " SigY(mm)=" << fEIDSigYVec[i]/mm;
    if ( fEIDEneVec.size() == fEIDAngSXVec.size() ){
      out << " AngX(mrad)="<< fEIDAngSXVec[i]/mrad
          << " AngY(mrad)="<< fEIDAngSYVec[i]/mrad;
    }
    out<<G4endl;
  }
  out << "*******************************************************"<<G4endl;
}

void G4MScanBeamManager::SetVerbose(G4int v){
  fVerbose = v;
  if ( fScanModel ) fScanModel->SetVerbose(v);
}

