//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Box type module
// 
//  (History)
//   2014-10-31  T.Aso
//   2014-11-23  T.Aso Modify to avoid compile warinings.
//
//---------------------------------------------------------------------
//
#include "G4MDiskComposerFileCatalogue.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4MDiskComposer.hh"
#include <fstream>
#include <sstream>

G4MDiskComposerFileCatalogue::G4MDiskComposerFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVDiskComposerCatalogue(name),fDefaultFileName(fileName){
  subModuleVec.clear();
}

G4MDiskComposerFileCatalogue::~G4MDiskComposerFileCatalogue()
{
  subModuleVec.clear();
}

void G4MDiskComposerFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  //fModule->SetAllParameters(material,dxyz);
  Apply();
}

void G4MDiskComposerFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MDiskComposerFileCalalogue::Prepare()","G4MDiskComposerFileCata00",
                FatalException,msg);
  }else{
    ifs.getline(chline,512);  // effective physical size 
    std::istringstream iss1(chline);
    G4double fr,fz;
    iss1 >> fr >> fz ;   // Radius and Full thickness
    dR = fr/2. * mm;
    dZ = fz/2. * mm;

    ifs.getline(chline,512);  //material
    std::istringstream iss2(chline);
    iss2 >> material;

    ifs.getline(chline,512); // Number of sub-modules
    std::istringstream iss3(chline); 
    G4int N;
    iss3 >> N;
    
    subModuleVec.clear();

    G4String subm;
    for (G4int i = 0; i < N; i++ ){
      ifs.getline(chline,512); // Number of sub-modules
      std::istringstream iss4(chline); 
      iss4 >> subm;
      subModuleVec.push_back(subm);
      G4cout << " DiskComposerFileCatalogue:: " << subm<< G4endl;
    }
  }
  ifs.close();
}

void G4MDiskComposerFileCatalogue::Apply(){

  G4MVParticleTherapySystem* system= G4MVGeometryBuilder::GetSystem();
  fModule->Clear();
  fModule->SetAllParameters( material, dR, dZ );
  for (size_t i = 0;  i < subModuleVec.size(); i++){
    G4MVBeamModule* module = system->GetModule(subModuleVec[i]);
    if ( !module ) {
      G4Exception("G4MDiskComposerFileCata::Apply()",
                  "G4MDiskCompFileCata00",JustWarning,": No sub module.. Break ");
      break;
    }
    G4cout << " DiskComposerFileCatalogue::Apply " << subModuleVec[i]<< G4endl;
    fModule->AddModule(module);
    fModule->AddToCreateList(subModuleVec[i]);
  }
  fModule->ReBuild();
}
