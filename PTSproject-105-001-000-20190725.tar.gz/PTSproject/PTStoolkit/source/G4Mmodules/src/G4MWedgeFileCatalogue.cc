//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MWedge.
// 
//  (History)
//   2016-11-06   T.Aso
//---------------------------------------------------------------------
//
#include "G4MWedgeFileCatalogue.hh"
#include "G4MWedge.hh"
#include <fstream>

G4MWedgeFileCatalogue::G4MWedgeFileCatalogue(const G4String& name,
                                             const G4String& filename)
  :G4MVWedgeCatalogue(name),fDefaultFileName(filename){
}

G4MWedgeFileCatalogue::~G4MWedgeFileCatalogue()
{}

void G4MWedgeFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDxyzWedge,
                            fMatWedge,
                            fXYvec,
                            fdir);
}

void G4MWedgeFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio(pname);
  if(!fileio) { 
    G4cerr << "File Not Found " << pname << G4endl;
  }else{
    fXYvec.clear();

    //G4int verbose = fModule->GetVerbose();
    
    G4double dx,dy, dz;
    fileio >> dx >> dy ;  // Full size of frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    fDxyzWedge.setX(dx);
    fDxyzWedge.setY(dy);
    
    fileio>>   fMatWedge;       // Material

    G4double angle;
    fileio >> angle ;  // angle of wedge
    angle *= degree;

    dz = dx*std::tan(angle);
    fDxyzWedge.setZ(dz);    

    fileio >> fdir ;  // angle of wedge

    //
    fXYvec.clear();
    fXYvec.push_back(G4TwoVector(-dx,dz));
    fXYvec.push_back(G4TwoVector(dx,dz));
    if ( fdir > 0 ) {
      fXYvec.push_back(G4TwoVector(dx,-dz));
    }else{
      fXYvec.push_back(G4TwoVector(-dx,-dz));
    }

    fileio.close();
  }
}

void G4MWedgeFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyzWedge,
                            fMatWedge,
                            fXYvec,
                            fdir);
  fModule->ReBuild();
}
 
