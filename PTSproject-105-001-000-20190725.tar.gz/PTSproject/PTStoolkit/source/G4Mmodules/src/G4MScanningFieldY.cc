//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MScanningFieldY
//
//  (HISTORY)
//  2014-11-23  T.Aso   Add a sign for swiching B field direction
//  2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#include "G4MScanningFieldY.hh"

G4MScanningFieldY::G4MScanningFieldY(G4double yVal, G4int isign) 
  : G4MVScanningField()
{
  SetMagField(yVal);
  SetSign(isign);
}

G4MScanningFieldY::G4MScanningFieldY(const G4MScanningFieldY& right)
  :G4MVScanningField(right){
}

G4MScanningFieldY* G4MScanningFieldY::Copy(){
    return new G4MScanningFieldY(*this);
}

void G4MScanningFieldY::SetMagField(double yVal){
  G4double B[3];
  B[0] = fSign*yVal;
  B[1] = 0;
  B[2] = 0;
  SetFieldValue(B);
}

G4MScanningFieldY::~G4MScanningFieldY() {
}
