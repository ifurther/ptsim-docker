//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Base class for beam modules.
//
// (HISTORY)
// 05 Oct. 2005 T.Aso
// 05 Oct. 2005 T.Aso Modified to include Utility method for UIcommand.
//                    Add SetDICOM() , GetDICOM()
// 05 Dec. 2005 T.Aso Add ReBuildModule().
// 24 Aug. 2006 T.Aso Add procedure for removing G4Region and updating
//                   G4ProductionCutsTable in UnInstall method.
// 22 Jan. 2007 T.Aso Update materials used in G4Region using RegionStore.
// 14 Feb. 2007 T.Aso G4MDICOM was changed to G4MVDICOM
// 15 Feb. 2007 T.Aso DICOM related functions and the messenger are
//                    moved into G4MVDICOM and G4MDICOMMessenger.
// 07 Dec. 2007 T.Aso Introduce quiet flag in GetModule() method.
// 08 Jul. 2010 T.Aso GetLogicalVolume(),ScanVolumeTree()
// 10 Aug. 2010 T.Aso Introduce RemoveModule().
// 12 Mar. 2012 T.Aso Introduce InstallAll(),UninstallAll().
//                    Add UpdateRun() method, and Event number arguments.
// 16 Nov. 2012 T.Aso Introduce bool argument in InstallAll(),UninstallAll().
// 2013-01-15 T.Aso  Modify ModuleList().
// 2013-03-03 T.Aso  ModuleListInWorld() was introduced. 
//                   Install() was modified to specify the world volume.
// 2013-10-24 T.Aso  SetLang();
// 2014-03-31 T.Aso  Install() was modified. InstallIfExist() was added.
// 2014-08-07 T.Aso  Modify arguments in ModuleList().
// 2014-11-23 T.Aso  Move event number arguments to KNCC code.
// 2014-11-23 T.Aso  G4Run and G4Event are given in UpdateRun() and 
//                   UpdateEvent() 
// 2015-02-26 T.Aso  module->UpdateRegion() is now called for mass geom too.
// 2016-04-07 T.Aso  BuildSDandField() (Temp.)
// 2016-04-12 T.Aso  ScanVolumeTree(), DumpVolumeTree()
// 2016-07-16 T.Aso  DumpVolumeTree() prints SD and collection.
// 2017-03-31 T.Aso  Manage Rank for MPI.
// -----------------------------------------------------------------
//
#include "G4MVParticleTherapySystem.hh"
#include "G4RunManager.hh"
#include "G4RegionStore.hh"
#include "G4ProductionCutsTable.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4Run.hh"
#include "G4Event.hh"

#include "G4VUserDetectorConstruction.hh"
#include "G4VSensitiveDetector.hh"
#include "G4MParallelWorld.hh"

#include "G4MCloneBeamModule.hh"
#include "G4PVPlacement.hh"

G4MVParticleTherapySystem::G4MVParticleTherapySystem(const G4String& name)
  :fName(name),fRank(-1),fWorldPhys(0) {
  theModuleStore = new G4MBeamModuleStore();
  fMessenger = new G4MParticleTherapySystemMessenger(this);
}

G4MVParticleTherapySystem::~G4MVParticleTherapySystem() {
  delete theModuleStore;
  delete fMessenger;
}

const G4String& G4MVParticleTherapySystem::GetName() {
  return fName;
}

G4VPhysicalVolume* G4MVParticleTherapySystem::GetWorldPhys() {
  return fWorldPhys;
}

G4LogicalVolume* 
G4MVParticleTherapySystem::GetLogicalVolume(const G4String& module,
                                            G4int idSelect){
  G4MVBeamModule *bp = GetModule(module,TRUE);
  if ( !bp ) return 0;
  const G4VPhysicalVolume *pv = bp->GetPhysicalVolume();
  if ( !pv ) return 0;
  G4LogicalVolume* lv = pv->GetLogicalVolume();
  if ( !lv ) return 0;
  
  G4int id=0;
  return ScanVolumeTree(lv,id, idSelect);
}

G4LogicalVolume* G4MVParticleTherapySystem::
ScanVolumeTree(G4LogicalVolume* lv, G4int& id, G4int idSelect){

  if ( id == idSelect ) return lv;
  G4int Ndaughters = lv->GetNoDaughters(); 
  G4LogicalVolume* preLog = 0;
  for (G4int i=0; i<Ndaughters; i++){
      G4LogicalVolume* daughterLVol = lv->GetDaughter(i)->GetLogicalVolume();
      if ( daughterLVol !=  preLog ) {
        preLog = daughterLVol;
        G4cout << id <<" "<<daughterLVol->GetName()<<G4endl;
        id++;
        G4LogicalVolume* p = ScanVolumeTree(daughterLVol, id, idSelect);
        if ( p ) return p;
      }
  }
  return 0;
} 

G4int G4MVParticleTherapySystem::DumpVolumeTree(G4LogicalVolume* lv,
                                               G4int cnt, G4int id){
  G4int Ndaughters = lv->GetNoDaughters(); 
  G4cout << id;
  cnt++;
  for( G4int it = 0; it < cnt ; it++) G4cout << " ";
  G4cout <<lv->GetName() <<" : " << lv->GetMaterial()->GetName()
         << "("<<Ndaughters<<")";
  G4VSensitiveDetector* sd = lv->GetSensitiveDetector();
  if ( sd ) {
    G4cout << "  sd:" << sd->GetName();
    G4int ncol = sd->GetNumberOfCollections();
    for ( G4int icol = 0; icol < ncol ; icol++) {
      G4cout << " col"<<icol<<":" <<sd->GetCollectionName(icol);
    }
  }
  G4cout << G4endl;
  G4LogicalVolume* preLog = 0;
  for (G4int i=0; i<Ndaughters; i++){
      G4LogicalVolume* daughterLVol = lv->GetDaughter(i)->GetLogicalVolume();
      if ( daughterLVol !=  preLog ) {
        preLog = daughterLVol;
        id = DumpVolumeTree(daughterLVol, cnt,++id);
      }
      if ( lv->GetDaughter(i)->IsReplicated() ||
           lv->GetDaughter(i)->IsParameterised() ) {
        break;
      }
  }
  return id;
} 


G4MVBeamModule* G4MVParticleTherapySystem::GetModule(const G4String& name,
                                                     G4bool quiet) {
  return theModuleStore->Get(name,quiet);
}

void G4MVParticleTherapySystem::SetModule(G4MVBeamModule* module) {
  theModuleStore->Add(module->GetName(),module);
}

void G4MVParticleTherapySystem::RemoveModule(const G4String& name) {
  theModuleStore->Remove(name);
}

void G4MVParticleTherapySystem::Install(const G4String& name, const G4String& pwName,
                                        G4bool layered) {
  G4cout << "+++ G4MVParticleTherapySystem::Install "<<name
         << " " <<pwName<<" " << layered <<G4endl;
  G4MVBeamModule* module = theModuleStore->Get(name);
  if( module )  {
    if ( module->GetPhysicalVolume() ){  // If already installed. clean first.
      UnInstall(name);
    }
    if ( pwName == "none" || pwName == "None") {
      module->BuildIn(GetWorldPhys()->GetLogicalVolume());
      module->UpdateRegion();
    }else { // Parallel World
      const G4VUserDetectorConstruction* det = 
        G4RunManager::GetRunManager()->GetUserDetectorConstruction();
      G4int N = det->GetNumberOfParallelWorld();
      for ( G4int i = 0; i < N ; i++ ){
        G4MParallelWorld* pw = dynamic_cast<G4MParallelWorld*>(det->GetParallelWorld(i));
        if ( pw->GetName() == pwName ){
          G4VPhysicalVolume* pwPhys = pw->GetPhysWorld();
          module->BuildIn(pwPhys->GetLogicalVolume());
          if ( layered ) module->UpdateRegion();
          break;
        }
      }
    }
  }else {
      G4cout << "@@ Module " << name <<" does not exist " <<G4endl;
  }
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
}

void G4MVParticleTherapySystem::InstallIfExist(const G4String& name, const G4String& pwName,
                                               G4bool layered) {
  G4cout << "+++ G4MVParticleTherapySystem::InstallIfExist "<<name
         << " " <<pwName<<" " << layered <<G4endl;
  G4MVBeamModule* module = theModuleStore->Get(name);
  //
  if ( module->GetPhysicalVolume() ){  // If already installed. clean first.
    Install(name,pwName,layered);
  }else{
    G4cout <<"@@ InstallIfExist : Phys not exist, do nothing."<<G4endl;
  }
}

void G4MVParticleTherapySystem::InstallAll(G4bool bTarget) {
  G4int  n = theModuleStore->NumModule();
  G4cout << "+++ G4MVParticleTherapySystem::InstallAll "<<n<<G4endl;
  for (G4int i = 0; i < n ; i++){
    G4String name = theModuleStore->GetName(i);
    if(name != "Room" ) {
      if ( !bTarget && (name == "DICOM" || name == "WaterPhantom") ) { 
      }else{
        Install(name);
      }        
    }
  }
}

void G4MVParticleTherapySystem::CloneIfExist(const G4String& name1, const G4String& name2,
                                             G4int copyid,
                                             G4double x,G4double y,G4double z,
                                             G4double rx,G4double ry,G4double rz){
  G4cout << "+++ G4MVParticleTherapySystem::CloneIfExist "<<name1 <<" " <<name2
         << " " << copyid << "xyz=("<<x<<","<<y<<","<<z<<")"
         << " rxyz=("<<rx<<","<<ry<<","<<rz<<")"<<G4endl;

  G4MVBeamModule* module1 = theModuleStore->Get(name1);
  if ( !module1  ) {
    G4cout <<"@@ CloneIfExist : the module does not exist, do nothing."<<G4endl;
  }
  //                                                                                                                  
  if ( module1->GetPhysicalVolume() ){  // If already installed. clean first.                                         
    //                                                                                                                
    const G4VPhysicalVolume* phys1 = module1->GetPhysicalVolume();
    G4LogicalVolume*   log1  = phys1->GetLogicalVolume();
    G4LogicalVolume*   motherLog1 = phys1->GetMotherLogical();
    //                                                                                                                
    G4MVBeamModule* module2 = new G4MCloneBeamModule(name2);
    module2->SetTranslation(G4ThreeVector(x,y,z));
    module2->SetRotation(G4ThreeVector(rx,ry,rz));
    theModuleStore->Add(name2, module2);
    G4VPhysicalVolume* phys2 =
      new G4PVPlacement(module2->GetRotation(), module2->GetTranslation(),
                        log1,name2,motherLog1, false, copyid);
    module2->SetPhysicalVolume(phys2);
    //                                                                                                                
  }else{
    G4cout <<"@@ CloneIfExist : Phys does not exist, do nothing."<<G4endl;
  }
}



void G4MVParticleTherapySystem::UnInstall(const G4String& name) {
  G4MVBeamModule* module = theModuleStore->Get(name);
  if(module!=NULL) {
    const G4VPhysicalVolume* physvol = module->GetPhysicalVolume();
    if ( physvol != NULL ){
       G4Region* reg = physvol->GetLogicalVolume()->GetRegion();
      if ( reg && reg != fWorldPhys->GetLogicalVolume()->GetRegion() ) {
          G4cout << " *** Remove G4Region ; "<<reg->GetName() <<G4endl;
          module->CleanUpRegion();
          //G4RegionStore::GetInstance()->DeRegister(reg);
          G4RegionStore::GetInstance()->UpdateMaterialList(fWorldPhys);
          G4ProductionCutsTable::GetProductionCutsTable()
            ->UpdateCoupleTable(fWorldPhys);
      }
      module->CleanUpVolumes();
      if ( module->GetType() == 1){ // Clone BeamModule                                                               
        const G4String mname = module->GetName();
        RemoveModule(mname);
      }
    }
  }else G4cout << "@@ Module " << name <<" does not exist " <<G4endl;
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
}

void G4MVParticleTherapySystem::UnInstallAll(G4bool bTarget) {
  G4int  n = theModuleStore->NumModule();
  G4cout << "+++ G4MVParticleTherapySystem::UnInstallAll "<<n<<G4endl;
  for (G4int i = 0; i < n ; i++){
    G4String name = theModuleStore->GetName(i);
    if(name != "Room" ) {
      if ( !bTarget && ( name == "DICOM" || name == "WaterPhantom")) {
      }else{
        UnInstall(name);
      }
    }
  }
}

void G4MVParticleTherapySystem::ReBuildModule(const G4String& name){
  G4MVBeamModule* module = theModuleStore->Get(name);
  if(module!=NULL) module->ReBuild();
  else G4cout << "@@ Module " << name <<" does not exist " <<G4endl;
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
}

G4VPhysicalVolume* G4MVParticleTherapySystem::BuildSystem() {
  fWorldPhys = BuildDefault();
  return fWorldPhys;
}

void G4MVParticleTherapySystem::BuildSDandField(){
  G4int  n = theModuleStore->NumModule();
  G4cout << "+++ G4MVParticleTherapySystem::BuildSDandField "<<n<<G4endl;
  for (G4int i = 0; i < n ; i++){
    G4MVBeamModule* module = theModuleStore->Get(i);
    if ( module->GetPhysicalVolume() ){  // If already installed.
      module->BuildInSDandField();
    }
  }
}

// Utility method for UIcommand.
void G4MVParticleTherapySystem::ModuleList(G4int lvl,std::ostream& out) {
   theModuleStore->ModuleList(lvl,out);
}

// Utility method for UIcommand.
void G4MVParticleTherapySystem::ModuleListInWorld(G4String& worldName, std::ostream& out) {
  //G4cout << worldName <<","<< fWorldPhys->GetName() <<G4endl;
  if ( fWorldPhys->GetName() == worldName ){
    theModuleStore->ModuleListInWorld(fWorldPhys->GetLogicalVolume(),out);
  }else{
    const G4VUserDetectorConstruction* det = 
      G4RunManager::GetRunManager()->GetUserDetectorConstruction();
    G4int N = det->GetNumberOfParallelWorld();
    for ( G4int i = 0; i < N ; i++ ){
      G4MParallelWorld* pw = dynamic_cast<G4MParallelWorld*>(det->GetParallelWorld(i));
      if ( pw->GetName() == worldName ){
        G4VPhysicalVolume* pwPhys = pw->GetPhysWorld();
        theModuleStore->ModuleListInWorld(pwPhys->GetLogicalVolume(),out);
        break;
      }
    }
  }
}

// Utility method for UIcommand.
void G4MVParticleTherapySystem::SetLang(G4int l) {
   theModuleStore->SetLang(l);
}


