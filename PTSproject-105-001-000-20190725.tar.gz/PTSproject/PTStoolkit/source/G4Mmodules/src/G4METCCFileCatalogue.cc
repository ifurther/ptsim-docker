//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for ETCC type module
// 
//  (History)
//   2017-12-22 T.Aso
//
//---------------------------------------------------------------------
//
#include "G4METCCFileCatalogue.hh"
#include "G4METCC.hh"
#include "G4MGParam.hh"
#include "G4TwoVector.hh"
#include <fstream>
#include <sstream>

G4METCCFileCatalogue::G4METCCFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVETCCCatalogue(name),fDefaultFileName(fileName){
  fVerbose = 1;
}

G4METCCFileCatalogue::~G4METCCFileCatalogue()
{}

void G4METCCFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  G4ThreeVector& dxyz = fCaseDxyz;
  G4String& material = fCaseMat;
  fModule->SetAllParameters(dxyz, material);
  fModule->SetInsideVol( fInsideDxyz, fInsideMat);
  fModule->SetGasVol(fGasDxyz, fGasMat, fGasZoffset);
  fModule->SetSubVol(fNsubX, fNsubY,
                     fSubDxyz, fSubOffset,
                     fSubPitch, fSubMat);
  fModule->SetLayerVol(fNlayer, 
                       fLayerDxyz,
                       fLayerOffZ,
                       fLayerMat);
  fModule->SetTowerVol(fTower);
}

void G4METCCFileCatalogue::Clear(){
  fLayerDxyz.clear();
  fLayerOffZ.clear();
  fLayerMat.clear();
  for ( G4int i = 0; i < (G4int)fTower.size(); i++){
    delete fTower[i];
  }
  fTower.clear();
}

void G4METCCFileCatalogue::Prepare(G4String& pname){
  //
  std::ifstream ifs(pname);
  if(!ifs){
    const G4String msg = "file open error"+pname;
    G4Exception("G4METCCFileCalalogue::Prepare()","G4METCCFileCata00",
                FatalException,msg);
  }else{
    Clear();

    G4double fx,fy,fz;
    G4String fstr;
    ifs >> fx >> fy >> fz >> fstr;   // Full Size
    if ( fVerbose > 0 ) {
      G4cout << fx <<" "<< fy <<" "<< fz <<" "<< fstr << G4endl;
    }
    fCaseDxyz.set(fx*mm/2.,fy*mm/2.,fz*mm/2.);
    fCaseMat = fstr;

    ifs >> fx >> fy >> fz >> fstr;   // Full Size
    if ( fVerbose > 0 ) {
      G4cout << fx <<" "<< fy <<" "<< fz  << G4endl;
    }
    fInsideDxyz.set(fx*mm/2.,fy*mm/2.,fz*mm/2.);
    fInsideMat = fstr;

    G4double foffx, foffy, foffz;
    G4double fpitchx,fpitchy;
    ifs >> fx >> fy >> fz >> foffz >> fstr;   // Full Size    
    if ( fVerbose > 0 ) {
      G4cout << fx <<" "<< fy <<" "<< fz <<" "<<foffz<<" "<< fstr << G4endl;
    }
    fGasDxyz.set(fx*mm/2.,fy*mm/2.,fz*mm/2.);
    fGasZoffset = foffz*mm;
    fGasMat = fstr;

    ifs >> fNsubX >> fNsubY;   // Full Size    
    if ( fVerbose > 0 ) {
      G4cout << fNsubX <<" "<< fNsubY <<G4endl;
    }
    ifs >> fx >> fy >> fz >> foffx >> foffy >> foffz
        >> fpitchx >> fpitchy >> fstr;
    if ( fVerbose > 0 ) {
      G4cout << fx <<" "<< fy <<" "<< fz <<" "
             << foffx <<" "<<foffy<<" "<< foffz<<" "
             << fpitchx <<" "<<fpitchy<<" "
             << fstr << G4endl;
    }
    fSubDxyz.set(fx*mm/2.,fy*mm/2.,fz*mm/2.);
    fSubOffset.set(foffx*mm, foffy*mm, foffz*mm);
    fSubPitch.set(fpitchx*mm, fpitchy*mm);
    fSubMat = fstr;

    G4double flag;
    G4int   fnx, fny;
    ifs >> fNlayer;
    for ( G4int i = 0; i < fNlayer; i++){
      ifs >> fx >> fy >> fz >> foffz >> fstr >> flag;
      if ( fVerbose > 0 ) {
        G4cout << fx <<" "<< fy <<" "<< fz <<" "
               << foffz<<" "
               << fstr << G4endl;
      }
      fLayerDxyz.push_back(G4ThreeVector(fx*mm/2.,fy*mm/2.,fz*mm/2.));
      fLayerOffZ.push_back(foffz*mm);
      fLayerMat.push_back(fstr);
      if ( flag > 0 ){
        ifs >> fx >> fy >> fstr>> fnx >> fny;
        if ( fVerbose > 0 ) {
          G4cout << fx <<" " << fy <<" " 
                 << fstr<< " " <<fnx << " " << fny<< G4endl;
        }
        G4TwoVector v(fx*mm/2.,fy*mm/2.);
        G4MGParam* p = new G4MGParam(v,fstr,fnx,fny);
        fTower.push_back(p);
      }else{
        fTower.push_back(0);
      }
    }
  }
  ifs.close();
}

void G4METCCFileCatalogue::Apply(){
  fModule->SetAllParameters(fCaseDxyz,fCaseMat);
  fModule->SetInsideVol( fInsideDxyz, fInsideMat);
  fModule->SetGasVol(fGasDxyz, fGasMat, fGasZoffset);
  fModule->SetSubVol(fNsubX, fNsubY,
                     fSubDxyz, fSubOffset,
                     fSubPitch, fSubMat);
  fModule->SetLayerVol(fNlayer, 
                       fLayerDxyz,
                       fLayerOffZ,
                       fLayerMat);
  fModule->SetTowerVol(fTower);
  //
  fModule->ReBuild();
}
