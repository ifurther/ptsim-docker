//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Box shape component with a B-field.
//
// (HISTORY)  
//
//---------------------------------------------------------------------
//
#include "G4MBoxField.hh"
#include "G4MBoxFieldMessenger.hh"
//
#include "G4FieldManager.hh"
//
#include "G4MModuleField.hh"
#include "G4AutoDelete.hh"

G4MBoxField::G4MBoxField(const G4String& name, const G4ThreeVector& dxyz,
                         const G4String& mat)
  : G4MBox(name,dxyz, mat)
{
  fModuleField = new G4MModuleField();
  fMessenger = new G4MBoxFieldMessenger(this,name);
}

G4MBoxField::G4MBoxField(const G4String& name)
  : G4MBox(name)
{
  fModuleField = new G4MModuleField();
  fMessenger = new G4MBoxFieldMessenger(this,name);
}

G4MBoxField::G4MBoxField(G4MVBoxCatalogue* catalogue)
  : G4MBox(catalogue)
{
  fModuleField = new G4MModuleField();
  fMessenger = new G4MBoxFieldMessenger(this,GetName());
}

G4MBoxField::~G4MBoxField()
{
  if ( fModuleField )  delete fModuleField;
  if ( fMessenger )  delete fMessenger;
}

void G4MBoxField::buildNode(G4VPhysicalVolume* physvol){
  G4LogicalVolume* logicalFrame = physvol->GetLogicalVolume();
  //
  //* Attach B-Field to logical volume
  fFieldLVList.push_back(logicalFrame);
  //
}

void G4MBoxField::SetFieldValue(const G4ThreeVector& bval){
  fModuleField->SetFieldValue(bval);
  if ( fModuleFieldCache.Get() ){
    (fModuleFieldCache.Get())->SetFieldValue(bval);
  }
}

void G4MBoxField::BuildInSDandField(){
  //
  if ( !fModuleField ) return;
  //
  //
  G4cout << " ASO  --- BOX Filed BuildInSDandField -1-" <<G4endl;
  //
    if ( !fModuleFieldCache.Get() ){
      G4MModuleField* field = fModuleField->Copy();
      fModuleFieldCache.Put(field);
      G4AutoDelete::Register(field);
    }
  //
    // Logical name
    for (G4int i = 0; i < (G4int)fFieldLVList.size(); i++){
       G4FieldManager* fieldManager = fFieldLVList[i]->GetFieldManager();
       if( fieldManager ){
          fieldManager->SetDetectorField(fModuleFieldCache.Get());
        }else{
          fieldManager = new G4FieldManager(fModuleFieldCache.Get());
        }
       fFieldLVList[i]->SetFieldManager(fieldManager,true);
    }
  G4cout << " ASO  --- BOX Filed BuildInSDandField -2-" <<G4endl;
}
