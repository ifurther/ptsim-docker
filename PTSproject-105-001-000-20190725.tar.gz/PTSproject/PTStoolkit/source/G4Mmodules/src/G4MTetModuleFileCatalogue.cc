//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for BMTemplate type module
// 
//  (History)
//  2018-04-22   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MTetModuleFileCatalogue.hh"
#include "G4MVTetModuleCatalogue.hh"
#include "G4MTetModule.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>
#include <sstream>

G4MTetModuleFileCatalogue::G4MTetModuleFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVTetModuleCatalogue(name),fDefaultFileName(fileName){
  fVerbose = 1;
}

G4MTetModuleFileCatalogue::~G4MTetModuleFileCatalogue()
{}

void G4MTetModuleFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fFileList, fFileCT2Dens, fFileRoi2Mat);
  fModule->SetHUMin(fHUMin);
  fModule->SetHUMax(fHUMax);
  fModule->SetDensityResol(fDensResol);
}

void G4MTetModuleFileCatalogue::Prepare(G4String& pname){
  //
  std::ifstream fileio(pname);
  if(!fileio) { 
    G4cerr << "File Not Found " << pname << G4endl;
  }else{
    fileio >> fFileList ;  //Tet FileList
    fileio >> fFileCT2Dens ;  // CT - Density map
    fileio >> fFileRoi2Mat ;  // Roi - Mat map
    fileio >> fHUMin >> fHUMax ;  // HU min and max
    fileio >> fDensResol;  // Density resol. in g/cm3
    //
    if ( fVerbose == 1 ) {
      G4cout << fFileList <<G4endl;
      G4cout << fFileCT2Dens <<G4endl;  // CT - Density map
      G4cout << fFileRoi2Mat <<G4endl;  // Roi - Mat map
      G4cout << fHUMin <<" "<< fHUMax<<G4endl;  // HU min and max
      G4cout << fDensResol/(g/cm3) << G4endl;  // Density resol. g/cm3
    }
    //
    fileio.close();
  }
}

void G4MTetModuleFileCatalogue::Apply(){
  fModule->SetAllParameters(fFileList, fFileCT2Dens, fFileRoi2Mat);
  fModule->SetHUMin(fHUMin);
  fModule->SetHUMax(fHUMax);
  fModule->SetDensityResol(fDensResol);
  //
  fModule->ReBuild();
}







 
