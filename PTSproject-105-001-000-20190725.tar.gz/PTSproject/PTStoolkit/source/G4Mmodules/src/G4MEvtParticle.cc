//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
// -----------------------------------------------------------------
// (Class Description)
//    Class for storing particle information for EvtInterface
//
// (HISTORY)
// 30 Nov. 2007 T.Aso
// 2017-03-15 T.Aso for threading
// -----------------------------------------------------------------
//

#include "G4MEvtParticle.hh"

G4ThreadLocal G4Allocator<G4MEvtParticle>* aEvtParticleAllocator=0;

G4MEvtParticle::G4MEvtParticle()
  :theParticle(0),position(0.0,0.0,0.0),time(0.0)
{}

G4MEvtParticle::G4MEvtParticle(G4PrimaryParticle* pp, 
                               G4double& px, G4double& py, G4double& pz,
                               G4double& t)
    :theParticle(pp),position(px,py,pz),time(t)
{}

G4MEvtParticle::G4MEvtParticle(G4PrimaryParticle* pp, 
                               G4ThreeVector& pos, G4double& t)
  :theParticle(pp),position(pos),time(t)
{}

G4MEvtParticle::~G4MEvtParticle()
{}

const G4MEvtParticle & 
G4MEvtParticle::operator=(const G4MEvtParticle &)
{ return *this; }

G4int G4MEvtParticle::operator==(const G4MEvtParticle &right) const
{ return (this==&right); }
G4int G4MEvtParticle::operator!=(const G4MEvtParticle &right) const
{ return (this!=&right); }
