//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MWobblerFieldY
//
//  (HISTORY)
//   2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#include "G4MWobblerFieldY.hh"

G4MWobblerFieldY::G4MWobblerFieldY(G4double amp, G4double ang) 
  : G4MVWobblerField(amp,ang)
{
  G4double B[3];
  B[0] = amp*sin(ang);
  B[1] = 0;
  B[2] = 0;
  SetFieldValue(B);
}

G4MWobblerFieldY::G4MWobblerFieldY(const G4MWobblerFieldY& right)
  :G4MVWobblerField(right){
}

G4MWobblerFieldY* G4MWobblerFieldY::Copy(){
   return new G4MWobblerFieldY(*this);
}

G4MWobblerFieldY::~G4MWobblerFieldY() {
}

void G4MWobblerFieldY::calcField() {
  G4double B[3];
  B[0] = GetAmplitude()*sin(GetAngle());
  B[1] = 0;
  B[2] = 0;
  SetFieldValue(B);
}

