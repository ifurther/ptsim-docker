//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Desctiption)
//    This Class represents a Wobbler Manget.
//
// (HISTORY)
//   07-OCT-05  T.ASO  Found a lack of constructor
//                     G4MWobblerMagnet(G4MVWobblerManget*).
//                     The implementation is added to source file.
//   22-Jan-07  T.Aso  Add VisAttributes.
//   10-Aug-10  T.Aso  Introduce SetMagFieldByAngle() method.
//   26-Jul-11  T.Aso  Modify to handle smaller B region.
//   2012-06-10 T.Aso  Implement Dump() method.
//   2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#include "G4MWobblerMagnet.hh"
#include "G4MVWobblerField.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4FieldManager.hh"
#include "G4VisAttributes.hh"

#include "G4AutoDelete.hh"

G4MWobblerMagnet::G4MWobblerMagnet(const G4String& name, 
                                   const G4String& matframe,
                                   const G4ThreeVector& dxyzframe, 
                                   const G4String& matfield, 
                                   const G4ThreeVector& dxyzfield, 
                                   G4MVWobblerField* bfield) 
  :G4MVBeamModule(name,dxyzframe),fmatFrame(matframe),
   fmatField(matfield),fBDxyz(dxyzfield),fMagField(bfield),fCatalogue(NULL)
{}

G4MWobblerMagnet::G4MWobblerMagnet(const G4String& name) 
  :G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MWobblerMagnet::G4MWobblerMagnet(G4MVWobblerMagnetCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MWobblerMagnet::~G4MWobblerMagnet() {
  delete fMagField;
  if ( fCatalogue ) delete fCatalogue;
}

void G4MWobblerMagnet::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MWobblerMagnet::SetAllParameters(const G4String& matframe,
                                        const G4ThreeVector& dxyzframe, 
                                        const G4String& matfield, 
                                        const G4ThreeVector& dxyzfield, 
                                        G4MVWobblerField* bfield) 
{
  fmatFrame=matframe;
  fEnvelopeSize=dxyzframe;
  fmatField=matfield;
  fBDxyz=dxyzfield;
  fMagField=bfield;
}

void G4MWobblerMagnet::Dump(std::ostream& out){
  out << fmatFrame<<"\t"<<fmatField <<G4endl;
  out << fEnvelopeSize/mm<<"\t" << fBDxyz/mm <<G4endl;
  if ( fMagField) {
    out << fMagField->GetAmplitude()/tesla<<G4endl;
    const G4double a[4]={0.,0.,0.,0.};
    G4double b[3]={0.,0.,0.};
    fMagField->GetFieldValue(a,b);
    out << b[0]<<" " <<b[1]<<" "<<b[2]<<G4endl;
  }
}


G4VPhysicalVolume* G4MWobblerMagnet::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* matFrame = G4Material::GetMaterial(fmatFrame);
  G4VSolid* solidFrame = 
    new G4Box(GetName(),fEnvelopeSize.x(),fEnvelopeSize.y(),fEnvelopeSize.z());
  G4LogicalVolume* logicalFrame = new G4LogicalVolume(
                                 solidFrame,       // Solid 
                                 matFrame,         // Material
                                 GetName());       // Name

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                     GetRotation(),
                     GetTranslation(),
                     logicalFrame,        
                      GetName(),          
                     worldlog,   
                     false,      
                     0);         
  return physical;
}

void G4MWobblerMagnet::buildNode(G4VPhysicalVolume* physvol) {

  G4LogicalVolume* logicalFrame = physvol->GetLogicalVolume();
  //
  //--- BField is less than envelope
  if ( fBDxyz.z() < fEnvelopeSize.z() ) {
    G4Material* matHole = G4Material::GetMaterial(fmatField);
    G4VSolid* solidHole = 
      new G4Box(GetName(),fBDxyz.x(),fBDxyz.y(),fEnvelopeSize.z());
    G4LogicalVolume* logicalHole = new G4LogicalVolume(
                                                       solidHole,     
                                                       matHole,       
                                                       GetName()); 

    logicalFrame->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.5,0.5)));
    //G4VPhysicalVolume* physHole = 
    new G4PVPlacement(0,G4ThreeVector(0,0,0),logicalHole,GetName(),
                      logicalFrame,false,0);
    logicalFrame = logicalHole;
  }

  //--- BField  Installed into  Frame
  G4Material* matB = G4Material::GetMaterial(fmatField);
  G4VSolid* solidB = 
    new G4Box(GetName(),fBDxyz.x(),fBDxyz.y(),fBDxyz.z());
  G4LogicalVolume* logicalB = new G4LogicalVolume(
                                 solidB,     
                                 matB,       
                                 GetName()); 

  logicalFrame->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.5,0.5)));

  //* Attach B-Field to logical volume
  fFieldLVList.push_back(logicalB);

  //G4VPhysicalVolume* physB = 
  new G4PVPlacement(0,G4ThreeVector(0,0,0),logicalB,GetName(),
                    logicalFrame,false,0);
}

void G4MWobblerMagnet::BuildInSDandField(){
  //
    if ( !fMagFieldCache.Get() ){
      G4MVWobblerField* field = fMagField->Copy();
      fMagFieldCache.Put(field);
      G4AutoDelete::Register(field);
    }
  //
    // Logical name
    for (G4int i = 0; i < (G4int)fFieldLVList.size(); i++){
       G4FieldManager* fieldManager = fFieldLVList[i]->GetFieldManager();
       if( fieldManager ){
          fieldManager->SetDetectorField(fMagFieldCache.Get());
        }else{
          fieldManager = new G4FieldManager(fMagFieldCache.Get());
        }
       fFieldLVList[i]->SetFieldManager(fieldManager,true);
    }
}

void G4MWobblerMagnet::SetMagFieldByAngle(G4double angle) {
  G4MVWobblerField* field = GetMagField();
  if ( field ) {
    field->SetAngle(angle);
  }else {
    G4Exception("G4WobblerMagnet::SetMagFieldByAngle()",
                "G4MWobblerMag00",JustWarning,": No field ");
  }
}

G4MVWobblerField* G4MWobblerMagnet::GetMagField() const{
  G4MVWobblerField* field = fMagFieldCache.Get();
  if ( field ) {
    return field;
  }
  return fMagField;
}
