//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MDiskCmd.
// 
//  (History)
//   22-JAN-07   T.Aso  created.
//
//---------------------------------------------------------------------
//
#include "G4MDiskCmdCatalogue.hh"
#include "G4MDisk.hh"
#include "G4UnitsTable.hh"
#include <sstream>

G4MDiskCmdCatalogue::G4MDiskCmdCatalogue(const G4String& name)
  :G4MVDiskCatalogue(name){
  fdR  =  36.*mm;
  fdZ  =  22.*mm/2.;
  fMat =  "Air";
}

G4MDiskCmdCatalogue::G4MDiskCmdCatalogue(const G4String& name,
					 G4double dr, G4double dz, 
					 const G4String& mat)
    :G4MVDiskCatalogue(name),fdR(dr),fdZ(dz),fMat(mat){
}

G4MDiskCmdCatalogue::~G4MDiskCmdCatalogue()
{}

void G4MDiskCmdCatalogue::Init(){
  fModule->SetAllParameters(fdR,fdZ,fMat);
}

void G4MDiskCmdCatalogue::Prepare(G4String& pname){
  G4String unitName;    
  std::istringstream  is(pname); 
  is >> fMat >> fdR >> fdZ >> unitName;
  G4double unit = G4UnitDefinition::GetValueOf(unitName);
  fdR *= unit;
  fdZ /= 2.;
  fdZ *= unit;
}

void G4MDiskCmdCatalogue::Apply(){
   fModule->SetAllParameters(fdR,fdZ,fMat);
   fModule->ReBuild();
}







 
