//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  Created by S.KAMEOKA
//
// 2013-11-01 T.Aso Add fCmdWaterPhantomBEdep command to score tracks
//                  w/o energy deposits.
// 2016-04-07 T.Aso UI directory name updated.
// 2019-04-04  T.Aso  Give the name of module to Messenger.
//---------------------------------------------------------------------
//
#include "G4MWaterPhantomMessenger.hh"
#include "G4MWaterPhantom.hh"

G4MWaterPhantomMessenger::G4MWaterPhantomMessenger(G4MWaterPhantom* wp,
                                                   const G4String& name)
  :fWP(wp) {

  const G4String& myDir = "/G4M/Module/"+name+"/";
  fDir = new G4UIdirectory(myDir);
  fDir->SetGuidance("UI commands for modules");

  //
  // WaterPhantom
  //
  const G4String WaterPhantomSize = myDir+"size";
  fCmdWaterPhantomSize = 
    new G4UIcmdWith3VectorAndUnit(WaterPhantomSize,this);
  fCmdWaterPhantomSize->SetGuidance("WaterPhantomSize");
  fCmdWaterPhantomSize->SetParameterName("dX","dY","dZ",true,true);
  fCmdWaterPhantomSize->SetDefaultUnit("mm");
  fCmdWaterPhantomSize->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String WaterPhantomDim = myDir+"dim";
  fCmdWaterPhantomDim = 
    new G4UIcmdWith3Vector(WaterPhantomDim,this);
  fCmdWaterPhantomDim->SetGuidance("WaterPhantomDimension");
  fCmdWaterPhantomDim->SetParameterName("nx","ny","nz",true,true);
  fCmdWaterPhantomDim->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String WaterPhantomSDSize = myDir+"sdsize";
  fCmdWaterPhantomSDSize =
    new G4UIcmdWith3VectorAndUnit(WaterPhantomSDSize,this);
  fCmdWaterPhantomSDSize->SetGuidance("WaterPhantom SD Size");
  fCmdWaterPhantomSDSize->SetParameterName("dxSD","dySD","dzSD",true,true);
  fCmdWaterPhantomSDSize->SetDefaultUnit("mm");
  fCmdWaterPhantomSDSize->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String WaterPhantomSDOffset = myDir+"sdoffset";
  fCmdWaterPhantomSDOffs =
    new G4UIcmdWith3VectorAndUnit(WaterPhantomSDOffset,this);
  fCmdWaterPhantomSDOffs->SetGuidance("WaterPhantom SD Offset");
  fCmdWaterPhantomSDOffs->SetParameterName("offxSD","offySD","offzSD",true,true);
  fCmdWaterPhantomSDOffs->SetDefaultUnit("mm");
  fCmdWaterPhantomSDOffs->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String WaterPhantomMaterial = myDir+"material";
  fCmdWaterPhantomMaterial =
    new G4UIcmdWithAString(WaterPhantomMaterial,this);
  fCmdWaterPhantomMaterial->SetGuidance("WaterPhantom Material");
  fCmdWaterPhantomMaterial->SetParameterName("material",false);
  fCmdWaterPhantomMaterial->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String WaterPhantomBEdep = myDir+"edep";
  fCmdWaterPhantomBEdep =
    new G4UIcmdWithABool(WaterPhantomBEdep,this);
  fCmdWaterPhantomBEdep->SetGuidance("WaterPhantom Edep flag");
  fCmdWaterPhantomBEdep->SetParameterName("EdepFlag",false);
  fCmdWaterPhantomBEdep->AvailableForStates(G4State_Init,G4State_Idle);

}

G4MWaterPhantomMessenger::~G4MWaterPhantomMessenger() {
  if (fCmdWaterPhantomSize) delete fCmdWaterPhantomSize;
  if (fCmdWaterPhantomDim)   delete fCmdWaterPhantomDim;
  if (fCmdWaterPhantomSDSize ) delete fCmdWaterPhantomSDSize;
  if (fCmdWaterPhantomSDOffs ) delete fCmdWaterPhantomSDOffs;
  if (fCmdWaterPhantomMaterial ) delete fCmdWaterPhantomMaterial;
  if (fCmdWaterPhantomBEdep ) delete fCmdWaterPhantomBEdep;
  if (fDir) delete fDir;
}

void G4MWaterPhantomMessenger::SetNewValue(G4UIcommand* command, 
                                           G4String newValue) {
 if ( command == fCmdWaterPhantomDim ){
    G4ThreeVector dim = fCmdWaterPhantomDim->GetNew3VectorValue(newValue);
    G4int nx = (G4int)dim.x();
    G4int ny = (G4int)dim.y();
    G4int nz = (G4int)dim.z();
    fWP->SetDimension(nx,ny,nz);
 } else if ( command == fCmdWaterPhantomSize ){
    G4ThreeVector size = fCmdWaterPhantomSize->GetNew3VectorValue(newValue);
    G4double dx = size.x();
    G4double dy = size.y();
    G4double dz = size.z();
    fWP->SetSize(dx,dy,dz);
 } else if ( command == fCmdWaterPhantomSDSize ){
   G4ThreeVector size = fCmdWaterPhantomSDSize->GetNew3VectorValue(newValue);
   G4double dx = size.x();
   G4double dy = size.y();
   G4double dz = size.z();
   fWP->SetSDSize(dx,dy,dz);
 } else if ( command == fCmdWaterPhantomSDOffs ){
   G4ThreeVector offs = fCmdWaterPhantomSDOffs->GetNew3VectorValue(newValue);
   G4double x = offs.x();
   G4double y = offs.y();
   G4double z = offs.z();
   fWP->SetSDOffset(x,y,z);
 } else if ( command == fCmdWaterPhantomMaterial ){
   fWP->SetMaterial(newValue);
 } else if ( command == fCmdWaterPhantomBEdep ){
   fWP->SetBEdep(fCmdWaterPhantomBEdep->GetNewBoolValue(newValue));
 }
}

G4String G4MWaterPhantomMessenger::GetCurrentValue(G4UIcommand* command) {
  return G4String("I do not know,"+command->GetCommandName());
}
