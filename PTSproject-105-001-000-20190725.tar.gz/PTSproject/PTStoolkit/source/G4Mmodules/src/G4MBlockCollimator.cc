//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// (Description)
//    Module for Block Collimator ( Almost idential to G4MDiskStructure )
//
// (HISTORY)  
//  22-JAN-07 T.Aso Overload SetAllParameters().
//
//---------------------------------------------------------------------
//
#include "G4MBlockCollimator.hh"
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MBlockCollimator::G4MBlockCollimator(const G4String &name,
				       const std::vector<G4double> &aDXs,
				       const std::vector<G4double> &aDYs,
				       G4double aDZ,
				       const std::vector<G4String> &mats)
  : G4MVBeamModule(name,G4ThreeVector(aDXs[0],aDYs[0],aDZ)),
    dxs(aDXs), dys(aDYs), matNames(mats),fCatalogue(NULL)
{}

G4MBlockCollimator::G4MBlockCollimator(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MBlockCollimator::G4MBlockCollimator(G4MVBlockCollimatorCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MBlockCollimator::~G4MBlockCollimator()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MBlockCollimator::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBlockCollimator::SetAllParameters(const std::vector<G4double> &aDXs,
					  const std::vector<G4double> &aDYs,
					  G4double aDZ,
					  const std::vector<G4String> &mats)
{
  dxs = aDXs ;  
  dys = aDYs ; 
  matNames=mats;
  SetEnvelopeSize(dxs[0],dys[0],aDZ);
}

void G4MBlockCollimator::SetAllParameters(const G4ThreeVector& dxyzBlock, 
					  const G4String& matBlock,
					  G4double winX, G4double winY,
					  const G4String& matWin)
{
    dxs.clear();
    dys.clear();
    G4double dz =0.0;
    matNames.clear();

    // Frame Size
    dz  = dxyzBlock.z();
    matNames.push_back(matBlock);

    if ( winX > 0. ) {
	dxs.push_back(dxyzBlock.x()*2.+winX);
	dxs.push_back(winX);
    } else {
	dxs.push_back(dxyzBlock.x());
	dxs.push_back(dxyzBlock.x());
    }
    if ( winY > 0. ) {
	dys.push_back(dxyzBlock.y()*2.+winY);
	dys.push_back(winY);
    } else {
	dys.push_back(dxyzBlock.y());
	dys.push_back(dxyzBlock.y());
    }
    matNames.push_back(matWin);
    SetEnvelopeSize(dxs[0],dys[0],dz);
}

G4VPhysicalVolume* G4MBlockCollimator::buildEnvelope(G4LogicalVolume *worldlog)
{
  if (matNames.empty()) {
    G4Exception("G4MBlockCollimator::buildEnvelope","BloclColl00",FatalException,
		"vector matNames is empty");
  }

  G4Material *matEnv = G4Material::GetMaterial(matNames[0]);

  if (dxs.size() != matNames.size()){
    G4Exception("G4MBlockCollimator::buildEnvelope","BloclColl00",FatalException,
		"vectors dxs and matNames do not match in size");
  }
  if (dys.size() != matNames.size()){
    G4Exception("G4MBlockCollimator::buildEnvelope","BloclColl00",FatalException,
		"vectors dys and matNames do not match in size");
  }

  G4Box *solEnv = new G4Box(GetName(),GetDX(),GetDY(),GetDZ()); 

  G4LogicalVolume *logEnv = new G4LogicalVolume(solEnv,
						matEnv,
						GetName());

  logEnv->SetVisAttributes(new G4VisAttributes(G4Colour(.5,.5,1.)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(GetRotation(),
						   GetTranslation(),
						   logEnv,
						   GetName(),
						   worldlog,
						   false,
						   0);
  return physical;
}

void G4MBlockCollimator::buildNode(G4VPhysicalVolume* physvol)
{
  G4LogicalVolume *logMother = physvol->GetLogicalVolume();

  for (size_t i = 1; i < dxs.size(); ++i) {
    G4Material *mat = G4Material::GetMaterial(matNames[i]);
    G4double dz = GetDZ();
    G4Box *solid =
      new G4Box(GetName(), dxs[i], dys[i], dz);
    G4LogicalVolume *lv = new G4LogicalVolume(solid,
					      mat,
					      GetName());

    new G4PVPlacement(0, G4ThreeVector(0, 0, 0), lv, GetName(), logMother,
		      false, 0);
    logMother = lv;
  }
}
