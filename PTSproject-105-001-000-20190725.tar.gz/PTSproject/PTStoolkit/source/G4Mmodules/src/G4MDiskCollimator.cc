//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//   Disk Type Collimator
//
//   22-JAN-07  T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MDiskCollimator.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MDiskCollimator::G4MDiskCollimator(const G4String &name, 
				     G4double dRin,G4double dRout,G4double dz,
				     const G4String &mat)
  : G4MVBeamModule(name,G4ThreeVector(dRin,dRout,dz)),fMatName(mat),
    fCatalogue(NULL)
{}

G4MDiskCollimator::G4MDiskCollimator(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MDiskCollimator::G4MDiskCollimator(G4MVDiskCollimatorCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MDiskCollimator::~G4MDiskCollimator()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MDiskCollimator::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MDiskCollimator::SetAllParameters(G4double dRin, G4double dRout,
					 G4double dZ,const G4String &mat){
  SetEnvelopeSize(dRin,dRout,dZ);
  fMatName=mat;
}

G4VPhysicalVolume* G4MDiskCollimator::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(fMatName);
  if ( !mat )  G4cout << " material " << fMatName << " is NULL "<<G4endl;

  G4Tubs *solid = new G4Tubs(GetName(), GetDRin(),GetDRout(),GetDZ(),
			     0.0, twopi);

  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());

  lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));

  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
						  GetTranslation(),
						  lv,
						  GetName(),
						  worldlog,
						  false,
						  0);

  return physical;
}

void G4MDiskCollimator::buildNode(G4VPhysicalVolume *)
{}
