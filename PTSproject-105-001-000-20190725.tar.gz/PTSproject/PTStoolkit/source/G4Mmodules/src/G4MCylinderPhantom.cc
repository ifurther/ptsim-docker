//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Water Phantom
//
// (HISTORY)
//   2019-03-29 T.Aso Copied from G4MWaterPhantom
//   2019-04-03 T.Aso Add fTtype=101 to represent this module.
// -----------------------------------------------------------------
// 
#include "G4MCylinderPhantom.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Material.hh"
#include "G4PVReplica.hh"

#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
#include "G4MWaterPhantomSD.hh"

#include "G4RegionStore.hh"
#include "G4Region.hh"

G4MCylinderPhantom::G4MCylinderPhantom(const G4String& name, 
                                 const G4ThreeVector& drpz, 
                                 G4int nr, G4int np, G4int nz) 
  :G4MVBeamModule(name,drpz),fDrpzSD(drpz),
   fNr(nr),fNp(np),fNz(nz),fMat(0),fMatName("H_2O"),bEdep(1), fProdCuts(NULL),fCatalogue(NULL){
  fType = 101; // CylinderPhantom Type
  fMessenger = new G4MCylinderPhantomMessenger(this,name);
}

G4MCylinderPhantom::G4MCylinderPhantom(const G4String& name) 
  :G4MVBeamModule(name) ,
   fNr(1),fNp(1),fNz(1),fMat(0),fMatName("H_2O"),bEdep(1), fProdCuts(NULL),fCatalogue(NULL)
{
  fType = 101; // CylinderPhantom Type
  fDrpzSD.set(0.,0.,0.);
  fMessenger = new G4MCylinderPhantomMessenger(this,name);
}

G4MCylinderPhantom::G4MCylinderPhantom(G4MVCylinderPhantomCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),
    fNr(1),fNp(1),fNz(1),fMat(0),fMatName("H_2O"),bEdep(1), fProdCuts(NULL),fCatalogue(catalogue)
{
  fType = 101; // CylinderPhantom Type
  fDrpzSD.set(0.,0.,0.);
  fCatalogue->SetModule(this);
  fCatalogue->Init();
  fMessenger = new G4MCylinderPhantomMessenger(this,catalogue->GetName());
}

G4MCylinderPhantom::~G4MCylinderPhantom() {
  if ( fCatalogue ) delete fCatalogue;
  delete fMessenger;
}

void G4MCylinderPhantom::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MCylinderPhantom::SetAllParameters(const G4ThreeVector& drpz,G4String& material,
                                       const G4ThreeVector& drpzsd,
                                       G4int nr, G4int np, G4int nz,
                                       const G4ThreeVector& offsetsd)
{
  fEnvelopeSize=drpz;
  fMatName = material;
  fDrpzSD=drpzsd;
  fNr=nr;
  fNp=np;
  fNz=nz;
  fMat = 0;
  frpzSD=offsetsd;
}

void G4MCylinderPhantom::SetSize(G4double dr, G4double dp, G4double dz){
  fEnvelopeSize.set(dr,dp,dz);
  fDrpzSD.set(dr,dp,dz);
}

void G4MCylinderPhantom::SetDimension(G4int nr, G4int np, G4int nz){
  fNr = nr;
  fNp = np;
  fNz = nz;
}

void G4MCylinderPhantom::SetSDSize(G4double dr, G4double dp, G4double dz){
  fDrpzSD.set(dr,dp,dz);
}
void G4MCylinderPhantom::SetSDOffset(G4double r, G4double p, G4double z){
  frpzSD.set(r,p,z);
}

G4VPhysicalVolume* G4MCylinderPhantom::buildEnvelope(G4LogicalVolume* worldlog) {

  fMat = 0;
  // A specified material is assigned in Mass geometry. 
  // But in paralell geometry, it is kept as NULL.
  if ( worldlog->GetName() == "Room"){
    fMat =  G4Material::GetMaterial(fMatName);
  }

  G4VSolid* solid = new G4Tubs(GetName(), 
                               0., fEnvelopeSize.x(),
                               fEnvelopeSize.z(),
                               0., fEnvelopeSize.y());
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,                 // Solid 
                                 fMat,                   // Material
                                 GetName()              // Name
                                 );

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(0.1,1.0,1.0));
  visAttr->SetVisibility(true);
  logical->SetVisAttributes(visAttr);

  //================================================
  if (!fProdCuts) fProdCuts = new G4ProductionCuts();
  fProdCuts->SetProductionCut(1.*mm);
  G4Region* phantomReg =  
    G4RegionStore::GetInstance()->FindOrCreateRegion(GetName());
  phantomReg->SetProductionCuts(fProdCuts);
  logical->SetRegion(phantomReg);
  phantomReg->AddRootLogicalVolume(logical);
  //================================================

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),
                   GetTranslation(),
                   logical,                      // Logical volume  
                   GetName(),                    // Name
                   worldlog,                     // Mother  volume 
                   false,                        // Not used 
                   0);                           // Copy number  
  return physical;
}

void G4MCylinderPhantom::buildNode(G4VPhysicalVolume* physvol) {
  //
  // SD  Geometry
  G4VSolid* solid = new G4Tubs(GetName(), 
                               0., fDrpzSD.x(), // R
                               fDrpzSD.z(),  // Z
                               0., fDrpzSD.y()); // PHI

  G4LogicalVolume* logical = new G4LogicalVolume(
                                                 solid,
                                                 fMat,  
                                                 GetName()
                                                 );
  //G4VPhysicalVolume* physical  =
  new G4PVPlacement(0,frpzSD,logical,GetName(),
                    physvol->GetLogicalVolume(),
                    false,
                    0);

  // Replicated Volume
  G4double dr = fDrpzSD.x();
  G4double dphi = fDrpzSD.y();
  G4double dz   = fDrpzSD.z();
  G4double drRep = dr/(G4double)fNr;
  G4double dphiRep = dphi/(G4double)fNp;
  G4double dzRepHalf = dz/(G4double)fNz;
  //
  // Z Slice
  G4String zRepName(GetName()+"Z");
  G4VSolid* solZRep = 
    new G4Tubs(zRepName,0., dr, dzRepHalf, 0., dphi);
  G4LogicalVolume* logZRep = 
      new G4LogicalVolume(solZRep,fMat,zRepName);
  //G4PVReplica* zReplica = 
      new G4PVReplica(zRepName,logZRep,logical,
                      kZAxis,fNz,dzRepHalf*2.);

  // PHI Slice
  G4String pRepName(GetName()+"Phi");
  G4VSolid* solPRep = 
    new G4Tubs(pRepName,0., dr, dzRepHalf, 0.,dphiRep);
  G4LogicalVolume* logPRep = 
      new G4LogicalVolume(solPRep,fMat,pRepName);
  //G4PVReplica* pReplica = 
      new G4PVReplica(pRepName,logPRep,logZRep,kPhi,fNp,dphiRep);

  // R Slice
  G4String rRepName(GetName()+"R");
  G4VSolid* solRRep = 
    new G4Tubs(rRepName,0., drRep, dzRepHalf, 0., dphiRep);
  G4LogicalVolume* logRRep = 
      new G4LogicalVolume(solRRep,fMat,rRepName);
  //G4PVReplica* rReplica = 
      new G4PVReplica(rRepName,logRRep,logPRep,kRho, fNr,drRep);

  /// Sensitive Detector
  fSdLVList.push_back(logRRep);

  /// set visibility (can't be done interactively?)
  logRRep->SetVisAttributes(G4VisAttributes::Invisible);
  logPRep->SetVisAttributes(G4VisAttributes::Invisible);
  logZRep->SetVisAttributes(G4VisAttributes::Invisible);
}

void G4MCylinderPhantom::BuildInSDandField() {
  // Manager
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  /// Sensitive Detector
  G4MWaterPhantomSD* wsd =
    dynamic_cast<G4MWaterPhantomSD*>
    (sdm->FindSensitiveDetector(GetName(),false));
  if ( !wsd ) {
    G4cout << "++ G4MCylinderPhantom::  Create Sensitive Detector "
           <<GetName()<<G4endl;
    wsd = new G4MWaterPhantomSD(GetName());
    wsd->SetDepth(0, 1, 2); // R PHI Z
    wsd->SetZeroEdep(bEdep);
    sdm->AddNewDetector(wsd);
  }
  // Logical name    
  for (G4int i = 0; i < (G4int)fSdLVList.size(); i++){
    fSdLVList[i]->SetSensitiveDetector(wsd);
  }
}

void G4MCylinderPhantom::SetBEdep(G4bool b){
  bEdep = b;
  /// Sensitive Detector
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4MWaterPhantomSD* wsd = dynamic_cast<G4MWaterPhantomSD*>(sdm->FindSensitiveDetector(GetName(),false));
  if ( wsd ) {
      wsd->SetZeroEdep(bEdep);
  }
}
