//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Water Phantom
//
// (HISTORY)
// 21 Oct. 2005 T.Aso Sensitive Detector is created at first time only.
//                    After second case, the SD is obtained from SDManager.
//                    
// 01 Dec. 2005 T.Aso Add SetSize(), SetDimension() method.
// 01 Dec. 2005 T.Aso Add G4Region for production cut.
// 21 Aug. 2006 T.Aso Add G4ProductioCut for G4Region.
// 30 Nov. 2006 T.Aso G4Region is obtained by 
//                    G4RegionStore::FindOrCreateRegion() 
// 22 Jan. 2007 T.Aso Add Vis Attributes.
// 11 MAR. 2007 T.Aso The messenger is migrated from a Setup to this class.
// 01 SEP. 2010 T.Aso SetAllParameter() method was modified for the 
//                    FileCatalogue.
// 14 SEP. 2010 T.Aso Bugfix in SetAllParameter().
// 2013-10-25   T.Aso fMat to switch parallel world.
// 2013-11-01   T.Aso bEdep flag to score trakcs w/o energy deposit.
// 2017-03--15 T.Aso Threading                    
// 2019-04-04  T.Aso  Give the name of module to Messenger.
// 2019-04-03 T.Aso Add fTtype=100 to represent this module. 
// 2019-07-24 T.Aso Material is set even if it is in a parallelworld.
// -----------------------------------------------------------------
// 
#include "G4MWaterPhantom.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Material.hh"
#include "G4PVReplica.hh"

#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
#include "G4MWaterPhantomSD.hh"

#include "G4RegionStore.hh"
#include "G4Region.hh"

G4MWaterPhantom::G4MWaterPhantom(const G4String& name, 
                                 const G4ThreeVector& dxyz, 
                                 G4int nx, G4int ny, G4int nz) 
  :G4MVBeamModule(name,dxyz),fDxyzSD(dxyz),
   fNx(nx),fNy(ny),fNz(nz),fMat(0),fMatName("H_2O"),bEdep(1), fProdCuts(NULL),fCatalogue(NULL){
  fType = 100; // WaterPhantom Type
  fMessenger = new G4MWaterPhantomMessenger(this,name);
}

G4MWaterPhantom::G4MWaterPhantom(const G4String& name) 
  :G4MVBeamModule(name) ,
   fNx(1),fNy(1),fNz(1),fMat(0),fMatName("H_2O"),bEdep(1), fProdCuts(NULL),fCatalogue(NULL)
{
  fType = 100; // WaterPhantom Type
  fDxyzSD.set(0.,0.,0.);
  fMessenger = new G4MWaterPhantomMessenger(this,name);
}

G4MWaterPhantom::G4MWaterPhantom(G4MVWaterPhantomCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),
    fNx(1),fNy(1),fNz(1),fMat(0),fMatName("H_2O"),bEdep(1), fProdCuts(NULL),fCatalogue(catalogue)
{
  fDxyzSD.set(0.,0.,0.);
  fType = 100; // WaterPhantom Type
  fCatalogue->SetModule(this);
  fCatalogue->Init();
  G4String name = catalogue->GetName();
  if ( name == "WaterPhantom" ) name = "Phantom";
  fMessenger = new G4MWaterPhantomMessenger(this,name);
}

G4MWaterPhantom::~G4MWaterPhantom() {
  if ( fCatalogue ) delete fCatalogue;
  delete fMessenger;
}

void G4MWaterPhantom::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MWaterPhantom::SetAllParameters(const G4ThreeVector& dxyz,G4String& material,
                                       const G4ThreeVector& dxyzsd,
                                       G4int nx, G4int ny, G4int nz,
                                       const G4ThreeVector& offsetsd)
{
  fEnvelopeSize=dxyz;
  fMatName = material;
  fDxyzSD=dxyzsd;
  fNx=nx;
  fNy=ny;
  fNz=nz;
  fMat = 0;
  fxyzSD=offsetsd;
}

void G4MWaterPhantom::SetSize(G4double dx, G4double dy, G4double dz){
  fEnvelopeSize.set(dx,dy,dz);
  fDxyzSD.set(dx,dy,dz);
}

void G4MWaterPhantom::SetDimension(G4int nx, G4int ny, G4int nz){
  fNx = nx;
  fNy = ny;
  fNz = nz;
}

void G4MWaterPhantom::SetSDSize(G4double dx, G4double dy, G4double dz){
  fDxyzSD.set(dx,dy,dz);
}
void G4MWaterPhantom::SetSDOffset(G4double x, G4double y, G4double z){
  fxyzSD.set(x,y,z);
}

G4VPhysicalVolume* G4MWaterPhantom::buildEnvelope(G4LogicalVolume* worldlog) {

  //fMat = 0;
  // A specified material is assigned in Mass geometry. 
  // But in paralell geometry, it is kept as NULL.
  //if ( worldlog->GetName() == "Room"){
  //  fMat =  G4Material::GetMaterial(fMatName);
  //}
  // 2019-07-24 T.Aso
  fMat =  G4Material::GetMaterial(fMatName);

  G4VSolid* solid = new G4Box(GetName(), 
                              fEnvelopeSize.x(),
                              fEnvelopeSize.y(),
                              fEnvelopeSize.z());
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,                 // Solid 
                                 fMat,                   // Material
                                 GetName()              // Name
                                 );

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(0.1,1.0,1.0));
  visAttr->SetVisibility(true);
  logical->SetVisAttributes(visAttr);

  //================================================
  if (!fProdCuts) fProdCuts = new G4ProductionCuts();
  fProdCuts->SetProductionCut(1.*mm);
  G4Region* phantomReg =  
    G4RegionStore::GetInstance()->FindOrCreateRegion(GetName());
  phantomReg->SetProductionCuts(fProdCuts);
  logical->SetRegion(phantomReg);
  phantomReg->AddRootLogicalVolume(logical);
  //================================================

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),
                   GetTranslation(),
                   logical,                      // Logical volume  
                   GetName(),                    // Name
                   worldlog,                     // Mother  volume 
                   false,                        // Not used 
                   0);                           // Copy number  
  return physical;
}

void G4MWaterPhantom::buildNode(G4VPhysicalVolume* physvol) {
  //
  // SD  Geometry
  G4VSolid* solid = new G4Box(GetName(), fDxyzSD.x(),fDxyzSD.y(),fDxyzSD.z());
  G4LogicalVolume* logical = new G4LogicalVolume(
                                                 solid,
                                                 fMat,  
                                                 GetName()
                                                 );
  //G4VPhysicalVolume* physical  =
  new G4PVPlacement(0,fxyzSD,logical,GetName(),
                    physvol->GetLogicalVolume(),
                    false,
                    0);

  // Replicated Volume
  G4double dxRepHalf = fDxyzSD.x()/(G4double)fNx;
  G4double dyRepHalf = fDxyzSD.y()/(G4double)fNy;
  G4double dzRepHalf = fDxyzSD.z()/(G4double)fNz;
  // Z Slice
  G4String zRepName(GetName()+"Z");
  G4VSolid* solZRep = 
      new G4Box(zRepName,fDxyzSD.x(),fDxyzSD.y(),dzRepHalf);
  G4LogicalVolume* logZRep = 
      new G4LogicalVolume(solZRep,fMat,zRepName);
  //G4PVReplica* zReplica = 
      new G4PVReplica(zRepName,logZRep,logical,
                      kZAxis,fNz,dzRepHalf*2.);
  // X Slice
  G4String xRepName(GetName()+"X");
  G4VSolid* solXRep = 
      new G4Box(xRepName,dxRepHalf,fDxyzSD.y(),dzRepHalf);
  G4LogicalVolume* logXRep = 
      new G4LogicalVolume(solXRep,fMat,xRepName);
  //G4PVReplica* xReplica = 
      new G4PVReplica(xRepName,logXRep,logZRep,kXAxis,fNx,dxRepHalf*2.);
  // Y Slice
  G4String yRepName(GetName()+"Y");
  G4VSolid* solYRep = 
      new G4Box(yRepName,dxRepHalf,dyRepHalf,dzRepHalf);
  G4LogicalVolume* logYRep = 
      new G4LogicalVolume(solYRep,fMat,yRepName);
  //G4PVReplica* yReplica = 
      new G4PVReplica(yRepName,logYRep,logXRep,kYAxis,fNy,dyRepHalf*2.);

  logYRep->SetVisAttributes(new G4VisAttributes(G4Colour(0.5,0.5,1.0)));

  /// Sensitive Detector
  fSdLVList.push_back(logYRep);

  /// set visibility (can't be done interactively?)
  logZRep->SetVisAttributes(G4VisAttributes::Invisible);
  logXRep->SetVisAttributes(G4VisAttributes::Invisible);
  logYRep->SetVisAttributes(G4VisAttributes::Invisible);
}

void G4MWaterPhantom::BuildInSDandField() {
  // Manager
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  /// Sensitive Detector
  G4MWaterPhantomSD* wsd =
    dynamic_cast<G4MWaterPhantomSD*>
    (sdm->FindSensitiveDetector(GetName(),false));
  if ( !wsd ) {
    G4cout << "++ G4MWaterPhantom::  Create Sensitive Detector "
           <<GetName()<<G4endl;
    wsd = new G4MWaterPhantomSD(GetName());
    wsd->SetZeroEdep(bEdep);
    sdm->AddNewDetector(wsd);
  }
  // Logical name    
  for (G4int i = 0; i < (G4int)fSdLVList.size(); i++){
    fSdLVList[i]->SetSensitiveDetector(wsd);
  }
}

void G4MWaterPhantom::SetBEdep(G4bool b){
  bEdep = b;
  /// Sensitive Detector
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4MWaterPhantomSD* wsd = dynamic_cast<G4MWaterPhantomSD*>(sdm->FindSensitiveDetector(GetName(),false));
  if ( wsd ) {
      wsd->SetZeroEdep(bEdep);
  }
}
