//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  Created by T.Aso
//
//  2014-12-01 T.Aso Add commands for defining a field map.
//
//
//---------------------------------------------------------------------
//
#include "G4MScanningMagnetMessenger.hh"
#include "G4MScanningMagnet.hh"
#include "G4UIparameter.hh"
#include "G4Tokenizer.hh"
#include <fstream>

G4MScanningMagnetMessenger::G4MScanningMagnetMessenger(G4MScanningMagnet* module)
  :fVerbose(1),fSM(module) {

  G4String cmdcategory = "/G4M/Module/"+module->GetName();
  cmdcategory.append("/");
  
  if ( fVerbose > 0) G4cout <<"G4MScanningMagnetMessenger:: Directory "
                            <<cmdcategory<<G4endl;

  fDir = new G4UIdirectory(cmdcategory);
  fDir->SetGuidance("UI commands for modules");

  //
  // ScanningMagnet
  //
  G4String cmdFV = cmdcategory+"fieldvalue";
  fCmdFieldValue = 
    new G4UIcmdWithADoubleAndUnit(cmdFV,this);
  fCmdFieldValue->SetGuidance("FieldValue");
  fCmdFieldValue->SetParameterName("BField",false);
  fCmdFieldValue->SetDefaultUnit("tesla");
  fCmdFieldValue->AvailableForStates(G4State_Idle);

  G4String cmdFDist = cmdcategory+"distance";
  fCmdFieldByDist = 
    new G4UIcmdWithADoubleAndUnit(cmdFDist,this);
  fCmdFieldByDist->SetGuidance("Set FieldValue by distance from isocenter.");
  fCmdFieldByDist->SetParameterName("BField",false);
  fCmdFieldByDist->SetDefaultUnit("mm");
  fCmdFieldByDist->AvailableForStates(G4State_Idle);

  G4String cmdFSign = cmdcategory+"sign";
  fCmdSign = 
    new G4UIcmdWithAnInteger(cmdFSign,this);
  fCmdSign->SetGuidance("Sign of Field");
  fCmdSign->SetParameterName("FSign",false);
  fCmdSign->AvailableForStates(G4State_Idle);

  // FieldMap
  G4String cmdCreateFM = cmdcategory+"createFieldMap";
  fCmdCreateFieldMap = new G4UIcmdWithABool(cmdCreateFM,this);
  fCmdCreateFieldMap->SetGuidance("Create Field Map:(option) a boolean for bilinear interpolation");
  fCmdCreateFieldMap->SetParameterName("FMB",true);
  fCmdCreateFieldMap->SetDefaultValue(true);
  fCmdCreateFieldMap->AvailableForStates(G4State_Idle);

  G4String cmdDeleteFM = cmdcategory+"deleteFieldMap";
  fCmdDeleteFieldMap = new G4UIcmdWithoutParameter(cmdDeleteFM,this);
  fCmdDeleteFieldMap->SetGuidance("Delete Field Map");
  fCmdDeleteFieldMap->AvailableForStates(G4State_Idle);

  G4String cmdStoreFM = cmdcategory+"storeFieldMap";
  fCmdStoreFieldMap = new G4UIcmdWithAString(cmdStoreFM,this);
  fCmdStoreFieldMap->SetGuidance("Store Field Map: File name");
  fCmdStoreFieldMap->SetParameterName("FMFile",false);
  fCmdStoreFieldMap->AvailableForStates(G4State_Idle);

  G4String cmdRetrieveFM = cmdcategory+"retrieveFieldMap";
  fCmdRetrieveFieldMap = new G4UIcmdWithAString(cmdRetrieveFM,this);
  fCmdRetrieveFieldMap->SetGuidance("Retrieve Field Map: File name");
  fCmdRetrieveFieldMap->SetParameterName("FMFile",false);
  fCmdRetrieveFieldMap->AvailableForStates(G4State_Idle);

  G4String cmdPutXFM = cmdcategory+"putXFieldMap";
  fCmdPutXFieldMap = new G4UIcommand(cmdPutXFM,this);
  fCmdPutXFieldMap->SetGuidance("Set value of X(Distance)");
  fCmdPutXFieldMap->SetGuidance("Syntax: idx  xvalue unit");
  G4UIparameter* param;
  param = new G4UIparameter("idx",'i',false);
  fCmdPutXFieldMap->SetParameter(param);
  param = new G4UIparameter("xvalue",'d',false);
  fCmdPutXFieldMap->SetParameter(param);
  param = new G4UIparameter("xunit",'s',false);
  fCmdPutXFieldMap->SetParameter(param);

  G4String cmdPutYFM = cmdcategory+"putYFieldMap";
  fCmdPutYFieldMap = new G4UIcommand(cmdPutYFM,this);
  fCmdPutYFieldMap->SetGuidance("Set value of Y(Kinetic energy)");
  fCmdPutYFieldMap->SetGuidance("Syntax: idy  yvalue");
  //G4UIparameter* param;
  param = new G4UIparameter("idy",'i',false);
  fCmdPutYFieldMap->SetParameter(param);
  param = new G4UIparameter("yvalue",'d',false);
  fCmdPutYFieldMap->SetParameter(param);
  param = new G4UIparameter("yunit",'s',false);
  fCmdPutYFieldMap->SetParameter(param);

  G4String cmdPutValueFM = cmdcategory+"putValueFieldMap";
  fCmdPutValueFieldMap = new G4UIcommand(cmdPutValueFM,this);
  fCmdPutValueFieldMap->SetGuidance("Set value for ( idx, idy )");
  fCmdPutValueFieldMap->SetGuidance("Syntax: idx diy  value unit");
  //G4UIparameter* param;
  param = new G4UIparameter("idx",'i',false);
  fCmdPutValueFieldMap->SetParameter(param);
  param = new G4UIparameter("idy",'i',false);
  fCmdPutValueFieldMap->SetParameter(param);
  param = new G4UIparameter("value",'d',false);
  fCmdPutValueFieldMap->SetParameter(param);
  param = new G4UIparameter("vunit",'s',false);
  fCmdPutValueFieldMap->SetParameter(param);

  //////

  // FieldCoeff
  G4String cmdCreateC = cmdcategory+"createFieldCoeff";
  fCmdCreateFieldCoeff = new G4UIcmdWithABool(cmdCreateC,this);
  fCmdCreateFieldCoeff->SetGuidance("Create Field Coeff:(option) a boolean for bilinear interpolation");
  fCmdCreateFieldCoeff->SetParameterName("CB",true);
  fCmdCreateFieldCoeff->SetDefaultValue(true);
  fCmdCreateFieldCoeff->AvailableForStates(G4State_Idle);

  G4String cmdDeleteC = cmdcategory+"deleteFieldCoeff";
  fCmdDeleteFieldCoeff = new G4UIcmdWithoutParameter(cmdDeleteC,this);
  fCmdDeleteFieldCoeff->SetGuidance("Delete Field Coeff");
  fCmdDeleteFieldCoeff->AvailableForStates(G4State_Idle);

  G4String cmdStoreC = cmdcategory+"storeFieldCoeff";
  fCmdStoreFieldCoeff = new G4UIcmdWithAString(cmdStoreC,this);
  fCmdStoreFieldCoeff->SetGuidance("Store Field Coeff: File name");
  fCmdStoreFieldCoeff->SetParameterName("CFile",false);
  fCmdStoreFieldCoeff->AvailableForStates(G4State_Idle);

  G4String cmdRetrieveC = cmdcategory+"retrieveFieldCoeff";
  fCmdRetrieveFieldCoeff = new G4UIcmdWithAString(cmdRetrieveC,this);
  fCmdRetrieveFieldCoeff->SetGuidance("Retrieve Field Coeff: File name");
  fCmdRetrieveFieldCoeff->SetParameterName("CFile",false);
  fCmdRetrieveFieldCoeff->AvailableForStates(G4State_Idle);

  G4String cmdPutXC = cmdcategory+"putXFieldCoeff";
  fCmdPutXFieldCoeff = new G4UIcommand(cmdPutXC,this);
  fCmdPutXFieldCoeff->SetGuidance("Set value of X(Distance)");
  fCmdPutXFieldCoeff->SetGuidance("Syntax: idx  xvalue unit");
  //G4UIparameter* param;
  param = new G4UIparameter("idx",'i',false);
  fCmdPutXFieldCoeff->SetParameter(param);
  param = new G4UIparameter("xvalue",'d',false);
  fCmdPutXFieldCoeff->SetParameter(param);
  param = new G4UIparameter("xunit",'s',false);
  fCmdPutXFieldCoeff->SetParameter(param);

  G4String cmdPutYC = cmdcategory+"putYFieldCoeff";
  fCmdPutYFieldCoeff = new G4UIcommand(cmdPutYC,this);
  fCmdPutYFieldCoeff->SetGuidance("Set value of Y(Kinetic energy)");
  fCmdPutYFieldCoeff->SetGuidance("Syntax: idy  yvalue");
  //G4UIparameter* param;
  param = new G4UIparameter("idy",'i',false);
  fCmdPutYFieldCoeff->SetParameter(param);
  param = new G4UIparameter("yvalue",'d',false);
  fCmdPutYFieldCoeff->SetParameter(param);
  param = new G4UIparameter("yunit",'s',false);
  fCmdPutYFieldCoeff->SetParameter(param);

  G4String cmdPutValueC = cmdcategory+"putValueFieldCoeff";
  fCmdPutValueFieldCoeff = new G4UIcommand(cmdPutValueC,this);
  fCmdPutValueFieldCoeff->SetGuidance("Set value for ( idx, idy )");
  fCmdPutValueFieldCoeff->SetGuidance("Syntax: idx diy  value ");
  //G4UIparameter* param;
  param = new G4UIparameter("idx",'i',false);
  fCmdPutValueFieldCoeff->SetParameter(param);
  param = new G4UIparameter("idy",'i',false);
  fCmdPutValueFieldCoeff->SetParameter(param);
  param = new G4UIparameter("value",'d',false);
  fCmdPutValueFieldCoeff->SetParameter(param);
}

G4MScanningMagnetMessenger::~G4MScanningMagnetMessenger() {
  delete fCmdFieldValue;
  delete fCmdFieldByDist;
  delete fCmdSign;
  //
  delete fCmdCreateFieldMap;
  delete fCmdDeleteFieldMap;
  delete fCmdStoreFieldMap;
  delete fCmdRetrieveFieldMap;
  delete fCmdPutXFieldMap;
  delete fCmdPutYFieldMap;
  delete fCmdPutValueFieldMap;
  //
  delete fCmdCreateFieldCoeff;
  delete fCmdDeleteFieldCoeff;
  delete fCmdStoreFieldCoeff;
  delete fCmdRetrieveFieldCoeff;
  delete fCmdPutXFieldCoeff;
  delete fCmdPutYFieldCoeff;
  delete fCmdPutValueFieldCoeff;
  //
  delete fDir;
}

void G4MScanningMagnetMessenger::SetNewValue(G4UIcommand* command, 
                                           G4String newValue) {
 if ( command == fCmdFieldValue ){
    G4double field = fCmdFieldValue->GetNewDoubleValue(newValue);
    fSM->SetFieldValue(field);
 } else if ( command == fCmdFieldByDist ){
    G4double dist = fCmdFieldByDist->GetNewDoubleValue(newValue);
    fSM->SetFieldByDist(dist);
 } else if ( command == fCmdSign ){
    G4int sign = fCmdSign->GetNewIntValue(newValue);
    fSM->SetSign(sign);
    //
 } else if ( command == fCmdCreateFieldMap ){
    G4bool interpolation = fCmdCreateFieldMap->GetNewBoolValue(newValue);
    fSM->CreateFieldMap(interpolation);
 } else if ( command == fCmdDeleteFieldMap ){
    fSM->DeleteFieldMap();
 } else if ( command == fCmdStoreFieldMap ){
    std::ofstream ofile(newValue);
    fSM->StoreFieldMap(ofile);
    ofile.close();
 } else if ( command == fCmdRetrieveFieldMap ){
    std::ifstream ifile(newValue);    
    fSM->RetrieveFieldMap(ifile);
    ifile.close();
 } else if ( command == fCmdPutXFieldMap ){
   G4Tokenizer next(newValue);
   G4int idx = StoI(next());
   G4double xvalue = StoD(next());
   G4String str = next();
   G4double xunit = fCmdPutXFieldMap->ValueOf(str.c_str());
   fSM->PutXFieldMap(idx,(xvalue*xunit));
 } else if ( command == fCmdPutYFieldMap ){
   G4Tokenizer next(newValue);
   G4int idy = StoI(next());
   G4double yvalue = StoD(next());
   G4String str = next();
   G4double yunit = fCmdPutYFieldMap->ValueOf(str.c_str());
   fSM->PutXFieldMap(idy,(yvalue*yunit));
 } else if ( command == fCmdPutValueFieldMap ){
   G4Tokenizer next(newValue);
   G4int idx = StoI(next());
   G4int idy = StoI(next());
   G4double value = StoD(next());
   G4String str = next();
   G4double vunit = fCmdPutValueFieldMap->ValueOf(str.c_str());
   fSM->PutValueFieldMap(idx,idy,(value*vunit));
   //
   //
 } else if ( command == fCmdCreateFieldCoeff ){
    G4bool interpolation = fCmdCreateFieldCoeff->GetNewBoolValue(newValue);
    fSM->CreateFieldCoeff(interpolation);
 } else if ( command == fCmdDeleteFieldCoeff ){
    fSM->DeleteFieldCoeff();
 } else if ( command == fCmdStoreFieldCoeff ){
    std::ofstream ofile(newValue);
    fSM->StoreFieldCoeff(ofile);
    ofile.close();
 } else if ( command == fCmdRetrieveFieldCoeff ){
    std::ifstream ifile(newValue);    
    fSM->RetrieveFieldCoeff(ifile);
    ifile.close();
 } else if ( command == fCmdPutXFieldCoeff ){
   G4Tokenizer next(newValue);
   G4int idx = StoI(next());
   G4double xvalue = StoD(next());
   G4String str = next();
   G4double xunit = fCmdPutXFieldCoeff->ValueOf(str.c_str());
   fSM->PutXFieldCoeff(idx,(xvalue*xunit));
 } else if ( command == fCmdPutYFieldCoeff ){
   G4Tokenizer next(newValue);
   G4int idy = StoI(next());
   G4double yvalue = StoD(next());
   G4String str = next();
   G4double yunit = fCmdPutYFieldCoeff->ValueOf(str.c_str());
   fSM->PutXFieldCoeff(idy,(yvalue*yunit));
 } else if ( command == fCmdPutValueFieldCoeff ){
   G4Tokenizer next(newValue);
   G4int idx = StoI(next());
   G4int idy = StoI(next());
   G4double value = StoD(next());
   fSM->PutValueFieldCoeff(idx,idy,value);
 }

}

G4String G4MScanningMagnetMessenger::GetCurrentValue(G4UIcommand* command) {
  return G4String("I do not know,"+command->GetCommandName());
}
