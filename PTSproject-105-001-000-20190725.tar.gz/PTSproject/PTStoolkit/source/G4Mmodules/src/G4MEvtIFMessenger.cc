//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
//---------------------------------------------------------------------
// class description:
//
//  This is a concrete class of G4UImessenger which handles commands for
// G4MEvtIF.
//
// (History)
//  30-Nov-2007 T.Aso Created.
//  2019-04-04 T.Aso File format ASCII/Binary.
//---------------------------------------------------------------------
//
#include "G4MEvtIFMessenger.hh"
#include "G4MVEvtInterface.hh"
#include "G4ParticleDefinition.hh"
#include "G4ThreeVector.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4ParticleTable.hh"
#include <sstream>
#include <fstream>

G4MEvtIFMessenger::G4MEvtIFMessenger(G4MVEvtInterface * fPtclGun)
  :fEvtGun(fPtclGun)
{
  gunDirectory = new G4UIdirectory("/G4M/EvtIF/");
  gunDirectory->SetGuidance("File IO Event Interface control commands.");

  openCmd = new G4UIcmdWithAString("/G4M/EvtIF/open",this);
  openCmd->SetGuidance("Open file of specified File name for beam parameters");
  openCmd->SetParameterName("FileName",false);
  openCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  closeCmd = new G4UIcmdWithoutParameter("/G4M/EvtIF/close",this);
  closeCmd->SetGuidance("Close specified File name of beam parameters");
  closeCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  verboseCmd = new G4UIcmdWithAnInteger("/G4M/EvtIF/verbose",this);
  verboseCmd->SetGuidance("Verbose level");
  verboseCmd->SetParameterName("verbose",false);
  verboseCmd->AvailableForStates(G4State_Idle);

  fmtCmd = new G4UIcmdWithAString("/G4M/EvtIF/format",this);
  fmtCmd->SetGuidance("Open file of specified File format: ASCII or BINARY.");
  fmtCmd->SetParameterName("Format",false);
  fmtCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

}

G4MEvtIFMessenger::~G4MEvtIFMessenger()
{
  delete openCmd;
  delete closeCmd;
  delete verboseCmd;
  delete fmtCmd;
  delete gunDirectory;
}

void G4MEvtIFMessenger::SetNewValue(G4UIcommand * command,G4String newValues)
{
  if( command==openCmd ){
      fEvtGun->OpenEventFile(newValues);
  }else if( command==closeCmd ){ 
      fEvtGun->CloseEventFile();
  }else  if( command==verboseCmd ){
      fEvtGun->SetVerbose(verboseCmd->GetNewIntValue(newValues));
  }else if( command==fmtCmd ){
   if ( newValues == "ASCII" || newValues == "ascii" ){
     fEvtGun->SetFileFormat(0);
   }else if ( newValues == "BINARY" || newValues == "binary" ){
     fEvtGun->SetFileFormat(1);
   }else {
     G4cout << " Format is only available from ASCII or BINARY" <<G4endl;
   }
  }
}
  
G4String G4MEvtIFMessenger::GetCurrentValue(G4UIcommand * command)
{
  G4String cv;
  if( command==openCmd ){ 
    //cv = fEvtGun->GetFileName();
  }else if ( command==closeCmd ){ 
    //  cv = fEvtGun->GetFileName();
  }else if ( command==verboseCmd ){ 
      cv = fEvtGun->GetVerbose();
  }
  return cv;
}


