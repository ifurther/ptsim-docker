//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MBoxStructure
//
//  (HISTORY)
//
//---------------------------------------------------------------------
//
#include "G4MBoxStructure.hh"
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MBoxStructure::G4MBoxStructure(const G4String &name,
                                 const std::vector<G4ThreeVector> &dxyz,
                                 const std::vector<G4double> &z,
                                 const std::vector<G4String> &mats)
  : G4MVBeamModule(name,dxyz[0]), 
    fDxyz(dxyz),fZ(z),fMatName(mats),fCatalogue(NULL)
{}

G4MBoxStructure::G4MBoxStructure(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MBoxStructure::G4MBoxStructure(G4MVBoxStructureCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MBoxStructure::~G4MBoxStructure()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MBoxStructure::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBoxStructure::SetAllParameters(const std::vector<G4ThreeVector> &dxyz,
                                       const std::vector<G4double> &z,
                                       const std::vector<G4String> &mats){
  fDxyz = dxyz ;  
  fZ    = z; 
  fMatName=mats;
  SetEnvelopeSize(fDxyz[0]);
}

G4VPhysicalVolume* G4MBoxStructure::buildEnvelope(G4LogicalVolume *worldlog)
{
  if (fMatName.empty()) {
    G4Exception("G4MBoxStructure::buildEnvelope()","G4MBoxStruc00",
                FatalException,"vector fMatName is empty");
  }
  G4Material *mat = G4Material::GetMaterial(fMatName[0]);

  G4Box *sol =
      new G4Box(GetName(), GetDX(),GetDY(),GetDZ());
  G4LogicalVolume *log = new G4LogicalVolume(sol,mat,GetName());

  log->SetVisAttributes(new G4VisAttributes(G4Colour(.5,.5,1.)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(GetRotation(),
                                                   GetTranslation(),
                                                   log,
                                                   GetName(),
                                                   worldlog,
                                                   false,
                                                   0);
  return physical;
}

void G4MBoxStructure::buildNode(G4VPhysicalVolume* physvol)
{
  G4LogicalVolume *logMother = physvol->GetLogicalVolume();

  for (size_t i = 1; i < fDxyz.size(); ++i) {
    G4Material *mat = G4Material::GetMaterial(fMatName[i]);
    G4Box *solid =
        new G4Box(GetName(), fDxyz[i].x(), fDxyz[i].y(), fDxyz[i].z()); 
    G4LogicalVolume *lv = new G4LogicalVolume(solid,
                                              mat,
                                              GetName());
    new G4PVPlacement(0, G4ThreeVector(0, 0, fZ[i]), lv, 
                      GetName(), logMother,false, 0);
    logMother = lv;
  }
}
