//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Box type module
// 
// (HISTORY)
// 19 Dec. 2010 T.Aso
// 2015-07-26 T.Aso nz in fNxyzTowVec has been fixed to 1.
// 2015-07-26 T.Aso izT is always 1 in FileCatalogue.
//---------------------------------------------------------------------
//
#include "G4MBoxDetectorFileCatalogue.hh"
#include "G4MBoxDetector.hh"
#include <fstream>
#include <sstream>

G4MBoxDetectorFileCatalogue::G4MBoxDetectorFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVBoxDetectorCatalogue(name),fDefaultFileName(fileName){
}

G4MBoxDetectorFileCatalogue::~G4MBoxDetectorFileCatalogue()
{}

void G4MBoxDetectorFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  //fModule->SetAllParameters(fDxyzSect,fMatSect);
  fModule->SetSector(fDxyzSect,fMatSect);
  fModule->SetModule(fNxyzMod,fDxyzMod,fMatMod,fOffsetMod,fPitchMod);
  fModule->SetSubModule(fNxyzSubMod,fDxyzSubMod,fMatSubMod,fOffsetSubMod,fPitchSubMod);
  fModule->SetLayer(fNzLay,fDxyzLayVec,fMatLayVec,fZoffLayVec);
  fModule->SetTower(fNxyzTowVec,fDxyzTowVec,fMatTowVec,fOffsetTowVec,fPitchTowVec);

}

void G4MBoxDetectorFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  //G4cout << " ASO: FileCatalogue  " <<filename<< G4endl;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MBoxDetectorFileCatalogue::Prepare()",
                "G4MBoxDetFileCata00",FatalException,msg);
  }else{
    //
    G4double _x,_y,_z;
    //
    // Sector
    ifs.getline(chline,512);  // Comments for Sector
    //G4cout << " ASO: FileCatalogue  " <<chline<< G4endl;
    ifs.getline(chline,512);  // Sector size
    std::istringstream iss1(chline);
    iss1 >> _x >> _y >> _z;   // Full Size
    fDxyzSect.setX(_x*mm/2.);
    fDxyzSect.setY(_y*mm/2.);
    fDxyzSect.setZ(_z*mm/2.);
    //G4cout << " ASO: FileCatalogue fDxyzSect " <<fDxyzSect<< G4endl;
    //
    ifs.getline(chline,512);  //material
    std::istringstream iss2(chline);
    iss2 >> fMatSect;
    //G4cout << " ASO: FileCatalogue fMatSect " <<fMatSect<< G4endl;
    //
    // Module
    ifs.getline(chline,512);  // Comments for Module

    ifs.getline(chline,512);  // Number of Modules
    std::istringstream iss3(chline);
    iss3 >> fNxyzMod[0] >> fNxyzMod[1] >> fNxyzMod[2];   // Number of Modules
    
    ifs.getline(chline,512);  // Module size
    std::istringstream iss4(chline);
    iss4 >> _x >> _y >> _z;   // Full Size
    fDxyzMod.setX(_x*mm/2.);
    fDxyzMod.setY(_y*mm/2.);
    fDxyzMod.setZ(_z*mm/2.);
    //
    ifs.getline(chline,512);  //material
    std::istringstream iss5(chline);
    iss5 >> fMatMod;
    //
    ifs.getline(chline,512);  // Module offset
    std::istringstream iss6(chline);
    iss6 >> _x >> _y >> _z;   // 
    fOffsetMod.setX(_x*mm);
    fOffsetMod.setY(_y*mm);
    fOffsetMod.setZ(_z*mm);
    //
    ifs.getline(chline,512);  // Module Pitch
    std::istringstream iss7(chline);
    iss7 >> _x >> _y >> _z;   // 
    fPitchMod.setX(_x*mm);
    fPitchMod.setY(_y*mm);
    fPitchMod.setZ(_z*mm);

    //
    // SubModule
    ifs.getline(chline,512);  // Comments for SubModule

    ifs.getline(chline,512);  // Number of SubModules
    std::istringstream iss8(chline);
    iss8 >> fNxyzSubMod[0] >> fNxyzSubMod[1] >> fNxyzSubMod[2];   // Number of SubModules

    ifs.getline(chline,512);  // SubModule size
    std::istringstream iss9(chline);
    iss9 >> _x >> _y >> _z;   // Full Size
    fDxyzSubMod.setX(_x*mm/2.);
    fDxyzSubMod.setY(_y*mm/2.);
    fDxyzSubMod.setZ(_z*mm/2.);
    //
    ifs.getline(chline,512);  //material
    std::istringstream iss10(chline);
    iss10 >> fMatSubMod;
    //
    ifs.getline(chline,512);  // SubModule offset
    std::istringstream iss11(chline);
    iss11 >> _x >> _y >> _z;   // 
    fOffsetSubMod.setX(_x*mm);
    fOffsetSubMod.setY(_y*mm);
    fOffsetSubMod.setZ(_z*mm);
    //
    ifs.getline(chline,512);  // SubModule Pitch
    std::istringstream iss12(chline);
    iss12 >> _x >> _y >> _z;   // 
    fPitchSubMod.setX(_x*mm);
    fPitchSubMod.setY(_y*mm);
    fPitchSubMod.setZ(_z*mm);

    //
    // Layer
    ifs.getline(chline,512);  // Comments for Module
    //
    ifs.getline(chline,512);  // N of layers
    std::istringstream iss18(chline);
    iss18 >> fNzLay;
    //
    fDxyzLayVec.clear();
    fMatLayVec.clear();
    fZoffLayVec.clear();
    G4String mat;
    for ( G4int i = 0; i < fNzLay; i++){
      //
      ifs.getline(chline,512);  // Full size
      std::istringstream iss19(chline);
      iss19 >> _x >> _y >> _z;   // Full Size
      G4ThreeVector dxyz(_x*mm/2.,_y*mm/2.,_z*mm/2.);
      fDxyzLayVec.push_back(dxyz);
      //
      ifs.getline(chline,512);  // Material
      std::istringstream iss20(chline);
      iss20 >> mat;      
      fMatLayVec.push_back(mat);
      //
      ifs.getline(chline,512);  // Offset
      std::istringstream iss21(chline);
      iss21 >> _z;   // Z-Offset
      fZoffLayVec.push_back(_z*mm);
    }

    //
    // Tower
    fNxyzTowVec.clear();
    fDxyzTowVec.clear();
    fMatTowVec.clear();
    fOffsetTowVec.clear();
    fPitchTowVec.clear();
    G4int nx, ny, nz;
    for ( G4int i = 0; i < fNzLay; i++){
      ifs.getline(chline,512);  // Comments for Tower

      ifs.getline(chline,512);  // Number of Tower
      std::istringstream iss13(chline);
      //iss13 >> nx >> ny >> nz;   // Number of Towers
      iss13 >> nx >> ny ;   // Number of Towers
      nz = 1; // nz is fixed to 1, because the layer has already defined it.
      fNxyzTowVec.push_back(G4ThreeVector(nx,ny,nz));

      ifs.getline(chline,512);  // Tower size
      std::istringstream iss14(chline);
      iss14 >> _x >> _y >> _z;   // Full Size
      fDxyzTowVec.push_back(G4ThreeVector(_x*mm/2.,_y*mm/2.,_z*mm/2.));
      //
      ifs.getline(chline,512);  //material
      std::istringstream iss15(chline);
      iss15 >> mat;
      fMatTowVec.push_back(mat);
      //
      ifs.getline(chline,512);  // Tower offset
      std::istringstream iss16(chline);
      iss16 >> _x >> _y >> _z;   // 
      fOffsetTowVec.push_back(G4ThreeVector(_x*mm,_y*mm,_z*mm));
      //
      ifs.getline(chline,512);  // Tower Pitch
      std::istringstream iss17(chline);
      //iss17 >> _x >> _y >> _z;   // 
      iss17 >> _x >> _y ;   // Offset
      _z = 0.0; // offset z is fixed to 0.0, because the layer has already defined it.
      fPitchTowVec.push_back(G4ThreeVector(_x*mm,_y*mm,_z*mm));
    }
  }
  ifs.close();
}

void G4MBoxDetectorFileCatalogue::Apply(){
  //
  fModule->SetSector(fDxyzSect,fMatSect);
  fModule->SetModule(fNxyzMod,fDxyzMod,fMatMod,fOffsetMod,fPitchMod);
  fModule->SetSubModule(fNxyzSubMod,fDxyzSubMod,fMatSubMod,fOffsetSubMod,fPitchSubMod);
  fModule->SetLayer(fNzLay,fDxyzLayVec,fMatLayVec,fZoffLayVec);
  fModule->SetTower(fNxyzTowVec,fDxyzTowVec,fMatTowVec,fOffsetTowVec,fPitchTowVec);
  //
  fModule->ReBuild();
}







 
