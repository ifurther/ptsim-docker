//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  Created by T.Aso
//
// 2019-03-20 T.Aso Copied from G4MWaterPhantomMessenger
//
//---------------------------------------------------------------------
//
#include "G4MCylinderPhantomMessenger.hh"
#include "G4MCylinderPhantom.hh"
#include "G4Tokenizer.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"


G4MCylinderPhantomMessenger::
G4MCylinderPhantomMessenger(G4MCylinderPhantom* wp,
                            const G4String& name)
  :fWP(wp) {
  const G4String& myDir = "/G4M/Module/"+name+"/";
  fDir = new G4UIdirectory(myDir);
  fDir->SetGuidance("UI commands for modules");

  //
  // CylinderPhantom
  //
  const G4String CylinderPhantomSize = myDir+"size";
  fCmdCylinderPhantomSize = new G4UIcommand(CylinderPhantomSize,this);
  fCmdCylinderPhantomSize->SetGuidance("CylinderPhantomSize");
  fCmdCylinderPhantomSize->SetGuidance(" R PHI Z Runit PHIunit Zunit");
  fCmdCylinderPhantomSize->SetGuidance(" Default mm degree mm");
  G4UIparameter* param;
  param = new G4UIparameter("dr",'d',false);
  fCmdCylinderPhantomSize->SetParameter(param);
  param = new G4UIparameter("dp",'d',false);
  fCmdCylinderPhantomSize->SetParameter(param);
  param = new G4UIparameter("dz",'d',false);
  fCmdCylinderPhantomSize->SetParameter(param);
  param = new G4UIparameter("Runit",'s',true);
  param->SetDefaultValue("mm");
  fCmdCylinderPhantomSize->SetParameter(param);
  param = new G4UIparameter("PHIunit",'s',true);
  param->SetDefaultValue("degree");
  fCmdCylinderPhantomSize->SetParameter(param);
  param = new G4UIparameter("Zunit",'s',true);
  param->SetDefaultValue("mm");
  fCmdCylinderPhantomSize->SetParameter(param);
  fCmdCylinderPhantomSize->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String CylinderPhantomDim = myDir+"dim";
  fCmdCylinderPhantomDim = 
    new G4UIcmdWith3Vector(CylinderPhantomDim,this);
  fCmdCylinderPhantomDim->SetGuidance("CylinderPhantomDimension");
  fCmdCylinderPhantomDim->SetGuidance(" NR NPHI NZ");
  fCmdCylinderPhantomDim->SetParameterName("nr","nphi","nz",true,true);
  fCmdCylinderPhantomDim->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String CylinderPhantomSDSize = myDir+"sdsize";
  fCmdCylinderPhantomSDSize = new G4UIcommand(CylinderPhantomSDSize,this);
  fCmdCylinderPhantomDim->SetGuidance("CylinderPhantomSDSize");
  fCmdCylinderPhantomDim->SetGuidance("dR PHI dZ {R_unit} {PHI_unit} {Z_unit}");
  fCmdCylinderPhantomDim->SetGuidance("         mm        degree     mm");
  param = new G4UIparameter("dr",'d',false);
  fCmdCylinderPhantomSDSize->SetParameter(param);
  param = new G4UIparameter("dp",'d',false);
  fCmdCylinderPhantomSDSize->SetParameter(param);
  param = new G4UIparameter("dz",'d',false);
  fCmdCylinderPhantomSDSize->SetParameter(param);
  param = new G4UIparameter("Runit",'s',true);
  param->SetDefaultValue("mm");
  fCmdCylinderPhantomSDSize->SetParameter(param);
  param = new G4UIparameter("PHIunit",'s',true);
  param->SetDefaultValue("degree");
  fCmdCylinderPhantomSDSize->SetParameter(param);
  param = new G4UIparameter("Zunit",'s',true);
  param->SetDefaultValue("mm");
  fCmdCylinderPhantomSDSize->SetParameter(param);
  fCmdCylinderPhantomSDSize->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String CylinderPhantomSDOffset = myDir+"sdoffset";
  fCmdCylinderPhantomSDOffs =
    new G4UIcommand(CylinderPhantomSDOffset,this);
  fCmdCylinderPhantomSDOffs->SetGuidance("CylinderPhantom SD Offset");
  fCmdCylinderPhantomSDOffs->SetGuidance(" Roff PHIoff Zoff R_unit PHI_unit Z_unit");
  fCmdCylinderPhantomSDOffs->SetGuidance(" mm degree mm");
  param = new G4UIparameter("roff",'d',false);
  fCmdCylinderPhantomSDOffs->SetParameter(param);
  param = new G4UIparameter("poff",'d',false);
  fCmdCylinderPhantomSDOffs->SetParameter(param);
  param = new G4UIparameter("zoff",'d',false);
  fCmdCylinderPhantomSDOffs->SetParameter(param);
  param = new G4UIparameter("Runit",'s',true);
  param->SetDefaultValue("mm");
  fCmdCylinderPhantomSDOffs->SetParameter(param);
  param = new G4UIparameter("PHIunit",'s',true);
  param->SetDefaultValue("degree");
  fCmdCylinderPhantomSDOffs->SetParameter(param);
  param = new G4UIparameter("Zunit",'s',true);
  param->SetDefaultValue("mm");
  fCmdCylinderPhantomSDOffs->SetParameter(param);
  fCmdCylinderPhantomSDOffs->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String CylinderPhantomMaterial = myDir+"material";
  fCmdCylinderPhantomMaterial =
    new G4UIcmdWithAString(CylinderPhantomMaterial,this);
  fCmdCylinderPhantomMaterial->SetGuidance("CylinderPhantom Material");
  fCmdCylinderPhantomMaterial->SetParameterName("material",false);
  fCmdCylinderPhantomMaterial->AvailableForStates(G4State_Init,G4State_Idle);

  const G4String CylinderPhantomBEdep = myDir+"edep";
  fCmdCylinderPhantomBEdep =
    new G4UIcmdWithABool(CylinderPhantomBEdep,this);
  fCmdCylinderPhantomBEdep->SetGuidance("CylinderPhantom Edep flag");
  fCmdCylinderPhantomBEdep->SetParameterName("EdepFlag",false);
  fCmdCylinderPhantomBEdep->AvailableForStates(G4State_Init,G4State_Idle);

}

G4MCylinderPhantomMessenger::~G4MCylinderPhantomMessenger() {
  if (fCmdCylinderPhantomSize) delete fCmdCylinderPhantomSize;
  if (fCmdCylinderPhantomDim)   delete fCmdCylinderPhantomDim;
  if (fCmdCylinderPhantomSDSize ) delete fCmdCylinderPhantomSDSize;
  if (fCmdCylinderPhantomSDOffs ) delete fCmdCylinderPhantomSDOffs;
  if (fCmdCylinderPhantomMaterial ) delete fCmdCylinderPhantomMaterial;
  if (fCmdCylinderPhantomBEdep ) delete fCmdCylinderPhantomBEdep;
  if (fDir) delete fDir;
}

void G4MCylinderPhantomMessenger::SetNewValue(G4UIcommand* command, 
                                           G4String newValue) {
 if ( command == fCmdCylinderPhantomDim ){
    G4ThreeVector dim = fCmdCylinderPhantomDim->GetNew3VectorValue(newValue);
    G4int nr = (G4int)dim.x();
    G4int np = (G4int)dim.y();
    G4int nz = (G4int)dim.z();
    fWP->SetDimension(nr,np,nz);
 } else if ( command == fCmdCylinderPhantomSize ){
    G4Tokenizer next(newValue);
    G4double dr = StoD(next());
    G4double dp = StoD(next());
    G4double dz = StoD(next());
    G4double drUnit = G4UnitDefinition::GetValueOf(next());
    G4double dpUnit = G4UnitDefinition::GetValueOf(next());
    G4double dzUnit = G4UnitDefinition::GetValueOf(next());
    dr *= drUnit;
    dp *= dpUnit;
    dz *= dzUnit;
    fWP->SetSize(dr,dp,dz);
 } else if ( command == fCmdCylinderPhantomSDSize ){
    G4Tokenizer next(newValue);
    G4double dr = StoD(next());
    G4double dp = StoD(next());
    G4double dz = StoD(next());
    G4double drUnit = G4UnitDefinition::GetValueOf(next());
    G4double dpUnit = G4UnitDefinition::GetValueOf(next());
    G4double dzUnit = G4UnitDefinition::GetValueOf(next());
    dr *= drUnit;
    dp *= dpUnit;
    dz *= dzUnit;
   fWP->SetSDSize(dr,dp,dz);
 } else if ( command == fCmdCylinderPhantomSDOffs ){
    G4Tokenizer next(newValue);
    G4double r = StoD(next());
    G4double p = StoD(next());
    G4double z = StoD(next());
    G4double rUnit = G4UnitDefinition::GetValueOf(next());
    G4double pUnit = G4UnitDefinition::GetValueOf(next());
    G4double zUnit = G4UnitDefinition::GetValueOf(next());
    r *= rUnit;
    p *= pUnit;
    z *= zUnit;
    fWP->SetSDOffset(r,p,z);
 } else if ( command == fCmdCylinderPhantomMaterial ){
   fWP->SetMaterial(newValue);
 } else if ( command == fCmdCylinderPhantomBEdep ){
   fWP->SetBEdep(fCmdCylinderPhantomBEdep->GetNewBoolValue(newValue));
 }
}

G4String G4MCylinderPhantomMessenger::GetCurrentValue(G4UIcommand* command) {
  return G4String("I do not know,"+command->GetCommandName());
}
