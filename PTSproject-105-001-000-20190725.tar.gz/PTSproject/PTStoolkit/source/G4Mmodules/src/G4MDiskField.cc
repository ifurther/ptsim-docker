//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shape component with a B-field.
//
// (HISTORY)  
// 2019-07-19 T.Aso 
//
//
//---------------------------------------------------------------------
//
#include "G4MDiskField.hh"
#include "G4MDiskFieldMessenger.hh"
//
#include "G4MModuleField.hh"
//
#include "G4FieldManager.hh"
#include "G4AutoDelete.hh"

G4MDiskField::G4MDiskField(const G4String &name, G4double dr, G4double dz,
                           const G4String &mat)
  : G4MDisk(name,dr,dz,mat)
{
  fModuleField = new G4MModuleField();
  fMessenger = new G4MDiskFieldMessenger(this,name);
}

G4MDiskField::G4MDiskField(const G4String &name)
  : G4MDisk(name)
{
  fModuleField = new G4MModuleField();
  fMessenger = new G4MDiskFieldMessenger(this,name);
}

G4MDiskField::G4MDiskField(G4MVDiskCatalogue* catalogue)
  : G4MDisk(catalogue)
{
  fModuleField = new G4MModuleField();
  fMessenger = new G4MDiskFieldMessenger(this, GetName());
}

G4MDiskField::~G4MDiskField()
{
  if ( fModuleField )  delete fModuleField;
  if ( fMessenger )  delete fMessenger;
}

void G4MDiskField::buildNode(G4VPhysicalVolume* physvol){
  G4LogicalVolume* logicalFrame = physvol->GetLogicalVolume();
  //
  //* Attach B-Field to logical volume
  fFieldLVList.push_back(logicalFrame);
  //
}

void G4MDiskField::SetFieldValue(const G4ThreeVector& bval){
  fModuleField->SetFieldValue(bval);
  if ( fModuleFieldCache.Get() ){
    (fModuleFieldCache.Get())->SetFieldValue(bval);
  }
}

void G4MDiskField::BuildInSDandField(){
  //
  if ( !fModuleField ) return;
  //
  //
    if (!fModuleFieldCache.Get() ){
      G4MModuleField* field = fModuleField->Copy();
      fModuleFieldCache.Put(field);
      G4AutoDelete::Register(field);
    }
  //
    // Logical name
    for (G4int i = 0; i < (G4int)fFieldLVList.size(); i++){
       G4FieldManager* fieldManager = fFieldLVList[i]->GetFieldManager();
       if( fieldManager ){
          fieldManager->SetDetectorField(fModuleFieldCache.Get());
        }else{
          fieldManager = new G4FieldManager(fModuleFieldCache.Get());
        }
       fFieldLVList[i]->SetFieldManager(fieldManager,true);
    }
}

