//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MModularComposer
//
//  (HISTORY)
//  2014-11-23 Modify to avoid warings.
//
//---------------------------------------------------------------------
//
#include "G4MVModuleComposer.hh"

G4MVModuleComposer::G4MVModuleComposer(const G4String& name, 
                                       G4ThreeVector& translation, 
                                       G4RotationMatrix& rotation) 
  :G4MVBeamModule(name,translation,rotation){
}

G4MVModuleComposer::G4MVModuleComposer(const G4String& name)
  :G4MVBeamModule(name){
}

G4MVModuleComposer::G4MVModuleComposer(const G4String& name, 
                                       const G4ThreeVector& dxyz )
  :G4MVBeamModule(name,dxyz){
}

G4MVModuleComposer::~G4MVModuleComposer() {
  theCreateList.clear();
  theModules.clear();
}

void G4MVModuleComposer::AddModule(G4MVBeamModule* module){
  theModules.insert(
    std::map<G4String,G4MVBeamModule*>::value_type(module->GetName(),module)
    );
}

const std::map<G4String,G4MVBeamModule*>& 
G4MVModuleComposer::GetModules() const {
  return theModules;
}

void G4MVModuleComposer::AddToCreateList(const G4String& name){
  theCreateList.push_back(name);
}

void G4MVModuleComposer::SetCreateList(std::vector<G4String>& createlist){
  theCreateList.clear();
  theCreateList = createlist;
}

const std::vector<G4String>& G4MVModuleComposer::GetCreateList() const {
  return theCreateList;
}

void G4MVModuleComposer::Clear(){
  theCreateList.clear();
  theModules.clear();
}

void G4MVModuleComposer::CleanUpVolumes(){
  for (std::map<G4String,G4MVBeamModule*>::iterator itr = theModules.begin(); itr != theModules.end(); itr++) {
    G4MVBeamModule* module = itr->second;
    module->CleanUpVolumes();
  }
  G4MVBeamModule::CleanUpVolumes();
}

void G4MVModuleComposer::Dump(std::ostream& out){
  out << "===  Sub-modules === "<<G4endl;
  for (std::map<G4String,G4MVBeamModule*>::iterator itr = theModules.begin(); itr != theModules.end(); itr++) {
    for ( G4int i = 0; i < (G4int)theCreateList.size(); i++){
      if ( itr->first == theCreateList[i] ){
        out  << itr->first << " ON " << G4endl;
      }else{
        out  << itr->first << " OFF " << G4endl;
      }
    }
  }
}

void G4MVModuleComposer::buildNode(G4VPhysicalVolume* physVol){
  for ( G4int i = 0; i < (G4int)theCreateList.size(); i++){
    G4String name = theCreateList[i];
    std::map<G4String,G4MVBeamModule*>::iterator itr=theModules.find(name);
    if ( itr != theModules.end() ) {
      ((*itr).second)->BuildIn(physVol->GetLogicalVolume());
      G4cout << "G4MVModuleComposer: Creating "<<name<<" in "<<GetName()<<G4endl;
    } else {
      G4cout << "@@@@@ No Module in G4MVModuleComposer @@@"<<name<<G4endl;
      exit(-1);
    }
  }
}

