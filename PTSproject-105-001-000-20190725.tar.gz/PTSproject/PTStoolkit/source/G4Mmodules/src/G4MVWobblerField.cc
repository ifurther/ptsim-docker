//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MVWobblerField
//
//  (HISTORY)
//   2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#include "G4MVWobblerField.hh"

G4MVWobblerField::G4MVWobblerField(G4double amp, G4double angle)
:G4MMagField(),fAmplitude(amp),fAngle(angle){
}

G4MVWobblerField::G4MVWobblerField(const G4MVWobblerField& right)
  :G4MMagField(right){
  //
  fAmplitude = right.fAmplitude;
  fAngle = right.fAngle;
}

void G4MVWobblerField::SetAmplitude(G4double amp) {
  fAmplitude = amp;
  calcField();
}

G4double G4MVWobblerField::GetAmplitude() const{
  return fAmplitude;
}

void G4MVWobblerField::SetAngle(G4double ang) {
  fAngle = ang;
  calcField();
}

G4double G4MVWobblerField::GetAngle() const {
  return fAngle;
}
