//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Bolus Module
//  (HISTORY)
// 24 JUL. 2007 T.Aso Modify node names.
// 2012-06-06   T.Aso Add xdir and ydir.
// 2014-03-31   T.Aso Optimaization of Parameterisation was modified
//                    from fZAxis to fUndefined. Because of error when
//                    installing in parallel world.
//
// -----------------------------------------------------------------
//
#include "G4MBolus.hh"
#include "G4PVParameterised.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MBolus::G4MBolus(const G4String& name, const G4ThreeVector& dxyz, 
		   const G4String& mat,
		   G4int nx, G4int ny, 
		   G4double x0, G4double y0,
		   G4double pitchx, G4double pitchy, 
		   std::vector<G4double>& thickvector)
  :G4MVBeamModule(name,dxyz),
   fMatBolus(mat),fNx(nx),fNy(ny),
   fx0(x0),fy0(y0),xdir(1),ydir(1),
   fPitchX(pitchx),fPitchY(pitchy),theThickVector(thickvector),
   fParameterisation(NULL),fCatalogue(NULL)
{}

G4MBolus::G4MBolus(const G4String& name)
  :G4MVBeamModule(name),xdir(1),ydir(1),fParameterisation(NULL),fCatalogue(NULL)
{}

G4MBolus::G4MBolus(G4MVBolusCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),xdir(1),ydir(1),fParameterisation(NULL),
   fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MBolus::~G4MBolus() {
  theThickVector.clear();
  delete fParameterisation;
  if ( fCatalogue ) delete fCatalogue;
}

void G4MBolus::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBolus::SetAllParameters(const G4ThreeVector& dxyz,
				const G4String& mat,
				G4int nx, G4int ny, 
				G4double x0, G4double y0,
				G4double pitchx, G4double pitchy, 
				std::vector<G4double>& thickvector)
{
    SetEnvelopeSize(dxyz);
    fMatBolus=mat;
    fNx=nx;
    fNy=ny;
    fx0=x0;
    fy0=y0;
    fPitchX=pitchx;
    fPitchY=pitchy;
    theThickVector.assign(thickvector.begin(),thickvector.end());
}

void G4MBolus::Dump(std::ostream& out){
  out << fMatBolus <<G4endl;
  out << fNx << G4endl; 
  out << fNy << G4endl; 
    for(G4int iy = 0; iy < fNy; iy++){
      for(G4int ix = 0; ix < fNx; ix++){
	G4int index = iy*fNx+ix;
	out << theThickVector[index];
	if ( ix < fNx-1 ) out<<","; 
      }
      out << G4endl;
    }
}

void G4MBolus::SetNxy(G4int nx, G4int ny) {
  fNx = nx;
  fNy = ny;
}

void G4MBolus::GetNxy(G4int& nx, G4int& ny) {
  nx = fNx;
  ny = fNy;
}

void G4MBolus::SetXYOrigin(G4double x0, G4double y0) {
  fx0 = x0;
  fy0 = y0;
}

void G4MBolus::SetThickVector(std::vector<G4double>& thickVec) {
  theThickVector.assign(thickVec.begin(),thickVec.end());
}

void G4MBolus::SetPitch(G4double xpitch, G4double ypitch) {
  fPitchX = xpitch;
  fPitchY = ypitch;
}

void G4MBolus::GetPitch(G4double& xpitch, G4double& ypitch) {
  xpitch = fPitchX;
  ypitch = fPitchY;
}

void G4MBolus::Smearing() {
  //
  // Smearing Drill hole with drill size.
  //
  G4double xpitch = fPitchX;
  G4double ypitch = fPitchY;
  G4int iXSmear = (G4int)(fDrillPitch/xpitch/2.);
  G4int iYSmear = (G4int)(fDrillPitch/ypitch/2.);
  //
  //
   std::vector<G4double> tmpVec(theThickVector.begin(),theThickVector.end());
   G4int nx = fNx;
   G4int ny = fNy;
   G4ThreeVector& fDxyzBolus = fEnvelopeSize;
   G4double dZ = fDxyzBolus.z() * 2.;
   for ( G4int iy = 0; iy < ny; iy++){
     for ( G4int ix = 0; ix < nx; ix++){
       // Examimed center.
       G4int index = iy*nx+ix;
       G4double ThisHeight = tmpVec[index];
       if ( ThisHeight >= dZ ) continue;
       // Smearing region
       for ( G4int j = -iYSmear; j <=iYSmear; j++){
	 if (iy + j < 0 || iy + j >= ny) continue;  //!!!
	 for ( G4int i = -iXSmear; i <=iXSmear ; i++){
	   if (ix + i < 0 || ix + i >= nx) continue; //!!!
	   G4int jndex = ( iy+j )*nx+(ix+i);
	   if ( tmpVec[jndex] > tmpVec[index] ) {
	     if ( theThickVector[jndex] > tmpVec[index] ){
	       if ( fVerbose > 0 ) {
	       G4cout << " Bolus Smear "<< index <<" " << jndex
		      << " org "<<tmpVec[jndex]
		      << " from "<<theThickVector[jndex] 
		      << " to "  <<tmpVec[index] <<G4endl;
	       }
	       theThickVector[jndex] = tmpVec[index];
	     }
	   } // 
	 }   // loop 3x3 j (y)
       }     // loop 3x3 i (x)
     } // loop (ix) 
   }   // loop (iy)
   //G4cout << " iXSmear " << iXSmear << " iYSmear "<< iYSmear<<G4endl;
}

G4VPhysicalVolume* G4MBolus::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* mat = G4Material::GetMaterial(fMatBolus);
  G4VSolid* solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume* logical = new G4LogicalVolume(
				 solid,       // Solid 
                                 mat,         // Material
				 GetName());  // Name

  G4VPhysicalVolume* physical  = new G4PVPlacement(
  		      GetRotation(),
  		      GetTranslation(),
		      logical,   // Logical volume  
                      GetName(), // Name
		      worldlog,  // Mother  volume 
		      false,     // Not used 
		      0);        // Copy number  

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,0.3,0.3,0.8));
  logical->SetVisAttributes(visAttr);

  return physical;
}

void G4MBolus::buildNode(G4VPhysicalVolume* physvol) {
  //------ Drill Hole
  // dummy values for G4Box -- will be modified by parameterised volume. 
  const G4String drillName = GetName()+"Drill";
  G4VSolid* solDrill =  new G4Box(drillName,
				  fPitchX/2.,fPitchY/2.,GetDZ());
  G4Material* hole= G4Material::GetMaterial("Air");
  G4LogicalVolume* logDrill = new G4LogicalVolume(solDrill,hole,drillName);
  fParameterisation = 
    new G4MBolusParameterisation(fNx,fNy,fPitchX,fPitchY,GetDZ()*2,
				 fx0,fy0,hole,xdir,ydir);
  fParameterisation->CalculateActiveVolume(theThickVector);
  G4int nofvolume = fParameterisation->GetNofActiveVolume();
  
  if ( nofvolume > 0 ){
      //G4VPhysicalVolume *phys = 
      new G4PVParameterised(drillName,
			    logDrill,
			    physvol->GetLogicalVolume(),
			    //kZAxis,
			    kUndefined,
			    nofvolume,
			    fParameterisation);
  }

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,1.0,1.0));
  logDrill->SetVisAttributes(visAttr);
}

