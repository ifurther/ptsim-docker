//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MSpotScanModel
//
//  (HISTORY)
//  2018-09-09 T.Aso Created.
//
//---------------------------------------------------------------------
//
#include "G4MSpotScanModel.hh"
#include "G4MScanBeamManager.hh"
#include "G4SystemOfUnits.hh"
#include <fstream>

G4MSpotScanModel::G4MSpotScanModel(const G4String& name)
  :G4MVScanModel(name) {
}

G4MSpotScanModel::~G4MSpotScanModel(){
  fEIDVec.clear();  // EnergyID
  fXVec.clear();       // X
  fYVec.clear();       // Y
  fDoseVec.clear();  // Dose
  fProbVec.clear();  // Probability
}

void G4MSpotScanModel::ReadScanFile(G4String& filename){
  // Open file
  std::ifstream ifs;
  ifs.open(filename.c_str());
  //
  if(!ifs) { 
    const G4String& msg =  "Scan File Not Found " + filename;
    G4Exception("G4MSpotScanModel::ReadScanFile()","G4MSpotScanModel00",
                FatalException,msg);
  }else{
    // Clear Vectors.
    Clear();
    // Read parameters  ( Assume space separated file. )
    G4int n;
    ifs >> n;
    //
    G4int   id;
    G4double x, y, d;
    //
    for ( G4int i = 0; i < n; i++){
      ifs >> id >> x >> y >> d;  
      x *= mm;
      y *= mm;
      d *= gray;
      fEIDVec.push_back(id); 
      fXVec.push_back(x);
      fYVec.push_back(y);
      fDoseVec.push_back(d);
    }
  }    
  ifs.close();
  //
}

void G4MSpotScanModel::CalculateProbability(){
  G4double total = 0;
  fProbVec.clear();
  for ( size_t i = 0; i < fDoseVec.size();  i++){
    //G4double energy = fEIDEneVec[fEIDVec[i]];
    G4double energy = fpSBMgr->GetEIDEnergy(fEIDVec[i]);
    // Gy to Number of particle 
    //G4double WNpar = fDoseVec[i]/GetWeight(energy);
    G4double WNpar = fDoseVec[i]/fpSBMgr->GetWeight(energy);
    if ( fVerbose > 2 ){
      G4cout << " ene "<<energy/MeV<<" dose "<<fDoseVec[i]/gray
             << " w "<< fpSBMgr->GetWeight(energy)/gray<<G4endl;
      G4cout << " WNpar "<<WNpar<<G4endl;
    }
    total += WNpar;
    fProbVec.push_back(total);
  }
  //
  // Normalize to 1.
  for ( size_t i = 0; i < fProbVec.size();  i++){
    fProbVec[i] /= total;
  }
}

const G4TwoVector& G4MSpotScanModel::GetCoord(G4int index){
 fSpotCoord.set(fXVec[index], fYVec[index]);
 return fSpotCoord;
}

void G4MSpotScanModel::Clear(){
  fEIDVec.clear();
  fXVec.clear();
  fYVec.clear();
  fDoseVec.clear(); 
  fProbVec.clear();
}





