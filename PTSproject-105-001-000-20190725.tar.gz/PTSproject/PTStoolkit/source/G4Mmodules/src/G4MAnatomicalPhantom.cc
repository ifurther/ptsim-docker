//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MAnatmicalPhantom
//
// (HISTORY)
//   Created   T.Aso
//                    
// -----------------------------------------------------------------
//                    
#include "G4MAnatomicalPhantom.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4EllipticalTube.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

G4MAnatomicalPhantom::G4MAnatomicalPhantom(G4MVAnatomicalPhantomCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MAnatomicalPhantom::G4MAnatomicalPhantom(const G4String &name)
  : G4MVBeamModule(name)
{
  // clear vector for node(component)
  nVec.clear();
}


G4MAnatomicalPhantom::~G4MAnatomicalPhantom()
{}

void G4MAnatomicalPhantom::SetEnvelopeParameter(G4String mat, G4double xr, G4double yr, G4double halfZ, G4String ESName)
{
  //Set Parameters for Envelope
  MatName = mat;
  drx = xr;
  dry = yr;
  dz = halfZ;
  EShapeName = ESName;

  G4ThreeVector v(drx,dry,dz);
  SetEnvelopeSize(v);  

  //Clear vector for nodes(components)
  nVec.clear();
}

G4VPhysicalVolume* G4MAnatomicalPhantom::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(MatName);
  G4LogicalVolume *lv;

  if(!EShapeName.compare("BOX")){
    G4Box *solid = new G4Box(GetName(), drx, dry, dz);
    lv = new G4LogicalVolume(solid, mat, GetName());
  }
  else{
    G4EllipticalTube *solid = new G4EllipticalTube(GetName(), drx, dry, dz);
    lv = new G4LogicalVolume(solid, mat, GetName());
  }

  G4VPhysicalVolume* physical = 
    new G4PVPlacement(GetRotation(),
                    GetTranslation(),
                    lv,
                    GetName(),
                    worldlog,
                    false,
                    0);

  G4VisAttributes* visAtt = new G4VisAttributes(G4Colour(0.0,1.0,1.,0.5));
  visAtt->SetVisibility(true);
  lv->SetVisAttributes(visAtt);

  return physical;
}

void G4MAnatomicalPhantom::buildNode(G4VPhysicalVolume *physvol)
{
  G4LogicalVolume*  logical = physvol->GetLogicalVolume();
  
  G4double NofNode = nVec.size();
  for(G4int i=0; i<NofNode; i++){
    if(nVec.at(i).Exist){
      G4double nodeX = nVec.at(i).posRadius
                       * std::cos(nVec.at(i).posAngle);
      G4double nodeY = nVec.at(i).posRadius
                       * std::sin(nVec.at(i).posAngle);
      G4double nodeZ = 0.0;

      G4VSolid* solid = new G4Tubs("Comp", 0., nVec.at(i).nodeRadius, dz, 0., twopi);
      G4Material* mat = G4Material::GetMaterial(nVec.at(i).Material);
      G4LogicalVolume* nLogical = new G4LogicalVolume(solid, mat, nVec.at(i).Material);
      new G4PVPlacement(0, G4ThreeVector(nodeX, nodeY, nodeZ),
                        nLogical, nVec.at(i).Material,
                        logical, false, 0);
    }
  }
}

