//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shape component
//
// (HISTORY)  
// 2012-06-06 T.Aso support Dump() method.
// 2013-01-15 T.Aso support Dump(std::ostream&) method.
//
//
//---------------------------------------------------------------------
//
#include "G4MDisk.hh"
#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MDisk::G4MDisk(const G4String &name, G4double dr, G4double dz,
                 const G4String &mat)
  : G4MVBeamModule(name,G4ThreeVector(0.,dr,dz)),
    fMatName(mat),fCatalogue(NULL)
{}

G4MDisk::G4MDisk(const G4String &name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MDisk::G4MDisk(G4MVDiskCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MDisk::~G4MDisk()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MDisk::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MDisk::SetAllParameters(G4double dr, G4double dz,const G4String &mat){
  SetEnvelopeSize(0.0,dr,dz);
  fMatName=mat;
}

G4VPhysicalVolume* G4MDisk::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(fMatName);
  if ( !mat )  {
      G4String mess = "material " + fMatName +" is NULL ";
      G4Exception("G4MDisk::buildEnvelope","G4MDisk00",
                  FatalException,mess);
  }
  G4double dr = GetDR();
  G4double dz = GetDZ();
  G4Tubs *solid = new G4Tubs(GetName(), 0, dr, dz, 0, twopi);

  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());

  lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));

  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                   lv,
                                                   GetName(),
                                                   worldlog,
                                                   false,
                                                   0);

  return physical;
}

void G4MDisk::buildNode(G4VPhysicalVolume *)
{}

void G4MDisk::Dump(std::ostream& out){
  out << fMatName<<G4endl;
  out << GetDR()/mm<<G4endl;
  out << GetDZ()/mm<<G4endl;
}
