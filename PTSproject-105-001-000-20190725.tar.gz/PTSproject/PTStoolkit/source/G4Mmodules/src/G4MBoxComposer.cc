//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// Class Description
//  G4MBox
// 
// (HISTORY)
// 2014-10-31 T.Aso Support FileCatalogue.   
//
//---------------------------------------------------------------------
//
#include "G4MBoxComposer.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MBoxComposer::G4MBoxComposer(const G4String& name, const G4String& mat,
                               const G4ThreeVector& dxyz)
  :G4MVModuleComposer(name,dxyz),fMat(mat),fCatalogue(NULL){
}

G4MBoxComposer::G4MBoxComposer(const G4String& name)
  :G4MVModuleComposer(name),fCatalogue(NULL){
}

G4MBoxComposer::G4MBoxComposer(G4MVBoxComposerCatalogue* catalogue)
  : G4MVModuleComposer(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MBoxComposer::~G4MBoxComposer() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MBoxComposer::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBoxComposer::Dump(std::ostream& out){
  out << "# Envelope Size (mm)" <<G4endl;
  out << GetDX()/mm <<","<<GetDY()/mm<<","<<GetDZ()/mm << G4endl;
  out << "# Envelope Material" <<G4endl;
  out << fMat<<G4endl;
  G4MVModuleComposer::Dump(out);
}

void G4MBoxComposer::SetAllParameters(const G4String& mat,
                                      const G4ThreeVector& dxyz){
  fMat = mat;
  SetEnvelopeSize(dxyz);
}

G4VPhysicalVolume* G4MBoxComposer::buildEnvelope(G4LogicalVolume* worldlog){
  G4Material* mat = G4Material::GetMaterial(fMat);

  G4VSolid* solid = new G4Box(GetName(), GetDX(),GetDY(),GetDZ());

  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,            // Solid 
                                 mat,              // Material
                                 GetName()         // Name
                                 );

  logical->SetVisAttributes(new G4VisAttributes(G4Colour(.3,1.,.3)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),                                  
                   GetTranslation(),                               
                   logical,           // Logical volume  
                   GetName(),         // Name
                   worldlog,          // Mother  volume 
                   false,             // Not used 
                   0);                // Copy number  
  return physical;
}




