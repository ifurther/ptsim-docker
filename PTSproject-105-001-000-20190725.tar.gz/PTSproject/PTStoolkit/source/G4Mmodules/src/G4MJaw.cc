//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Jaw shape component
//
// (HISTORY)  
//  2015-12-14 T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MJaw.hh"
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MJaw::G4MJaw(const G4String& name, 
               const G4ThreeVector& dxyz, const G4String& blkmat,
               G4double sdist, G4double aperture, G4double zpos,
               G4int dir)
  : G4MVBeamModule(name), fCatalogue(NULL){
  fDxyzBlock = dxyz;
  fBlkMat = blkmat;
  fSourceDist = sdist;
  fAperture = aperture;
  fZpos = zpos;
  fDir  = dir;
  //
  // Calculations
  // Tilt angle.
  fTheta  = std::fabs(atan(fAperture/fSourceDist));
  // Poition 
  //G4double z, dx, dy, dz, theta;
  G4double z, dx, dy, theta;
  z  = fZpos;
  dx = fDxyzBlock.x();
  dy = fDxyzBlock.y();
  //dz = fDxyzBlock.z();
  theta = fTheta;
  //
  G4double sign;
  if ( fDir > 0 ) sign = 1.0;
  else            sign = -1.0;
  //
  if ( std::abs(fDir) == 1 ) { // For JawX
    fBlkPos.set(sign*(z*std::sin(theta)+dx*std::cos(theta)),0.,
                z*std::cos(theta)-dx*std::sin(theta));
  } else if ( std::abs(fDir) == 2 ) { // For JawY
    fBlkPos.set(0, sign*(z*std::sin(theta)+dy*std::cos(theta)),
                z*std::cos(theta)-dy*std::sin(theta));
  }
  //
  SetEnvelopeSize(fDxyzBlock);
  //
}

G4MJaw::G4MJaw(const G4String& name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MJaw::G4MJaw(G4MVJawCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MJaw::~G4MJaw()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MJaw::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}


void G4MJaw::SetAllParameters(const G4ThreeVector& dxyz, const G4String& blkmat,
                              G4double sdist, G4double aperture, G4double zpos,
                              G4int dir){
  fDxyzBlock = dxyz;
  fBlkMat = blkmat;
  fSourceDist = sdist;
  fAperture = aperture;
  fZpos = zpos;
  fDir  = dir;
  //
  // Calculations
  // Tilt angle.
  fTheta  = std::fabs(atan(fAperture/fSourceDist));
  // Poition 
  //G4double z, dx, dy, dz, theta;
  G4double z, dx, dy, theta;
  z = fZpos;
  dx = fDxyzBlock.x();
  dy = fDxyzBlock.y();
  //dz = fDxyzBlock.z();
  theta = fTheta;
  //
  G4double sign;
  if ( fDir > 0 ) sign = 1.0;
  else            sign = -1.0;
  //
  if ( std::abs(fDir) == 1 ) { // For JawX
    fBlkPos.set(sign*(z*std::sin(theta)+dx*std::cos(theta)),0.,
                z*std::cos(theta)-dx*std::sin(theta));
  } else if ( std::abs(fDir) == 2 ) { // For JawY
    fBlkPos.set(0, sign*(z*std::sin(theta)+dy*std::cos(theta)),
                z*std::cos(theta)-dy*std::sin(theta));
  }
  //
  SetEnvelopeSize(fDxyzBlock);
  //
}

G4VPhysicalVolume* G4MJaw::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(fBlkMat);

  G4Box *solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());
  lv->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.3,0.3)));

  //G4VPhysicalVolume* physical = new G4PVPlacement(t3d,
  //G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
  //                                                GetTranslation(),
  // The Position and Rotation are automatically calculated
  // from the source-iso distance and the aperture.
  //
  G4RotationMatrix* rot = GetRotation();
  if       ( fDir == -1 ) rot->rotateY(-fTheta); // Jaw +X;
  else if  ( fDir == +1 ) rot->rotateY(fTheta);  // Jaw -X;
  else if  ( fDir == -2 ) rot->rotateX(fTheta); // Jaw +Y;
  else if  ( fDir == +2 ) rot->rotateX(-fTheta);  // Jaw -Y;
  SetTranslation(fBlkPos);
  //
  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                  lv,
                                                  GetName(),
                                                  worldlog,
                                                  false,
                                                  0);

  return physical;
}

void G4MJaw::buildNode(G4VPhysicalVolume* ){
}
