//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    DICOM Module
//
// (HISTORY)
// 15 Feb, 2007 T.Aso  Created as a super class of G4MDICOM.
//                     Common part are moved from previous G4MDICOM.
//                     Introduce Messenger for handling parameters,
//                     these commands are previously maintained in 
//                     G4MParticleTherapyMessenger.
// 08 Jun, 2007 T.Aso  Placement of Envelope was modified accoring
//                     to A.Kimura's suggestion.
//                     Gantry rotation was introduced.
// 25 Jul, 2007 T.Aso  The envelope size was taken from
//                     G4MDICOMData::GetZ() rather than ZSliceLocation().
//                     GetZ() includes Zoffset of CT image which was
//                     introduced for NCC requirements.
// 16 Dec, 2008 T.Aso  The functions for setting a offset of CT image
//                     are removed.
// 16 Dec, 2008 T.Aso  DICOM transformations are modified by the
//                     contrinutions of S.Kemeoka (NCC).
// 18 Mar, 2009 T.Aso  Introduce fDensResol that is for density 
//                     resolution for creating materials.
// 24 Mar, 2009 T.Aso  Exception for ensuring G4BOX for the envelope.
// 09 Sep, 2009 T.Aso  Introduce PrepareDICOM() method.
// 12 Oct, 2009 T.Aso  Modify the destructor to check DICOMManger.
// 08 Sep, 2010 T.Aso  Add window trim in Z.
// 2012-06-06   T.Aso  Add Dump().
// 2012-07-02   T.Aso  Bugfix at Dump(). The xo,yo,zo were corrected.
// 2013-03-26   T.Aso  G4MDICOMRTS was moved from G4MNestedROIDICOM.
//                     G4MDICOMROIReplacer was introduced.
// 2013-08-19   T.Aso  Modify the dicom unit vectors according to Y.Maeda's
//                     suggestion. 
//                      - Introduce unit vector of dicom volume for grid.dat.
// 2013-11-01   T.Aso  Add English version of Dump() messages.
// 2013-11-25   T.Aso  Data orientation.
// 2014-01-31   T.Aso  fComplement, fLabel boolean.
// 2014-02-07   T.Aso  Get methods for gantry, couch angles.
//                     UpdatePlacement() method.
// 2014-03-04   T.Aso  Bugfix for exchanging the order of column and row in
//                     Dump().
// 2014-03-10   T.Aso  Displacement is the same as ImagePatientPosition.
//                     ImageOrientation vector is managed in DICOMData.
// 2014-03-11   T.Aso  fVis for voxel visualization.
// 2014-03-25   T.Aso  fVis for default true.
// 2014-03-27   T.Aso  Methods for material list.
// 2014-08-20   T.Aso  Update local DataOrientation from DICOM CT data
//                     in buildEnvelope. (In case for w/o ModifyEnvelope)
// 2014-09-04   T.Aso  Apply the unit vector to ctoffset 
//                     in ComputeTransform3D. Bugfix by the suggestion
//                     from Yamashita san.
// 2014-09-04   T.Aso  GetCToffset(). ( Yamashita san's suggestion ).
// 2014-10-11   T.Aso  Add DumpForDCM().
// 2014-10-31   T.Aso  Supporting valid window in Z.
//                     Dump for DICOM RT.
// 2014-12-31   T.Aso  Supporting valid window in Z.
// 2015-07-22   T.Aso  Supporting RTS ROI with remesh.
// 2016-12-21   T.Aso  fLabelVec and GetLabelVec() for debugging.
// 2017-02-20   T.Aso  Cleanup debug output.
//                     Set tranlation and rotation in G4VBeamModule.
// 2017-03--15 T.Aso Threading
// 2018-04--22 T.Aso Air is taken from G4MVBeamModule.
// 2019-04-03 T.Aso Add fTtype=1000 to represent this module. 
// -----------------------------------------------------------------
// 

// 
#include "G4MVDICOM.hh"
#include "G4RunManager.hh"

#include "G4MDICOMHandler.hh"
#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"

#include "G4MDICOMRTS.hh"

#include "G4MDICOMRemesh.hh"
#include "G4MDICOMRemesh2D.hh"
#include "G4MDICOMComplement.hh"
#include "G4MDICOMMask.hh"
#include "G4MDICOMROIReplacer.hh"
#include "G4MDICOMLabel.hh"
#include "G4MDICOMCT2Density.hh"
#include "G4MDICOMCT2Material.hh"

#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Element.hh"
#include "G4Transform3D.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4Element.hh"
#include "G4SDManager.hh"

#include "G4MVDicomParameterisation.hh"

#include "G4MDICOMSD.hh"
#include "G4ProductionCuts.hh"
#include "G4RegionStore.hh"

#include <cmath>

G4MVDICOM::G4MVDICOM(G4String name) 
  :G4MVBeamModule(name),fDICOMFileName("DICOM.dat"),
   fComplement(true),
   fRemeshSize(5.),fRemeshBin(1),
   fXmin(-DBL_MAX),fXmax(+DBL_MAX),fYmin(-DBL_MAX),fYmax(+DBL_MAX),
   fZmin(-DBL_MAX),fZmax(+DBL_MAX),fTrim(false),fLabel(true),
   fValueMin(-DBL_MAX),fValueMax(DBL_MAX),
   fAirCTValue(-1000.),
   fCTCutOff(-500), fFileCT2Density("CT2Density.dat"),fParamType("H_2O"),
   fCTSample(1),fDensResol(0),
   fIsocenter(G4ThreeVector()),fCouchAngle(0.0),fGantry(0.0),
   fUnitVecX(1),fUnitVecY(1),fUnitVecZ(1), ////Added by y.maeda(2013/08/13)  
   fDataOrientation("NONE"),
   fProdCuts(NULL),fmatList(NULL),fEnvMat(NULL),fDicomRTS(NULL),
   fRoiCTReplacerFile(""),fCatalogue(NULL)
{
  fType = 1000; // DICOM Type
  fLabelVec.clear();
  fMessenger = new G4MDICOMMessenger(this);
  fVis = true;
}

G4MVDICOM::G4MVDICOM(G4MVDICOMCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fmatList(NULL),fEnvMat(NULL),
    fDicomRTS(NULL),fRoiCTReplacerFile(""),fCatalogue(catalogue),fEnvelopePhys(0)
{
  fType = 1000; // DICOM Type
  fVis = true;
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MVDICOM::~G4MVDICOM() {
  if ( fmatList ) {
    delete fmatList;
    if ( fVerbose > 0 ) G4cout <<"---- fmatList -----" << G4endl;
  }
  if ( fCatalogue ) {
    delete fCatalogue;
    if ( fVerbose > 0 ) G4cout <<"---- fCatalogue -----" <<G4endl;
  }
  if ( fMessenger ) {
    delete fMessenger;
    if ( fVerbose > 0 )G4cout <<"---- fMessenger -----" <<G4endl;
  }
  if ( fDicomRTS ) {
    delete fDicomRTS;
    if ( fVerbose > 0 ) G4cout <<"---- RTS -----" <<G4endl;
  }
  //
  fLabelVec.clear();
  //
  if ( G4MDICOMManager::IsExist() ){
    G4MDICOMManager* mgr=G4MDICOMManager::GetPointer();
    if ( fVerbose > 0 ) G4cout <<"---- Manager delete -----" <<G4endl;
    if ( mgr ) delete mgr;
  }
}

void G4MVDICOM::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MVDICOM::SetAllParameters(const G4String& dicomfile, 
                                G4double remesh, G4double airCT,
                                G4double ctcut, const G4String& ct2densfile,
                                G4double gantry = 0.0,
                                const G4String& paramtype="H_2O", 
                                 G4int ctsample=1){
  fDICOMFileName = dicomfile;
  fRemeshSize    = remesh;
  fAirCTValue    = airCT;
  fCTCutOff      = ctcut;
  fFileCT2Density= ct2densfile;
  fGantry        = gantry;
  fParamType     = paramtype;
  fCTSample      = ctsample;
  fXmin          =-DBL_MAX;
  fXmax          =+DBL_MAX;
  fYmin          =-DBL_MAX;
  fYmax          =+DBL_MAX;
  fZmin          =-DBL_MAX;
  fZmax          =+DBL_MAX;
  fTrim          = false;
  fValueMin      =-DBL_MAX;
  fValueMax      =+DBL_MAX;
}

G4MDICOMData* G4MVDICOM::PrepareDICOM(G4bool override){
  return PrepareDICOM(fLabelVec,override);
}

G4MDICOMData* G4MVDICOM::PrepareDICOM(std::vector<short>& mask,
                                      G4bool override){

  //-- Open DICOM Handler---------------------------------------
  G4MDICOMConfiguration* config=
    G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  G4MDICOMData* dicomData = config->GetDICOMData();
  //--------------------------------------------------------------

  // DICOM FILTERING--------------------------------
  // complement lacked slices
  if ( fComplement ){
    G4MDICOMComplement  filterComplement;
    config->DoFiltering(filterComplement);
    ModifyEnvelope(dicomData);
    if ( fVerbose > 0 ) dicomData->ShowParameters();
  }

  // CT replacer by ROI data.
  if ( fDicomRTS ){
    // Previously, we used SliceLocation for z-position.
    // Now we use ImagePositionPatient for z-position from
    // the request of FPHPTC. Therefore we do not need to
    // correct the z-position anymore.
    //fDicomRTS->CheckAndSetZCoordBase(config);
    fDicomRTS->ConvertROItoDICOMData(dicomData);
    fDicomRTS->ComplementROISlice(dicomData);
  }
  if ( fDicomRTS && fRoiCTReplacerFile != "" ){
    G4MDICOMROIReplacer  filterRoiCTRepl(fDicomRTS, fRoiCTReplacerFile);
    config->DoFiltering(filterRoiCTRepl);
  }

  // Valid Window
  G4MDICOMMask filterMask(fXmin,fYmin,fXmax,fYmax,fAirCTValue);
  filterMask.SetValidWindowZ(fZmin,fZmax);
  filterMask.SetValueWindow(fValueMin, fValueMax);
  config->DoFiltering(filterMask);

  // Remesing(3D)
  if ( fRemeshSize > dicomData->GetXPixelSPC() && 
       fRemeshSize > dicomData->GetYPixelSPC() ){
       G4MDICOMRemesh filterMesh(fRemeshSize,fAirCTValue);
       config->DoFiltering(filterMesh); 
       ModifyEnvelope(dicomData);
       if ( fVerbose > 0  ) dicomData->ShowParameters();
       // (20150820)
       if ( fDicomRTS ) fDicomRTS->RemeshROIData(dicomData);
  }

  // Remesing (2D)
  if ( fRemeshBin > 1 ){ 
       G4MDICOMRemesh2D filterMesh2D(fRemeshBin,fRemeshBin,fAirCTValue);
       config->DoFiltering(filterMesh2D); 
       ModifyEnvelope(dicomData);
       if ( fVerbose > 0 ) dicomData->ShowParameters();
       // (20150820)
       if ( fDicomRTS ) fDicomRTS->RemeshROIData(dicomData);
  }

  // Triming
  if (fTrim){
       dicomData->Trim(fXmin,fXmax,fYmin,fYmax,fZmin,fZmax);
       ModifyEnvelope(dicomData);
       if ( fVerbose > 0 ) dicomData->ShowParameters();
       if ( fDicomRTS ) fDicomRTS->RemeshROIData(dicomData);
  }

  // Cut-off
  if ( fLabel ) {
    G4MDICOMLabel label(fCTCutOff,override,fAirCTValue);
    config->DoFiltering(label);
    mask = label.GetLabels();
  } else {
    G4int zslice   = dicomData->GetSlice();
    G4int rows     = dicomData->GetRow();
    G4int columns  = dicomData->GetColumn();
    mask.clear();
    mask.resize( zslice*rows*columns,0 );
  }

  return dicomData;
}

G4MDICOMCT2Material* G4MVDICOM::PrepareMatList(){
  //G4Material* air = G4Material::GetMaterial("G4_AIR");
  G4Material* air = G4Material::GetMaterial(fMatAir);
  if ( fParamType == "H_2O" ) {
    fmatList = new G4MDICOMCT2Material(fFileCT2Density);
  }else{
    fmatList = new G4MDICOMCT2Material(fFileCT2Density,fParamType);
  }
  fmatList->SetDensityResol(fDensResol);  // Add 17-MAR-2009.
  fmatList->SetCTWindow(fValueMin, air, fValueMax);
  fmatList->CreateMaterial();

  return fmatList;
}

const G4Transform3D 
G4MVDICOM::ComputeTransform3D(const G4ThreeVector& ctoffset){
  //
  // Position of envelope which is calculated
  // to place specified point in DICOM frame
  // with isocenter. 
  // This is accually a translation of Couch coordinate.
  //
  G4ThreeVector ICtmp;
  G4ThreeVector CToffsettmp;
  if (fDataOrientation.contains("NONE") != 0 ){
    // Fukui has own conversion in setup. ( This part will be removed soon. )
    ICtmp.set(fIsocenter.x(),fIsocenter.y(),fIsocenter.z());
    CToffsettmp.set(ctoffset.x(),ctoffset.y(),ctoffset.z());
    //
  } else {
    //
    ICtmp.set(fUnitVecX*fIsocenter.x(),
              fUnitVecY*fIsocenter.y(),
              fUnitVecZ*fIsocenter.z());
    CToffsettmp.set(fUnitVecX*ctoffset.x(),
                    fUnitVecY*ctoffset.y(),
                    fUnitVecZ*ctoffset.z());
  }
  //
  //G4ThreeVector ICoffset = fIsocenter - ctoffset;
  //G4ThreeVector ICoffset = ICtmp - ctoffset;
  G4ThreeVector ICoffset = ICtmp - CToffsettmp;
  G4RotationMatrix rot0;
  G4Transform3D transfIC(rot0,-1.*ICoffset);
  G4cout << " G4MVDICOM:: isocenter offset = ( "
         << ICoffset.x()/mm << ","
         << ICoffset.y()/mm << ","
         << ICoffset.z()/mm << ") mm " << G4endl;
  if ( fVerbose > 0 ) {
    G4cout << "======= G4MVDICOM::ComputeTransform3D ========="<<G4endl;
    G4cout << " DataOrientation : "<< fDataOrientation << G4endl;
    G4cout << " UnitVec :" << fUnitVecX<<","<<fUnitVecY<<","<<fUnitVecZ<<G4endl;
    G4cout << " isocenter :" << fIsocenter.x()<<","<<fIsocenter.y()<<","<<fIsocenter.z()<<G4endl;
    G4cout << " ctoffset :" << ctoffset.x()<<","<< ctoffset.y()<<","<<ctoffset.z()<<G4endl;
  }
  //
  //  Rotating DICOM data for translating DICOM frame
  //  to Patient frame.
  //
  G4RotationMatrix rotDicom2Patient;
  rotDicom2Patient.rotateX(-90.*deg);
  G4Transform3D transfDicom2Patient(rotDicom2Patient, G4ThreeVector());
  //
  //  Rotating Couch around isocenter.
  //
  // T.Aso 2013.11.22
  G4double CouchAngleTmp = fCouchAngle;
  if(fDataOrientation.contains("NONE") != 0 ){
    // Fukui has own conversion in setup.
  }else if(fDataOrientation.contains("FFS") != 0 || 
           fDataOrientation.contains("FFP") != 0 ) {
    CouchAngleTmp += 180.*deg;
  };
  G4RotationMatrix rotCouch;
  //rotCouch.rotateZ(fCouchAngle); //Aso 2013.11.22
  rotCouch.rotateZ(CouchAngleTmp);
  G4Transform3D transfCouch(rotCouch, G4ThreeVector());
  //
  // Gantry angle
  //
  G4RotationMatrix rotGantry;
  rotGantry.rotateY(-1.*fGantry);
  G4Transform3D transfGantry(rotGantry,G4ThreeVector());

  //
  // Combine all transformations.
  //
  G4Transform3D transf = transfGantry*transfCouch*transfDicom2Patient
      *transfIC;

  return transf;
}

void G4MVDICOM::ModifyEnvelope(G4MDICOMData* dicom){
  if (!fEnvelopePhys) 
    G4Exception("G4MVDICOM::ModifyEnvelope()","G4MVDICOM00",
                JustWarning,"No physVol for Envelope");
  G4VSolid* solid = fEnvelopePhys->GetLogicalVolume()->GetSolid();
  if( solid->GetEntityType() != "G4Box" ){
    const G4String& msg ="G4MVDICOM: - Solid type is not supported.";
    G4Exception("G4MVDICOM::ModifyEnvelope()","G4MVDICOM00",
                JustWarning,msg);
  }
  G4Box* box = (G4Box*)(solid);
  G4ThreeVector dxyz = dicom->GetDxyz() *mm;
  box->SetXHalfLength(dxyz.x());
  box->SetYHalfLength(dxyz.y());
  box->SetZHalfLength(dxyz.z());
  fEnvelopeSize.set(dxyz.x(),dxyz.y(),dxyz.z());
  //
  // 2014-03-06 T.Aso
  fDataOrientation = dicom->GetPatPosType();
  fUnitVecX = (G4int)dicom->GetXorient();
  fUnitVecY = (G4int)dicom->GetYorient();
  fUnitVecZ = 1;
  
  const G4ThreeVector ctoffset = dicom->GetCToffset() *mm;
  const G4Transform3D tran3d = ComputeTransform3D(ctoffset);

  const G4RotationMatrix& rot = tran3d.getRotation().inverse();
  //G4RotationMatrix* pRot = 0;
  //if ( !rot.isIdentity() ) pRot = new G4RotationMatrix(rot);
  const G4ThreeVector& tran = tran3d.getTranslation();

  // 2017-02-20 T.Aso 
  //fEnvelopePhys->SetTranslation(tran);
  SetTranslation(tran);
  //
  //fEnvelopePhys->SetRotation(pRot);
  SetRotation(rot);
  //
}

void G4MVDICOM::UpdatePlacement(){
  //-- Open DICOM Handler---------------------------------------
  G4MDICOMConfiguration* config=
    G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  G4MDICOMData* dicomData = config->GetDICOMData();
  //--------------------------------------------------------------
  ModifyEnvelope(dicomData);
}

G4int G4MVDICOM::RenameMaterial(const G4String& oname, const G4String& nname){
  return  fmatList->SetMaterialNameTo(oname,nname);
}


void G4MVDICOM::ShowMatList(std::ostream& out, G4int lvl){
  fmatList->Show(out,lvl);
}

void G4MVDICOM::Dump(std::ostream& out){
  // ASO 
  //out << " ASO G4MVDICOM::Dump " << fEnvelopePhys->GetTranslation() << G4endl;
  //
  if(flang == 10 )  {
    DumpForDCM(out);
    return;
  }
  //========================================================
  G4MDICOMManager* mgr=G4MDICOMManager::GetPointer();
  //mgr->Show();
  G4MDICOMConfiguration* config = mgr->Get(fDICOMFileName);
  G4MDICOMData* dicomData = config->GetDICOMData();
  //========================================================

  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double zPixelSpacing  = dicomData->GetZPixelSPC();
  G4int totalRows         = dicomData->GetRow(); 
  G4int totalColumns      = dicomData->GetColumn();
  G4int totalSlices       = dicomData->GetSlice();
  // 2014-03-06 T.Aso commented
  //const G4ThreeVector& CToffset = dicomData->GetCToffset();
  //G4double x0             = dicomData->GetX(0);
  //G4double y0             = dicomData->GetY(0);
  //G4double z0             = dicomData->GetZ(0);
  //
  // Origin in Patient Frame
  // The position of first voxel (ix=0,iy=0,iz=0)
  // with respect to CT image frame.
  //
  // 2014-03-06 T.Aso commented.
  //G4double xo = CToffset.x()+x0;
  //G4double yo = CToffset.y()+y0;
  //G4double zo = CToffset.z()+z0;
  G4double xo = dicomData->GetCTX(0);
  G4double yo = dicomData->GetCTY(0);
  G4double zo = dicomData->GetCTZ(0);

  //Added by y.maeda(2013/08/13)                                                       
  // 2014-03-06 T.Aso commented.
  //xo *= (double)fUnitVecX;
  //yo *= (double)fUnitVecY;

  if ( flang == 0 ){
    out << "# 計算グリッド定義"<<G4endl;
    out << "# 原点座標 X,Y,Z (患者座標系) 【カンマ区切り実数】"<<G4endl;
  }else if ( flang == 1 ) {
    out << "# DICOM Calculation GRID"<<G4endl;
    out << "# Origin in Patient Frame (CSV float)"<<G4endl;
  }
  if ( flang == 0 || flang == 1 ) out << xo<<","<<yo<<","<<zo<<G4endl;

  if ( flang == 0 ){
    out << "# X方向単位ベクトル 【カンマ区切り実数】"<<G4endl;
  }else if ( flang == 1 ){
    out << "# X unit vector (CSV float)"<<G4endl;
  }
  if ( flang == 0 || flang == 1 ) out <<fUnitVecX<<",0,0"<<G4endl;  //Added by y.maeda(2013/08/13)  

  if ( flang == 0 ){  
    out << "# Y方向単位ベクトル 【カンマ区切り実数】"<<G4endl;
  }else if ( flang == 1 ){
    out << "# Y unit vector (CSV float)"<<G4endl;
  }
  if ( flang == 0 || flang == 1 ) out << "0,"<<fUnitVecY<<",0"<<G4endl; //Added by y.maeda(2013/08/13)  

  if ( flang == 0 ){  
    out << "# Z方向単位ベクトル 【カンマ区切り実数】"<<G4endl;
  }else if ( flang == 1 ){
    out << "# Z unit vector (CSV float)"<<G4endl;
  }
  if ( flang == 0 || flang == 1 ) out << "0,0,"<<fUnitVecZ<<G4endl; //Added by y.maeda(2013/08/13)  

  if ( flang == 0 ){  
    out << "# ボクセル数 X,Y,Z 【カンマ区切り 0より大きい整数】"<<G4endl;
  }else if (flang == 1 ) {
    out << "# Number of voxels Nx,Ny,Nz (CSV int)"<<G4endl;
  }
  // 2014-03-04 T.Aso
  //out <<totalRows <<","<<totalColumns<<","<<totalSlices<<G4endl;
  if ( flang == 0 || flang == 1 ) out <<totalColumns<<","<<totalRows <<","<<totalSlices<<G4endl;

  if ( flang == 0 ){  
    out << "# ボクセルサイズ[mm] X,Y,Z 【カンマ区切り実数】"<<G4endl;
  }else if ( flang == 1 ) {
    out << "# Voxel Size in [mm] (CSV float)"<<G4endl;
  }
  if ( flang == 0 || flang == 1 ) out << xPixelSpacing<<","<<yPixelSpacing<<","<<zPixelSpacing<<G4endl;
}

void G4MVDICOM::DumpForDCM(std::ostream& out){
  //
  
  //========================================================
  G4MDICOMManager* mgr=G4MDICOMManager::GetPointer();
  //mgr->Show();
  G4MDICOMConfiguration* config = mgr->Get(fDICOMFileName);
  G4MDICOMData* dicomData = config->GetDICOMData();
  //========================================================

  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double zPixelSpacing  = dicomData->GetZPixelSPC();
  G4int totalRows         = dicomData->GetRow(); 
  G4int totalColumns      = dicomData->GetColumn();
  G4int totalSlices       = dicomData->GetSlice();
  G4double xo = dicomData->GetCTX(0);
  G4double yo = dicomData->GetCTY(0);
  G4double zo = dicomData->GetCTZ(0);
  //
  ///G4double scaling = dicomData->GetScaling();
  //

  out << "dcmodify -ma \"(0008,0070)=PTSIM\" dose.dcm" <<G4endl;
  out << "dcmodify -ma \"(0008,1010)=PTSIM\" dose.dcm" <<G4endl;

  out << "dcmodify -ma \"(0018,0050)="<<zPixelSpacing<<"\" dose.dcm"<<G4endl;

  out << "dcmodify -ma \"(0020,0032)="
      <<xo<<"\\" << yo << "\\" << zo <<"\"  dose.dcm"<<G4endl;

  out << "dcmodify -ma \"(0020,0037)="
      <<fUnitVecX<<"\\" << "0.0\\0.0\\"
      <<"0.0\\"<< fUnitVecY<<"\\0.0"
      <<"\"  dose.dcm"<<G4endl;

  out << "dcmodify -ma \"(0028,0008)="<<totalSlices<< "\" dose.dcm"<<G4endl;
  out << "dcmodify -ma \"(0028,0010)="<<totalRows<< "\" dose.dcm"<<G4endl;
  out << "dcmodify -ma \"(0028,0011)="<<totalColumns<< "\" dose.dcm"<<G4endl;

  out << "dcmodify -ma \"(0028,0030)="
      <<xPixelSpacing<< "\\"<< yPixelSpacing
      <<"\" dose.dcm"<<G4endl;

  out << "dcmodify -ma \"(3004,000c)=";
  for ( G4int i = 0 ; i < totalSlices ; i++){
    out << (i*zPixelSpacing);
    //out << dicomData->GetSliceLocation(i);
    if ( i < totalSlices-1 ) out << "\\";
  }
  out << "\" dose.dcm" << G4endl;

  ////out << "dcmodify -ma \"(3004,000e)="<<scaling<< "\" dose.dcm"<<G4endl;
  ////out << "dcmodify -mf \"PixelData=dose.data\" dose.dcm"<<G4endl;

}

G4VPhysicalVolume* G4MVDICOM::buildEnvelope(G4LogicalVolume* worldlog) {
  // DICOM Data Mother

  fEnvMat = 0;
  // A material is assigned to Air in Mass geometry. 
  if ( worldlog->GetName() == "Room"){
    //fEnvMat = G4Material::GetMaterial("Air");
    fEnvMat = G4Material::GetMaterial(fMatAir);
  }

  //-- Open DICOM Handler---------------------------------------
  G4MDICOMHandler dh;
  dh.Load(fDICOMFileName);
  G4MDICOMManager* mgr=G4MDICOMManager::GetPointer();
  mgr->Show();
  G4MDICOMConfiguration* config = mgr->Get(fDICOMFileName);
  G4MDICOMData* dicomData = config->GetDICOMData();
  //--------------------------------------------------------------

  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double zPixelSpacing  = dicomData->GetZPixelSPC();
  G4int totalRows         = dicomData->GetRow(); 
  G4int totalColumns      = dicomData->GetColumn();
  G4int totalSlices       = dicomData->GetSlice();
  //
  G4ThreeVector dHalf = dicomData->GetDxyz();
  G4double dxHalf = dHalf.x()*mm;
  G4double dyHalf = dHalf.y()*mm;
  G4double dzHalf = dHalf.z()*mm;
  fEnvelopeSize.set(dxHalf,dyHalf,dzHalf);
  G4cout << "..........G4MVDICOM: "
         << dxHalf << ", "
         << dyHalf << ", "
         << dzHalf << G4endl;
  G4cout << "..........G4MVDICOM: "
         << xPixelSpacing << ", "
         << yPixelSpacing << ", "
         << zPixelSpacing << ", "
         << totalRows << ", "
         << totalColumns << ", "
         << totalSlices << ", "
         << G4endl;

  G4VSolid* solPatientWorld = new G4Box(GetName(), dxHalf, dyHalf, dzHalf);

  G4LogicalVolume* logPatientWorld = 
    new G4LogicalVolume( solPatientWorld,// Solid 
                         fEnvMat, // Material
                         GetName());// Name
  //================================================
  if (!fProdCuts) fProdCuts = new G4ProductionCuts();
  fProdCuts->SetProductionCut(1.*mm);
  G4Region* dicomReg =  
    G4RegionStore::GetInstance()->FindOrCreateRegion(GetName());
  dicomReg->SetProductionCuts(fProdCuts);
  logPatientWorld->SetRegion(dicomReg);
  dicomReg->AddRootLogicalVolume(logPatientWorld);
  //================================================
  // The coordinate of center of the Envelope.
  const G4ThreeVector ctoffset = dicomData->GetCToffset() *mm;
  //
  // Calculate transformation with current parameters.
  // Combined for gantry, frame rotation, CT positioning,
  // couach angle and positioning.
  //
  // 2014-08-20 T.Aso ( Update local DataOrientation from DICOM CT data. )
  //  
  fDataOrientation = dicomData->GetPatPosType();
  fUnitVecX = (G4int)dicomData->GetXorient();
  fUnitVecY = (G4int)dicomData->GetYorient();
  fUnitVecZ = 1;
  G4Transform3D transf = ComputeTransform3D(ctoffset);
  //
  // ASO 20170220 Fill trans and rot in  G4MVBeamModule.
  const G4RotationMatrix& rot = transf.getRotation().inverse();
  const G4ThreeVector& tran = transf.getTranslation();
  SetTranslation(tran);
  G4RotationMatrix* pRot = GetRotation();
  *pRot = rot;
  SetRotation((*pRot));

  //
  // Place the DICOM data on the Beam.
  //
  //G4VPhysicalVolume* physical  = 
  fEnvelopePhys =
      new G4PVPlacement(transf,
                        logPatientWorld,  // Logical volume  
                        GetName(),        // Name
                        worldlog,         // Mother  volume 
                        false,            // Not used 
                        0);               // Copy number  

  return fEnvelopePhys;
}

//Added by T.Yamashita(2014/09/03)           
const G4ThreeVector G4MVDICOM::GetCToffset() const {
  G4MDICOMManager* mgr=G4MDICOMManager::GetPointer();
  G4MDICOMConfiguration* config = mgr->Get(fDICOMFileName);
  G4MDICOMData* dicomData = config->GetDICOMData();
  return dicomData->GetCToffset() *mm;
}

void G4MVDICOM::EnableRTS(G4bool enable){
  if ( enable ) {
    if ( !fDicomRTS ){
      fDicomRTS = new G4MDICOMRTS();
    } else {
      G4Exception("G4MVDICOM::EnableRTS()","G4MVDICOM00",
                JustWarning,"RTS has been already registrated.");
    }
  }else{
    if ( fDicomRTS ) delete fDicomRTS;
    fDicomRTS = NULL;
  }
}
