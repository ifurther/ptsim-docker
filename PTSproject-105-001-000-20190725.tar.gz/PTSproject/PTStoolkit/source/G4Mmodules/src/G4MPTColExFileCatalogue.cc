//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MPTColEx.
// 
//  (History)
//   2014-04-09   T.Aso
//---------------------------------------------------------------------
//
#include "G4MPTColExFileCatalogue.hh"
#include "G4MPTCollimatorEx.hh"
#include <fstream>

G4MPTColExFileCatalogue::G4MPTColExFileCatalogue(const G4String& name,
					     const G4String& filename)
  :G4MVPTCollimatorExCatalogue(name),fDefaultFileName(filename){
}

G4MPTColExFileCatalogue::~G4MPTColExFileCatalogue()
{}

void G4MPTColExFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDxyzPTCol,
			    fMatPTCol,
			    fXYvec,
			    fdir);
}

void G4MPTColExFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio(pname);
  if(!fileio) { 
    G4cerr << "File Not Found " << pname << G4endl;
  }else{
    fXYvec.clear();

    G4int verbose = fModule->GetVerbose();
    
    G4double dx,dy,dz;
    fileio >> dx >> dy >> dz;  // Full size of PTCol frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    dz *= ( mm/2. );
    fDxyzPTCol.setX(dx);
    fDxyzPTCol.setY(dy);
    fDxyzPTCol.setZ(dz);
    
    fileio>>   fMatPTCol;       // Material of PTCol

    G4int npoint;
    fileio >> npoint ;       // Number of data points

    G4double x,y;
    for ( G4int i = 0; i < npoint; i++){
      fileio >> x >> y;
      x *=mm;
      y *=mm;
      fXYvec.push_back(G4TwoVector(x,y));
      if ( verbose > 0 ) G4cout << x <<  " " << y<< G4endl;
    }

    fileio >> fdir;   // Direction of data in XY

    fileio.close();
  }
}

void G4MPTColExFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyzPTCol,
			    fMatPTCol,
			    fXYvec,
			    fdir);
  fModule->ReBuild();
}
 
