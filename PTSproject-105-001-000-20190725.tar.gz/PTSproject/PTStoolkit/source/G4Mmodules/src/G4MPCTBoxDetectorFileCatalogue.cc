//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for PCTBox type module
// 
// (HISTORY)
// 19 Dec. 2010 T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MPCTBoxDetectorFileCatalogue.hh"
#include "G4MPCTBoxDetector.hh"
#include <fstream>
#include <sstream>

G4MPCTBoxDetectorFileCatalogue::G4MPCTBoxDetectorFileCatalogue(const G4String& name,
					 const G4String& fileName)
  :G4MVPCTBoxDetectorCatalogue(name),fDefaultFileName(fileName){
}

G4MPCTBoxDetectorFileCatalogue::~G4MPCTBoxDetectorFileCatalogue()
{}

void G4MPCTBoxDetectorFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(dxyz, material);
}

void G4MPCTBoxDetectorFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MPCTBoxDetectorFileCatalogue::Prepare()",
		"G4MPCTBoxDetFileCata00",FatalException,msg);
  }else{
    ifs.getline(chline,512);  // effective physical size 
    std::istringstream iss1(chline);
    G4double fx,fy,fz;
    iss1 >> fx >> fy >> fz;   // Full Size
    dxyz.setX(fx*mm/2.);
    dxyz.setY(fy*mm/2.);
    dxyz.setZ(fz*mm/2.);

    ifs.getline(chline,512);  //material
    std::istringstream iss3(chline);
    iss3 >> material;

    //G4cout << dxyz/mm <<" " <<material<<G4endl;
  }
  ifs.close();
}

void G4MPCTBoxDetectorFileCatalogue::Apply(){
   fModule->SetAllParameters(dxyz, material);
   fModule->ReBuild();
}







 
