//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    DICOM Module
//
// (HISTORY)
// 21 Oct. 2005 T.Aso Sensitive Detector is created at first time only.
//                    After second case, the SD is obtained from SDManager.
// 01 Dec. 2005 T.Aso Add G4Region for production cut.
// 24 Aug. 2006 T.Aso Add member of G4ProductionCuts for maintain cuts 
//                    information. This is required to re-installing 
//                    module after uninstallation.
// 30 Nov. 2006 T.Aso G4Region is obtained by G
//                    4RegionStore::FindOrCreateRegion() 
// 27 Feb. 2007 T.Aso Change class structure to have G4VDICOM super class.
//                    Most of methods was moved to the super class.
// 24 Jul. 2007 T.Aso Change name of node to XXXnode.
//                    G4MDICOMComplement filter was introduced.
// 16 Dec. 2008 T.Aso DoEnvelope() for resizing mother volume caused 
//                    by remeshing.
// 09 Sep. 2009 T.Aso PrepareDICOM() introduced.
// 10 Sep. 2009 T.Aso PrepareMatList() introduced.
// 2016-12-21 T.Aso PrepareDICOM(), GetLabelVec().
// 2017-03-15 T.Aso for threading
// 2019-04-04 T.Aso SDName was replaced from "G4MDICOM" to the beam module name.
// -----------------------------------------------------------------
// 
#include "G4MDICOM.hh"

#include "G4MDICOMHandler.hh"
#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"
#include "G4MDICOMCT2Density.hh"
#include "G4MDICOMCT2Material.hh"

#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Element.hh"
#include "G4Transform3D.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4Element.hh"
#include "G4SDManager.hh"

#include "G4MVDicomParameterisation.hh"
#include "G4MDicomWaterParameterisation.hh"
//#include "G4MDicomTissueParameterisation.hh"

#include "G4MDICOMSD.hh"
#include "G4ProductionCuts.hh"
#include "G4RegionStore.hh"

#include <cmath>

G4MDICOM::G4MDICOM(G4String name) 
  :G4MVDICOM(name)
{}

G4MDICOM::G4MDICOM(G4MVDICOMCatalogue* catalogue)
  : G4MVDICOM(catalogue->GetName())
{}

G4MDICOM::~G4MDICOM() {}

void G4MDICOM::buildNode(G4VPhysicalVolume* physvol) {

  //-- Open DICOM Handler---------------------------------------
  G4MDICOMConfiguration* config=
    G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  //--------------------------------------------------------------

  //std::vector<short> label;
  G4bool  override=FALSE;
  //G4MDICOMData* dicomData=PrepareDICOM(label,override);
  G4MDICOMData* dicomData=PrepareDICOM(override);
  std::vector<short>& label=GetLabelVec();
  G4MDICOMCT2Material* matList = PrepareMatList();
  //
  G4Material* air = G4Material::GetMaterial("Air");//Dummy material.
  //
  G4MDicomWaterParameterisation*
    param = new G4MDicomWaterParameterisation(
                                                   dicomData,
                                                   label,
                                                   matList);
  param->SetCTSampling(fCTSample);  // CT Sampling
  //
  // ------------------------------------------------
  // CT-Density (Prepare For Dose Calculation) 
  config->DoFiltering(new G4MDICOMCT2Density(fFileCT2Density));   
  //
  G4double sliceThickness = dicomData->GetZPixelSPC();
  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double tissueX = (xPixelSpacing/2) *mm;
  G4double tissueY = (yPixelSpacing/2) *mm;
  G4double tissueZ = (sliceThickness/2) *mm;

  //
  G4cout << " G4MDicom Tissue Half length (mm)" 
         << " x " << tissueX/mm 
         << " y " << tissueY/mm
         << " z " << tissueZ/mm << G4endl;

  const G4String nodeName = GetName() + "Node";
  G4Box* patient = new G4Box( nodeName, tissueX, tissueY, tissueZ);

  G4LogicalVolume* logicalPatient
      = new G4LogicalVolume(patient, air, nodeName);


  //G4VPhysicalVolume* physicalPatient = 
  new G4PVParameterised(nodeName,
                        logicalPatient,
                        physvol->GetLogicalVolume(),
                        kUndefined,
                        param->GetNoOfActive(), 
                        param );

  // Sensitive Detector
  fSdLVList.push_back(logicalPatient);
}

void G4MDICOM::BuildInSDandField() {
  G4String SDName = GetName();
  SetSensitive(SDName, fSdLVList[0]);
}

void G4MVDICOM::SetSensitive(G4String& SDName, G4LogicalVolume* logical) {
  G4SDManager * SDMan = G4SDManager::GetSDMpointer();

  G4VSensitiveDetector * dicomSD = SDMan->FindSensitiveDetector(SDName,false);
  if ( !dicomSD ){
    G4cout << "++ G4MVDICOM::  Create Sensitive Detector "<<SDName<<G4endl;
    dicomSD = new G4MDICOMSD(SDName);
    SDMan->AddNewDetector(dicomSD);
  }
  ((G4MDICOMSD*)dicomSD)->SetDICOMFile(fDICOMFileName);

  logical->SetSensitiveDetector(dicomSD);
}


