//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for PropellerBlades
// 
//  (History)
//   06-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MPropellerBladesFileCatalogue.hh"
#include "G4MPropellerBlades.hh"
#include <fstream>

G4MPropellerBladesFileCatalogue::
G4MPropellerBladesFileCatalogue(const G4String& name,
				const G4String& fileName)
  :G4MVPropellerBladesCatalogue(name),fMasterMat("Air"),
   fDefaultFileName(fileName){
}

G4MPropellerBladesFileCatalogue::~G4MPropellerBladesFileCatalogue()
{}

void G4MPropellerBladesFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetMasterMat(fMasterMat);
   fModule->SetAllParameters(fR,fAngle,fDz,fNfin,fMat);
}

void G4MPropellerBladesFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File not found "+pname;
    G4Exception("G4MPropellerBladesFileCatalogue::Prepare()",
		"G4MPropellerFileCata00",FatalException,msg);
  }else{
    G4int verbose = fModule->GetVerbose();
    // Master Volume's Material.
    fileio >> fMasterMat >> fNfin;
    if (verbose >0 ) G4cout << fMasterMat << " " <<G4endl;
    G4int nplate;
    fileio >> fMat >> fR>> nplate;
    if (verbose >0 ) G4cout << fMat << " " << fR<< " " <<nplate <<G4endl;
    fR *= mm;
    fAngle.clear();
    fDz.clear();
    G4double ang,dz;
    for ( G4int i = 0; i < nplate; i++){
	fileio >> ang >> dz; 
	if (verbose >0 ) G4cout << ang <<" "<<dz<<G4endl;
	ang  *= degree;
	dz   *= (mm/2.);  // Full width to half width.
	fAngle.push_back(ang);
	fDz.push_back(dz);
    }
  }
}

void G4MPropellerBladesFileCatalogue::Apply(){
    fModule->SetMasterMat(fMasterMat);
    fModule->SetAllParameters(fR,fAngle,fDz,fNfin,fMat);
    fModule->ReBuild();
}
