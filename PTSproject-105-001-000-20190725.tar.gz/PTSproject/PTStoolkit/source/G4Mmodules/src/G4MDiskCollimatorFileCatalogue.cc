//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   22-JAN-07   T.Aso
//  2014-03-11 T.Aso fVerbose.
//
//  
//---------------------------------------------------------------------
//
#include "G4MDiskCollimatorFileCatalogue.hh"
#include "G4MDiskCollimator.hh"
#include <fstream>
#include <sstream>

G4MDiskCollimatorFileCatalogue::
G4MDiskCollimatorFileCatalogue(const G4String& name,
                               const G4String& fileName)
  :G4MVDiskCollimatorCatalogue(name),fDefaultFileName(fileName){
}

G4MDiskCollimatorFileCatalogue::~G4MDiskCollimatorFileCatalogue()
{}

void G4MDiskCollimatorFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(Rin, Rout, dZ, material);
}

void G4MDiskCollimatorFileCatalogue::Prepare(G4String& pname){
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String& msg = "file open error "+pname;
    G4Exception("G4MDiskCollimatorFileCatalogue::Prepare()",
                "G4MDiskCollFileCata00",FatalException,msg);
  }else{
    ifs.getline(chline,512);  //Collimator ID
    ifs.getline(chline,512);  //description

    ifs.getline(chline,512);  // Size
    std::istringstream iss1(chline);
    G4double thickness;  
    iss1 >> Rin >> Rout >> thickness;
    Rin  *= mm;
    Rout *= mm;
    dZ = thickness*mm /2.;

    ifs.getline(chline,512);  //material
    std::istringstream iss2(chline);
    iss2 >> material;
    if ( fVerbose > 0 ) G4cout << material <<G4endl;
  }
  ifs.close();
}

void G4MDiskCollimatorFileCatalogue::Apply(){
   fModule->SetAllParameters(Rin,Rout,dZ,material);
   fModule->ReBuild();
}







 
