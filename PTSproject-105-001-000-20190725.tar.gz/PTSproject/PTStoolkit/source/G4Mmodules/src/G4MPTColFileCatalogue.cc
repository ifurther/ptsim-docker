//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MPTCol.
// 
//  (History)
//   2012-06-6   T.Aso
//---------------------------------------------------------------------
//
#include "G4MPTColFileCatalogue.hh"
#include "G4MPTCollimator.hh"
#include <fstream>

G4MPTColFileCatalogue::G4MPTColFileCatalogue(const G4String& name,
					     const G4String& filename)
  :G4MVPTCollimatorCatalogue(name),fDefaultFileName(filename){
}

G4MPTColFileCatalogue::~G4MPTColFileCatalogue()
{}

void G4MPTColFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDxyzPTCol,
			    fMatPTCol,
			    fDx,fDy,
			    fXvec,fYvec,
			    fXdir,fYdir);
}

void G4MPTColFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio(pname);
  if(!fileio) { 
    G4cerr << "File Not Found " << pname << G4endl;
  }else{
    fXvec.clear();
    fYvec.clear();

    G4int verbose = fModule->GetVerbose();
    
    G4double dx,dy,dz;
    fileio >> dx >> dy >> dz;  // Full size of PTCol frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    dz *= ( mm/2. );
    fDxyzPTCol.setX(dx);
    fDxyzPTCol.setY(dy);
    fDxyzPTCol.setZ(dz);
    
    fileio>>   fMatPTCol;       // Material of PTCol

    fileio >> fDx >> fDy ;      // Pitch.
    fDx *= mm;
    fDy *= mm;

    G4int npoint;
    fileio >> npoint ;       // Number of data points

    G4double x,y;
    for ( G4int i = 0; i < npoint; i++){
      fileio >> x >> y;
      x *=mm;
      y *=mm;
      fXvec.push_back(x);
      fYvec.push_back(y);
      if ( verbose > 0 ) G4cout << x <<  " " << y<< G4endl;
    }

    fileio >> fXdir >> fYdir;   // Direction of data in XY

    fileio.close();
  }
}

void G4MPTColFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyzPTCol,
			    fMatPTCol,
			    fDx,fDy,
			    fXvec,fYvec,
			    fXdir,fYdir);
  fModule->ReBuild();
}
 
