//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
// $Id: G4MFanBeam.cc,v 1.7 2007/04/25 10:20:12 aso Exp $
// GEANT4 tag $Name:  $
//
//---------------------------------------------------------------------
//  G4MFanBeam
//
//  (HISTROY)
//   T.ASO updated with the help of Y.Jizou.
//
//---------------------------------------------------------------------
//
// G4MFanBeam
#include "G4MFanBeam.hh"
#include "G4MFanBeamMessenger.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4Event.hh"
#include "G4ios.hh"


G4MFanBeam::G4MFanBeam()
  :G4ParticleGun(), beamdE(0.),fR(1000*mm),fTheta(0.),fZ(0.),fPhi(0.)
    
{ 
  //anEngine = new CLHEP::HepJamesRandom();
  //CLHEP::HepRandom::setTheEngine(anEngine);
  theBeamMessenger = new G4MFanBeamMessenger(this);
}

G4MFanBeam::~G4MFanBeam()
{
  //delete anEngine;
  delete theBeamMessenger;
}


void G4MFanBeam::SetEnergyFluctuation(const G4double de)
{ beamdE = de; }

G4double G4MFanBeam::GetEnergyFluctuation() const
{ return beamdE; }

void G4MFanBeam::SetRadius(const G4double r)
{
  fR=r;
}

G4double G4MFanBeam::GetRadius()
{
  return fR;
}

void G4MFanBeam::SetTheta(const G4double theta)
{
  fTheta=theta;
}

G4double G4MFanBeam::GetTheta()
{
  return fTheta;
}

void G4MFanBeam::SetZ(const G4double z)
{
  fZ=z;
}

G4double G4MFanBeam::GetZ()
{
  return fZ;
}

void G4MFanBeam::SetPhi(const G4double phi)
{

  fPhi=phi;
}

G4double G4MFanBeam::GetPhi()
{
  return fPhi;
}


void G4MFanBeam::GeneratePrimaryVertex(G4Event* evt)
{
  if(particle_definition==0) return;

  //  G4double sX = fR*std::cos(fTheta);
  //  G4double sY = fR*std::sin(fTheta);
  G4double sX = 0.0;
  G4double sY = fR;
  G4double sZ = 0.0;


  // create a new vertex
  G4PrimaryVertex* vertex = 
    new G4PrimaryVertex(G4ThreeVector(sX,sY,sZ),particle_time);


  // Energy Flactuation
  G4double kineticE =  particle_energy;
  if ( beamdE > 0. ) kineticE = CLHEP::RandGauss::shoot(kineticE,beamdE);
    
  // create new primaries and set them to the vertex
  G4double mass =  particle_definition->GetPDGMass();
  G4double energy = kineticE + mass;
  G4double pmom = std::sqrt(energy*energy-mass*mass);

  G4double ph;
  
  if(gaussSpot){
    //ph = CLHEP::RandGauss::shoot(0,fPhi/2.0);
    ph = CLHEP::RandGauss::shoot(0,fPhi/2.0);
  }else{
    ph = CLHEP::RandFlat::shoot(-fPhi/2.0,fPhi/2.0);
  }
  
  //ph = CLHEP::RandGauss::shoot(0,fPhi/2.0);
  

  
  G4double rx=-sin(ph);
  G4double ry=-cos(ph);
  G4double rz=0.0;

  G4double px = pmom*rx;
  G4double py = pmom*ry;
  G4double pz = pmom*rz;


  for( G4int i=0; i<NumberOfParticlesToBeGenerated; i++ )
  {
    G4PrimaryParticle* particle =
      new G4PrimaryParticle(particle_definition,px,py,pz);
    particle->SetMass( mass );
    particle->SetCharge( particle_charge );
    particle->SetPolarization(particle_polarization.x(),
                               particle_polarization.y(),
                               particle_polarization.z());
    vertex->SetPrimary( particle );
  }

  evt->AddPrimaryVertex( vertex );
}



