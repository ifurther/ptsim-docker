//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MGLUtil
//    Graphical library for handling images.
//
//  (HISTORY)
//   2012-09-10 T.Aso Created. 
//   2013-04-05 T.Aso The loop counter "i" in "Reverse if ...." was
//                   replaced to "j", because of redefinition of "i".
//   2014-10-16 T.Aso ix1,ix2,iy1,y2 initialize.
//                         
//
//---------------------------------------------------------------------
//
#include "globals.hh"
#include "G4MGLUtil.hh"

G4MGLUtil::G4MGLUtil(){
  fVerbose=0;
}

G4int G4MGLUtil::searchInsideXPY(G4int iymin, G4int iymax, 
                                std::vector<short>& map, 
                                G4int nx, G4int , G4int& ixS, G4int& iyS){
  // Assume iymin is the minimum coordinate of Y.
  // Assume iymax is the maximum coordinate of Y. 
  G4int flag = 0;
  G4int count = 0;
  G4int ix1=0, ix2=0;
  for ( G4int iy = iymin+4; iy < iymax ; iy++ ){
    count = 0;
    for ( G4int ix = 0; ix < nx; ix++ ){
      G4int id  = ix + nx*iy;
      if ( map[id] > 0 ) {
        if ( flag == 0 ) {
          count++;
          if ( count == 1 ) ix1 = ix;
          if ( count == 2 ) ix2 = ix;
        }
        flag++;
      }else{
        flag = 0;
      }
    }
    if ( count == 2 && std::abs(ix1-ix2)>1 ) {
      for ( G4int ix =ix1; ix < ix2; ix++ ){
        G4int id  = ix + nx*iy;
        if ( map[id] == 0 ) {
          ix1 = ix-1;
          break;
        }
      }
      ixS = (ix1+ix2)/2;
      iyS = iy;
      return std::abs(ix1-ix2)+1;
    }
  }
  return 0;
}

G4int G4MGLUtil::searchInsideXNY(G4int iymin, G4int iymax, 
                                std::vector<short>& map, 
                                G4int nx, G4int , G4int& ixS, G4int& iyS){
  // Assume iymin is the minimum coordinate of Y.
  // Assume iymax is the maximum coordinate of Y. 
  G4int flag = 0;
  G4int count = 0;
  G4int ix1=0, ix2=0;
  for ( G4int iy = iymax-4; iy > iymin ; iy-- ){
    count = 0;
    for ( G4int ix = 0; ix < nx; ix++ ){
      G4int id  = ix + nx*iy;
      if ( map[id] > 0 ) {
        if ( flag == 0 ) {
          count++;
          if ( count == 1 ) ix1 = ix;
          if ( count == 2 ) ix2 = ix;
        }
        flag++;
      }else{
        flag = 0;
      }
    }
    if ( count == 2 && std::abs(ix1-ix2)>1 ) {
      for ( G4int ix =ix1; ix < ix2; ix++ ){
        G4int id  = ix + nx*iy;
        if ( map[id] == 0 ) {
          ix1 = ix-1;
          break;
        }
      }
      ixS = (ix1+ix2)/2;
      iyS = iy;
      return std::abs(ix1-ix2)+1;
    }
  }
  return 0;
}


G4bool G4MGLUtil::searchInsideY(G4int ixmin, G4int ixmax, 
                                std::vector<short>& map, 
                                G4int nx, G4int ny, G4int& ixS, G4int& iyS){
  // Assume iymin is the minimum coordinate of Y. 
  // Assume iymax is the maximum coordinate of Y. 
  G4int flag = 0;
  G4int count = 0;
  G4int iy1=0, iy2=0;
  for ( G4int ix = ixmin+3; ix < ixmax ; ix++ ){
    count = 0;
    for ( G4int iy = 0; iy < ny; iy++ ){
      G4int id  = ix + nx*iy;
      if ( map[id] > 0 ) {
        if ( flag == 0 ) {
          count++;
          if ( count == 1 ) iy1 = iy;
          if ( count == 2 ) iy2 = iy;
        }
        flag++;
      }else{
        flag = 0;
      }
    }
    if ( count == 2 && std::abs(iy1-iy2)>1 ) {
      for ( G4int iy =iy1; iy < iy2 ; iy++ ){
        G4int id  = ix + nx*iy;
        if ( map[id] == 0 ) {
          iy1 = iy-1;
          break;
        }
      }
      ixS = ix;
      iyS = (iy1+iy2)/2;
      return true;
    }
  }
  return false;
}


void G4MGLUtil::drawLine(G4int ix0, G4int iy0, G4int ix1, G4int iy1,
                         std::vector<short>& map, G4int nx, G4int ){
  G4int px,py,dx,dy,addx,addy;
  G4int c = 0;

  dx = ix1-ix0;
  if ( dx < 0 ){
    dx = -dx;
    addx = -1;
  }else if ( dx > 0 ) {
    addx=1;
  }else{  // dx=0                                                                      
    addx=0;
  }
  dy = iy1-iy0;
  if ( dy < 0 ){
    dy = -dy;
    addy = -1;
  }else if ( dy > 0){
    addy=1;
  }else{ // dy=0                                                                       
    addy = 0;
  }

  px = ix0;
  py = iy0;
  G4int id;
  if ( dx > dy ){
    for ( G4int i=0; i <=dx; i++ ){
      id = py*nx+px;
      map[id] = 1;
      c = c+dy;
      if ( c >= dx ){
        c = c - dx;
        py = py + addy;
      }
      px = px+addx;
    }
  }else{
    for (G4int i = 0; i <= dy; i++ ){
      id = py*nx+px;
      map[id] = 1;
      c = c+dx; 
      if ( c >= dy ){
        c=c-dy;
        px=px+addx;
      }
      py=py+addy;
    }
  }
}

void G4MGLUtil::paint(G4int ix0, G4int iy0, std::vector<short>& map,
                      G4int nx, G4int ny){
  std::stack<short> stackX;
  std::stack<short> stackY;
  stackX.push(ix0);
  stackY.push(iy0);
  //
  G4int i,x,y,XL,XR;
  while( !stackX.empty() ) {
    x = stackX.top(); stackX.pop();
    y = stackY.top(); stackY.pop();
    G4int id = y*nx+x;
    map[id]  = 1;
    for ( i = x; i > 0; i-- ){
      id = y*nx+(i-1);
      if ( map[id] == 1 ){ break; }
      else {
        map[id] = 1 ;
      }
    }
    XL = i;
    for ( i = x; i < nx-1; i++ ){
      id = y*nx+(i+1);
      if ( map[id] == 1 ) { break; }
      else {
        map[id] = 1;
      }
    }
    XR = i;
    if( (y-1) >= 0 ) scanLine(XL,XR,y-1,map,nx,ny,stackX,stackY);
    if( (y+1) < ny ) scanLine(XL,XR,y+1,map,nx,ny,stackX,stackY);
  }
  //
  // Reverse if the painting was performed at outside of ROI
  // 
  if ( map[0] == 1 && map[nx*ny-1] == 1 ) {
    for ( G4int j = 0; j < nx*ny ; j++ ){
      if ( map[j] == 1 ) map[j] = 0;
      else               map[j] = 1;
    }
  }
}


void G4MGLUtil::scanLine(G4int XL, G4int XR, G4int iy0, 
                         std::vector<short>& map,
                         G4int nx, G4int ,
                         std::stack<short>& stackX, std::stack<short>& stackY){
  G4int id;
  while (XL <= XR ){
    for (; XL <= XR; XL++ ) {
      id = iy0*nx+XL;
      if ( map[id] == 0 ) break;
    }
    if ( map[id] != 0 ) break;

    for (; XL <= XR; XL++ ) {
      id = iy0*nx+XL;
      if ( map[id] != 0 ) break;
    }
    stackX.push(XL-1);
    stackY.push(iy0);
  }

}

