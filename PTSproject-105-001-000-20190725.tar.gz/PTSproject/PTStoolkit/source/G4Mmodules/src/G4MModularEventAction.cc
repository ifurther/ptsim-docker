//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularEventAction.cc,v 1.1 2009/03/17 09:29:34 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularEventAction
//
//  06-MAR-09  T.Aso Created
//  09-Sep-09  T.Aso Bug fix for the identification of new run.
// 2017-03-15 T.Aso for threading.
// 2017-09-24 T.Aso Remove a member fRun.
// 2017-09-24 T.Aso Change sequence of NewRun identification to keep
//                 the flag until the end of event.
//
//====================================================================

#include "G4MModularEventAction.hh"
#include "G4EventManager.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include "G4Run.hh"

G4MModularEventAction::G4MModularEventAction()
//:G4UserEventAction(),fRun(0),fRunID(-1){
  :G4UserEventAction(),fRunID(-1){
  eventActionVector = new G4MEventActionConstVector();
}

G4MModularEventAction::~G4MModularEventAction(){
  G4MEventActionConstVector::iterator itr;
  for (itr = eventActionVector->begin(); 
       itr!= eventActionVector->end(); ++itr){
    delete (*itr);
  }
  eventActionVector->clear();
  delete eventActionVector;
}

void G4MModularEventAction::BeginOfEventAction(const G4Event* aEvent)
{

    G4MEventActionConstVector::iterator itr;
    for (itr = eventActionVector->begin(); 
         itr!= eventActionVector->end(); ++itr){
      (*itr)->BeginOfEventAction(aEvent);
    }
}

void G4MModularEventAction::EndOfEventAction(const G4Event* aEvent)
{
  G4MEventActionConstVector::iterator itr;
  for (itr = eventActionVector->begin(); 
       itr!= eventActionVector->end(); ++itr){
    (*itr)->EndOfEventAction(aEvent);
  }
  //
  if ( IsNewRun() ){ // Update fRunID to new ID.
    fRunID = (G4RunManager::GetRunManager()->GetCurrentRun()->GetRunID());
  }
}

G4bool G4MModularEventAction::IsNewRun(){
  //
  if(G4RunManager::GetRunManager()->GetCurrentRun()->GetRunID()==fRunID) {
    return FALSE;
  }else{
    //fRun = (G4Run*)(G4RunManager::GetRunManager()->GetCurrentRun());
    //fRunID = (G4RunManager::GetRunManager()->GetCurrentRun()->GetRunID());
    return TRUE;
  }
}

