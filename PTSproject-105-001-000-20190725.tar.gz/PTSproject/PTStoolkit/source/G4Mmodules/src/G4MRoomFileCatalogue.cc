//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   04-Oct-05   T.Aso
//   17-Feb-09   T.Aso Exception for file error.
//
//
//---------------------------------------------------------------------  
//
#include "G4MRoomFileCatalogue.hh"
#include "G4MRoom.hh"
#include <fstream>
#include <sstream>

G4MRoomFileCatalogue::G4MRoomFileCatalogue(const G4String& name,
					   const G4String& filename)
  :G4MVRoomCatalogue(name),fDefaultFileName(filename){
}

G4MRoomFileCatalogue::~G4MRoomFileCatalogue()
{}

void G4MRoomFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  Apply();
}

void G4MRoomFileCatalogue::Prepare(G4String& pname){
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String& msg = "file open erro "+filename;
    G4Exception("G4MRoomFileCatalogue::Prepare()","G4MRoomFileCata00",
		FatalException,msg);
  }else{
    ifs.getline(chline,512);  //id
    ifs.getline(chline,512);  //description

    ifs.getline(chline,512);  //effective physical size given by full width.
    std::istringstream iss1(chline);
    iss1 >> fdX >> fdY >> fdZ;
    fdX /=2.;  // to half width
    fdY /=2.;  // to half width
    fdZ /=2.;  // to half width
    fdX *=mm;
    fdY *=mm;
    fdZ *=mm;

    ifs.getline(chline,512);  //material
    std::istringstream iss3(chline);
    iss3 >> material;

    ifs.getline(chline,512); // density

  }
  ifs.close();
}

void G4MRoomFileCatalogue::Apply(){
   fModule->SetMatName(material);
   fModule->SetAllParameters(G4ThreeVector(fdX,fdY,fdZ));
   fModule->ReBuild();
}







 
