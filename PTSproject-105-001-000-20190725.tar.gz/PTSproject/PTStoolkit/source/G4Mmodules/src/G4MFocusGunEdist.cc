//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------//
// (Description)
//    BeamGun for two focusing beam.
//    This was created for NCC beamline.
//
//  (HISTORY)
//    T.Aso
//
//---------------------------------------------------------------------
//
// G4MFocusGunEdist
#include "G4MFocusGunEdist.hh"
#include "G4MFocusGunEdistMessenger.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4Event.hh"
#include "G4ios.hh"

G4MFocusGunEdist::G4MFocusGunEdist()
  :G4ParticleGun(),isIntEdist(false),nsample(0)
{ 
  theFocusMessenger = new G4MFocusGunEdistMessenger(this);
}

G4MFocusGunEdist::~G4MFocusGunEdist()
{
  delete theFocusMessenger;
}

void G4MFocusGunEdist::ClearEnergyDist(){
  EdistPOFV    = ZeroPhysVector;
  IntEdistPOFV = ZeroPhysVector;
  isIntEdist = false;
}

void G4MFocusGunEdist::InsertEnergyDist(G4double energy, 
					G4double prob){
  EdistPOFV.InsertValues(energy,prob);
}

void G4MFocusGunEdist::SampleEnergyDist(G4int npoint){
  G4double emin = EdistPOFV.GetMinLowEdgeEnergy();
  G4double emax = EdistPOFV.GetMaxLowEdgeEnergy();
  G4double step = (emax-emin)/npoint;
  G4bool outOfRange;
  G4PhysicsOrderedFreeVector EdistTMP=EdistPOFV;
  EdistPOFV = ZeroPhysVector;
  for ( G4int i = 0; i < npoint; i++){
    G4double energy = emin+step*i;
    G4double value  = EdistTMP.GetValue(energy,outOfRange);
    EdistPOFV.InsertValues(energy,value);    
  }
}

void G4MFocusGunEdist::IntegrateEnergyDist(){
  G4double sumProb = 0.0;
  std::vector<G4double> eval;
  std::vector<G4double> pval;

  G4int maxbin = (G4int)EdistPOFV.GetVectorLength();
  IntEdistPOFV = ZeroPhysVector;
  // Integration
  for ( G4int i = 0; i < maxbin; i++ ){
    sumProb += EdistPOFV[i];
    eval.push_back(EdistPOFV.GetLowEdgeEnergy(size_t(i)));
    pval.push_back(sumProb);
  }
  // Normalization
  for ( G4int i = 0; i < maxbin; i++){
    pval[i] /= sumProb;
    IntEdistPOFV.InsertValues(eval[i],pval[i]);
  }
  isIntEdist = true;
}

void G4MFocusGunEdist::GeneratePrimaryVertex(G4Event* evt)
{
  if(particle_definition==0) return;

  //######### Set Position ##########
  G4double  sX = particle_position.x();//Beam-Position_X
  G4double  sY = particle_position.y();//Beam-Position_Y
  G4double  sZ = particle_position.z();//Beam-Position_Z


  //######### Set dx,dy(sZ-FocusX,Y) ##########
  //  G4double Delta_z = FocusX-FocusY;
  G4double Delta_x = sZ-FocusX;//Distance Z-X_Focus
  G4double Delta_y = sZ-FocusY;//Distance Z-Y_Focus


  //######### Set Shoot Position sX,sY  ##########
  sX = CLHEP::RandGauss::shoot(sX,std::abs(SigmaX * Delta_x));
  sY = CLHEP::RandGauss::shoot(sY,std::abs(SigmaY * Delta_y));

  //######### Set Beam parameter (Not Changed)##########
  // create a new vertex
  G4PrimaryVertex* vertex = 
    new G4PrimaryVertex(G4ThreeVector(sX,sY,sZ),particle_time);

  // Energy distribution
  if ( !isIntEdist ) {
    if ( nsample > 0 ) SampleEnergyDist(nsample);
    IntegrateEnergyDist();
  }
  G4double rndm = CLHEP::RandFlat::shoot(0.0,1.0);
  G4double kineticE = IntEdistPOFV.GetEnergy(rndm);

  // create new primaries and set them to the vertex
  G4double mass =  particle_definition->GetPDGMass();
  G4double energy = kineticE + mass;
  G4double pmom = std::sqrt(energy*energy-mass*mass);

  //
  G4double px = pmom* particle_momentum_direction.x();
  G4double py = pmom* particle_momentum_direction.y();
  G4double pz = pmom* particle_momentum_direction.z();


  //########### Set Beam Direction ###############

  G4double r1,r2;          // r1-X_slope,r2-Y_slope 
  if(Delta_x != 0.0 && Delta_y != 0.0){
    //isocenter < X,Y_Focus <= particle_Position
    r1 = sX/Delta_x;       //X_slope
    r2 = sY/Delta_y;       //Y_slope
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1));  //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;              //Z-Direction -1
    px = r1*pz;            //
    py = r2*pz;            //
  }
  else if(Delta_x == 0.0 && Delta_y == 0.0){ 
    //X,Y_Focus = particle_position
    r1 = CLHEP::RandGauss::shoot(0.0,SigmaX);
    r2 = CLHEP::RandGauss::shoot(0.0,SigmaY);
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;              //Z-Direction -1
    px = r1*pz;            //
    py = r2*pz;//
  }
  else if(Delta_y == 0.0){ 
    //isocenter < Y_Focus = particle_Position 
    r1 = sX/Delta_x;        //X_slope
    r2 = CLHEP::RandGauss::shoot(0.0,SigmaY);
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;               //Z-Direction -1
    px = r1*pz;             //
    py = r2*pz;             //
  }
  else if(Delta_x == 0.0){ 
    //isocenter < X_Focus = particle_Position
    r1 = CLHEP::RandGauss::shoot(0.0,SigmaX);
    r2 = sY/Delta_y;        //Y_slope
    pz = std::sqrt(pmom*pmom/(r1*r1+r2*r2+1)); //p=(r1*px)2+(r2*py)2+(pz)2
    pz = -pz;               //Z-Direction -1
    px = r1*pz;             //
    py = r2*pz;             //
  }
  else{}                    //isocentr 



  //############ Set Beam ###############
  for( G4int i=0; i<NumberOfParticlesToBeGenerated; i++ )
  {
    G4PrimaryParticle* particle =
      new G4PrimaryParticle(particle_definition,px,py,pz);
    particle->SetMass( mass );
    particle->SetCharge( particle_charge );
    particle->SetPolarization(particle_polarization.x(),
			      particle_polarization.y(),
			      particle_polarization.z());
    vertex->SetPrimary( particle );
  }

  evt->AddPrimaryVertex( vertex );
}
