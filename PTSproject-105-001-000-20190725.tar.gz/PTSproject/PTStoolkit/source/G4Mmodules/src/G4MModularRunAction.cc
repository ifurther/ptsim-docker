//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularRunAction.cc,v 1.1 2009/03/17 09:29:34 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularRunAction
//
//  06-MAR-09  T.Aso Created
//  09-Sep-09  T.Aso Bug fix for the identification of new run.
// 2017-03-15 T.Aso for threading.
//====================================================================

#include "G4MModularRunAction.hh"
#include "G4MModularEventAction.hh"
#include "G4RunManager.hh"
#include "G4Run.hh"

G4MModularRunAction::G4MModularRunAction()
  :G4UserRunAction(){
  runActionVector = new G4MRunActionConstVector();
}

G4MModularRunAction::~G4MModularRunAction(){
  G4MRunActionConstVector::iterator itr;
  for (itr = runActionVector->begin(); 
       itr!= runActionVector->end(); ++itr){
    delete (*itr);
  }
  runActionVector->clear();
  delete runActionVector;
}

void G4MModularRunAction::BeginOfRunAction(const G4Run* aRun)
{
  //--- Write out the start time
  G4cout << "Run ID " << aRun->GetRunID() << G4endl;
  system("echo === RunStartTime: ; date");
  G4cout << G4endl;

  G4MRunActionConstVector::iterator itr;
  for (itr = runActionVector->begin(); 
       itr!= runActionVector->end(); ++itr){
    (*itr)->BeginOfRunAction(aRun);
  }

}

void G4MModularRunAction::EndOfRunAction(const G4Run* aRun)
{

  //--- Write out the end time
  G4cout << G4endl;
  system("echo === RunEndTime: ; date");
  G4cout << G4endl;

  G4MRunActionConstVector::iterator itr;
  for (itr = runActionVector->begin(); 
       itr!= runActionVector->end(); ++itr){
    (*itr)->EndOfRunAction(aRun);
  }
}
