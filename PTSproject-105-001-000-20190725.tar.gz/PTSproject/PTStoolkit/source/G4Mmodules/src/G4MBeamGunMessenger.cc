//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MBeamGunMessenger
//
//  This is a concrete class of G4UImessenger which handles commands for
// G4MBeamGun.
//
//  (HISTORY)
//   2013-03-30 T.Aso SystemOfUnits/PhysicsConstants.
//   2014-02-07 T.Aso eflucPerc command.
//   2016-01-13 T.Aso PID for ions is supported.
//   2016-01-14 T.Aso angSigma command. ( Angular variance in mrad ).
//
//---------------------------------------------------------------------
//

#include "G4MBeamGunMessenger.hh"
#include "G4MBeamGun.hh"
#include "G4ParticleDefinition.hh"
#include "G4Proton.hh"
#include "G4ThreeVector.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcommand.hh"
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"

#include "G4Tokenizer.hh"

#include "G4UnitsTable.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include <sstream>
#include <fstream>

G4MBeamGunMessenger::G4MBeamGunMessenger(G4MBeamGun * fPtclGun)
  :fParticleGun(fPtclGun)
{
  gunDirectory = new G4UIdirectory("/G4M/Beam/");
  gunDirectory->SetGuidance("Beam Gun control commands.");

  gausSpotCmd = new G4UIcmdWithABool("/G4M/Beam/gaussSpot",this);
  gausSpotCmd->SetGuidance("Gaussian beam position around origin");
  gausSpotCmd->SetParameterName("gaussSpot",false);
  gausSpotCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  spotCmd = new G4UIcmdWith3VectorAndUnit("/G4M/Beam/spotsize",this);
  spotCmd->SetGuidance("Set spot size of the Beam.");
  spotCmd->SetParameterName("dX","dY","dZ",true,true);
  spotCmd->SetDefaultUnit("mm");
  spotCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  eflucCmd = new G4UIcmdWithADoubleAndUnit("/G4M/Beam/energyfluc",this);
  eflucCmd->SetGuidance("Set Energy fluctuation of the Beam.");
  eflucCmd->SetParameterName("dE",false);
  eflucCmd->SetDefaultUnit("MeV");
  eflucCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  //
  new G4UnitDefinition("perCent","perCent","perCent",perCent);
  //
  eflucPercCmd = new G4UIcmdWithADoubleAndUnit("/G4M/Beam/energyflucPerc",this);
  eflucPercCmd->SetGuidance("Set Energy fluctuation of the Beam in Percentage.");
  eflucPercCmd->SetParameterName("dEPerc",false);
  eflucPercCmd->SetDefaultUnit("perCent");
  eflucPercCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  //
  emitCmd = new G4UIcmdWith3Vector("/G4M/Beam/emittance",this);
  emitCmd->SetGuidance("Set emittance of the Beam.");
  emitCmd->SetParameterName("EmitX","EmitY","EmitZ",true,true);
  emitCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  //
  angCmd = new G4UIcommand("/G4M/Beam/angSigma",this);
  angCmd->SetGuidance("Sigma of angular dist.");
  angCmd->SetGuidance("Usage: /G4M/Beam/angSigma sx sy unit");
  angCmd->SetGuidance("sx, sy: (double) Sigma of angle");
  angCmd->SetGuidance("unit: unit of angle");
  G4UIparameter* param;
  param = new G4UIparameter("angsx",'d',true);
  param->SetDefaultValue(0.);
  angCmd->SetParameter(param);
  param = new G4UIparameter("angsy",'d',true);
  param->SetDefaultValue(0.);
  angCmd->SetParameter(param);
  param = new G4UIparameter("unit",'s',true);
  param->SetDefaultValue("mrad");
  angCmd->SetParameter(param);
  //
  fileCmd = new G4UIcmdWithAString("/G4M/Beam/file",this);
  fileCmd->SetGuidance("File name for setting Beam parameters from file");
  fileCmd->SetParameterName("FileName",false);
  fileCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // set initial value to G4MBeamGun
  fParticleGun->SetParticleDefinition( G4Proton::Proton() );
  fParticleGun->SetParticleMomentumDirection( G4ThreeVector(0.0,0.0,-1.0) );
  fParticleGun->SetParticleEnergy( 200.0*MeV );
  fParticleGun->SetParticlePosition(G4ThreeVector(0.*cm, 0.*mm, 3000.0*mm));
  fParticleGun->SetParticleTime( 0.0*ns );
  fParticleGun->SetSpotSize(G4ThreeVector());
  fParticleGun->SetGaussSpot(true);
}

G4MBeamGunMessenger::~G4MBeamGunMessenger()
{
  delete gausSpotCmd;
  delete emitCmd;
  delete angCmd;
  delete fileCmd;
  delete spotCmd;
  delete eflucCmd;
  delete eflucPercCmd;
  delete gunDirectory;
}

void G4MBeamGunMessenger::SetNewValue(G4UIcommand * command,G4String newValues)
{
  if( command==gausSpotCmd ){
    fParticleGun->SetGaussSpot(gausSpotCmd->GetNewBoolValue(newValues));
  }else if( command==spotCmd ){ 
    fParticleGun->SetSpotSize(spotCmd->GetNew3VectorValue(newValues)); 
  }else if ( command == eflucCmd ) {
      fParticleGun->SetEnergyFluctuation(eflucCmd->GetNewDoubleValue(newValues));
  }else if ( command == eflucPercCmd ) {
      G4cout << "G4MBeamGunMessenger::efuctCmd perCent" 
             <<  eflucCmd->GetNewDoubleValue(newValues) 
             << " eFluct (MeV) "<< fParticleGun->GetEnergyFluctuation()/MeV << G4endl;
      fParticleGun->SetEnergyFluctByPercent(eflucCmd->GetNewDoubleValue(newValues));
      G4cout << "G4MBeamGunMessenger::efuctCmd perCent" 
             <<  eflucCmd->GetNewDoubleValue(newValues) 
             << " eFluct (MeV) "<< fParticleGun->GetEnergyFluctuation()/MeV << G4endl;
  }else if ( command == emitCmd ) {
    fParticleGun->SetEmittance(emitCmd->GetNew3VectorValue(newValues));
  }else if ( command == angCmd ) {
    G4Tokenizer next(newValues);
    G4double sx = StoD(next());
    G4double sy = StoD(next());
    G4double unit = G4UnitDefinition::GetValueOf(next());
    fParticleGun->SetAngleSigma(sx*unit,sy*unit);
  }else if (command == fileCmd ) {
    char chline[512];
    G4String filename = newValues;// newValues should be a exact file name.
    std::ifstream ifs;
    ifs.open(filename.c_str());

    ////////////
    ifs.getline(chline,512);  //energy ID
    ifs.getline(chline,512);  //description

    ifs.getline(chline,512);  //particle ID
    std::istringstream iss1(chline);
    G4int particleID;
    iss1 >> particleID;
    G4ParticleDefinition* particle = 
      G4ParticleTable::GetParticleTable()->FindParticle(particleID);
    if (!particle){
      // +-100ZZZAAAI => Only for nucleus.
      if ( std::abs(particleID) > 1000000000 ){
        G4int Anum = (G4int)((particleID%10000)/10);
        G4int Znum = (G4int)((particleID%10000000)/10000);
        G4int Level = (G4int)((particleID%10));
        particle = G4IonTable::GetIonTable()->GetIon(Znum,Anum,Level);
        if ( particle == 0 ){
          std::stringstream ss;
          ss << "Z A L " << Znum << " " << Anum << " " << Level;
          G4String mes = ss.str();
          G4Exception("G4MBeamGunMessenger","G4MBeamGunMessenger00",
                      FatalException,mes);
        }
      }
    }
    fParticleGun->SetParticleDefinition(particle);

    ifs.getline(chline,512);  //particle energy / energy spread
    std::istringstream iss2(chline);
    G4double particleEN;
    G4double ENspread;
    iss2 >> particleEN >> ENspread;
    fParticleGun->SetParticleEnergy(particleEN*MeV);
    fParticleGun->SetEnergyFluctuation(ENspread);

    //angular variance /spatial covaliance /spatial variance
    ifs.getline(chline,512);  
    std::istringstream iss3(chline);
    G4double angularv;  //angular variance
    G4double angulars;  //angular-spatial covaliance
    iss3 >> angularv >> angulars;

    ifs.getline(chline,512);  //spatial variance in X and Y
    std::istringstream iss4(chline);
    G4double spatialx;  //spatial variance
    G4double spatialy;  //spatial variance
    iss4 >> spatialx >> spatialy ;
    fParticleGun->SetSpotSize(G4ThreeVector(spatialx*mm,spatialy*mm,0.0));
    ifs.close();
  }
}

G4String G4MBeamGunMessenger::GetCurrentValue(G4UIcommand * command)
{
  G4String cv;
  
  if( command==spotCmd ){ 
    cv = spotCmd->ConvertToString(fParticleGun->GetSpotSize(),"mm"); }
  else if ( command==eflucCmd ){ 
    cv = eflucCmd->ConvertToString(fParticleGun->GetEnergyFluctuation(),"MeV");
  }else if ( command==emitCmd ){
    cv = emitCmd->ConvertToString(fParticleGun->GetEmittance()); 
  }
  return cv;
}


