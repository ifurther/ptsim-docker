//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// RigdgeFileter
//
// Constructor
//   G4MRidgeFilter(const G4String& name, const G4String& mat, 
//                  G4int nbar, G4double barpitch, G4double barlen,
//                  const std::vector<G4double>& xfin, 
//                  const std::vector<G4double>& zfin)
//      nbar :  Number of bars
//      barpitch : The pitch between adjacent bars. 
//                 nbar*barpitch defines a size of x direction of 
//                 the ridge filter.
//      barlen : length of the bar, i.e y length
//      xfin : vector of fin's outer edge ( x-position. )
//                  ( Last value must be center of a ridge.)
//                  ( i.e Must be equals to barpitch/2.)
//      zfin : vector of fin's hieght. ( z-direction )
//         Exsample (HIBMC representation)
//                 x         z        gives  xHalfWidth     xPosition
//            _| 1.12755   0              
//          ___| 1.467896  2.347418       0.170173       1.202277
//        _____| 1.752794  4.694836       0.142449       0.889655
//      _______| 1.965832  7.042253       0.106519       0.640687      
//    _________| 2.171185  9.389671       0.102677       0.431492
//  ___________| 2.325188 11.73709        0.077001       0.251814
//_ _ _ _ _ _ _| 2.5      14.08451        0.097406       0.0087406(half)
//                            where
//                               xHalfWidth = (x[i+1]-x[i])/2, 
//                               xPosition  = (barpitch/2)-(x[i+1]+x[i])/2, 
//
//
// (HISTORY) T.Aso
//  24-JUL-2007  Node names are changed.
//  23-JAN-2008  Bug fix about ridge direction. The direction of ridge
//               was modified from -Z to +Z.
//  2012-06-23 T.Aso Introduce Attached scatter.
//  2014-03-11 T.Aso fVerbose
//
// -----------------------------------------------------------------
//
#include "G4MRidgeFilter.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MRidgeFilter::G4MRidgeFilter(const G4String& name, const G4String& mat, 
                               G4int nbar, G4double barpitch, G4double barlen,
                               const std::vector<G4double>& xfin, 
                               const std::vector<G4double>& zfin)
  :G4MVBeamModule(name),fMatRidge(mat),fnbar(nbar),fbarPitch(barpitch),
   fbarLength(barlen),
   fxFin(xfin),fzFin(zfin),
   fSctMat(""),fSctThick(0.0),
   fCatalogue(NULL){
}

G4MRidgeFilter::G4MRidgeFilter(const G4String& name)
  :G4MVBeamModule(name),
   fMatRidge(""),fnbar(0),fbarPitch(0.),
   fbarLength(0.),
   fSctMat(""),fSctThick(0.0),
   fCatalogue(NULL){
}

G4MRidgeFilter::G4MRidgeFilter(G4MVRidgeFilterCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MRidgeFilter::~G4MRidgeFilter() {
  fxFin.clear();
  fzFin.clear();
  if ( fCatalogue ) delete fCatalogue;
}

void G4MRidgeFilter::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MRidgeFilter::SetAllParameters(const G4String& mat, 
                                      G4int nbar, G4double barpitch, 
                                      G4double barlen,
                                      const std::vector<G4double>& xfin, 
                                      const std::vector<G4double>& zfin,
                                      const G4String& sctmat, 
                                      G4double sctthick)
{
  fMatRidge=mat;
  fnbar=nbar;
  fbarPitch=barpitch;
  fbarLength=barlen;
  fxFin=xfin;
  fzFin=zfin;
  fSctMat = sctmat;
  fSctThick = sctthick;
}

void G4MRidgeFilter::Dump(std::ostream& out){
  out << "== Dump G4MRidgeFilter =="<<G4endl;
  out << fMatRidge << G4endl;
  out << " Bar pitch  " << fbarPitch/mm <<" mm"<<G4endl;
  out << " Bar length " << fbarLength/mm <<" mm"<<G4endl;
  for ( G4int i = 0; i < (G4int)fxFin.size(); i++){
    out << fxFin[i]/mm <<"\t"<<fzFin[i]<<G4endl;
  }
  out << fSctMat << G4endl;
  out << fSctThick/mm << G4endl;
}

void G4MRidgeFilter::SetFin(const std::vector<G4double>& x, 
                            const std::vector<G4double>& z) {
  fxFin = x;
  fzFin = z;
}

G4VPhysicalVolume* G4MRidgeFilter::buildEnvelope(G4LogicalVolume* worldlog) {
  G4Material* Mat = G4Material::GetMaterial("Air");  
  G4double Dx = fbarPitch/2.*fnbar;
  G4double Dy = fbarLength/2.;
  G4double Dz = 0.0;
  G4int NfinSize = fzFin.size();
  for ( G4int i = 0; i < NfinSize; i++) {
      if ( Dz < fzFin[i] ) Dz = fzFin[i];
  }
  if ( !(Dz > 0.0) ) {
    G4Exception("G4MRidgeFilter::buildEnvelope()","G4MRidge00",
                FatalException,"@@@ G4MRidgeFilter: Envelop Dz is zero.");
  }
  //
  // Attached scattering plate 
  if ( fSctMat != "" && fSctThick > 0.0 ) {
    Dz += fSctThick;
  }
  //
  Dz /= 2.;
  fEnvelopeSize.set(Dx,Dy,Dz);  // Size of Envelope.

  G4VSolid* solid = new G4Box(GetName(),Dx,Dy,Dz);
  G4LogicalVolume* logical = new G4LogicalVolume(solid,Mat,GetName());
  G4VPhysicalVolume* physical  = new G4PVPlacement(
                     GetRotation(),
                     GetTranslation(),
                     logical,                      // Logical volume  
                      GetName(),                       // Name
                     worldlog,    // Mother  volume 
                     false,                         // Not used 
                     0);                            // Copy number  
  //  logical->SetVisAttributes(G4VisAttributes::Invisible);  
  return physical;
}

void G4MRidgeFilter::buildNode(G4VPhysicalVolume* physvol) {
  if ( fzFin.size() == 0 ) return;
  //
  G4RotationMatrix Rm;
  //
  // Attach scattering plate
  if ( fSctMat != "" && fSctThick > 0.0 ) {
    G4Material* sctMat = G4Material::GetMaterial(fSctMat);
    G4double sctDx = fbarPitch/2.*fnbar;
    G4double sctDy = fbarLength/2.;
    G4double sctDz = fSctThick/2.;
    const G4String sctPlateName = GetName()+"SctPlate";
    G4VSolid* sctSolid = new G4Box(sctPlateName,sctDx,sctDy,sctDz);
    G4LogicalVolume* sctLog = new G4LogicalVolume(sctSolid,sctMat,sctPlateName);
    sctLog->SetVisAttributes(new G4VisAttributes(G4Colour(1.,0.,0.0)));
    G4ThreeVector Tm(0.,0.,-fEnvelopeSize.z()+sctDz);
    G4Transform3D t3d(Rm,Tm);
    //G4VPhysicalVolume* p = 
    new G4PVPlacement(t3d,sctLog,sctPlateName,
                      physvol->GetLogicalVolume(),
                      0,0);
  }
  //FinBox
  G4Material* boxMat = G4Material::GetMaterial("Air");
  G4double boxDx = fbarPitch/2.;
  G4double boxDy = fbarLength/2.;
  G4double boxDz = 0.0;
  G4int NfinSize = fzFin.size();
  for ( G4int i = 0; i < NfinSize ; i++){
      if ( boxDz < fzFin[i] ) boxDz = fzFin[i];
  }
  boxDz /=2.;
  const G4String finBoxName = GetName()+"FinBox";
  G4VSolid* boxSolid = new G4Box(finBoxName,boxDx,boxDy,boxDz);
  G4LogicalVolume* boxLog = new G4LogicalVolume(boxSolid,boxMat,finBoxName);
  //boxLog->SetVisAttributes(G4VisAttributes::Invisible); 
  boxLog->SetVisAttributes(new G4VisAttributes(G4Colour(1.,1.,0.3)));

  //FinBox Placement
  for ( G4int i = 0; i < fnbar; i++){
    G4ThreeVector Tm(-(fbarPitch/2.*fnbar)+fbarPitch/2.+fbarPitch*i,0.,
                     +fSctThick/2.);
    G4Transform3D t3d(Rm,Tm);
    //G4VPhysicalVolume* p = 
    new G4PVPlacement(t3d,boxLog,finBoxName,
                      physvol->GetLogicalVolume(),
                      0,
                      i);
  }

  //Fin ( Install fins into FinBOX )
  const G4String finName = GetName()+"Fin";
  G4Material* finMat = G4Material::GetMaterial(fMatRidge);
  G4double dx,dy,dz;
  G4double x,y,z;
  G4double dzBox = boxDz;
  G4int fNfin = fzFin.size();
  for (G4int i = 0; i < (fNfin-1); i++){
    dx = (fxFin[i+1]-fxFin[i])/2.;
    dy = boxDy;
    dz = fzFin[i+1]/2.;
    x  = fxFin[fNfin-1]-(fxFin[i+1]+fxFin[i])/2.;
    y  = 0.*mm;
    z  = -(dzBox-dz);
    G4VSolid* finSolid = new G4Box(finName,dx,dy,dz);
    G4LogicalVolume* finLog = new G4LogicalVolume(finSolid,finMat,finName);
    //G4VisAttributes* vattr = new G4VisAttributes;
    //vattr->SetColour(0,0,255,1.);
    //finLog->SetVisAttributes(vattr);
    // Left and Right placement
    //G4VPhysicalVolume* finPhysP = 
    new G4PVPlacement(0,G4ThreeVector(+x,y,z),finLog,finName,
                          boxLog,false,0);
    //G4VPhysicalVolume* finPhysN = 
    new G4PVPlacement(0,G4ThreeVector(-x,y,z),finLog,finName,
                          boxLog,false,1);
    if ( fVerbose > 0 ){
      G4cout << i << " " << finName 
             << " dxyz " << dx <<" "<<dy<<" "<<dz
             << " xyz  " << x  <<" "<<y<<" "<<z
             << G4endl;
    }
  }  
}

