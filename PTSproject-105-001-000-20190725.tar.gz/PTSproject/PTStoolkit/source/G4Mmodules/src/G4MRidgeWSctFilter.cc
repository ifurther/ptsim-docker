//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// RigdgeFileter
//
// Constructor
//   G4MRidgeWSctFilter(const G4String& name, const G4String& mat, 
//                  G4int nbar, G4double barpitch, G4double barlen,
//                  const std::vector<G4double>& xfin, 
//                  const std::vector<G4double>& zfin)
//      nbar :  Number of bars
//      barpitch : The pitch between adjacent bars. 
//                 nbar*barpitch defines a size of x direction of 
//                 the ridge filter.
//      barlen : length of the bar, i.e y length
//      xfin : vector of fin's outer edge ( x-position. )
//      zfin : vector of fin's hieght. ( z-direction )
//
// (HISTORY) T.Aso
//  2012-06-23 T.Aso Introduce Attached scatter.
//  2012-06-26 T.Aso Copied from G4MRidgeFilter. 
//                   The code was modified according to FukuiCC data.
//  2013-01-15 T.Aso (Bugfix. T.Aso 2012/12/22). The type of zFinZeo
//                  was modified from int to double.
//
// -----------------------------------------------------------------
//
#include "G4MRidgeWSctFilter.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"

G4MRidgeWSctFilter::G4MRidgeWSctFilter(const G4String& name, const G4String& mat, 
                               G4int nbar, G4double barpitch, G4double barlen,
                               const std::vector<G4double>& xfin, 
                               const std::vector<G4double>& zfin)
  :G4MVBeamModule(name),fMatRidge(mat),fnbar(nbar),fbarPitch(barpitch),
   fbarLength(barlen),
   fxFin(xfin),fzFin(zfin),
   fSctMat(""),fSctThick(0.0),
   fCatalogue(NULL){
}

G4MRidgeWSctFilter::G4MRidgeWSctFilter(const G4String& name)
  :G4MVBeamModule(name),
   fMatRidge(""),fnbar(0),fbarPitch(0.),
   fbarLength(0.),
   fSctMat(""),fSctThick(0.0),
   fCatalogue(NULL){
}

G4MRidgeWSctFilter::G4MRidgeWSctFilter(G4MVRidgeWSctFilterCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MRidgeWSctFilter::~G4MRidgeWSctFilter() {
  fxFin.clear();
  fzFin.clear();
  if ( fCatalogue ) delete fCatalogue;
}

void G4MRidgeWSctFilter::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MRidgeWSctFilter::SetAllParameters(const G4String& mat, 
                                      G4int nbar, G4double barpitch, 
                                      G4double barlen,
                                      const std::vector<G4double>& xfin, 
                                      const std::vector<G4double>& zfin,
                                      const G4String& sctmat, 
                                      G4double sctthick)
{
  fMatRidge=mat;
  fnbar=nbar;
  fbarPitch=barpitch;
  fbarLength=barlen;
  fxFin=xfin;
  fzFin=zfin;
  fSctMat = sctmat;
  fSctThick = sctthick;
}

void G4MRidgeWSctFilter::Dump(std::ostream& out){
  out << "== Dump G4MRidgeWSctFilter =="<<G4endl;
  out << fMatRidge << G4endl;
  out << " Bar pitch  " << fbarPitch/mm <<" mm"<<G4endl;
  out << " Bar length " << fbarLength/mm <<" mm"<<G4endl;
  for ( G4int i = 0; i < (G4int)fxFin.size(); i++){
    out << fxFin[i]/mm <<"\t"<<fzFin[i]<<G4endl;
  }
  out << fSctMat << G4endl;
  out << fSctThick/mm << G4endl;
}

void G4MRidgeWSctFilter::SetFin(const std::vector<G4double>& x, 
                            const std::vector<G4double>& z) {
  fxFin = x;
  fzFin = z;
}

G4VPhysicalVolume* G4MRidgeWSctFilter::buildEnvelope(G4LogicalVolume* worldlog) {
  G4Material* Mat = G4Material::GetMaterial("Air");  
  G4double Dx = fbarPitch/2.*fnbar;
  G4double Dy = fbarLength/2.;
  G4double Dz = 0.0;
  G4int NfinSize = fzFin.size();
  for ( G4int i = 0; i < NfinSize; i++) {
      if ( Dz < fzFin[i] ) Dz = fzFin[i];
  }
  if ( !(Dz > 0.0) ) {
    G4Exception("G4MRidgeWSctFilter::buildEnvelope()","G4MRidge00",
                FatalException,"@@@ G4MRidgeWSctFilter: Envelop Dz is zero.");
  }
  //
  // Attached scattering plate 
  if ( fSctMat != "" && fSctThick > 0.0 ) {
    Dz += fSctThick;
  }
  //
  Dz /= 2.;
  fEnvelopeSize.set(Dx,Dy,Dz);  // Size of Envelope.

  G4VSolid* solid = new G4Box(GetName(),Dx,Dy,Dz);
  G4LogicalVolume* logical = new G4LogicalVolume(solid,Mat,GetName());
  G4VPhysicalVolume* physical  = new G4PVPlacement(
                     GetRotation(),
                     GetTranslation(),
                     logical,                      // Logical volume  
                      GetName(),                       // Name
                     worldlog,    // Mother  volume 
                     false,                         // Not used 
                     0);                            // Copy number  
  //  logical->SetVisAttributes(G4VisAttributes::Invisible);  
  return physical;
}

void G4MRidgeWSctFilter::buildNode(G4VPhysicalVolume* physvol) {
  if ( fzFin.size() == 0 ) return;
  //
  G4RotationMatrix Rm;
  //
  // Attach scattering plate
  if ( fSctMat != "" && fSctThick > 0.0 ) {
    G4Material* sctMat = G4Material::GetMaterial(fSctMat);
    G4double sctDx = fbarPitch/2.*fnbar;
    G4double sctDy = fbarLength/2.;
    G4double sctDz = fSctThick/2.;
    const G4String sctPlateName = GetName()+"SctPlate";
    G4VSolid* sctSolid = new G4Box(sctPlateName,sctDx,sctDy,sctDz);
    G4LogicalVolume* sctLog = new G4LogicalVolume(sctSolid,sctMat,sctPlateName);
    sctLog->SetVisAttributes(new G4VisAttributes(G4Colour(1.,0.,0.0)));
    G4ThreeVector Tm(0.,0.,-fEnvelopeSize.z()+sctDz);
    //Space between scattering plate and Rigde was incorpolated(Y.maeda 2012/06/25) 
    //G4ThreeVector Tm(0.,0.,-fEnvelopeSize.z()+sctDz-8.*mm);
    G4Transform3D t3d(Rm,Tm);
    //G4VPhysicalVolume* p = 
    new G4PVPlacement(t3d,sctLog,sctPlateName,
                      physvol->GetLogicalVolume(),
                      0,0);
  }
  //FinBox
  G4Material* boxMat = G4Material::GetMaterial("Air");
  G4double boxDx = fbarPitch/2.;
  G4double boxDy = fbarLength/2.;
  G4double boxDz = 0.0;
  G4int NfinSize = fzFin.size();
  for ( G4int i = 0; i < NfinSize ; i++){
      if ( boxDz < fzFin[i] ) boxDz = fzFin[i];
  }
  boxDz /=2.;
  const G4String finBoxName = GetName()+"FinBox";
  G4VSolid* boxSolid = new G4Box(finBoxName,boxDx,boxDy,boxDz);
  G4LogicalVolume* boxLog = new G4LogicalVolume(boxSolid,boxMat,finBoxName);
  //boxLog->SetVisAttributes(G4VisAttributes::Invisible); 
  boxLog->SetVisAttributes(new G4VisAttributes(G4Colour(1.,1.,0.3)));

  //FinBox Placement
  for ( G4int i = 0; i < fnbar; i++){
    G4ThreeVector Tm(-(fbarPitch/2.*fnbar)+fbarPitch/2.+fbarPitch*i,0.,
                     +fSctThick/2.);
    G4Transform3D t3d(Rm,Tm);
    //G4VPhysicalVolume* p = 
    new G4PVPlacement(t3d,boxLog,finBoxName,
                      physvol->GetLogicalVolume(),
                      0,
                      i);
  }

  //Fin ( Install fins into FinBOX )
  const G4String finName = GetName()+"Fin";
  G4Material* finMat = G4Material::GetMaterial(fMatRidge);
  G4double dx,dy,dz;
  G4double x,y,z;
  G4double dzBox = boxDz;
  G4int fNfin = fzFin.size();

  //Modified by Y.maeda (2012/06/26)
  //G4int zFinZeo=0.;  ( Bugfix. T.Aso 2012/12/22 )
  G4double zFinZeo=0.;
  for (G4int i = 0; i < fNfin; i++){
    dx = boxDx-fxFin[i];
    dy = boxDy;
    if(i>0) zFinZeo=fzFin[i-1];
    dz = (fzFin[i]-zFinZeo)/2.;
    x  = fxFin[i]+dx-boxDx;
    y  = 0.*mm;
    z  = (fzFin[i]-dz-dzBox);
    //
    G4VSolid* finSolid = new G4Box(finName,dx,dy,dz);
    G4LogicalVolume* finLog = new G4LogicalVolume(finSolid,finMat,finName);
    //G4VPhysicalVolume* finPhys = 
    new G4PVPlacement(0,G4ThreeVector(x,y,z),finLog,finName,
                      boxLog,false,0);
    //G4cout << i << " " << finName 
    //       << " dxyz " << dx <<" "<<dy<<" "<<dz
    //       << " xyz  " << x  <<" "<<y<<" "<<z
    //       << G4endl;
  }  
}

