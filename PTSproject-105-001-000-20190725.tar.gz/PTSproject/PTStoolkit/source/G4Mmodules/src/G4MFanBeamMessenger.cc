//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
//
//---------------------------------------------------------------------
//  G4MFanBeamMessenger
//
//  (HISTROY)
//   T.ASO updated with the help of Y.Jizou.
//   2013-03-30 T.Aso PhysicalConstants/SystemOfUnits.
//
//---------------------------------------------------------------------
//

#include "G4MFanBeamMessenger.hh"
#include "G4MFanBeam.hh"
#include "G4ParticleDefinition.hh"
#include "G4Proton.hh"
#include "G4ThreeVector.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4ParticleTable.hh"

#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include <sstream>
#include <fstream>

G4MFanBeamMessenger::G4MFanBeamMessenger(G4MFanBeam * fPtclGun)
  :fParticleGun(fPtclGun)
{
  gunDirectory = new G4UIdirectory("/G4M/FanBeam/");
  gunDirectory->SetGuidance("Beam Gun control commands.");

  gausSpotCmd = new G4UIcmdWithABool("/G4M/FanBeam/gaussSpot",this);
  gausSpotCmd->SetGuidance("Gaussian beam position around origin");
  gausSpotCmd->SetParameterName("gaussSpot",false);
  gausSpotCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  radiusCmd = new G4UIcmdWithADoubleAndUnit("/G4M/FanBeam/radius",this);
  radiusCmd->SetGuidance("Set Radius");
  radiusCmd->SetParameterName("mm",false);
  radiusCmd->SetDefaultUnit("r");
  radiusCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  thetaCmd = new G4UIcmdWithADoubleAndUnit("/G4M/FanBeam/theta",this);
  thetaCmd->SetGuidance("Set theta");
  thetaCmd->SetParameterName("theta",false);
  thetaCmd->SetDefaultUnit("deg");
  thetaCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  zCmd = new G4UIcmdWithADoubleAndUnit("/G4M/FanBeam/z",this);
  zCmd->SetGuidance("Set z");
  zCmd->SetParameterName("z",false);
  zCmd->SetDefaultUnit("mm");
  zCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  phiCmd = new G4UIcmdWithADoubleAndUnit("/G4M/FanBeam/phi",this);
  phiCmd->SetGuidance("Set phi");
  phiCmd->SetParameterName("phi",false);
  phiCmd->SetDefaultUnit("deg");
  phiCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  eflucCmd = new G4UIcmdWithADoubleAndUnit("/G4M/Beam/energyfluc",this);
  eflucCmd->SetGuidance("Set Energy fluctuation of the Beam.");
  eflucCmd->SetParameterName("dE",false);
  eflucCmd->SetDefaultUnit("MeV");
  eflucCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // set initial value to G4MBeamGun
  fParticleGun->SetParticleDefinition( G4Proton::Proton() );
  fParticleGun->SetParticleMomentumDirection( G4ThreeVector(0.0,0.0,-1.0) );
  fParticleGun->SetParticleEnergy( 200.0*MeV );
  fParticleGun->SetParticlePosition(G4ThreeVector(0.*cm, 0.*mm, 3000.0*mm));
  fParticleGun->SetParticleTime( 0.0*ns );
  fParticleGun->SetGaussSpot(true);
}

G4MFanBeamMessenger::~G4MFanBeamMessenger()
{
  delete gausSpotCmd;
  delete radiusCmd;
  delete thetaCmd;
  delete zCmd;
  delete phiCmd;
  delete eflucCmd;
  delete gunDirectory;
}

void G4MFanBeamMessenger::SetNewValue(G4UIcommand * command,G4String newValues)
{
  if( command==gausSpotCmd ){
    fParticleGun->SetGaussSpot(gausSpotCmd->GetNewBoolValue(newValues));
  }else if( command==eflucCmd ){ 
    fParticleGun->SetEnergyFluctuation(eflucCmd->GetNewDoubleValue(newValues));
  }else if ( command==radiusCmd ){
    fParticleGun->SetRadius(radiusCmd->GetNewDoubleValue(newValues));
  }else if ( command==thetaCmd ){
    fParticleGun->SetTheta(thetaCmd->GetNewDoubleValue(newValues));
  }else if ( command==zCmd ){
    fParticleGun->SetZ(zCmd->GetNewDoubleValue(newValues));
  }else if ( command==phiCmd ){
    fParticleGun->SetPhi(phiCmd->GetNewDoubleValue(newValues));
  }
}

G4String G4MFanBeamMessenger::GetCurrentValue(G4UIcommand * )
{
  G4String cv="";
  return cv;
}


