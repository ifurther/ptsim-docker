//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for BoxMonitor
// 
//  (History)
//   06-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
//
#include "G4MBoxMonitorFileCatalogue.hh"
#include "G4MBoxMonitor.hh"
#include <fstream>

G4MBoxMonitorFileCatalogue::
G4MBoxMonitorFileCatalogue(const G4String& name,
			    const G4String& fileName)
  :G4MVBoxMonitorCatalogue(name),fDefaultFileName(fileName),fVerbose(0){
}

G4MBoxMonitorFileCatalogue::~G4MBoxMonitorFileCatalogue()
{}

void G4MBoxMonitorFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fDx,fDy,fDz,fMaterial,fZ,fMasterMat);
}

void G4MBoxMonitorFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File not found "+pname;
    G4Exception("G4MBoxMonitorFileCatalogu::Prepare","G4MBoxMonFileCata00",
		FatalException,msg);
  }else{
    G4int nPlate = 0;
    // Master Volume's Material.
    fileio >> fMasterMat >> nPlate;
    fDx.clear();
    fDy.clear();
    fDz.clear();
    fMaterial.clear();
    fZ.clear();
    G4double Dx,Dy,Dz,z;
    G4String mat;
    if (fVerbose > 0 ) G4cout << fMasterMat << " " << nPlate <<G4endl;
    for ( G4int i = 0; i < nPlate; i++){
      fileio >> mat >> Dx >> Dy >> Dz >> z ;
      if ( fVerbose > 0 ) {
	G4cout << mat <<" "<<Dx<<" "<<Dy<<" "<<Dz<<" "<<z<<G4endl;
      }
      Dx   *= (mm/2.);
      Dy   *= (mm/2.);
      Dz   *= (mm/2.);  // Full width to half width.
      z    *= mm;
      fDx.push_back(Dx);
      fDy.push_back(Dy);
      fDz.push_back(Dz);
      fMaterial.push_back(mat);
      fZ.push_back(z);
    }
  }
}

void G4MBoxMonitorFileCatalogue::Apply(){
  fModule->SetAllParameters(fDx,fDy,fDz,fMaterial,fZ,fMasterMat);
  fModule->ReBuild();
}
