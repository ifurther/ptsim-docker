//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Wobbler Magnet
// 
//  (History)
//   22-Jan-07   T.Aso
//   16-Feb-09   T.Aso B-field calculation for carbonion.
//
//---------------------------------------------------------------------
//
#include "globals.hh"
#include "G4MWobblerFileCatalogue.hh"
#include "G4MWobblerMagnet.hh"
#include "G4MWobblerFieldX.hh"
#include "G4MWobblerFieldY.hh"
//
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"
#include "G4NucleiProperties.hh"
#include "G4ParticleDefinition.hh"
#include <fstream>

G4MWobblerFileCatalogue::G4MWobblerFileCatalogue(const G4String& name,
                                                     const G4String& fileName)
  :G4MVWobblerMagnetCatalogue(name),fDefaultFileName(fileName){
}

G4MWobblerFileCatalogue::~G4MWobblerFileCatalogue()
{}

void G4MWobblerFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  G4MVWobblerField* field = NULL;
  if ( fRasterDir.y() > 0. )  field = new G4MWobblerFieldX(fFieldValue,0.*deg);
  else if(fRasterDir.x() >0.) field = new G4MWobblerFieldY(fFieldValue,0.*deg);
  else G4cout << "@@@ G4MWobblerFileCatalogue: Has no field. ! "<<G4endl; 
  fModule->SetAllParameters(fMatFrame,fDxyzframe,fMatfield,fDxyzfield,field);
  fModule->SetTranslation(G4ThreeVector(0.,0.,fPositionZ));
}

void G4MWobblerFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio;
  G4String filename = pname;
  fileio.open(filename.c_str());  //file open
  if(!fileio) { 
     G4String mes = "File Not Found " + pname;
     G4Exception("G4MWobblerFileCatalogue::Prepare()","G4MWobblerFileCata00",
                 FatalException,mes);
  }

    G4double dx,dy,dz;
    fileio >> dx >> dy >> dz;  // Full size of Frame
    //G4cout  <<  dx << dy <<dz;  // Full size of Frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    dz *= ( mm/2. );
    fDxyzframe.setX(dx);
    fDxyzframe.setY(dy);
    fDxyzframe.setZ(dz);
    
    fileio>>   fMatFrame;       // Material of Frame

    G4double dxx,dyy,dzz;
    fileio >> dxx >> dyy >> dzz;  // Full size of Gap
    dxx *= ( mm/2. );
    dyy *= ( mm/2. );
    dzz *= ( mm/2. );
    fDxyzfield.setX(dxx);
    fDxyzfield.setY(dyy);
    fDxyzfield.setZ(dzz);

    fileio>>   fMatfield;       // Material of Field

    // Particle ID ,  Energy,   Position
    fileio >> fParticleID >>  fParticleE  >>  fPositionZ;
    fParticleE *= MeV;
    fPositionZ  *= mm;

    fileio >> fRadius ;       // Wobbling Radius
    fRadius *= mm;

    G4double dirX,dirY;
    fileio >> dirX >> dirY ;  // Raster Direction
    fRasterDir.setX(dirX);
    fRasterDir.setY(dirY);
    fRasterDir.setZ(0.0);

    //
    G4double mass   = 0.0;
    G4double charge = 0.0;
    //
    G4ParticleDefinition* pdef = 
        G4ParticleTable::GetParticleTable()->FindParticle(fParticleID);
    if ( !pdef ) {
      G4int Z,A,J;
      G4double E;
      if( G4IonTable::GetNucleusByEncoding(fParticleID,Z,A,E,J) ){
      mass   = G4NucleiProperties::GetNuclearMass(A,Z);
      charge = Z;
      }else{
     G4Exception("G4MWobblerFileCatalogue::Prepare()","G4MWobblerFileCata00",
                 FatalException,"WobblerFileCatalogue unknown particle");
      }
    }else{
      mass   = pdef->GetPDGMass();
      charge = pdef->GetPDGCharge();
    }

    if (fParticleE > 0. ){
        G4double mom  = sqrt((fParticleE+mass)*(fParticleE+mass)-mass*mass);
        //fFieldValue = 
        //    mom/charge/(fDxyzfield.z()*2.0)
        //    *fRadius/sqrt(fPositionZ*fPositionZ+fRadius*fRadius);
        G4double sintheta = 
          fRadius/sqrt(fRadius*fRadius+fPositionZ*fPositionZ);
        //** Simple p = 0.3 B rho ( for proton )
        fFieldValue = 
            (mom/MeV)/0.3/(charge/eplus)*sintheta/(fDxyzfield.z()*2./mm)*tesla;
        //G4cout<<" mom " << mom/MeV << " MeV" << G4endl;
        //G4cout<<" dz x2  " << fDxyzfield.z()*2./mm<< " mm"<<G4endl;
        //G4cout<<" r   " << fRadius/mm << " mm"<<G4endl;
        //G4cout<<" posZ "<<fPositionZ/mm <<" mm"<<G4endl;
        //G4cout<<" sin " <<fRadius/sqrt(fPositionZ*fPositionZ+fRadius*fRadius)
        //<<G4endl;
    }else {
        fFieldValue = 0.0;
    }

    //G4cout << " FieldValue " << fFieldValue/tesla << " tesla "<<G4endl;

    fileio.close();
}

void G4MWobblerFileCatalogue::Apply(){
  G4MVWobblerField* field = fModule->GetMagField();  
  if (field ) {
    field->SetAmplitude(fFieldValue);
  }else{
    G4cout << "@@@ G4MWobblerFileCatalogue: Has no field. ! "<<G4endl; 
  }
  fModule->SetAllParameters(fMatFrame,fDxyzframe,fMatfield,fDxyzfield,field);
  fModule->SetTranslation(G4ThreeVector(0.,0.,fPositionZ));
  fModule->ReBuild();
}
