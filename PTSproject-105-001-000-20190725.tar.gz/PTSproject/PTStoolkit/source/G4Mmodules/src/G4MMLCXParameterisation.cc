//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MMLCXParameterisation
//
//  (HISTORY)
//  2013-03-30 T.Aso PhysicalConstants/SystemOfUnits.
//  2017-02-20 T.Aso Change Exception from waring to fatal.
//
//---------------------------------------------------------------------
//

#include "G4MMLCXParameterisation.hh"

#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"


G4MMLCXParameterisation::G4MMLCXParameterisation(G4int nleafpair, 
                                               G4double dxleaf,
                                               G4double dyleaf,
                                               G4double dzleaf,
                                               G4double y0leaf,
                                               G4Material* mat):
  fNofVolume(0),fNLeafPair(nleafpair),
  fdxLeaf(dxleaf),fdyLeaf(dyleaf),fdzLeaf(dzleaf), 
  fy0(y0leaf),fmat(mat)
{
  fpX.clear();
  fpY.clear();
  fBlockDX.clear();
  fBlockDY.clear();
}

G4MMLCXParameterisation::~G4MMLCXParameterisation(){
  fpX.clear();
  fpY.clear();
  fBlockDX.clear();
  fBlockDY.clear();
}

void G4MMLCXParameterisation::
CalculateActiveVolume(std::vector<G4double>& xval, G4ThreeVector& dxyzFrame){
  CalculateActiveVolume(xval);
  AddBlock(dxyzFrame);
}

void G4MMLCXParameterisation::CalculateActiveVolume(std::vector<G4double>& xval){

  // xval represents a set of leaf position.
  // Leaf positions are given ...
  // xval is  from -x,-y to -x,+y, then +x,-y to +x,+y.
  fNofVolume = fNLeafPair*2;
  if ( (G4int)xval.size() != fNofVolume ) {
    G4cout << " MLCXParam:: xval.size() " << xval.size()
           <<" nleafpair " << fNofVolume <<G4endl;
    const G4String& msg =
      "G4MMLCXParameterisation::Xvalues: Size Length Missmatch";
    G4Exception("G4MMLCParameterisation::CalculateActiveVolume()",
                "G4MMLCPara00",FatalException,msg);
  }

  fpX.resize(fNofVolume);
  fpY.resize(fNofVolume);
  fBlockDX.clear();
  fBlockDY.clear();

  //
  // A leaf size is give by fdxLeaf,fdyLeaf,fdzLeaf
  //       Numbering of leaf for leaf position.
  //   +Y
  //    |__ +X 
  //             nyleaf-1   2*nyleaf-1
  //                .         .
  //                .         .
  //                2       nyleaf+2
  //                1       nyleaf+1
  //                0       nyleaf+0
  //
  for ( G4int i = 0; i < fNofVolume ; i++) {
    if ( i < fNLeafPair ) {
      fpX[i]= -fdxLeaf+xval[i];
      fpY[i]= fy0 + (i%fNLeafPair)*fdyLeaf*2.;
    }else{
      fpX[i]= +fdxLeaf+xval[i];
      fpY[i]= fy0 + (i%fNLeafPair)*fdyLeaf*2.;
    }
  }
}

G4int G4MMLCXParameterisation::GetNofActiveVolume(){ return fNofVolume; }

void G4MMLCXParameterisation::AddBlock(G4ThreeVector& dxyzFrame){
  //
  // Add two components for Upside and Downside Blocks.
  //
  fBlockDX.clear();
  fBlockDY.clear();
  //
  fNofVolume += 2;
  //
  //----- Blok upside SIZE
  G4double yUp = fy0+fdyLeaf*(2.*fNLeafPair-1.); // 
  G4double yDw = fy0-fdyLeaf;  // 
  G4double yUpDy =  (dxyzFrame.y()-yUp)/2.; // Y Half Thickness for Upside.
  G4double yDwDy =  (dxyzFrame.y()+yDw)/2.; // Y Half Thickness for Dwside.
  G4double yUpPy =  dxyzFrame.y()-yUpDy; // Y coordinate for Upside.
  G4double yDwPy = -dxyzFrame.y()+yDwDy; // Y coordinate for Upside.
  //----- Upside Block 
  fBlockDX.push_back(dxyzFrame.x());
  fBlockDY.push_back(yUpDy);
  fpX.push_back(0.0);
  fpY.push_back(yUpPy);
  //----- Downside Block 
  fBlockDX.push_back(dxyzFrame.x());
  fBlockDY.push_back(yDwDy);
  fpX.push_back(0.0);
  fpY.push_back(yDwPy);
}

void G4MMLCXParameterisation::ComputeDimensions(G4Box & aBox,
                                                const G4int copyNo,
                                                const G4VPhysicalVolume* )const
{
  if ( copyNo < (fNLeafPair*2) ) {
    aBox.SetXHalfLength(fdxLeaf);
    aBox.SetYHalfLength(fdyLeaf);
    aBox.SetZHalfLength(fdzLeaf);
  }else { // -- AddBlock -- Two additional blocks at Up and Down side.
    aBox.SetXHalfLength(fBlockDX[copyNo-fNLeafPair*2]);
    aBox.SetYHalfLength(fBlockDY[copyNo-fNLeafPair*2]);
    aBox.SetZHalfLength(fdzLeaf);
  }
}

void G4MMLCXParameterisation::ComputeTransformation
(const G4int copyNo,  G4VPhysicalVolume* physVol)const{
  G4ThreeVector position(fpX[copyNo],fpY[copyNo],0.*mm);
  physVol->SetTranslation(position);
}

G4Material* G4MMLCXParameterisation::ComputeMaterial(const G4int,
                                                     G4VPhysicalVolume*,
                                                     const G4VTouchable*){
  return fmat;
}


