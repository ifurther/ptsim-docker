//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  Created by T.Aso 2016-01-17
// 2017-03-31 T.Aso commands inclding the module name.
//
//
//---------------------------------------------------------------------
//
#include "G4MBoxDetectorMessenger.hh"
#include "G4MBoxDetector.hh"
#include "G4Tokenizer.hh"

G4MBoxDetectorMessenger::G4MBoxDetectorMessenger(const G4String& mname, G4MBoxDetector* det)
  :fDET(det) {

  G4String dname  = "/G4M/Module/BoxDetector/";
  dname.append(mname);
  dname.append("/");
  //fDir = new G4UIdirectory("/G4M/Module/BoxDetector/");
  fDir = new G4UIdirectory(dname);
  fDir->SetGuidance("UI commands for modules");

  //
  // BoxDetector
  //
  
  // edep flag.
  const G4String BEdep = dname+"edep";
  //fCmdBEdep = new G4UIcmdWithABool("/G4M/Module/BoxDetector/edep",this);
  fCmdBEdep = new G4UIcmdWithABool(BEdep,this);
  fCmdBEdep->SetGuidance("BoxDetector Edep flag");
  fCmdBEdep->SetGuidance("Usage: /G4M/Module/BoxDetctor <flag:b>");
  fCmdBEdep->SetGuidance("flag==false, skip steps if no energy deposit.");
  fCmdBEdep->SetParameterName("EdepFlag",false);
  fCmdBEdep->AvailableForStates(G4State_Init,G4State_Idle);

  // SetDepth
  const G4String Depth = dname+"setDepth";
  //fCmdDepth = new G4UIcommand("/G4M/Module/BoxDetector/setDepth",this);
  fCmdDepth = new G4UIcommand(Depth,this);
  fCmdDepth->SetGuidance("Set geometrical depth for indecs");
  fCmdDepth->SetGuidance("Usage: /G4M/Module/BoxDetector/setDepth ix iy iz im is");
  fCmdDepth->SetGuidance("im and is are omittable. default  0");
  G4UIparameter* param;
  param = new G4UIparameter("ixDepth",'i',false);
  fCmdDepth->SetParameter(param);
  param = new G4UIparameter("iyDepth",'i',false);
  fCmdDepth->SetParameter(param);
  param = new G4UIparameter("izDepth",'i',false);
  fCmdDepth->SetParameter(param);
  param = new G4UIparameter("imDepth",'i',true);
  param->SetDefaultValue(0);
  fCmdDepth->SetParameter(param);
  param = new G4UIparameter("isDepth",'i',true);
  param->SetDefaultValue(0);
  fCmdDepth->SetParameter(param);

}

G4MBoxDetectorMessenger::~G4MBoxDetectorMessenger() {
  if (fCmdBEdep ) delete fCmdBEdep;
  if (fCmdDepth ) delete fCmdDepth;
  if (fDir) delete fDir;
}

void G4MBoxDetectorMessenger::SetNewValue(G4UIcommand* command, 
                                           G4String newValue) {
 if ( command == fCmdBEdep ){
   fDET->SetBEdep(fCmdBEdep->GetNewBoolValue(newValue));
 } else if ( command == fCmdDepth ) {
   G4Tokenizer next(newValue);
   G4int idx = StoI(next());
   G4int idy = StoI(next());
   G4int idz = StoI(next());
   G4int idm = StoI(next());
   G4int ids = StoI(next());
   fDET->SetDepth(idx,idy,idz,idm,ids);
 }
}

G4String G4MBoxDetectorMessenger::GetCurrentValue(G4UIcommand* command) {
  return G4String("I do not know,"+command->GetCommandName());
}
