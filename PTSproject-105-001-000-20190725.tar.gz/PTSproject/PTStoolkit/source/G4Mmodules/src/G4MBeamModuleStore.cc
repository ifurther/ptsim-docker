//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
// -----------------------------------------------------------------
// (Class Description)
//  G4MBeamModuleStore:
//    Collection class for beam modules.
//
// 05 Oct. 2005 T.Aso
// 07 Dec. 2007 T.Aso introduce a flag at Get() method for suppressing
//                   warning about non-existing modules.
// 10 Aug. 2010 T.Aso Introduce Remove() method.
// 14 Mar. 2012 T.Aso Add Get(G4int i),GetName(), GetNumMudule().
// 2013-03-27   T.Aso ModuleListInWorld() for checking if mass/paralell
//                    geometry is used.
// 2013-03-30  T.Aso SystemOfUnits/PhysicsConstants.
// 2013-10-24   T.Aso SetLang()
// 2014-03-11   T.Aso fVerbose.
// 2014-03-11   T.Aso Revise List().
// 2015-12-14   T.Aso Revise List(). one space character was inserted.
// 2017-04-03   T.Aso Suppress debug outputs.
// -----------------------------------------------------------------
//
#include "G4MBeamModuleStore.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include <iomanip>

G4MBeamModuleStore::G4MBeamModuleStore() {
  fVerbose = 0;
}

G4MBeamModuleStore::~G4MBeamModuleStore() {
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    if ( fVerbose > 0 ) {
      G4cout <<"****  Deleting Module " << itr->first << G4endl;
    }
    delete itr->second;
  }
  theModules.clear();
  if ( fVerbose > 0 ) {
    G4cout <<"****  G4MBeamModuleStore Cleared " << G4endl;
  }
}

void G4MBeamModuleStore::Add(G4String name, G4MVBeamModule* module) {
  theModules.insert(
     std::map<G4String,G4MVBeamModule*>::value_type(name,module)
  );
}

G4MVBeamModule* G4MBeamModuleStore::Get(G4String name, G4bool quiet) {
  G4MVBeamModule* retObj=0;
  std::map<G4String,G4MVBeamModule*>::iterator itr=theModules.find(name);
  if ( itr != theModules.end() ) retObj = (*itr).second;
  else {
    if ( !quiet ){
      G4cout << "@@@@@ G4MBeamModuleStore:: No Configuration found  @@@"
             <<name<<G4endl;
    }
    retObj = NULL;
  }
  return retObj;
}

G4MVBeamModule* G4MBeamModuleStore::Get(G4int i) {
  G4int n = 0;
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    if ( i == n ) {
      if ( fVerbose > 0 ) {
        G4cout <<"* Module " << std::setw(20)<<std::left << itr->first << G4endl;
      }
      return itr->second;
    }
    n++;
  }
  return NULL;
}

G4String G4MBeamModuleStore::GetName(G4int i) {
  G4int n = 0;
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    if ( i == n ) {
      return itr->first;
    }
    n++;
  }
  return "";;
}

void G4MBeamModuleStore::ModuleList(G4int lvl, std::ostream& out) {
  //
  G4LogicalVolume* roomLV = Get("Room")->GetPhysicalVolume()->GetLogicalVolume();
  //
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    out <<"* Module " << std::setw(15)<<std::left << itr->first << "\t";
    const G4VPhysicalVolume* pv =  (itr->second)->GetPhysicalVolume() ;
    if ( pv ) {
      out << std::setw(10) << " Active ";
    }else {
      out << std::setw(10) << " Inactive ";
    }
    //
    if ( pv && lvl == 1 ) {
      if ( roomLV && (roomLV == pv->GetLogicalVolume() || roomLV->IsDaughter(pv) )){
        out << " Mass-Geom ";
      }else{
        out << " "<<pv->GetMotherLogical()->GetName()<<" ";
      }
    }
    //
    if ( lvl > 1 ) {
      const G4ThreeVector& t = (itr->second)->GetTranslation();
      const G4ThreeVector& d = (itr->second)->GetEnvelopeSize();
      out << " Center: " ;
      out << std::setw(5)<< t.x()/mm<<" ";
      out << std::setw(5)<< t.y()/mm<<" ";
      out << std::setw(8)<< t.z()/mm<<" ";
      out << " width: " ;
      out << std::setw(5)<< d.x()/mm<<" ";
      out << std::setw(5)<< d.y()/mm<<" ";
      out << std::setw(8)<< d.z()/mm<<" ";
      out << " mm";
    }
    G4cout << G4endl;
  }
}

void G4MBeamModuleStore::ModuleListInWorld(G4LogicalVolume* worldLV, std::ostream& out) {
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    const G4VPhysicalVolume* pv = (itr->second)->GetPhysicalVolume();
    if ( pv ) {
      if ( worldLV->IsDaughter(pv) ){
                  out <<"* Module " << std::setw(15)<<std::left << itr->first<<G4endl;
      }
    }
  }
}

G4int G4MBeamModuleStore::NumModule() {
  return (G4int)theModules.size();
}

void G4MBeamModuleStore::Clear() {
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    G4cout <<"****  Deleting Module " << itr->first << G4endl;
    delete itr->second;
  }
  theModules.clear();
    G4cout <<"****  G4MBeamModuleStore Cleared " << G4endl;
}

void G4MBeamModuleStore::Remove(const G4String& name) {
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    if ( itr->first == name ) {
      G4cout <<"****  Deleting Module " << itr->first << G4endl;
      theModules.erase(itr);
      //delete itr->second;
      break;
    }
  }

}

void G4MBeamModuleStore::SetLang(G4int l) {
  std::map<G4String,G4MVBeamModule*>::iterator itr;
  for ( itr=theModules.begin(); itr !=theModules.end(); itr++){
    (itr->second)->SetLang(l);
  }
}
