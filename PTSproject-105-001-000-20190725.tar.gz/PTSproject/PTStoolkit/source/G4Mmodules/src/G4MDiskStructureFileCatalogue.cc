//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for DiskStructure
// 
//  (History)
//   06-Oct-05   T.Aso
//
//
//---------------------------------------------------------------------
//
#include "G4MDiskStructureFileCatalogue.hh"
#include "G4MDiskStructure.hh"
#include <fstream>

G4MDiskStructureFileCatalogue::
G4MDiskStructureFileCatalogue(const G4String& name,
                              const G4String& fileName)
  :G4MVDiskStructureCatalogue(name),fDefaultFileName(fileName){
}

G4MDiskStructureFileCatalogue::~G4MDiskStructureFileCatalogue()
{}

void G4MDiskStructureFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fRout,fDz,fZ,fMaterial);
}

void G4MDiskStructureFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File Not Found " + pname ; 
    G4Exception("G4MDiskStructureFileCatalogue::Prepare()",
                "G4MDiskStructFileCata00",FatalException,msg);
  }else{
    G4int nPlate = 0;
    // Master Volume's Material.
    fileio >> nPlate;
    fRout.clear();
    fDz.clear();
    fMaterial.clear();
    fZ.clear();
    G4double rout,dz,z;
    G4String mat;
    for ( G4int i = 0; i < nPlate; i++){
      fileio >> mat >> rout >> dz >> z ;
      //G4cout << mat <<" "<<rout<<" "<<dz<<" "<<z<<G4endl;
      rout *= mm;
      dz   *= (mm/2.);  // Full width to half width.
      z    *= mm;
      fRout.push_back(rout);
      fDz.push_back(dz);
      fMaterial.push_back(mat);
      fZ.push_back(z);
    }
  }
}

void G4MDiskStructureFileCatalogue::Apply(){
  fModule->SetAllParameters(fRout,fDz,fZ,fMaterial);
  fModule->ReBuild();
}
