//
//
//

#include "G4MVRoomCatalogue.hh"


G4MVRoomCatalogue::G4MVRoomCatalogue(const G4String& name)
  :G4MVParamCatalogue(name){}

 
