//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MWireMonitor
//
// (HISTORY)
//   06-Oct-05   T.Aso
//   22-Jan-07   T.Aso Add VisAttributes
//          
// -----------------------------------------------------------------          
//                    
#include "G4MWireMonitor.hh"

#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Material.hh"
#include "G4MVWireMonitorCatalogue.hh"
#include "G4RotationMatrix.hh"
#include "G4VisAttributes.hh"

G4MWireMonitor::G4MWireMonitor(const G4String& name,
		   const std::vector<G4String>&      MatElm,
		   const std::vector<G4ThreeVector>& DxyzElm,
		   const std::vector<G4double>&      ZElm,
		   const std::vector<G4int>&         NWire,
		   const std::vector<G4double>&      SlantWire,
		   const std::vector<G4double>&      PitchWire,
		   const std::vector<G4String>&      MatWire,
		   const std::vector<G4double>&      DrWire,
		   const std::vector<G4double>&      DzWire,
		   const std::vector<G4double>&      ZWire,
		   const G4String&                   MatMaster )
    :G4MVMonitor(name),fCatalogue(NULL){
  SetAllParameters(MatElm,DxyzElm,ZElm,NWire,
		   SlantWire,PitchWire,MatWire,DrWire,DzWire,ZWire,MatMaster);
}

G4MWireMonitor::G4MWireMonitor(const G4String& name)
  :G4MVMonitor(name),fCatalogue(NULL){
}

G4MWireMonitor::G4MWireMonitor(G4MVWireMonitorCatalogue* catalogue)
  :G4MVMonitor(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MWireMonitor::~G4MWireMonitor() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MWireMonitor::ApplyFromCatalogue(G4String& newValue) {
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MWireMonitor::
SetAllParameters(const std::vector<G4String>& MatElm,
		 const std::vector<G4ThreeVector>& DxyzElm,
		 const std::vector<G4double>&      ZElm,
		 const std::vector<G4int>&         NWire,
		 const std::vector<G4double>&      SlantWire,
		 const std::vector<G4double>&      PitchWire,
		 const std::vector<G4String>&      MatWire,
		 const std::vector<G4double>&      DrWire,
		 const std::vector<G4double>&      DzWire,
		 const std::vector<G4double>&      ZWire,
		 const G4String&                   MatMaster ){
  // Initialize parameters.
    fMatElm  =     MatElm;
    fDxyzElm =     DxyzElm;
    fZElm =     ZElm ; 
    fNWire = NWire;
    fSlantWire = SlantWire;
    fPitchWire = PitchWire;
    fMatWire = MatWire;
    fDrWire= DrWire;
    fDzWire = DzWire;
    fZWire = ZWire;
    fMatMaster = MatMaster;


  // search for smallest/biggest one
  G4double xmaximum = DBL_MIN;
  G4double ymaximum = DBL_MIN;
  G4double zminimum = DBL_MAX;
  G4double zmaximum = DBL_MIN;
  G4int N = fZElm.size();
  for ( G4int i = 0; i < N; i++){
    if ( fDxyzElm[i].x() > xmaximum ) xmaximum = fDxyzElm[i].x(); 
    if ( fDxyzElm[i].y() > ymaximum ) ymaximum = fDxyzElm[i].y(); 
    if ( ( fZElm[i]+fDxyzElm[i].z() ) > zmaximum ) {
      zmaximum = fZElm[i]+fDxyzElm[i].z(); 
    }
    if ( ( fZElm[i]-fDxyzElm[i].z() ) < zminimum ) {
      zminimum = fZElm[i]-fDxyzElm[i].z(); 
    }
  }
  fEnvelopeSize.set(xmaximum, ymaximum, (zmaximum-zminimum)/2.);
  fZOffsetMaster = (zmaximum+zminimum)/2.;
}

G4VPhysicalVolume* G4MWireMonitor::buildEnvelope(G4LogicalVolume* worldlog) {
  // --- Master Volume 
  //
  G4Material* matMaster = G4Material::GetMaterial(fMatMaster);
  G4VSolid* solMaster   = new G4Box(GetName(),
				    fEnvelopeSize.x(),
				    fEnvelopeSize.y(),
				    fEnvelopeSize.z());
  G4LogicalVolume* logMaster = new G4LogicalVolume(solMaster,
						   matMaster,
						   GetName());
  logMaster->SetVisAttributes(new G4VisAttributes(G4Colour(0.0,1.0,0.0)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(
  		      GetRotation(),
		      GetTranslation(),
		      logMaster,       
                      GetName(),       
		      worldlog,    
		      false,       
		      0);          
  return physical;
}

void G4MWireMonitor::buildNode(G4VPhysicalVolume* physvol) {
  //---  Component inside Master Volume ---

    // Windows
  G4int nCom = fZElm.size();
  for (G4int i = 0; i < nCom ; i++){
    G4Material* matCom = G4Material::GetMaterial(fMatElm[i]);
  if (matCom==NULL) G4cout << fMatElm[i] << G4endl;
    G4String comName = fMatElm[i]+i;
    G4VSolid* solCom = 
	new G4Box(comName,fDxyzElm[i].x(),fDxyzElm[i].y(),fDxyzElm[i].z());
    G4LogicalVolume* logCom = new G4LogicalVolume(
				 solCom,            
                                 matCom,            
				 comName            
				 );        
    logCom->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));
    G4double z = fZElm[i] - fZOffsetMaster;
    //G4VPhysicalVolume* phyCom  = 
	new G4PVPlacement(
			  0,                        
			  G4ThreeVector(0.,0.,z), 
			  logCom,                 
			  comName,                
			  physvol->GetLogicalVolume(),
			  false,                      
			  0);                
  } 
  
  // Wire
  G4int nLayer = fNWire.size();
  for ( G4int il = 0; il<nLayer; il++){
      G4Material* matCom = G4Material::GetMaterial(fMatWire[il]);
      if (matCom==NULL) G4cout << fMatWire[il] << G4endl;
      G4String comName = fMatWire[il]+il;
      G4VSolid* solCom = 
	  new G4Tubs(comName,0., fDrWire[il], fDzWire[il],0.,twopi);
      G4LogicalVolume* logCom = new G4LogicalVolume(
	  solCom,                
	  matCom,                
	  comName            
	  );        
      logCom->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,0.0)));

      G4double z = fZWire[il] - fZOffsetMaster;
      G4RotationMatrix* rotM = new G4RotationMatrix();
      rotM->rotateX(90.*degree);
      rotM->rotateY(fSlantWire[il]);
      G4double stX=0.0;
      G4double stY=0.0;
      for (G4int i = 0; i < fNWire[il] ; i++){
	  G4double pos =
	    -fNWire[il]*fPitchWire[il]/2.+fDrWire[il]/2.+fPitchWire[il]*i;
	  if ( fSlantWire[il] >0. ) stY = pos;
	  else stX = pos;
	  //G4VPhysicalVolume* phyCom  = 
	  new G4PVPlacement(
	      rotM,         
	      G4ThreeVector(stX,stY,z),
	      logCom,                  
	      comName,                 
	      physvol->GetLogicalVolume(),
	      false,                       
	      i);                    
      }
  } 
}

