//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
//---------------------------------------------------------------------
//  G4MFocusGunEdistMessenger
//
//  This is a concrete class of G4UImessenger which handles commands for
// G4MBeamGun.
//
//  (HISTORY)
//   T.ASO Created
//  2013-03-30 T.Aso PhysicalConstants/SystemOfUnits.
//
//---------------------------------------------------------------------
//
//

#include "G4MFocusGunEdistMessenger.hh"
#include "G4MFocusGunEdist.hh"
#include "G4ParticleDefinition.hh"
#include "G4Proton.hh"
#include "G4ThreeVector.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4ParticleTable.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"

#include <sstream>
#include <fstream>

G4MFocusGunEdistMessenger::
G4MFocusGunEdistMessenger(G4MFocusGunEdist * fPtclGun)
  :fParticleGun(fPtclGun)
{
  gunDirectory = new G4UIdirectory("/G4M/Beam/");
  gunDirectory->SetGuidance("Beam Gun control commands.");

  // Energy and Intensity
  energyDistCmd = new G4UIcmdWith3Vector("/G4M/Beam/addEnergy",this);
  energyDistCmd->SetGuidance("Energy-Intensity distribution");
  energyDistCmd->SetGuidance("Energy should be given in MeV.");
  energyDistCmd->SetParameterName("Ehist","Intensity","Dummy",true,true);
  energyDistCmd->SetRange("Ehist >=0. && Intensity >= 0." );
  energyDistCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // Clear Energy and Intensity
  clearCmd = new G4UIcmdWithoutParameter("/G4M/Beam/clear",this);
  clearCmd->SetGuidance("Clear Energy-Intensity distribution");
  clearCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // Samplimg Energy and INtensity 
  sampleCmd = new G4UIcmdWithAnInteger("/G4M/Beam/sample",this);
  sampleCmd->SetGuidance("Number of sampling point for interpolation");
  sampleCmd->SetGuidance("of Energy-intensity distribution.");
  sampleCmd->SetParameterName("nsample",false);
  sampleCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // Energy and Intensity from file
  beamFileCmd = new G4UIcmdWithAString("/G4M/Beam/file",this);
  beamFileCmd->SetGuidance("File name for setting Beam parameters from file");
  beamFileCmd->SetParameterName("FileName",false);
  beamFileCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // Focusing point
  focusDistXCmd = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/FocusDistanceX",this);
  focusDistXCmd->SetGuidance("Foucus point of X in Z");
  focusDistXCmd->SetParameterName("Z-Position",false);
  focusDistXCmd->SetDefaultUnit("mm");
  focusDistXCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  focusDistYCmd = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/FocusDistanceY",this);
  focusDistYCmd->SetGuidance("Foucus point of Y in Z");
  focusDistYCmd->SetParameterName("Z-Position",false);
  focusDistYCmd->SetDefaultUnit("mm");
  focusDistYCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  spExpandXCmd  = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/SpatialExpanseX",this);
  spExpandXCmd->SetGuidance("Sigma of beam for focusing");
  spExpandXCmd->SetParameterName("Expanse of beam in X ",false);
  spExpandXCmd->SetDefaultUnit("mrad");
  spExpandXCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  spExpandYCmd  = 
    new G4UIcmdWithADoubleAndUnit("/G4M/Beam/SpatialExpanseY",this);
  spExpandYCmd->SetGuidance("Sigma of beam for focusing");
  spExpandYCmd->SetParameterName("Expanse of beam in Y ",false);
  spExpandYCmd->SetDefaultUnit("mrad");
  spExpandYCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  // set initial value 
  fParticleGun->SetParticleDefinition( G4Proton::Proton() );
  fParticleGun->SetParticleMomentumDirection( G4ThreeVector(0.0,0.0,-1.0) );
  fParticleGun->SetParticleEnergy( 200.0*MeV );
  fParticleGun->SetParticlePosition(G4ThreeVector(0.*mm, 0.*mm, 3000.0*mm));
  fParticleGun->SetParticleTime( 0.0*ns );
  ///added by takase
  fParticleGun->SetFocusDistanceX( 0.0*mm );
  fParticleGun->SetFocusDistanceY( 0.0*mm );
  fParticleGun->SetSpatialExpanseX( 0.0*mrad );
  fParticleGun->SetSpatialExpanseY( 0.0*mrad );
  //
}

G4MFocusGunEdistMessenger::~G4MFocusGunEdistMessenger()
{
  delete gunDirectory;
  delete beamFileCmd;
  delete energyDistCmd;
  delete clearCmd;
  delete sampleCmd;
  delete focusDistXCmd;
  delete focusDistYCmd;
  delete spExpandXCmd;
  delete spExpandYCmd;
}

void G4MFocusGunEdistMessenger::SetNewValue(G4UIcommand * command,
                                            G4String newValues)
{
  if (command == beamFileCmd ) {
    char chline[512];
    G4String filename = newValues;// newValues should be a exact file name.
    std::ifstream ifs;
    ifs.open(filename.c_str());

    ifs.getline(chline,512);  //energy ID  DUMMY
    ifs.getline(chline,512);  //description DUMMY

    ifs.getline(chline,512);  //particle ID 
    std::istringstream iss1(chline);
    G4int particleID;
    iss1 >> particleID;
    G4ParticleDefinition* pdef = 
      G4ParticleTable::GetParticleTable()->FindParticle(particleID);
    fParticleGun->SetParticleDefinition(pdef);

    ifs.getline(chline,512);  // Number of points for energy-intensity map.
    std::istringstream iss2(chline);
    G4int nbin;
    iss2 >> nbin;

    G4double energy;
    G4double prob;
    fParticleGun->ClearEnergyDist();
    for (G4int i = 0; i < nbin; i++){
      ifs.getline(chline,512);  //particle energy / prob.
      std::istringstream issN(chline);
      issN >> energy >> prob;
      fParticleGun->InsertEnergyDist(energy*MeV,prob);
    }

  }
  else if ( command == energyDistCmd ){
    G4ThreeVector v3 = energyDistCmd->GetNew3VectorValue(newValues);
    fParticleGun->InsertEnergyDist(v3.x()*MeV,v3.y());
  }
  else if ( command == clearCmd ){
    fParticleGun->ClearEnergyDist();
  }
  else if ( command == sampleCmd ){
    fParticleGun->SetSample(sampleCmd->GetNewIntValue(newValues));
  }
  else if ( command == focusDistXCmd ) {
    G4double focus=focusDistXCmd->GetNewDoubleValue(newValues);
    fParticleGun->SetFocusDistanceX(focus);
  }
  else if ( command == focusDistYCmd ) {
    G4double focus=focusDistYCmd->GetNewDoubleValue(newValues);
    fParticleGun->SetFocusDistanceY(focus);
  }
  else if ( command == spExpandXCmd ) {
    G4double expand = spExpandXCmd->GetNewDoubleValue(newValues);
    fParticleGun->SetSpatialExpanseX(expand);
  }
  else if ( command == spExpandYCmd ) {
    G4double expand = spExpandYCmd->GetNewDoubleValue(newValues);
    fParticleGun->SetSpatialExpanseY(expand);
  }
}
G4String G4MFocusGunEdistMessenger::GetCurrentValue(G4UIcommand * )
{
  G4String cv;
  return cv;
}


