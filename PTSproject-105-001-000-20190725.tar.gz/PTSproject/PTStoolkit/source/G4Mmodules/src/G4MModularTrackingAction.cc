//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularTrackingAction.cc,v 1.7 2007/07/05 08:10:24 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularTrackingAction
//
//  06-MAR-09  T.Aso Created
//
//====================================================================

#include "G4MModularTrackingAction.hh"
#include "G4TrackingManager.hh"
#include "G4Track.hh"

G4MModularTrackingAction::G4MModularTrackingAction()
  :G4UserTrackingAction(){
  trackActionVector = new G4MTrackActionConstVector();
  isInitialized = false;
}

G4MModularTrackingAction::~G4MModularTrackingAction(){
  G4MTrackActionConstVector::iterator itr;
  for (itr = trackActionVector->begin(); 
       itr!= trackActionVector->end(); ++itr){
    delete (*itr);
  }
  trackActionVector->clear();
  delete trackActionVector;
}

void G4MModularTrackingAction::PreUserTrackingAction(const G4Track* aTrack)
{
  if ( !isInitialized ){
    G4MTrackActionConstVector::iterator itr;
    for (itr = trackActionVector->begin(); 
	 itr!= trackActionVector->end(); ++itr){
      (*itr)->SetTrackingManagerPointer(fpTrackingManager);   
    }
    isInitialized = true;
  }
  G4MTrackActionConstVector::iterator itr;
  for (itr = trackActionVector->begin(); 
       itr!= trackActionVector->end(); ++itr){
    (*itr)->PreUserTrackingAction(aTrack);
  }
}

void G4MModularTrackingAction::PostUserTrackingAction(const G4Track* aTrack)
{
  G4MTrackActionConstVector::iterator itr;
  for (itr = trackActionVector->begin(); 
       itr!= trackActionVector->end(); ++itr){
    (*itr)->PostUserTrackingAction(aTrack);
  }
}
