//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Bolus Module with Honeycomb holes.
//  (HISTORY)
//   2014-03-10   T.Aso
//   2014-03-11   T.Aso fVerbose.
// 2014-03-31   T.Aso Optimaization of Parameterisation was modified
//                    from fZAxis to fUndefined. Because of error when
//                    installing in parallel world.
// -----------------------------------------------------------------
//
#include "G4MHoneyCombBolus.hh"
#include "G4PVParameterised.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Trd.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MHoneyCombBolus::G4MHoneyCombBolus(const G4String& name, const G4ThreeVector& dxyz, 
                                     const G4String& mat,
                                     G4int nx, G4int ny, 
                                     G4double x0, G4double y0,
                                     G4double pitchx, G4double pitchy, 
                                     std::vector<G4double>& thickvector)
  :G4MVBeamModule(name,dxyz),
   fMatBolus(mat),fNx(nx),fNy(ny),
   fx0(x0),fy0(y0),xdir(1),ydir(1),
   fPitchX(pitchx),fPitchY(pitchy),fFact(0.5),
   theThickVector(thickvector),
   fParameterisation(NULL),fCatalogue(NULL)
{}

G4MHoneyCombBolus::G4MHoneyCombBolus(const G4String& name)
  :G4MVBeamModule(name),xdir(1),ydir(1),fParameterisation(NULL),fCatalogue(NULL)
{}

G4MHoneyCombBolus::G4MHoneyCombBolus(G4MVHoneyCombBolusCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),xdir(1),ydir(1),fParameterisation(NULL),
   fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MHoneyCombBolus::~G4MHoneyCombBolus() {
  theThickVector.clear();
  delete fParameterisation;
  if ( fCatalogue ) delete fCatalogue;
}

void G4MHoneyCombBolus::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MHoneyCombBolus::SetAllParameters(const G4ThreeVector& dxyz,
                                         const G4String& mat,
                                         G4int nx, G4int ny, 
                                         G4double x0, G4double y0,
                                         G4double pitchx, G4double pitchy, 
                                         G4double fac,
                                std::vector<G4double>& thickvector)
{
    SetEnvelopeSize(dxyz);
    fMatBolus=mat;
    fNx=nx;
    fNy=ny;
    fx0=x0;
    fy0=y0;
    fPitchX=pitchx;
    fPitchY=pitchy;
    fFact = fac;
    theThickVector.assign(thickvector.begin(),thickvector.end());
}

void G4MHoneyCombBolus::Dump(std::ostream& out){
  out << fMatBolus <<G4endl;
  out << fNx << G4endl; 
  out << fNy << G4endl; 
    for(G4int iy = 0; iy < fNy; iy++){
      for(G4int ix = 0; ix < fNx; ix++){
        G4int index = iy*fNx+ix;
        out << theThickVector[index];
        if ( ix < fNx-1 ) out<<","; 
      }
      out << G4endl;
    }
}

void G4MHoneyCombBolus::SetNxy(G4int nx, G4int ny) {
  fNx = nx;
  fNy = ny;
}

void G4MHoneyCombBolus::GetNxy(G4int& nx, G4int& ny) {
  nx = fNx;
  ny = fNy;
}

void G4MHoneyCombBolus::SetXYOrigin(G4double x0, G4double y0) {
  fx0 = x0;
  fy0 = y0;
}

void G4MHoneyCombBolus::SetThickVector(std::vector<G4double>& thickVec) {
  theThickVector.assign(thickVec.begin(),thickVec.end());
}

void G4MHoneyCombBolus::SetPitch(G4double xpitch, G4double ypitch) {
  fPitchX = xpitch;
  fPitchY = ypitch;
}

void G4MHoneyCombBolus::GetPitch(G4double& xpitch, G4double& ypitch) {
  xpitch = fPitchX;
  ypitch = fPitchY;
}

G4VPhysicalVolume* G4MHoneyCombBolus::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  if ( fVerbose > 0 ) G4cout << fMatBolus <<G4endl;
  G4Material* mat = G4Material::GetMaterial(fMatBolus);
  //
  G4VSolid* solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,       // Solid 
                                 mat,         // Material
                                 GetName());  // Name

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                      GetRotation(),
                      GetTranslation(),
                      logical,   // Logical volume  
                      GetName(), // Name
                      worldlog,  // Mother  volume 
                      false,     // Not used 
                      0);        // Copy number  

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,0.3,0.3,0.8));
  logical->SetVisAttributes(visAttr);

  return physical;
}

void G4MHoneyCombBolus::buildNode(G4VPhysicalVolume* physvol) {
  //------ Drill Hole
  // dummy values for G4Trd -- will be modified by parameterised volume. 
  const G4String drillName = GetName()+"Drill";
  G4double dx1 = fPitchY/(1.+fFact);
  G4double dx2 = fPitchY-dx1;
  G4double dy1 = GetDZ();
  G4double dy2 = GetDZ();
  G4double dz  = fPitchX/4.;
  G4double xoffset  = fPitchX/2.;
  if ( fVerbose > 0 ) {
    G4cout << "dx1= "<<dx1 <<" dx2= "<<dx2<<" dz= "<<dz <<G4endl;
  }
  //
  G4VSolid* solDrill =  new G4Trd(drillName,dx1,dx2,dy1,dy2,dz);
  //
  G4Material* hole= G4Material::GetMaterial("Air");
  G4LogicalVolume* logDrill = new G4LogicalVolume(solDrill,hole,drillName);
  fParameterisation = 
    new G4MHoneyCombBolusParameterisation(fNx,fNy,fPitchX,fPitchY,GetDZ()*2,
                                          fx0,fy0,xoffset,hole,xdir,ydir);
  fParameterisation->CalculateActiveVolume(theThickVector);
  G4int nofvolume = fParameterisation->GetNofActiveVolume();
  if ( fVerbose > 0 ) G4cout << nofvolume <<G4endl;
  
  if ( nofvolume > 0 ){
      //G4VPhysicalVolume *phys = 
      new G4PVParameterised(drillName,
                            logDrill,
                            physvol->GetLogicalVolume(),
                            //kZAxis,
                            kUndefined,
                            nofvolume,
                            fParameterisation);
  }

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.,1.0,1.0));
  logDrill->SetVisAttributes(visAttr);
}

