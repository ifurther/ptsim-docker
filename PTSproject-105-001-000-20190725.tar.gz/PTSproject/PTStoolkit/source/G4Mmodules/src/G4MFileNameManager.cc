//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
//---------------------------------------------------------------------
//  G4MFileNameManager
//
//  (HISTROY)
//  2017-03-17  T.ASO  Create.
//  2017-04-03  T.Aso  replace find() to rfind().
//--------------------------------------------------------------------
//
#include "G4MFileNameManager.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4Threading.hh"
//
G4String  G4MFileNameManager::TakeOffExtension(G4String& name) const{
  G4String extension;
  if ( name.rfind(".") != std::string::npos ) {
    extension = name.substr(name.find("."));
    name = name.substr(0, name.find("."));
  }
  else {
    //extension = ".data";
    extension = "";
  }
  return extension;
}

G4String  G4MFileNameManager::GetRankFileName(const G4String basename) 
  const{
  G4String name(basename);
  // Take out file extension
  G4String extension = TakeOffExtension(name);
  // Add rank to a file name if MPI processing
  G4int rank = G4MVGeometryBuilder::GetSystem()->GetRank();
  if ( rank >= 0 ){
    std::ostringstream osm;
    osm << rank;
    name.append("_");
    name.append(osm.str());
  }
  // Add (back if it was present) file extension
  name.append(extension);

  return name;

}

G4String  G4MFileNameManager::GetFullFileName(const G4String basename) const{
  G4String name(basename);
  // Take out file extension
  G4String extension = TakeOffExtension(name);
  //
#if defined(G4MULTITHREADED)
  // Add thread Id to a file name if MT processing
  G4int tid = G4Threading::G4GetThreadId();
  if ( tid > -1 ) {
    std::ostringstream os;
    os << G4Threading::G4GetThreadId();
    name.append("_t");
    name.append(os.str());
  }
#endif
  // Add (back if it was present) file extension
  name.append(extension);

  return name;
}


