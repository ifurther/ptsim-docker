//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MPCTTubeDetector
//
// (HISTORY)
//   Created for PortonCT study. T.Aso
//   19 Dec. 2010 T.Aso Add file catalogue constructor.
//   2015-12-14 T.Aso Use G4MWaterPhantomSD.
//   2017-03--15 T.Aso Threading
// -----------------------------------------------------------------
//
//                    
// 
#include "G4MPCTTubeDetector.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"
#include "G4Material.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
// --

//#include "G4MPCTSD.hh"
#include "G4MWaterPhantomSD.hh"

//##ModelId=42F3E51B009C
G4MPCTTubeDetector::G4MPCTTubeDetector(const G4String& name,
                                       G4double rin, G4double rout, 
                                       G4double dz,
                                       G4String mat)
  :G4MVBeamModule(name,G4ThreeVector(rin,rout,dz)),fCatalogue(NULL),
   fRin(rin),fRout(rout),fDz(dz),fMaterial(mat){
}

G4MPCTTubeDetector::G4MPCTTubeDetector(const G4String& name) 
  :G4MVBeamModule(name),fCatalogue(NULL),fMaterial("Air")
{
}

G4MPCTTubeDetector::G4MPCTTubeDetector(G4MVPCTTubeDetectorCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue),fMaterial("Air"){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

//##ModelId=42F3E524036B
G4MPCTTubeDetector::~G4MPCTTubeDetector() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MPCTTubeDetector::SetAllParameters(G4double rin, G4double rout, G4double dz, G4String& mat){
  fRin=rin;
  fRout=rout;
  fDz=dz;
  fMaterial = mat;
  SetEnvelopeSize(rin,rout,dz);
}

void G4MPCTTubeDetector::SetSize(G4double rin, G4double rout, G4double dz){
  fRin=rin;
  fRout=rout;
  fDz=dz;
}

G4VPhysicalVolume* G4MPCTTubeDetector::buildEnvelope(G4LogicalVolume* worldlog) {
  G4Material* mat = G4Material::GetMaterial(fMaterial);

  G4VSolid* solid = new G4Tubs(GetName(), fRin,fRout,fDz,0,twopi);
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,                      // Solid 
                                 mat,                           // Material
                                 GetName()                      // Name
                                 );

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),
                   GetTranslation(),
                   logical,                      // Logical volume  
                   GetName(),                       // Name
                   worldlog,  // Mother  volume 
                   false,                         // Not used 
                   0);                            // Copy number  

  fSdLVList.push_back(logical);

  return physical;

}

void G4MPCTTubeDetector::buildNode(G4VPhysicalVolume*) {
}

void G4MPCTTubeDetector::BuildInSDandField() {
  /// Sensitive Detector
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector *pctsd = sdm->FindSensitiveDetector(GetName(),false);
  if ( !pctsd ) {
    G4cout << "++ G4MPCTBoxDetector::  Create Sensitive Detector "
           <<GetName()<<G4endl;
    const G4String colName = "HitsCollection";
    G4MWaterPhantomSD* wsd = new G4MWaterPhantomSD(GetName(),colName);
    wsd->SetDepth(0,0,0);
    wsd->SetZeroEdep(false);
    sdm->AddNewDetector(wsd);
    pctsd = wsd;
  }
  // Logical name
  for (G4int i = 0; i < (G4int)fSdLVList.size(); i++){
    fSdLVList[i]->SetSensitiveDetector(pctsd);
  }
}


