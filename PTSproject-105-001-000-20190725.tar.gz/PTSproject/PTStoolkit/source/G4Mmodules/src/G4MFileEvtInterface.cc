//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
//---------------------------------------------------------------------
//  G4MFileEvtInterface
//
//  (HISTROY)
//   29-Nov-2007  T.ASO  Create.
//   19-Mar-2008  T.Aso  Verbose and methods for Open/Close File is
//                      moved from G4MFileEvtInterface. 
//   2015-01-08 T.Aso FindIon() for Geant4 version 10.
// 2017-03-15 T.Aso for threading.
//   2019-04-04 T.Aso File format ASCII/Binary.
//---------------------------------------------------------------------
//
#include "G4Types.hh"
#include "G4ios.hh"
#include "G4MFileEvtInterface.hh"
#include "G4PrimaryParticle.hh"
#include "G4IonTable.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4Event.hh"
//#include "G4Threading.hh"
#include "G4MFileNameManager.hh"

G4MFileEvtInterface::G4MFileEvtInterface()
  :G4MVEvtInterface(),fFilename("evfile.dat")
{}

G4MFileEvtInterface::~G4MFileEvtInterface()
{}

void G4MFileEvtInterface::OpenEventFile(G4String& evfile){

    if(inputFile.is_open()) inputFile.close();

    //G4String name = GetFullFileName(evfile);
    G4MFileNameManager fnm;
    G4String name = fnm.GetRankFileName(evfile);
    name = fnm.GetFullFileName(name);
    //
    const char* fn = name.data();
    if ( fileFormat == 0 ){ //ASCII
      inputFile.open((char*)fn);
    }else{ // Binary
      inputFile.open((char*)fn, std::ios::in|std::ios::binary);
    }
    if (inputFile.is_open()){
        fFilename = evfile;
        if ( verbose > 3 ) {
          G4cout << "%%G4MFileEvtInterface opens " 
                 << fFilename <<G4endl;
        }
    }else{
      G4Exception("G4MFileEvtInterface::OpenEventFile()","G4MFileEvtIF00",
                  JustWarning,"cannot open file.");
    }
}

void G4MFileEvtInterface::CloseEventFile(){

    if(inputFile.is_open()) inputFile.close();
    if ( verbose > 3 ) {
      G4cout << "%%G4MFileEvtInterface closes " 
             << fFilename <<G4endl;
    }

}

void G4MFileEvtInterface::getParticleInfo()
{

    G4int NPAR; // Number of particles in this event
    if ( fileFormat == 0 ) { // ASCII
      inputFile >> NPAR;
    }else{ // Binary
      inputFile.read((char*)&NPAR,sizeof(G4int));
    }
    if ( verbose > 0 ) G4cout << "# "<< NPAR <<G4endl;
    if ( inputFile.eof() ){
      G4Exception("G4MFileEvtInterface::getParticleInfo()","G4MFileEvtIF00",
                  JustWarning,"End-Of-File : G4MEvt input file");
        return;
    }

    for ( G4int i = 0; i < NPAR; i++){
        G4double x,y,z;    // x,y,z vertex-position (mm)
        G4double t;        // time                  (ns)
        G4int    pdg;      // PDG code
        G4double mass;     // Mass                 (GeV)
        G4double charge;   // Charge               (e)
        G4double px,py,pz; // Momentum             (MeV)
        G4double polx,poly,polz; // Polarization

        if ( fileFormat == 0 ) { // ASCII
          inputFile >> x >> y>> z >> t 
                    >> mass >> pdg>> charge
                    >>px>>py>>pz
                    >>polx>>poly>>polz;
        }else{ // Binary
          G4float fx,fy,fz;    // x,y,z vertex-position (mm)
          G4float ft;        // time                  (ns)
          G4float fmass;     // Mass                 (GeV)
          G4int   icharge;   // Charge               (e)
          G4float fpx,fpy,fpz; // Momentum             (MeV)
          inputFile.read((char*)&fx, sizeof(G4float)); x = fx;
          inputFile.read((char*)&fy, sizeof(G4float)); y = fy;
          inputFile.read((char*)&fz, sizeof(G4float)); z = fz;
          inputFile.read((char*)&ft, sizeof(G4float)); t = ft;
          inputFile.read((char*)&pdg, sizeof(G4int));  
          inputFile.read((char*)&fmass, sizeof(G4float)); mass = fmass;
          inputFile.read((char*)&icharge, sizeof(G4int)); charge = icharge;
          inputFile.read((char*)&fpx, sizeof(G4float)); px = fpx;
          inputFile.read((char*)&fpy, sizeof(G4float)); py = fpy;
          inputFile.read((char*)&fpz, sizeof(G4float)); pz = fpz;
          polx=0; poly=0; polz=0;
        }
        //
        if ( verbose > 1 ) {
          G4cout << " ### "  << x <<" "<< y<<" "<< z << " "<< t 
                 <<" "<< mass<<" " <<" " <<pdg<<" "<< charge
                 <<" " << px<<" "<<py<<" "<<pz
                 <<" "<< polx<<" "<<poly<<" "<<polz << G4endl;
        }

        x *= mm;
        y *= mm;
        z *= mm;
        t *= nanosecond;
        mass *= MeV;
        px *= MeV;
        py *= MeV;
        pz *= MeV;

        G4ParticleDefinition* p = NULL;
        G4int Z=0, A=0, J=0;
        G4double E=0.0;
        /* --ASO 20170207 replace
        if ( G4IonTable::GetNucleusByEncoding(pdg, Z, A, E, J) ) { // Ion
          //p = G4ParticleTable::GetParticleTable()->GetIon(Z,A,E);
          p = G4IonTable::GetIonTable()->FindIon(Z,A,E);

        }else{
          p = G4ParticleTable::GetParticleTable()->FindParticle(pdg);
        }
        */
        //---- ASO 20170214 with
        p = G4ParticleTable::GetParticleTable()->FindParticle(pdg);
        // Ion
        if ( p == 0 && G4IonTable::GetNucleusByEncoding(pdg, Z, A, E, J)){ 
            p = G4IonTable::GetIonTable()->GetIon(Z,A,E);
        }
        //----
        //
        //
        if ( !p ) {
          std::ostringstream os;
          os << pdg;
          G4String msg = "%%% could not unfold PDG number "+os.str();
          G4Exception("G4MFileEvtInterface::getParticleInfo",
                      "G4M000",FatalException, msg);
        }else{
        
          G4PrimaryParticle* pParticle
            = new G4PrimaryParticle(p,px,py,pz);
          pParticle->SetMass(mass);
          pParticle->SetCharge(charge);
          pParticle->SetPolarization(polx,poly,polz);

          if ( verbose > 1 ) {
            G4cout << "### "
                   << p->GetParticleName() 
                   << " charge "  << p->GetPDGCharge() 
                   << " Mass "  << p->GetPDGMass() << G4endl;
          }
          G4MEvtParticle* evpar 
            = new G4MEvtParticle(pParticle,x,y,z,t);
          HPlist.push_back(evpar);
        }
    }
}



