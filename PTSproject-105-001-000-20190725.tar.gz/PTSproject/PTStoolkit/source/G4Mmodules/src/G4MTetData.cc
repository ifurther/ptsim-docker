//
// ********************************************************************
// * Disclaimer                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Tet Data
//  (HISTORY)
// 2018-03-11 T.Aso
// -----------------------------------------------------------------
//
#include "G4MTetData.hh"
#include <fstream>

G4MTetData::G4MTetData(const G4String& name, 
                       const G4ThreeVector& oxyz,
                       G4int matid,
                       G4int noff)
  :fName(name),fMatID(matid),fOxyz(oxyz),fNoff(noff){
  //
  //Clear();
}

G4MTetData::~G4MTetData(){
  Clear();
}

void G4MTetData::SetTet(size_t i, G4Tet* t, G4int hu){
  fTetVec[i] = t;
  fTetHU[i] = hu;
}

void G4MTetData::AddTet(G4Tet* t, G4int hu){
  fTetVec.push_back(t);
  fTetHU.push_back(hu);
}

void G4MTetData::AddTet(const G4double p[12], G4int hu){
    G4ThreeVector p0(p[0],p[1],p[2]);
    G4ThreeVector p1(p[3],p[4],p[5]);
    G4ThreeVector p2(p[6],p[7],p[8]);
    G4ThreeVector p3(p[9],p[10],p[11]);
    G4Tet* t = new G4Tet("Tet0",p0,p1,p2,p3);
    //
    AddTet(t,hu);
    for ( G4int i = 0; i < 12 ; i+=3 ){
      if ( p[i]   < fMinXYZ.x() ) { fMinXYZ.setX(p[i]); }
      if ( p[i+1] < fMinXYZ.y() ) { fMinXYZ.setY(p[i+1]); }
      if ( p[i+2] < fMinXYZ.z() ) { fMinXYZ.setZ(p[i+2]); }
      if ( p[i]   > fMaxXYZ.x() ) { fMaxXYZ.setX(p[i]); }
      if ( p[i+1] > fMaxXYZ.y() ) { fMaxXYZ.setY(p[i+1]); }
      if ( p[i+2] > fMaxXYZ.z() ) { fMaxXYZ.setZ(p[i+2]); }
    }
}

void G4MTetData::Clear(){
  std::vector<G4Tet*>::iterator itr;
  for (itr = fTetVec.begin(); 
       itr!= fTetVec.end(); ++itr){
    delete (*itr);
  }
  fTetVec.clear();
  //
  fTetHU.clear();
  //
  fMinXYZ.set(DBL_MAX,DBL_MAX,DBL_MAX);
  fMaxXYZ.set(-DBL_MAX,-DBL_MAX,-DBL_MAX);
}









