//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MHoneyCombBolus.
// 
//  (History)
//   2014-03-10   T.Aso
//---------------------------------------------------------------------
//
#include "G4MHoneyCombBolusFileCatalogue.hh"
#include "G4MHoneyCombBolus.hh"
#include <fstream>

G4MHoneyCombBolusFileCatalogue::G4MHoneyCombBolusFileCatalogue(const G4String& name,
                                             const G4String& filename)
  :G4MVHoneyCombBolusCatalogue(name),fDefaultFileName(filename){
}

G4MHoneyCombBolusFileCatalogue::~G4MHoneyCombBolusFileCatalogue()
{}

void G4MHoneyCombBolusFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(fDxyzBolus,
                            fMatBolus,fNx,fNy,fx0,fy0,fPitchX,fPitchY,
                            fFact,
                            theThickness);
}

void G4MHoneyCombBolusFileCatalogue::Prepare(G4String& pname){

  std::ifstream fileio(pname);
  if(!fileio) { 
    G4cerr << "File Not Found " << pname << G4endl;
  }else{
    theThickness.clear();

    //G4int verbose = fModule->GetVerbose();
    G4int verbose = 1;
    
    G4double dx,dy,dz;
    fileio >> dx >> dy >> dz;  // Full size of Bolus frame
    dx *= ( mm/2. );
    dy *= ( mm/2. );
    dz *= ( mm/2. );
    fDxyzBolus.setX(dx);
    fDxyzBolus.setY(dy);
    fDxyzBolus.setZ(dz);
    
    fileio>>   fMatBolus;       // Material of Bolus
    fileio >> fNx >> fNy ;      // Dimension of drill hole.

    fileio >> fx0 >> fy0;       // Offset of first point.
    fx0 *= mm;
    fy0 *= mm;

    fileio >> fPitchX >> fPitchY;  // Drill pitch in x,y (mm)
    fPitchX *= mm;
    fPitchY *= mm;

    fileio >> fFact ;  // 0.5 for regular hexagon

    G4double t;
    for ( G4int iy = 0; iy < fNy; iy++){
        for ( G4int ix = 0; ix < fNx; ix++){
            fileio >> t;
            t *= mm;
            theThickness.push_back(t);
            if ( verbose > 0 ) G4cout << t <<  " " ;
        }
        if ( verbose > 0 ) G4cout << G4endl;
    }
    fileio.close();
  }
}

void G4MHoneyCombBolusFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyzBolus,fMatBolus,
                            fNx,fNy,fx0,fy0,fPitchX,fPitchY,
                            fFact,
                            theThickness);
   fModule->ReBuild();
}




 
