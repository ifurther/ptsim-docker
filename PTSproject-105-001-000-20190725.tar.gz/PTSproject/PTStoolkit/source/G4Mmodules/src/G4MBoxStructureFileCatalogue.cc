//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------//
//  (Desctiption)
//   This is a class for catalogue of parameters for BoxStructure
// 
//  (History)
//   06-Oct-05   T.Aso
// 2014-03-11 T.Aso fVerbose.
//---------------------------------------------------------------------//
//
#include "G4MBoxStructureFileCatalogue.hh"
#include "G4MBoxStructure.hh"
#include <fstream>

G4MBoxStructureFileCatalogue::
G4MBoxStructureFileCatalogue(const G4String& name,
                             const G4String& fileName)
  :G4MVBoxStructureCatalogue(name),fDefaultFileName(fileName)
{}

G4MBoxStructureFileCatalogue::~G4MBoxStructureFileCatalogue()
{}

void G4MBoxStructureFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fDxyz,fZ,fMaterial);
}

void G4MBoxStructureFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg = "File Not Found " + pname;
    G4Exception("G4MBoxStructureFileCatalogue::Prepare()","G4MBoxStructFileCata00",
                FatalException,msg);
  }else{
    G4int nPlate = 0;
    // Number of Plate
    fileio >> nPlate;
    fDxyz.clear();
    fZ.clear();
    fMaterial.clear();
    fZ.clear();
    G4double dx,dy,dz,z;
    G4String mat;
    for ( G4int i = 0; i < nPlate; i++){
      fileio >> mat >> dx >> dy >> dz >> z ;
      if ( fVerbose > 0 ){
        G4cout << mat <<" "<<dx<<" " <<dy<<" "<<dz<<" "<<z<<G4endl;
      }
      dx *= (mm/2.);
      dy *= (mm/2.);
      dz   *= (mm/2.);  // Full width to half width.
      z    *= mm;
      G4ThreeVector dxyz(dx,dy,dz);
      fDxyz.push_back(dxyz);
      fZ.push_back(z);
      fMaterial.push_back(mat);
    }
  }
}

void G4MBoxStructureFileCatalogue::Apply(){
  fModule->SetAllParameters(fDxyz,fZ,fMaterial);
  fModule->ReBuild();
}
