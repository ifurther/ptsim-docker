//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// 2019-07-19  T.Aso 
//---------------------------------------------------------------------
//
#include "G4MBoxFieldMessenger.hh"
#include "G4MBoxField.hh"

G4MBoxFieldMessenger::G4MBoxFieldMessenger(G4MBoxField* mp,
                                                   const G4String& name)
  :fboxField(mp) {

  const G4String& myDir = "/G4M/Module/"+name+"/";
  fDir = new G4UIdirectory(myDir);
  fDir->SetGuidance("UI commands for modules");

  //
  // Field
  //
  const G4String field3D = myDir+"field";
  fCmdSetField = 
    new G4UIcmdWith3VectorAndUnit(field3D,this);
  fCmdSetField->SetGuidance("Field strength (x,y,z,unit)");
  fCmdSetField->SetParameterName("dX","dY","dZ",true,true);
  fCmdSetField->SetDefaultUnit("tesla");
  fCmdSetField->AvailableForStates(G4State_Init,G4State_Idle);
}

G4MBoxFieldMessenger::~G4MBoxFieldMessenger() {
  if (fCmdSetField) delete fCmdSetField;
  if (fDir) delete fDir;
}

void G4MBoxFieldMessenger::SetNewValue(G4UIcommand* command, 
                                           G4String newValue) {
 if ( command == fCmdSetField ){
    const G4ThreeVector& field3d = fCmdSetField->GetNew3VectorValue(newValue);
    fboxField->SetFieldValue(field3d);
 } 
}

G4String G4MBoxFieldMessenger::GetCurrentValue(G4UIcommand* command) {
  return G4String("I do not know,"+command->GetCommandName());
}
