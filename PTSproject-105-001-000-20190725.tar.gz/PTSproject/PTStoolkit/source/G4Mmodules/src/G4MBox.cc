//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Box shape component
//
// (HISTORY)  
//
//---------------------------------------------------------------------
//
#include "G4MBox.hh"
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4PVPlacement.hh"

G4MBox::G4MBox(const G4String& name, const G4ThreeVector& dxyz,
	       const G4String& mat)
  : G4MVBeamModule(name,dxyz), matName(mat),fCatalogue(NULL)
{}

G4MBox::G4MBox(const G4String& name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MBox::G4MBox(G4MVBoxCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MBox::~G4MBox()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4MBox::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBox::SetAllParameters(const G4ThreeVector& dxyz, const G4String& mat){
  SetEnvelopeSize(dxyz);
  matName = mat;
}


G4VPhysicalVolume* G4MBox::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(matName);

  G4Box *solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());

  //G4VPhysicalVolume* physical = new G4PVPlacement(t3d,
  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
						  GetTranslation(),
						   lv,
						   GetName(),
						   worldlog,
						   false,
						   0);
  return physical;
}

void G4MBox::buildNode(G4VPhysicalVolume*){}
