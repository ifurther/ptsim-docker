//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Desctiption)
//    Messenger for Particle Therapy System
//
//
//   /G4M/Module/    directory
//     Commands:
//        install    moduleName pwName layered; Install the module as a physical volume
//        installIfExist    moduleName pwName layered; Install the module if the physical volume
//        cloneIfExist   mNameFrom mNameTo copyid x y z rx ry rz; Install the module if the physical volume
//        uninstall  moduleName  ; Uninstall the module from world volume
//        installAll    ; Rebuild all modules except Room
//        installBM     ; Rebuild all modules except Room, WP,and DICOM
//        uninstallAll  ; Uninstall all modules except Room
//        uninstallBM   ; Uninstall all modules except Room, WP,and DICOM
//        rebuild    moduleName  ; Combination of Uninstall/Install.
//        list        level oname      ; Listing available modules and status
//        listInWorld     worldName oname; Listing modules installed in worldName
//        lang  id       ;  Lang. in dump command. id=0 JPN, id!=0 ENG.
//
//     Commands
//        select     moduleName  ; Select Module for messeging to module
//        typeid     catalogue id; Select a Module parameter from 
//                                 the selected module's Catalogue.
//        dump       N/A         ; Dump module parameter.
//        dumpToFile       filename    ; Dump module parameter.
//        translate  x y z unit  ; Translate the selected module
//        rotate     Ox Oy Oz unit  ; Rotate the selected module
//        downEdgeZ  z unit      ; Place downstream Edge of the module
//        upEdgeZ    z unit      ; Place upstream Edge of the module
//        attachZ    module ; Place the selected module with DICOM.
//
//        verbose    level       ; Vebose level
//
//        selectLV   {moduleName}  {idSelect}; Select LV
//        dumpLV     {moduleName} ;
//        createSD   {SDName} {ColName} {edepFlag} {depx} {depy} {depz} {depm} {deps} ; 
//        setDepthSD {SDName} {depx} {depy} {depz} {depm} {deps} 
//        setEdepSD  {SDName} {flag} 
//        setStepSD  {SDName} {flag} 
//        attachSD   {SDName} ; (not completed.)
//        detachSD    (not completed.)
//        attachTrgID  {SDName} {ID}; (not completed.)
//
//        physicsModified ; /run/geometryModified and 
//                        G4ProductionCutsTable::PhysicsTableUpdated().
//
//
//
// (HISTORY)
//   05-OCT-05  Created/Modified T.Aso
//   05-OCT-05  Add select command and its command group.  T.Aso
//   09-NOV-05  CmdUpdateEvent moved from HIBMCSetup.
//   05-DEC-05  Add Rebuild command.
//   05-DEC-05  Add Rebuild command.
//   14-FEB-07  G4MDICOM was replaced to G4MVDICOM, T.ASO
//   15-FEB-07  G4MDICOM related commands are moved into G4MDICOMMessenger. TA
//   14-FEB-07  G4MDICOM was replaced to G4MVDICOM, T.ASO
//   15-FEB-07  G4MDICOM related commands are moved into G4MDICOMMessenger. TA
//   10-Aug-10  selectLV and dumpLV commands.
//   11-Sep-11  Invoke ReBuild when executing typeid. T.Aso
//   2012-06-06 T.Aso installAll, uninstallAll, dump commands. 
//   2012-06-10 T.Aso correct description of command signature in comment line.
//   2012-11-16 T.Aso installBM, uninstallBM, dump commands. 
//   2013-01-15 T.Aso update the list command.
//   2013-03-27 T.Aso install command has one more option for specifying 
//                    a parallel world geometry.
//                    listInWorld command is introduced.
//   2013-03-27 T.Aso install command has one more option for specifying 
//                    a parallel world geometry.
//                    listInWorld command is introduced.
//  2013-03-30 T.Aso PhysicalConstants/SystemOfUnits.
//               A variable "m" conflicts with "meter" in SetNewValue().
//               The variable name was chaged to "module". CmdLVSelect.
//   2013-11-01 T.Aso lang command.
//   2014-02-05 T.Aso attachZ command.
//   2014-03-31 T.Aso install command was modifed. installIfExist command.
//   2014-08-07 T.Aso add ostream in list command.
//   2014-09-04 T.Aso Revise attachZ command according to Yamashita san's
//                    suggestion.
//   2016-01-14 T.Aso Modify guide for cloneIfExist.
//   2016-04-07 T.Aso (attachSD, attachTrgID)
//   2016-07-16 T.Aso StepSD.
//   2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#include "G4MParticleTherapySystemMessenger.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4UIparameter.hh"
#include "G4Tokenizer.hh"
#include "G4Material.hh"
//
#include "G4MVDICOM.hh"
//
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
//
#include "G4UImanager.hh"
#include "G4ProductionCutsTable.hh"
//
#include "G4SDManager.hh"
#include "G4MSDManager.hh"
//
G4MParticleTherapySystemMessenger::
G4MParticleTherapySystemMessenger(G4MVParticleTherapySystem* system)
  :fSystem(system) {
    fDir = new G4UIdirectory("/G4M/Module/");
    fDir->SetGuidance("UI commands for modules");

    fCmdUpdate = new G4UIcmdWithoutParameter("/G4M/Module/Update",this);
    fCmdUpdate->SetGuidance("Update Module for new event.");
    fCmdUpdate->AvailableForStates(G4State_Idle,G4State_EventProc);

    //fCmdInstall = new G4UIcmdWithAString("/G4M/Module/install",this);
    //fCmdInstall->SetGuidance("Install of beam-line module");
    //fCmdInstall->SetParameterName("install",false);
    //fCmdInstall->AvailableForStates(G4State_Idle);
    fCmdInstall = new G4UIcommand("/G4M/Module/install",this);
    fCmdInstall->SetGuidance("Install of beam-line module");
    fCmdInstall->SetGuidance("Usage: /G4M/Module/install mname");
    fCmdInstall->SetGuidance("Usage: /G4M/Module/install mname pwName");
    fCmdInstall->SetGuidance("Usage: /G4M/Module/install mname pwName layered");
    fCmdInstall->SetGuidance("mname: (String) Module name ");
    fCmdInstall->SetGuidance("pwName:(String) ParallelWorldName (omittable)");
    fCmdInstall->SetGuidance("        Default = none ");
    fCmdInstall->SetGuidance("layered:(G4bool) Layered Mass geometry (omittable)");
    fCmdInstall->SetGuidance("        Default = true");
    G4UIparameter* param;
    param = new G4UIparameter("mname",'s',false);
    fCmdInstall->SetParameter(param);
    param = new G4UIparameter("pwName",'s',true);
    param->SetDefaultValue("none");
    fCmdInstall->SetParameter(param);
    param = new G4UIparameter("layered",'b',true);
    param->SetDefaultValue(true);
    fCmdInstall->SetParameter(param);

    fCmdInstallIfExist = new G4UIcommand("/G4M/Module/installIfExist",this);
    fCmdInstallIfExist->SetGuidance("InstallIfExist of beam-line module");
    fCmdInstallIfExist->SetGuidance("Usage: /G4M/Module/installIfExist mname");
    fCmdInstallIfExist->SetGuidance("Usage: /G4M/Module/installIfExist mname pwName");
    fCmdInstallIfExist->SetGuidance("Usage: /G4M/Module/installIfExist mname pwName layered");
    fCmdInstallIfExist->SetGuidance("mname: (String) Module name ");
    fCmdInstallIfExist->SetGuidance("pwName:(String) ParallelWorldName (omittable)");
    fCmdInstallIfExist->SetGuidance("        Default = none ");
    fCmdInstallIfExist->SetGuidance("layered:(G4bool) Layered Mass geometry (omittable)");
    fCmdInstallIfExist->SetGuidance("        Default = true");
    //G4UIparameter* param;
    param = new G4UIparameter("mname",'s',false);
    fCmdInstallIfExist->SetParameter(param);
    param = new G4UIparameter("pwName",'s',true);
    param->SetDefaultValue("none");
    fCmdInstallIfExist->SetParameter(param);
    param = new G4UIparameter("layered",'b',true);
    param->SetDefaultValue(true);
    fCmdInstallIfExist->SetParameter(param);

    //        cloneIfExist   mNameFrom mNameTo copyid x y z rx ry rz; Install the module if the physical volume           
    fCmdCloneIfExist = new G4UIcommand("/G4M/Module/cloneIfExist",this);
    fCmdCloneIfExist->SetGuidance("CloneIfExist: Make a clone of  beam-line module");
    fCmdCloneIfExist->SetGuidance("Usage: /G4M/Module/cloneIfExist mname1 mname2 copyID");
    fCmdCloneIfExist->SetGuidance("Usage: /G4M/Module/cloneIfExist mname1 mnam2 copyID x y z unit rx ry rz unit");
    fCmdCloneIfExist->SetGuidance("mname1: (String) Module name (from) ");
    fCmdCloneIfExist->SetGuidance("mname2: (String) Module name (to) ");
    fCmdCloneIfExist->SetGuidance("copyID: (int) CopyNo");
    fCmdCloneIfExist->SetGuidance("x y z unit :(double and unit) Position (omittable)");
    fCmdCloneIfExist->SetGuidance("rx ry rz unit :(double and unit) Rotation (omittable)");
    //G4UIparameter* param;                                                                                           
    param = new G4UIparameter("mname1",'s',false);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("pwName2",'s',false);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("copyID",'i',true);
    param->SetDefaultValue(0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("x",'d',true);
    param->SetDefaultValue(0.0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("y",'d',true);
    param->SetDefaultValue(0.0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("z",'d',true);
    param->SetDefaultValue(0.0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("unit",'s',true);
    param->SetDefaultValue("mm");
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("rx",'d',true);
    param->SetDefaultValue(0.0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("ryy",'d',true);
    param->SetDefaultValue(0.0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("rz",'d',true);
    param->SetDefaultValue(0.0);
    fCmdCloneIfExist->SetParameter(param);
    param = new G4UIparameter("unit",'s',true);
    param->SetDefaultValue("deg");
    fCmdCloneIfExist->SetParameter(param);


    fCmdUnInstall = new G4UIcmdWithAString("/G4M/Module/uninstall",this);
    fCmdUnInstall->SetGuidance("UnInstall of beam-line module");
    fCmdUnInstall->SetParameterName("uninstall",false);
    fCmdUnInstall->AvailableForStates(G4State_Idle);

    fCmdInstallAll = new G4UIcmdWithoutParameter("/G4M/Module/installAll",this);
    fCmdInstallAll->SetGuidance("Install all beam-line module");
    fCmdInstallAll->AvailableForStates(G4State_Idle);

    fCmdInstallBM = new G4UIcmdWithoutParameter("/G4M/Module/installBM",this);
    fCmdInstallBM->SetGuidance("Install all beam-line module except targets");
    fCmdInstallBM->AvailableForStates(G4State_Idle);

    fCmdUnInstallAll = new G4UIcmdWithoutParameter("/G4M/Module/uninstallAll",this);
    fCmdUnInstallAll->SetGuidance("UnInstall all beam-line module");
    fCmdUnInstallAll->AvailableForStates(G4State_Idle);

    fCmdUnInstallBM = new G4UIcmdWithoutParameter("/G4M/Module/uninstallBM",this);
    fCmdUnInstallBM->SetGuidance("UnInstall all beam-line module except targets");
    fCmdUnInstallBM->AvailableForStates(G4State_Idle);

    fCmdReBuild = new G4UIcmdWithAString("/G4M/Module/rebuild",this);
    fCmdReBuild->SetGuidance("UnInstall/Install of beam-line module");
    fCmdReBuild->SetParameterName("rebuild",false);
    fCmdReBuild->AvailableForStates(G4State_Idle);

    //fCmdList = new G4UIcmdWithAnInteger("/G4M/Module/list",this);
    //fCmdList->SetGuidance("List of beam-line module");
    //fCmdList->SetParameterName("level",true);
    //fCmdList->SetDefaultValue(0);
    //fCmdList->AvailableForStates(G4State_Idle);
    fCmdList = new G4UIcommand("/G4M/Module/list",this);
    fCmdList->SetGuidance("List of beam-line module");
    fCmdList->SetGuidance("Usage: /G4M/Module/list lvl oname");
    fCmdList->SetGuidance("lvl: (int) verbose level");
    fCmdList->SetGuidance("oname: (string) stdout or filename");
    fCmdList->SetGuidance("         default stdout");
    //G4UIparameter* param;
    param = new G4UIparameter("lvl",'i',true);
    param->SetDefaultValue(1);
    fCmdList->SetParameter(param);
    param = new G4UIparameter("oname",'s',true);
    param->SetDefaultValue("stdout");
    fCmdList->SetParameter(param);

    fCmdListInWorld = new G4UIcmdWithAString("/G4M/Module/listInWorld",this);
    fCmdListInWorld->SetGuidance("List of beam-line module in the world");
    fCmdListInWorld->SetParameterName("world",false);
    fCmdListInWorld->AvailableForStates(G4State_Idle);

    fCmdLang = new G4UIcmdWithAnInteger("/G4M/Module/lang",this);
    fCmdLang->SetGuidance("Lang. in dump command");
    fCmdLang->SetParameterName("lang",true);
    fCmdLang->SetDefaultValue(0);
    fCmdLang->AvailableForStates(G4State_Idle);

    fCmdSelect = new G4UIcmdWithAString("/G4M/Module/select",this);
    fCmdSelect->SetGuidance("Select beam-line module for messeaging");
    fCmdSelect->SetParameterName("select",false);
    fCmdSelect->AvailableForStates(G4State_Idle);

    fCmdDump = new G4UIcmdWithoutParameter("/G4M/Module/dump",this);
    fCmdDump->SetGuidance("Dump beam module parameter");
    fCmdDump->AvailableForStates(G4State_Idle);

    fCmdDumpFile = new G4UIcmdWithAString("/G4M/Module/dumpToFile",this);
    fCmdDumpFile->SetGuidance("Dump beam module parameter to File");
    fCmdDumpFile->SetParameterName("file",false);
    fCmdDumpFile->AvailableForStates(G4State_Idle);

    fCmdTypeID = new G4UIcmdWithAString("/G4M/Module/typeid",this);
    fCmdTypeID->SetGuidance("Cataloged type ID for the current module.");
    fCmdTypeID->SetParameterName("typeid",false);
    fCmdTypeID->AvailableForStates(G4State_Idle);

    fCmdTranslate= new G4UIcmdWith3VectorAndUnit("/G4M/Module/translate",this);
    fCmdTranslate->SetGuidance("Translate the current module.");
    fCmdTranslate->SetParameterName("pX","pY","pZ",false,false);
    fCmdTranslate->SetDefaultUnit("mm");
    fCmdTranslate->AvailableForStates(G4State_Idle);

    fCmdDownEdgeZ= new G4UIcmdWithADoubleAndUnit("/G4M/Module/downEdgeZ",this);
    fCmdDownEdgeZ->SetGuidance("Place downstream Edge of the module");
    fCmdDownEdgeZ->SetParameterName("pz",false);
    fCmdDownEdgeZ->SetDefaultUnit("mm");
    fCmdDownEdgeZ->AvailableForStates(G4State_Idle);

    fCmdUpEdgeZ= new G4UIcmdWithADoubleAndUnit("/G4M/Module/upEdgeZ",this);
    fCmdUpEdgeZ->SetGuidance("Place upstream Edge of the module");
    fCmdUpEdgeZ->SetParameterName("pz",false);
    fCmdUpEdgeZ->SetDefaultUnit("mm");
    fCmdUpEdgeZ->AvailableForStates(G4State_Idle);


    fCmdAttachZ = new G4UIcmdWithAString("/G4M/Module/attachZ",this);
    fCmdAttachZ->SetGuidance("Attach selected module to the given module (DICOM) ");
    fCmdAttachZ->SetGuidance("Usage: /G4M/Module/attachZ mother_mname");
    fCmdAttachZ->SetGuidance("mother_mname:(String) Module name of mother ");
    fCmdAttachZ->SetParameterName("mModule",true);
    fCmdAttachZ->SetDefaultValue("DICOM");
    fCmdAttachZ->AvailableForStates(G4State_Idle);

    fCmdRotate= new G4UIcmdWith3VectorAndUnit("/G4M/Module/rotate",this);
    fCmdRotate->SetGuidance("Rotate the current module.");
    fCmdRotate->SetParameterName("rotX","rotY","rotZ",false,false);
    fCmdRotate->SetDefaultUnit("deg");
    fCmdRotate->AvailableForStates(G4State_Idle);

    fCmdVerbose = new G4UIcmdWithAnInteger("/G4M/Module/verbose",this);
    fCmdVerbose->SetGuidance("Set verbose level of the current module.");
    fCmdVerbose->SetParameterName("level",false,false);
    fCmdVerbose->AvailableForStates(G4State_Idle);

    fCmdLVSelect = new G4UIcommand("/G4M/Module/selectLV",this);
    fCmdLVSelect->SetGuidance("Select logical volume of beam module");
    fCmdLVSelect->SetGuidance("Usage: /G4M/Module/selectLV mname lvid");
    fCmdLVSelect->SetGuidance("mname: (String) Module name ");
    fCmdLVSelect->SetGuidance("id: (int) order number of logical volume ");
    //G4UIparameter* param;
    param = new G4UIparameter("mname",'s',false);
    fCmdLVSelect->SetParameter(param);
    param = new G4UIparameter("lvid",'i',false);
    fCmdLVSelect->SetParameter(param);
    fCmdLVSelect->AvailableForStates(G4State_Idle);

    fCmdLVDump = new G4UIcmdWithAString("/G4M/Module/dumpLV",this);
    fCmdLVDump->SetGuidance("Dump LV Structure of the module");
    fCmdLVDump->SetParameterName("mname",false);
    fCmdLVDump->AvailableForStates(G4State_Idle);


    fCmdCreateSD = new G4UIcommand("/G4M/Module/createSD",this);
    fCmdCreateSD->SetGuidance("Create a DetectorSD and register it to SDManager");
    fCmdCreateSD->SetGuidance("Usage: /G4M/Module/createSD sdname colname edepFlag");
    fCmdCreateSD->SetGuidance("                            depx depy depz depm deps");
    fCmdCreateSD->SetGuidance("sdname: (String) SD name ");
    fCmdCreateSD->SetGuidance("colame:(String) collection name");
    fCmdCreateSD->SetGuidance("edepFlag:(G4bool) true require non-zero energy deposit for scoring.");
    fCmdCreateSD->SetGuidance("            Default = true");
    fCmdCreateSD->SetGuidance("depx,depy,depz,depm,deps:(G4int) Depth of the geomtrical volume. ");
    fCmdCreateSD->SetGuidance("            Default = 0");
    param = new G4UIparameter("sdname",'s',false);
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("colame",'s',true);
    param->SetDefaultValue("none");
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("bedep",'b',true);
    param->SetDefaultValue(true);
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("depx",'i',true);
    param->SetDefaultValue(0);
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("depy",'i',true);
    param->SetDefaultValue(0);
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("depz",'i',true);
    param->SetDefaultValue(0);
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("depm",'i',true);
    param->SetDefaultValue(0);
    fCmdCreateSD->SetParameter(param);
    param = new G4UIparameter("deps",'i',true);
    param->SetDefaultValue(0);
    fCmdCreateSD->SetParameter(param);

    fCmdSetDepthSD = new G4UIcommand("/G4M/Module/setDepthSD",this);
    fCmdSetDepthSD->SetGuidance("Set Depth parameters for a DetectorSD");
    fCmdSetDepthSD->SetGuidance("Usage: /G4M/Module/setDepthSD sdname ");
    fCmdSetDepthSD->SetGuidance("                              depx depy depz depm deps");
    fCmdSetDepthSD->SetGuidance("sdname: (String) SD name ");
    fCmdSetDepthSD->SetGuidance("depx,depy,depz,depm,deps:(G4int) Depth of the geomtrical volume. ");
    fCmdSetDepthSD->SetGuidance("            Default = 0");
    param = new G4UIparameter("sdname",'s',false);
    fCmdSetDepthSD->SetParameter(param);
    param = new G4UIparameter("depx",'i',true);
    param->SetDefaultValue(0);
    fCmdSetDepthSD->SetParameter(param);
    param = new G4UIparameter("depy",'i',true);
    param->SetDefaultValue(0);
    fCmdSetDepthSD->SetParameter(param);
    param = new G4UIparameter("depz",'i',true);
    param->SetDefaultValue(0);
    fCmdSetDepthSD->SetParameter(param);
    param = new G4UIparameter("depm",'i',true);
    param->SetDefaultValue(0);
    fCmdSetDepthSD->SetParameter(param);
    param = new G4UIparameter("deps",'i',true);
    param->SetDefaultValue(0);
    fCmdSetDepthSD->SetParameter(param);

    fCmdSetEdepSD = new G4UIcommand("/G4M/Module/setEdepSD",this);
    fCmdSetEdepSD->SetGuidance("Set Edep flag for a DetectorSD");
    fCmdSetEdepSD->SetGuidance("Usage: /G4M/Module/setEdepSD sdname edepFlag");
    fCmdSetEdepSD->SetGuidance("sdname: (String) SD name ");
    fCmdSetEdepSD->SetGuidance("edepFlag:(G4bool) true require non-zero energy deposit for scoring.");
    fCmdSetEdepSD->SetGuidance("            Default = true");
    param = new G4UIparameter("sdname",'s',false);
    fCmdSetEdepSD->SetParameter(param);
    param = new G4UIparameter("bedep",'b',true);
    param->SetDefaultValue(true);
    fCmdSetEdepSD->SetParameter(param);

    fCmdSetStepSD = new G4UIcommand("/G4M/Module/setStepSD",this);
    fCmdSetStepSD->SetGuidance("Set Step flag for a DetectorSD");
    fCmdSetStepSD->SetGuidance("Usage: /G4M/Module/setStepSD sdname stepFlag");
    fCmdSetStepSD->SetGuidance("sdname: (String) SD name ");
    fCmdSetStepSD->SetGuidance("edepFlag:(G4bool) true = score steps in vector ");
    fCmdSetStepSD->SetGuidance("            Default = false");
    param = new G4UIparameter("sdname",'s',false);
    fCmdSetStepSD->SetParameter(param);
    param = new G4UIparameter("bstep",'b',true);
    param->SetDefaultValue(false);
    fCmdSetStepSD->SetParameter(param);

    fCmdSDAttach = new G4UIcmdWithAString("/G4M/Module/attachSD",this);
    fCmdSDAttach->SetGuidance("Attach SD to the selected LV");
    fCmdSDAttach->SetParameterName("sdname",false);
    fCmdSDAttach->AvailableForStates(G4State_Idle);

    fCmdSDDetach = new G4UIcmdWithoutParameter("/G4M/Module/detachSD",this);
    fCmdSDDetach->SetGuidance("Detach SD from the selected LV");
    fCmdSDDetach->AvailableForStates(G4State_Idle);

    fCmdAttachTrgID = new G4UIcommand("/G4M/Module/attachTrgID",this);
    fCmdAttachTrgID->SetGuidance("Assign a trigger ID to the selected LV.");
    fCmdAttachTrgID->SetGuidance("Usage: /G4M/Module/attachTrigID ");
    fCmdAttachTrgID->SetGuidance("mname: (String) TriggerSD name ");
    fCmdAttachTrgID->SetGuidance("ID: (int) Trigger ID ");
    //G4UIparameter* param;
    param = new G4UIparameter("sdname",'s',false);
    fCmdAttachTrgID->SetParameter(param);
    param = new G4UIparameter("trgid",'i',false);
    fCmdAttachTrgID->SetParameter(param);
    fCmdAttachTrgID->AvailableForStates(G4State_Idle);

    fCmdPhysicsModified = 
      new G4UIcmdWithoutParameter("/G4M/Module/physicsModified",this);
    fCmdPhysicsModified->SetGuidance("/run/physicsModified and ");
    fCmdPhysicsModified->SetGuidance(" update MaterialCutsCouple.");
    fCmdPhysicsModified->AvailableForStates(G4State_Idle);

    fcurrentModule = 0;
    fcurrentLV = 0;
}

G4MParticleTherapySystemMessenger::~G4MParticleTherapySystemMessenger() {
  fcurrentModule =0;
  fcurrentLV = 0;

  delete fDir;
  delete fCmdUpdate;
  delete fCmdInstall;
  delete fCmdInstallIfExist;
  delete fCmdCloneIfExist;
  delete fCmdUnInstall;
  delete fCmdInstallAll;
  delete fCmdUnInstallAll;
  delete fCmdInstallBM;
  delete fCmdUnInstallBM;
  delete fCmdReBuild;
  delete fCmdList;
  delete fCmdListInWorld;
  delete fCmdLang;
  delete fCmdSelect;
  delete fCmdDump;
  delete fCmdDumpFile;
  delete fCmdTypeID;
  delete fCmdTranslate;
  delete fCmdDownEdgeZ;
  delete fCmdUpEdgeZ;
  delete fCmdAttachZ;
  delete fCmdVerbose;
  delete fCmdRotate;
  delete fCmdLVSelect;
  delete fCmdLVDump;
  delete fCmdSDAttach;
  delete fCmdSDDetach;
  delete fCmdAttachTrgID;
  delete fCmdPhysicsModified;

}

void G4MParticleTherapySystemMessenger::SetNewValue(G4UIcommand* command, 
                                                    G4String newValue) {
  if ( command == fCmdInstall ){
    G4cout << "+++ G4MParticleTherapySystemMessenger    Install " 
           <<newValue<<G4endl;
    G4String mname, pwName;
    G4bool   layered;
    std::istringstream iss(newValue);
    iss >> mname >> pwName >> layered;
    fSystem->Install(mname,pwName,layered);
  }else if ( command == fCmdInstallIfExist ){
    G4cout << "+++ G4MParticleTherapySystemMessenger    InstallIfExist " 
           <<newValue<<G4endl;
    G4String mname, pwName;
    G4bool   layered;
    std::istringstream iss(newValue);
    iss >> mname >> pwName >> layered;
    fSystem->InstallIfExist(mname,pwName,layered);
  }else if ( command == fCmdCloneIfExist ){
    G4cout << "+++ G4MParticleTherapySystemMessenger    CloneIfExist "
           <<newValue<<G4endl;
    G4String mname1, mname2;
    G4int copyID;
    G4double x,y,z, rx, ry, rz;
    G4String unitPos, unitRot;
    std::istringstream iss(newValue);
    iss >> mname1 >> mname2 >> copyID >> x >> y >> z >> unitPos
        >> rx >> ry >> rz >> unitRot;
    G4double PosUnit = G4UnitDefinition::GetValueOf(unitPos);
    G4double RotUnit = G4UnitDefinition::GetValueOf(unitRot);
    x *= PosUnit; y *= PosUnit; z *= PosUnit;
    rx *= RotUnit; ry *= RotUnit; rz *= RotUnit;
    fSystem->CloneIfExist(mname1,mname2,copyID,x,y,z,rx,ry,rz);
  }else if ( command == fCmdUnInstall ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  UnInstall " 
           <<newValue<<G4endl;
    fSystem->UnInstall(newValue);
  }else if ( command == fCmdInstallAll ){
    G4cout << "+++ G4MParticleTherapySystemMessenger    InstallAll " 
           <<G4endl;
    fSystem->InstallAll();
  }else if ( command == fCmdUnInstallAll ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  UnInstallAll " 
           <<G4endl;
    fSystem->UnInstallAll();
  }else if ( command == fCmdInstallBM){
    G4cout << "+++ G4MParticleTherapySystemMessenger    InstallBM " 
           <<G4endl;
    fSystem->InstallAll(false);
  }else if ( command == fCmdUnInstallBM ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  UnInstallBM " 
           <<G4endl;
    fSystem->UnInstallAll(false);
  }else if ( command == fCmdReBuild ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  ReBuild " 
           <<newValue<<G4endl;
    fSystem->ReBuildModule(newValue);
  }else if ( command == fCmdUpdate ){
    fSystem->UpdateEvent();
  }else if ( command == fCmdList ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  List +++" <<G4endl;
    //fSystem->ModuleList(fCmdList->GetNewIntValue(newValue));
    G4int lvl;
    G4String oname;
    std::istringstream iss(newValue);
    iss >>  lvl >> oname ;
    if ( oname == "stdout" ){
      fSystem->ModuleList(lvl,G4cout);
    }else{
      std::ofstream fout(oname);
      fSystem->ModuleList(lvl,fout);
      fout.close();
    }
  }else if ( command == fCmdListInWorld ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  ListInWorld +++" <<G4endl;
    fSystem->ModuleListInWorld(newValue);
  }else if ( command == fCmdLang ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  List +++" <<G4endl;
    fSystem->SetLang(fCmdLang->GetNewIntValue(newValue));
  }else if ( command == fCmdSelect ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  Select +++" 
           <<newValue<<G4endl;
    fcurrentModule = fSystem->GetModule(newValue);
  }else if ( command == fCmdTypeID ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  TypeID +++" 
           <<newValue<<G4endl;
    if ( fcurrentModule ) {
      fcurrentModule->ApplyFromCatalogue(newValue);
      fcurrentModule->ReBuild();
    }else {
      G4cerr << "@@@ G4MParticleTherapySystemMessenger::ApplyFromCatalogue"
                << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdDump ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  Dump +++" <<G4endl;
    if ( fcurrentModule ) {
      fcurrentModule->Dump(G4cout);
    }else {
      G4cerr << "@@@ G4MParticleTherapySystemMessenger::Dump()"
                << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdDumpFile ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  DumpFile +++" 
           << newValue<< G4endl;
    if ( fcurrentModule ) {
      std::ofstream fout(newValue);
      fcurrentModule->Dump(fout);
      fout.close();
    }else {
      G4cerr << "@@@ G4MParticleTherapySystemMessenger::DumpFile()"
                << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdTranslate ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  Translate +++" 
           <<newValue<<G4endl;
    if ( fcurrentModule ) 
      fcurrentModule->
        SetTranslation(fCmdTranslate->GetNew3VectorValue(newValue));
    else G4cerr << "@@@ G4MParticleTherapySystem::TranslateModule;"
                << " current module has not selected " << G4endl;
  }else if ( command == fCmdDownEdgeZ ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  DownEdgeZ +++" 
           <<newValue<<G4endl;
    if ( fcurrentModule ) {
       fcurrentModule->
         PlaceAtDownZEdge(fCmdDownEdgeZ->GetNewDoubleValue(newValue));
    }else {
      G4cerr << "@@@ G4MParticleTherapySystem::downEdgeZModule;"
             << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdUpEdgeZ ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  UpEdgeZ +++" 
           <<newValue<<G4endl;
    if ( fcurrentModule ) {
      fcurrentModule->
        PlaceAtUpZEdge(fCmdUpEdgeZ->GetNewDoubleValue(newValue));
    }else {
      G4cerr << "@@@ G4MParticleTherapySystem::downEdgeZModule;"
             << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdAttachZ ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  AttachZ +++" 
           <<newValue<<G4endl;
    G4MVBeamModule* momModule = fSystem->GetModule(newValue);
    if ( fcurrentModule && momModule && newValue == "DICOM" ){
      G4MVDICOM* dicom = dynamic_cast<G4MVDICOM*>(momModule);
      G4double dY = dicom->GetDY();
      G4double mydy = fcurrentModule->GetDY();
      // 2014-09-09 Yamashita san 
      //G4ThreeVector myOffset(0,(mydy+dY),0); // replace with.
      //Added by T.Yamashita(2014/09/03)           
      //     -- Apply the direction of CT image to offset.
      G4int unitVecY = dicom->GetUnitVecY(); 
      G4ThreeVector myOffset(0,unitVecY*(mydy+dY),0);
      //     -- Avoid double counting of ctoffset.
      const G4ThreeVector ctoffset = dicom->GetCToffset();
      myOffset += ctoffset;
      //
      //
      const G4Transform3D tran3d = dicom->ComputeTransform3D(myOffset);
      const G4RotationMatrix& rot = tran3d.getRotation().inverse();
      const G4ThreeVector& tran = tran3d.getTranslation();
      fcurrentModule->SetTranslation(tran);
      fcurrentModule->SetRotation(rot);
    }else {
      G4cerr << "@@@ G4MParticleTherapySystem::AttachZModule;"
             << " current module has not selected " << G4endl;
    }
  } else if ( command == fCmdVerbose ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  Verbose +++" 
           <<newValue<<G4endl;
    if ( fcurrentModule ) {
      fcurrentModule->
        SetVerbose(fCmdVerbose->GetNewIntValue(newValue));
    }else {
      G4cerr << "@@@ G4MParticleTherapySystem::SetVerbose;"
             << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdRotate ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  Rotate +++"
           <<newValue<<G4endl;
    if ( fcurrentModule ) {
      fcurrentModule->SetRotation(fCmdRotate->GetNew3VectorValue(newValue));
    }else {
      G4cerr << "@@@ G4MVParticleTherapySystemMessenger::RotateModule;"
             << " current module has not selected " << G4endl;
    }
  }else if ( command == fCmdLVSelect ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  SelectLV +++" 
           <<newValue<<G4endl;
    G4Tokenizer next(newValue);
    G4String module = next();
    G4int idSelect = StoI(next());
    fcurrentLV = fSystem->GetLogicalVolume(module,idSelect);
    if ( fcurrentLV ){
      G4cout << fcurrentLV->GetName() <<", "
             << fcurrentLV->GetMaterial()->GetName() << G4endl;
    }else{
      G4cout << "No LV selected"<<G4endl;
    }

  }else if ( command == fCmdLVDump ){
    G4MVBeamModule* bm = fSystem->GetModule(newValue);
    if ( bm ) {
      const G4VPhysicalVolume* pv = bm->GetPhysicalVolume();
      if ( pv ) {
        G4LogicalVolume* lv = pv->GetLogicalVolume();
        if (lv ){
          fSystem->DumpVolumeTree(lv);
        }
      }
    }
  }else if ( command == fCmdCreateSD ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  CreateSD+++" 
           <<newValue<<G4endl;
    G4Tokenizer next(newValue);
    G4String sdname = next();
    G4String colname = next();
    G4bool bedep = StoB(next());
    G4int  depx = StoI(next());
    G4int  depy = StoI(next());
    G4int  depz = StoI(next());
    G4int  depm = StoI(next());
    G4int  deps = StoI(next());
    G4MSDManager::GetPointer()->CreateSD(sdname,colname,bedep,depx,depy,depz,
                                         depm, deps);
    //
  }else if ( command == fCmdSetDepthSD ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  SetDepthSD+++" 
           <<newValue<<G4endl;
    G4Tokenizer next(newValue);
    G4String sdname = next();
    G4int  depx = StoI(next());
    G4int  depy = StoI(next());
    G4int  depz = StoI(next());
    G4int  depm = StoI(next());
    G4int  deps = StoI(next());
    G4MSDManager::GetPointer()->SetDepthSD(sdname,depx,depy,depz,
                                           depm, deps);
    //
  }else if ( command == fCmdSetEdepSD ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  SetEdepSD+++" 
           <<newValue<<G4endl;
    G4Tokenizer next(newValue);
    G4String sdname = next();
    G4bool bedep = StoB(next());
    G4MSDManager::GetPointer()->SetEdepSD(sdname,bedep);
    //

  }else if ( command == fCmdSetStepSD ){
    G4cout << "+++ G4MParticleTherapySystemMessenger  SetStepSD+++" 
           <<newValue<<G4endl;
    G4Tokenizer next(newValue);
    G4String sdname = next();
    G4bool bstep = StoB(next());
    G4MSDManager::GetPointer()->SetStepSD(sdname,bstep);
    //

  }else if ( command == fCmdSDAttach ){
    G4String& sdname = newValue;
    if ( fcurrentLV ){
      G4MSDManager::GetPointer()->AttachSD(sdname,fcurrentLV);
    }else{
      if ( !fcurrentLV ) G4cout << "%%%%%%% No LV skipped...."<<G4endl;      
    }
  }else if ( command == fCmdSDDetach ){
    if ( fcurrentLV ){
      G4MSDManager::GetPointer()->DetachSD(fcurrentLV);
    }else{
      if ( !fcurrentLV ) G4cout << "%%%%%%% No LV skipped...."<<G4endl;      
    }
  }else if ( command == fCmdAttachTrgID ){
    G4Tokenizer next(newValue);
    G4String sdname = next();
    G4int id = StoI(next());
    if ( fcurrentLV ){
      G4MSDManager::GetPointer()->AttachTrgSD(sdname,fcurrentLV,id);
    }else{
      if ( !fcurrentLV ) G4cout << "%%%%%%% No LV skipped...."<<G4endl;      
    }
  }else if ( command == fCmdPhysicsModified ){
    G4UImanager::GetUIpointer()->ApplyCommand("/run/physicsModified");
    G4ProductionCutsTable::GetProductionCutsTable()->PhysicsTableUpdated();
  }else{
    G4cerr << "%%%%%%  Command not found %%%%%%%"<<G4endl;
  }

}

G4String G4MParticleTherapySystemMessenger::
GetCurrentValue(G4UIcommand* command) {
  if ( command == fCmdSelect )  {
    if ( fcurrentModule ) return fcurrentModule->GetName();
  }
  return G4String("I do not know,");
}

