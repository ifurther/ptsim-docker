//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MBoxDetector
//
// (HISTORY)
//   2014-09-16 Created for PET study. T.Aso
//   2015-07-26 T.Aso   index of tower: izT was replaced to iz
//                      (e.g. layer number).
//   2015-07-26 T.Aso sdLog for temporary use.
//                    ** Under construction.
//   2015-12-14 T.Aso SD?
//   2016-04-07 T.Aso Messenger
//   2016-07-16 T.Aso ApplyFromCatalogue
//   2017-03-15 T.Aso for threading
// -----------------------------------------------------------------
//
// BeamModule Envelope = Sector
//                         - Module 
//                         - SubModule 
//                               - Layer
//                    
// 
#include "G4MBoxDetector.hh"
#include "G4MBoxDetectorMessenger.hh"
//
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"
#include "G4Material.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"
// --

#include "G4MDetectorSD.hh"
//#include "G4MWaterPhantomSD.hh"
//#include "G4MTrajectorySD.hh"

G4MBoxDetector::G4MBoxDetector(const G4String& name) 
  :G4MVBeamModule(name),fCatalogue(NULL),
   fDxyzSect(0,0,0),fMatSect("G4_AIR"),
   fDxyzMod(0,0,0),fMatMod("G4_AIR"),fOffsetMod(0,0,0),fPitchMod(0,0,0),
   fDxyzSubMod(0,0,0),fMatSubMod("G4_AIR"),fOffsetSubMod(0,0,0),fPitchSubMod(0,0,0),
   fNzLay(1)
{
  // Module         
  fNxyzMod[0]=1;  fNxyzMod[1]=1;  fNxyzMod[2]=1;
  // SubSubModule
  fNxyzSubMod[0]=1;fNxyzSubMod[1]=1; fNxyzSubMod[2]=1;
  // Layer
  fDxyzLayVec.clear();
  fMatLayVec.clear();
  fZoffLayVec.clear();
  //
  // Tower
  fNxyzTowVec.clear();
  fDxyzTowVec.clear();
  fMatTowVec.clear();
  fOffsetTowVec.clear();
  fPitchTowVec.clear();
  //
  //
  fMessenger = new G4MBoxDetectorMessenger(name, this);
}

G4MBoxDetector::G4MBoxDetector(G4MVBoxDetectorCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue){
  fCatalogue->SetModule(this);
  fCatalogue->Init();
  //
  fMessenger = new G4MBoxDetectorMessenger(catalogue->GetName(),this);
}


//##ModelId=42F3E524036B
G4MBoxDetector::~G4MBoxDetector() {
  if ( fCatalogue ) delete fCatalogue;
  fDxyzLayVec.clear();
  fMatLayVec.clear();
  fZoffLayVec.clear();
  //
  fNxyzTowVec.clear();
  fDxyzTowVec.clear();
  fMatTowVec.clear();
  fOffsetTowVec.clear();
  fPitchTowVec.clear();
  //
  delete fMessenger;
}

void G4MBoxDetector::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MBoxDetector::SetAllParameters(G4ThreeVector& dxyz,G4String& mat){
  fDxyzSect = dxyz;
  fMatSect = mat;
  SetEnvelopeSize(dxyz);
}

G4VPhysicalVolume* G4MBoxDetector::buildEnvelope(G4LogicalVolume* worldlog) {
  //
  // Sector
  G4Material* mat = G4Material::GetMaterial(fMatSect);
  //G4cout << "Sector "<< fMatSect << G4endl;
  //G4cout << "Sector "<< fDxyzSect << G4endl;

  G4VSolid* solid = new G4Box(GetName(),fDxyzSect.x(),fDxyzSect.y(),fDxyzSect.z());
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,                      // Solid 
                                 mat,                           // Material
                                 GetName()                      // Name
                         );

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),
                   GetTranslation(),
                   logical,                      // Logical volume  
                   GetName(),                       // Name
                   worldlog,  // Mother  volume 
                   false,                         // Not used 
                   0);                            // Copy number  


  return physical;

}

void G4MBoxDetector::buildNode(G4VPhysicalVolume* physVol) {
  //
  //
  G4LogicalVolume *logMother = physVol->GetLogicalVolume();
  //
  // Module
  //
  //G4cout << "Module "<< fMatMod << G4endl;
  //G4cout << " "<< fDxyzMod << G4endl;

  G4String name = "Module";
  G4Material *mat = G4Material::GetMaterial(fMatMod);
  G4Box *solid =
    new G4Box(name, fDxyzMod.x(), fDxyzMod.y(), fDxyzMod.z());
  G4LogicalVolume *lvmod = new G4LogicalVolume(solid,mat,name);
  for (G4int iz = 0; iz < fNxyzMod[2] ; iz++) {
    for (G4int iy = 0; iy < fNxyzMod[1] ; iy++) {
      for (G4int ix = 0; ix < fNxyzMod[0] ; ix++) {
        G4double x = fOffsetMod.x() + fPitchMod.x()*ix;
        G4double y = fOffsetMod.y() + fPitchMod.y()*iy;
        G4double z = fOffsetMod.z() + fPitchMod.z()*iz;
        G4int index = ix+iy*fNxyzMod[0]+iz*fNxyzMod[0]*fNxyzMod[1];
        new G4PVPlacement(0, G4ThreeVector(x, y, z), lvmod,
                          name, logMother,false, index);

      }
    }
  }
  logMother = lvmod;


  //G4cout << "SubModule "<< fMatSubMod << G4endl;
  //G4cout << " "<< fDxyzSubMod << G4endl;
  //
  // SubModule
  //
  name = "SubModule";
  mat = G4Material::GetMaterial(fMatSubMod);
  solid =
    new G4Box(name, fDxyzSubMod.x(), fDxyzSubMod.y(), fDxyzSubMod.z());
  lvmod = new G4LogicalVolume(solid,mat,name);
  lvmod->SetVisAttributes(G4VisAttributes::Invisible);
  for (G4int iz = 0; iz < fNxyzSubMod[2] ; iz++) {
    for (G4int iy = 0; iy < fNxyzSubMod[1] ; iy++) {
      for (G4int ix = 0; ix < fNxyzSubMod[0] ; ix++) {
        G4double x = fOffsetSubMod.x() + fPitchSubMod.x()*ix;
        G4double y = fOffsetSubMod.y() + fPitchSubMod.y()*iy;
        G4double z = fOffsetSubMod.z() + fPitchSubMod.z()*iz;
        G4int index = ix+iy*fNxyzSubMod[0]+iz*fNxyzSubMod[0]*fNxyzSubMod[1];
        new G4PVPlacement(0, G4ThreeVector(x, y, z), lvmod,
                          name, logMother,false, index);

      }
    }
  }
  logMother = lvmod;

  //
  // Check Layer and Tower
  //
  if ( fNzLay != (G4int)fMatTowVec.size() ){
    const G4String& msg = "Layer and Tower number missmatch ";
    G4Exception("G4MBoxDetector::buildNode()","G4MBoxDet00",
                FatalException,msg);
  }
  //
  // Layer
  //
  G4Colour colTow[3] ={G4Color(1,0,0),G4Color(0,1,0),G4Color(0,0,1)};
  //
  //
  name = "Layer";
  G4String towerBase = "tower";
  for (G4int iz = 0; iz < fNzLay ; iz++) {
    mat = G4Material::GetMaterial(fMatLayVec[iz]);
    G4ThreeVector dxyz = fDxyzLayVec[iz];
    G4double zoffset  = fZoffLayVec[iz];
    solid =
      new G4Box(name, dxyz.x(), dxyz.y(), dxyz.z());
    G4cout << " Layer : " << dxyz << G4endl;
    G4cout << " Layer z : " << zoffset << G4endl;
    lvmod = new G4LogicalVolume(solid,mat,name);
    lvmod->SetVisAttributes(G4VisAttributes::Invisible);
    new G4PVPlacement(0, G4ThreeVector(0., 0., zoffset), lvmod,
                          name, logMother,false, iz);
    //
    // Tower inside layer
    //
    G4String towername = GetName(towerBase,iz);
    G4Material* towermat = G4Material::GetMaterial(fMatTowVec[iz]);
    G4VSolid * towersolid =
    new G4Box(towername, fDxyzTowVec[iz].x(), fDxyzTowVec[iz].y(), fDxyzTowVec[iz].z());
    //
    //
    G4LogicalVolume* towerLog = new G4LogicalVolume(towersolid,towermat,towername); 
    //
    // Temp. for SD
    //if ( towermat->GetName() == "G4_BGO" ) sdLogVec.push_back(towerLog);
    fSdLVList.push_back(towerLog);
    //
    //
    //
    if ( iz < 3 ) towerLog->SetVisAttributes(new G4VisAttributes(colTow[iz]));    
    //if ( iz == 0 ) towerLog->SetVisAttributes(G4VisAttributes::Invisible);
    G4int towNx = (G4int)fNxyzTowVec[iz].x();
    G4int towNy = (G4int)fNxyzTowVec[iz].y();
    G4int towNz = (G4int)fNxyzTowVec[iz].z();  // towNz is always 1 ( in Catalogue Definision ).
    //
    for (G4int izT = 0; izT < towNz ; izT++) {
      for (G4int iyT = 0; iyT < towNy ; iyT++) {
        for (G4int ixT = 0; ixT < towNx ; ixT++) {
          G4double xT = fOffsetTowVec[iz].x() + fPitchTowVec[iz].x()*ixT;
          G4double yT = fOffsetTowVec[iz].y() + fPitchTowVec[iz].y()*iyT;
          G4double zT = fOffsetTowVec[iz].z() + fPitchTowVec[iz].z()*izT;
          // 20150726 izT was replaced to iz (i.e. layer number).
          //    izT is always 1 in FileCatalogue.
          //G4int index = ixT+iyT*towNx+izT*towNx*towNy;
          //G4int index = ixT+iyT*towNx+(iz)*towNx*towNy;
          G4int index = ixT+iyT*towNx;
          new G4PVPlacement(0, G4ThreeVector(xT, yT, zT), towerLog,
                          towername, lvmod,false, index);
        }
      }
    }
    //
    //----
  }
  logMother = lvmod;

}

void G4MBoxDetector::BuildInSDandField() {
  /// Sensitive Detector                                                                     
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4VSensitiveDetector *mysd = sdm->FindSensitiveDetector(GetName(),false);
  if ( !mysd ) {
    G4cout << "++ G4MBoxDetector::  Create Sensitive Detector "<<GetName()<<G4endl;
    G4MDetectorSD* sd = new G4MDetectorSD(GetName(),"HitsCollection");
    sd->SetZeroEdep(false);
    sd->SetDepth(0,0,1,2,4);
    sd->SetNxyzMod(fNxyzSubMod[0],fNxyzSubMod[1],fNxyzSubMod[2]);
    sd->SetNzTow(fNzLay);
    for ( G4int iz = 0; iz < fNzLay; iz++){
      sd->SetNxyTow((G4int)fNxyzTowVec[iz].x(),(G4int)fNxyzTowVec[iz].y(),iz);
    }
    // G4MWaterPhantomSD* sd = new G4MWaterPhantomSD(GetName(),"PETHitsCollection");       
    //sd->SetDepth(0,2,4);                                                                 
    //G4MTrajectorySD* sd = new G4MTrajectorySD("PET","PETHitsCollection");                
    //sd->SetDepth(0,2,4);                                                                 
    mysd = sd;
    sdm->AddNewDetector(mysd);
  }
  //                                                                                         
  // Logical name                                                                            
  for (G4int i = 0; i < (G4int)fSdLVList.size(); i++){
    fSdLVList[i]->SetSensitiveDetector(mysd);
  }
}

void G4MBoxDetector::SetSector(G4ThreeVector& dxyz, G4String& mat){
  fDxyzSect = dxyz;
  fMatSect = mat;
  SetEnvelopeSize(dxyz);
}

void G4MBoxDetector::SetModule(G4int n[3], G4ThreeVector& dxyz, G4String& mat,
                               G4ThreeVector& offset, G4ThreeVector& pitch){
  fNxyzMod[0] = n[0];   fNxyzMod[1] = n[1];   fNxyzMod[2] = n[2];
  fDxyzMod = dxyz;
  fMatMod = mat;
  fOffsetMod = offset;
  fPitchMod = pitch;
}

void G4MBoxDetector::SetSubModule(G4int n[3], G4ThreeVector& dxyz, G4String& mat,
                               G4ThreeVector& offset, G4ThreeVector& pitch){
  fNxyzSubMod[0] = n[0];   fNxyzSubMod[1] = n[1];   fNxyzSubMod[2] = n[2];
  fDxyzSubMod = dxyz;
  fMatSubMod = mat;
  fOffsetSubMod = offset;
  fPitchSubMod = pitch;
}

void G4MBoxDetector::SetLayer(G4int nz,
                              std::vector<G4ThreeVector>& dxyzVec,
                              std::vector<G4String>&  matVec,
                              std::vector<G4double>&  offsetVec){
  fNzLay = nz;
  fDxyzLayVec = dxyzVec;
  fMatLayVec = matVec;
  fZoffLayVec = offsetVec;
}

void G4MBoxDetector::SetTower(std::vector<G4ThreeVector>& nVec, 
                              std::vector<G4ThreeVector>& dxyzVec, 
                              std::vector<G4String>& matVec,
                              std::vector<G4ThreeVector>& offsetVec,
                              std::vector<G4ThreeVector>& pitchVec){

  fNxyzTowVec = nVec;
  fDxyzTowVec = dxyzVec;
  fMatTowVec = matVec;
  fOffsetTowVec = offsetVec;
  fPitchTowVec = pitchVec;

}

void G4MBoxDetector::SetBEdep(G4bool b){
   bEdep = b;
   /// Sensitive Detector 
   G4SDManager *sdm = G4SDManager::GetSDMpointer();
   G4MDetectorSD* sd = 
     dynamic_cast<G4MDetectorSD*>(sdm->FindSensitiveDetector(GetName(),false));
   if ( sd ) {
     sd->SetZeroEdep(bEdep);
   }
}

void G4MBoxDetector::SetDepth(G4int d_x, G4int d_y, G4int d_z, G4int d_m, G4int d_s){
   /// Sensitive Detector 
   G4SDManager *sdm = G4SDManager::GetSDMpointer();
   G4MDetectorSD* sd = 
     dynamic_cast<G4MDetectorSD*>(sdm->FindSensitiveDetector(GetName(),false));
   if ( sd ) {
     sd->SetDepth(d_x,d_y,d_z,d_m,d_s);
   }
}

void G4MBoxDetector::Dump(std::ostream& out){
  G4int d_x=0, d_y=0, d_z=0, d_m=0, d_s=0;
  /// Sensitive Detector 
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4MDetectorSD* sd = 
    dynamic_cast<G4MDetectorSD*>(sdm->FindSensitiveDetector(GetName(),false));
  if ( sd ) {
    d_x = sd->GetDepth(0);
    d_y = sd->GetDepth(1);
    d_z = sd->GetDepth(2);
    d_m = sd->GetDepth(3);
    d_s = sd->GetDepth(4);
  }
  out << " Depth  :" << d_x <<","<<d_y<<","<<d_z<<","<<d_m<<","<<d_s<<G4endl;
  out << " Sector :" <<G4endl;
  out << "  (size):" << fDxyzSect/mm << G4endl;
  out << "  (mat) :" << fMatSect <<G4endl;
  out << " Module :" << G4endl;
  out << "  (dim) :" << fNxyzMod[0]<<","<<fNxyzMod[1]<<","<<fNxyzMod[2]<< G4endl;
  out << "  (size):" << fDxyzMod/mm << G4endl;
  out << "  (mat) :" << fMatMod <<G4endl;
  out << "  (off) :" << fOffsetMod/mm <<G4endl;
  out << "  (pit) :" << fPitchMod/mm <<G4endl;
  out << " SubMod :" << G4endl;
  out << "  (dim) :" << fNxyzSubMod[0]<<","<<fNxyzSubMod[1]<<","<<fNxyzSubMod[2]<< G4endl;
  out << "  (size):" << fDxyzSubMod/mm << G4endl;
  out << "  (mat) :" << fMatMod <<G4endl;
  out << "  (off) :" << fOffsetSubMod/mm <<G4endl;
  out << "  (pit) :" << fPitchSubMod/mm <<G4endl;
  out << " Layer  :" << G4endl;
  out << "  (dim) :" << fNzLay<<G4endl;
  for ( G4int iz = 0; iz < fNzLay; iz++ ){
    out << " Layer "<<iz<<G4endl;
    out << "  (size):" << fDxyzLayVec[iz]/mm << G4endl;
    out << "  (mat) :" << fMatLayVec[iz] <<G4endl;
    out << "  (off) :" << fZoffLayVec[iz]/mm <<G4endl;
    out << "  Tower   :" << G4endl;
    out << "    (dim) :" << fNxyzTowVec[iz]<<G4endl;
    out << "    (size):" << fDxyzTowVec[iz]/mm << G4endl;
    out << "    (mat) :" << fMatTowVec[iz] <<G4endl;
    out << "    (off) :" << fOffsetTowVec[iz]/mm <<G4endl;
    out << "    (pit) :" << fPitchTowVec[iz]/mm <<G4endl;
  }

}
