//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    DICOM Module for Regular Parameterisation
//
// (HISTORY)
// 27 Feb. 2007 T.Aso Copied from G4DICOM and modified for 
//                    RegularParameterisation.
// 13 Jun. 2007 T.Aso Introduce G4MDicomRegularParameterisation.
// 25 Jul. 2007 T.Aso The position of inner envelope was moved with 
//                    respect to the offset of CT image.
//                    This is requested from NCC.
// 20 Mar. 2008 T.Aso Offset of CT image was removed.
// 09 Sep. 2009 T.Aso Use density resolution setting.
//                    DICOMData filters are moved to G4MVDICOM.
// 09 Sep. 2009 T.Aso PrepareDICOM() introduced.
// 10 Sep. 2009 T.Aso PrepareMatList() introduced.
// 14 Sep. 09 T.Aso  Mask information for outline extraction in DICOM data
//                    was implemented for material assignment.
// 2016-12-21 T.Aso PrepareDICOM(), GetLabelVec().
//   2017-03--15 T.Aso Threading                  
// 2019-04-04 T.Aso SDName was replaced from "G4MDICOM" to the beam module name.
// -----------------------------------------------------------------
// 
#include "G4MRegularDICOM.hh"

#include "G4MDICOMHandler.hh"
#include "G4MDICOMManager.hh"
#include "G4MDICOMConfiguration.hh"
#include "G4MDICOMData.hh"
#include "G4MDICOMCT2Density.hh"
#include "G4MDICOMCT2Material.hh"

#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4Element.hh"
#include "G4Transform3D.hh"
#include "G4PVReplica.hh" 
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4Element.hh"
#include "G4SDManager.hh"

#include "G4VisAttributes.hh"

#include "G4MDicomRegularParameterisation.hh"

//#include "G4MRegularDICOMSD.hh"

#include <cmath>

G4MRegularDICOM::G4MRegularDICOM(G4String name) 
  :G4MVDICOM(name)
{}

G4MRegularDICOM::G4MRegularDICOM(G4MVDICOMCatalogue* catalogue)
  : G4MVDICOM(catalogue->GetName())
{}

G4MRegularDICOM::~G4MRegularDICOM() {}

void G4MRegularDICOM::buildNode(G4VPhysicalVolume* physvol) {

  //-- Open DICOM Handler---------------------------------------
  G4MDICOMConfiguration* config=
    G4MDICOMManager::GetPointer()->Get(fDICOMFileName);
  //--------------------------------------------------------------


  //std::vector<short> label;
  G4bool  override=TRUE;
  //G4MDICOMData* dicomData= PrepareDICOM(label,override);
  G4MDICOMData* dicomData= PrepareDICOM(override);
  std::vector<short>& label=GetLabelVec();
  G4MDICOMCT2Material* matList = PrepareMatList();

  G4Material* air = G4Material::GetMaterial("Air");//Dummy material.
  //
  //
  G4double xPixelSpacing  = dicomData->GetXPixelSPC();
  G4double yPixelSpacing  = dicomData->GetYPixelSPC();
  G4double sliceThickness = dicomData->GetZPixelSPC();
  G4int    totalRows      = dicomData->GetRow(); 
  G4int    totalColumns   = dicomData->GetColumn();
  G4int    totalSlices    = dicomData->GetSlice();
  G4double tissueX        = (xPixelSpacing/2.) *mm;
  G4double tissueY        = (yPixelSpacing/2.) *mm;
  G4double tissueZ        = (sliceThickness/2.) *mm;
  G4ThreeVector dxyz      = dicomData->GetDxyz()*mm;
  G4double dX             = dxyz.x();
  G4double dY             = dxyz.y();
  G4double dZ             = dxyz.z();
  //
  // ------------------------------------------------
  G4MDicomRegularParameterisation* param 
    = new G4MDicomRegularParameterisation();
    param->SetVoxelDimensions(tissueX,tissueY,tissueZ);
    param->SetNoVoxel(totalRows,totalColumns,totalSlices);
    param->SetMaterials(matList->GetMaterialVector());
    //
    //SetMaterialIndices() is performed in AssignMaterialToVexles().
    G4String Air="Air";
    param->
      AssignMaterialToVoxels(dicomData,label,
                             matList->GetCTIndexByName(Air));
    // ------------------------------------------------
    //CT-Density (Prepare For Dose Calculation)
    G4MDICOMCT2Density filterDensity(fFileCT2Density);
    config->DoFiltering(filterDensity);   
    dicomData->ShowParameters();
    //
    G4cout << "**** Regular DICOM "<<G4endl;
    G4cout << "* G4MDicom RegularVolume Half length (mm)" 
           << " dx " << dX/mm 
           << " dy " << dY/mm
           << " dz " << dZ/mm << " mm" << G4endl;
    G4cout << "* G4MDicom RegularVolume Half tissue (mm)" 
           << " tissuex " << tissueX/mm 
           << " tissuey " << tissueY/mm
           << " tissuez " << tissueZ/mm << " mm" << G4endl;
    G4cout << " row " << totalRows << " column " << totalColumns
           << " slice " << totalSlices<<G4endl;
  //
  //
  G4String voxelName(GetName()+"VoxelRegl");
  G4Box* voxel = new G4Box(voxelName, tissueX, tissueY, tissueZ);
  G4LogicalVolume* logVoxel = new G4LogicalVolume(voxel, air, voxelName);
  logVoxel->SetVisAttributes(G4VisAttributes::Invisible);
  //
  param->BuildContainerSolid(physvol);
  G4Box* container_solid = (G4Box*)(physvol->GetLogicalVolume()->GetSolid());
  param->CheckVoxelsFillContainer(container_solid->GetXHalfLength(),
                                  container_solid->GetYHalfLength(),
                                  container_solid->GetZHalfLength());
  G4PVParameterised* patient_phys = 
    new G4PVParameterised(GetName(),
                          logVoxel,
                          physvol->GetLogicalVolume(),
                          kZAxis, 
                          totalRows*totalColumns*totalSlices,
                          param);
  
  patient_phys->SetRegularStructureId(1);

  fSdLVList.push_back(logVoxel);
}

void G4MRegularDICOM::BuildInSDandField() {
  /* Not supported
  G4String SDName = GetName();
  SetSensitive(SDName, fSdLVList[0]);
  */
}

void G4MRegularDICOM::SetSensitive(G4String& , G4LogicalVolume* ) {
  /* Not supported
  G4SDManager * SDMan = G4SDManager::GetSDMpointer();

  G4VSensitiveDetector * dicomSD = SDMan->FindSensitiveDetector(SDName,false);
  if ( !dicomSD ){
      G4cout << "++ G4MRegularDICOM::  Create Sensitive Detector "<<SDName<<G4endl;
      dicomSD = new G4MRegularDICOMSD(SDName);
      SDMan->AddNewDetector(dicomSD);
  }
  ((G4MRegularDICOMSD*)dicomSD)->SetDICOMFile(fDICOMFileName);

  logical->SetSensitiveDetector(dicomSD);
  */
}

