//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------//
//
//  (Desctiption)
//   This is a class for catalogue of parameters for WireMonitor
// 
//  (History)
//   06-Oct-05   T.Aso
// 2014-03-11   T.Aso fVerbose.
//
//---------------------------------------------------------------------
//
#include "G4MWireMonitorFileCatalogue.hh"
#include "G4MWireMonitor.hh"
#include <fstream>

G4MWireMonitorFileCatalogue::
G4MWireMonitorFileCatalogue(const G4String& name,
                            const G4String& fileName)
  :G4MVWireMonitorCatalogue(name),fDefaultFileName(fileName){
}

G4MWireMonitorFileCatalogue::~G4MWireMonitorFileCatalogue()
{}

void G4MWireMonitorFileCatalogue::Init(){
   Prepare(fDefaultFileName);
   fModule->SetAllParameters(fMatElm,fDxyzElm,fZElm,
                             fNWire,fSlantWire,fPitchWire, 
                             fMatWire,fDrWire,fDzWire,fZWire,
                             fMatMaster );
}

void G4MWireMonitorFileCatalogue::Prepare(G4String& pname){
  std::ifstream fileio(pname);
  if(!fileio) { 
    const G4String& msg="File not found "+pname;
    G4Exception("G4MWireMonitorFileCatalogue()","G4MWireMonFileCata00",
                FatalException,msg);
  }else{
    G4int nElm = 0;
    // Master Volume's Material.
    fileio >> fMatMaster >> nElm;
    if ( fVerbose > 0 ) G4cout << fMatMaster << " " << nElm<<G4endl;
    //
    // Box Plate
    fDxyzElm.clear();
    fZElm.clear();
    fMatElm.clear();
    G4double dx,dy,dz,z;
    G4String mat;
    for ( G4int i = 0; i < nElm; i++){
      fileio >> mat >> dx >> dy >> dz >> z ;
      if ( fVerbose > 0 ) G4cout << mat <<" "<<dx<<" "<<dy<<" "<<dz<<" "<<z<<G4endl;
      dx   *= (mm/2.);
      dy   *= (mm/2.);
      dz   *= (mm/2.);  // Full width to half width.
      z    *= mm;
      G4ThreeVector v(dx,dy,dz);
      fDxyzElm.push_back(v);
      fZElm.push_back(z);
      fMatElm.push_back(mat);
    }
    // Wire
    fNWire.clear();
    fSlantWire.clear();
    fPitchWire.clear();
    fMatWire.clear();
    fDrWire.clear();
    fDzWire.clear();
    fZWire.clear();
    G4int nLayer=0;
    G4int nwire;
    G4double slant,pitch,drw,dzw,zw;
    G4String matw;
    fileio >> nLayer ;
    if ( fVerbose > 0 ) G4cout << nLayer <<G4endl;
    for ( G4int i = 0; i < nLayer; i++){
        fileio >> nwire >> slant >> pitch ;
        if ( fVerbose > 0 ) G4cout << nwire <<" "<<slant<<" "<<pitch <<G4endl;
        slant *= degree;
        pitch *=mm;
        fNWire.push_back(nwire);
        fSlantWire.push_back(slant);
        fPitchWire.push_back(pitch);
        fileio >> matw >> drw >> dzw>>zw;
        drw *= mm;
        dzw *= (mm/2.);
        zw  *= mm;  
        fMatWire.push_back(matw);
        fDrWire.push_back(drw);
        fDzWire.push_back(dzw);
        fZWire.push_back(zw);
    }
  }
}

void G4MWireMonitorFileCatalogue::Apply(){
   fModule->SetAllParameters(fMatElm,fDxyzElm,fZElm,
                             fNWire,fSlantWire,fPitchWire, 
                             fMatWire,fDrWire,fDzWire,fZWire,
                             fMatMaster );
  fModule->ReBuild();
}
