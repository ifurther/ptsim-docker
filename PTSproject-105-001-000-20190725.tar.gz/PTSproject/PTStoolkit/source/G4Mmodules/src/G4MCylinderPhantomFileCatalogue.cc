//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for WaterPhantom type module
// 
//  (History)
//  2019-03-20 T.Aso Copied from G4MWaterPhantomFileCatalogue.
//
//---------------------------------------------------------------------
//
#include "G4MCylinderPhantomFileCatalogue.hh"
#include "G4MCylinderPhantom.hh"
#include <fstream>
#include <sstream>

G4MCylinderPhantomFileCatalogue::G4MCylinderPhantomFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVCylinderPhantomCatalogue(name),fDefaultFileName(fileName){
}

G4MCylinderPhantomFileCatalogue::~G4MCylinderPhantomFileCatalogue()
{}

void G4MCylinderPhantomFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(drpz, material,drpzsd,nr,np,nz,offsetsd);
}

void G4MCylinderPhantomFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MCylinderPhantomFileCatalogue::Prepare()",
                "G4MCylinderPhantomFileCata00",FatalException,msg);
  }else{
    ifs.getline(chline,512);  // Full size 
    std::istringstream iss1(chline);
    G4double fr,fp,fz;
    iss1 >> fr >> fp >> fz;   // Full Size
    drpz.setX(fr*mm);
    drpz.setY(fp*degree);
    drpz.setZ(fz*mm/2.);

    ifs.getline(chline,512);  //material
    std::istringstream iss2(chline);
    iss2 >> material;

    ifs.getline(chline,512);  // Full size (SD)
    std::istringstream iss3(chline);
    iss3 >> fr >> fp >> fz;   // Full Size (SD)
    drpzsd.setX(fr*mm);
    drpzsd.setY(fp*degree);
    drpzsd.setZ(fz*mm/2.);

    ifs.getline(chline,512);  // Dimension (SD)
    std::istringstream iss4(chline);
    iss4 >> nr >> np >> nz;   // Dimension (SD)

    ifs.getline(chline,512);  // SD offset
    std::istringstream iss5(chline);
    iss5 >> fr >> fp >> fz;   // SD offset
    offsetsd.setX(fr);
    offsetsd.setY(fp*degree);
    offsetsd.setZ(fz*mm);

  }
  ifs.close();
}

void G4MCylinderPhantomFileCatalogue::Apply(){
   fModule->SetAllParameters(drpz, material,drpzsd,nr,np,nz,offsetsd);
   fModule->ReBuild();
}







 
