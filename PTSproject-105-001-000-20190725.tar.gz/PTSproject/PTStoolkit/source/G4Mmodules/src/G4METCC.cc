//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for ETCC shape component
//
// (HISTORY)  
// 2017-12-22 T.Aso
//---------------------------------------------------------------------
//
#include "G4METCC.hh"
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4PVPlacement.hh"
#include "G4PVReplica.hh"
#include "G4MDetectorSD.hh"
#include "G4SDManager.hh"

G4METCC::G4METCC(const G4String& name, const G4ThreeVector& dxyz,
               const G4String& mat)
  : G4MVBeamModule(name,dxyz), matName(mat),fCatalogue(NULL)
{}

G4METCC::G4METCC(const G4String& name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4METCC::G4METCC(G4MVETCCCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4METCC::~G4METCC()
{
  if ( fCatalogue ) delete fCatalogue;
}

void G4METCC::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4METCC::SetAllParameters(const G4ThreeVector& dxyz, const G4String& mat){
  SetEnvelopeSize(dxyz);
  matName = mat;
}


G4VPhysicalVolume* G4METCC::buildEnvelope(G4LogicalVolume* worldlog)
{
  G4Material *mat = G4Material::GetMaterial(matName);

  G4Box *solid = new G4Box(GetName(),GetDX(),GetDY(),GetDZ());

  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());

  //G4VPhysicalVolume* physical = new G4PVPlacement(t3d,
  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                   lv,
                                                   GetName(),
                                                   worldlog,
                                                   false,
                                                   0);
  return physical;
}

void G4METCC::buildNode(G4VPhysicalVolume* physEnv){

  G4LogicalVolume* logEnv = physEnv->GetLogicalVolume();
  //
  // Inside
  G4Box *solid_in = new G4Box(GetName(),
                              fInsideDxyz.x(),
                              fInsideDxyz.y(),
                              fInsideDxyz.z());

  G4Material *mat = G4Material::GetMaterial(fInsideMat);
  G4LogicalVolume *lv_in = new G4LogicalVolume(solid_in,mat,GetName());
  //G4VPhysicalVolume* phys = 
    new G4PVPlacement(0,G4ThreeVector(),lv_in,GetName(),
                      logEnv,false,0);

  // Gas
  G4String GasName(GetName()+"Gas");
  G4Box *solGas = new G4Box(GasName,
                            fGasDxyz.x(),
                            fGasDxyz.y(),
                            fGasDxyz.z());

  mat = G4Material::GetMaterial(fGasMat);
  G4LogicalVolume *lvGas = new G4LogicalVolume(solGas,mat,GasName);
  new G4PVPlacement(0,G4ThreeVector(0.,0., fGasZoffset),lvGas,GasName,
                    lv_in,false,0);

  //========================
  fSdLVList.push_back(lvGas);
  //========================

  // Submodule
  G4Box *solSub = new G4Box(GetName(),
                            fSubDxyz.x(),
                            fSubDxyz.y(),
                            fSubDxyz.z());

  mat = G4Material::GetMaterial(fSubMat);
  G4LogicalVolume *lvSub = new G4LogicalVolume(solSub,mat,GetName());
  G4int count = 0;
  G4double posz = fSubOffset.z();
  for ( G4int iy = 0; iy < fNsubY; iy++){
    G4double posy = fSubOffset.y()+fSubPitch.y()*iy;
    for ( G4int ix = 0; ix < fNsubX; ix++){
      G4double posx = fSubOffset.x()+fSubPitch.x()*ix;
      new G4PVPlacement(0,G4ThreeVector(posx,posy,posz),
                        lvSub,GetName(),lv_in,false,count++);
    }
  } 

  // Layer ( inside submodule )
  for ( G4int i = 0; i < fNlayer; i++){
    G4Box *solLayer = new G4Box(GetName(),
                                fLayerDxyz[i].x(),
                                fLayerDxyz[i].y(),
                                fLayerDxyz[i].z());

    mat = G4Material::GetMaterial(fLayerMat[i]);
    G4LogicalVolume *lvLayer = 
      new G4LogicalVolume(solLayer,mat,GetName());
    new G4PVPlacement(0,G4ThreeVector(0.,0.,fLayerOffZ[i]),
                      lvLayer,GetName(),lvSub,false,i);
    // Tower
    if ( fTower[i] != 0 ){
      G4MGParam* p = fTower[i];
      G4double pDx = p->GetDx();
      G4double pDy = p->GetDy();
      G4double pNx = p->GetNx();
      G4double pNy = p->GetNy();
      G4String& pMat = p->GetMat();
      //
      // Y Slice
      G4String yRepName(GetName()+"Crystal");
      G4Box *solY = new G4Box(GetName(),
                              fLayerDxyz[i].x(),
                              pDy,
                              fLayerDxyz[i].z());

      mat = G4Material::GetMaterial(pMat);      
      G4LogicalVolume *logY = 
      new G4LogicalVolume(solY,mat,GetName());
      //G4PVReplica* yReplica = 
      new G4PVReplica(yRepName,logY,lvLayer,kYAxis,pNy,pDy*2.);
      //
      // X Slice
      G4String xRepName(GetName()+"XY");
      G4Box *solX = new G4Box(GetName(),
                              pDx,
                              pDy,
                              fLayerDxyz[i].z());

      G4LogicalVolume *logX = 
      new G4LogicalVolume(solX,mat,GetName());

      //========================
      fSdLVList.push_back(logX);
      //========================

      //G4PVReplica* xReplica = 
      new G4PVReplica(xRepName,logX,logY,kXAxis,pNx,pDx*2.);
    } // End of Tower

  }
}

void G4METCC::BuildInSDandField() {
  /// Sensitive Detector
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  G4String GasName(GetName()+"Gas");
  G4String CrystalName(GetName()+"Crystal");
  //
  G4VSensitiveDetector *GasSD = 
    sdm->FindSensitiveDetector(GasName,false);
  G4VSensitiveDetector *CrystalSD = 
    sdm->FindSensitiveDetector(CrystalName,false);
  //
  if ( !GasSD  ) {
    G4cout << "++ G4METCC::  Create Sensitive Detector for Gas "<<G4endl;
    G4MDetectorSD* sd = new G4MDetectorSD(GasName,"HitsCollection");
    sd->SetZeroEdep(false); // Don't Skip recoding whatever the edep equals to zero.
    sd->SetSaveStep(true); // Do not merge steps.
    // 0=Gas, 1=inside, 2=Module
    sd->SetDepth(2,2,2,2,2); // Module
    sdm->AddNewDetector(sd);
    fSdLVList[0]->SetSensitiveDetector(sd);
  }
  if ( !CrystalSD  ) {
    G4cout << "++ G4METCC::  Create Sensitive Detector for Crystal "<<G4endl;
    G4MDetectorSD* sd = new G4MDetectorSD(CrystalName,"HitsCollection");
    sd->SetZeroEdep(true); // Skip recoding if the edep equals to zero.
    sd->SetSaveStep(false); // merge steps.
    // 0=x, 1=y, 2=layer, 3=submod, 4=inside, 5=Module
    sd->SetDepth(0,1,3,3,5); // x y submod Module
    sdm->AddNewDetector(sd);
    fSdLVList[1]->SetSensitiveDetector(sd);
  }
}

