//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MMagField
//
//  (HISTORY)
// 2017-03-15 T.Aso for threading.
//
//---------------------------------------------------------------------
//
#include "G4MMagField.hh"

G4MMagField::G4MMagField():G4MagneticField() {
  fBfield[0]=0.;
  fBfield[1]=0.;
  fBfield[2]=0.;
}

G4MMagField::G4MMagField(const G4MMagField& right)
 :G4MagneticField() {
    fBfield[0]=right.fBfield[0];
    fBfield[1]=right.fBfield[1];
    fBfield[2]=right.fBfield[2];
}

void G4MMagField::GetFieldValue(const G4double [4], G4double* BField) const {
  BField[0] = fBfield[0];
  BField[1] = fBfield[1];
  BField[2] = fBfield[2];
}

void G4MMagField::SetFieldValue(G4double* bfield) {
  fBfield[0] = bfield[0];
  fBfield[1] = bfield[1];
  fBfield[2] = bfield[2];
}

void G4MMagField::SetFieldValue(const G4ThreeVector&  bfield) {
  fBfield[0] = bfield.x();
  fBfield[1] = bfield.y();
  fBfield[2] = bfield.z();
}

