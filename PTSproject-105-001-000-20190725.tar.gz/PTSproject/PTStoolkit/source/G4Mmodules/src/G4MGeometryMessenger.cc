//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MGeometryMessenger
//
//   /G4M/    directory
//      Commands
//         System   sysname
//         ChangeSystem sysname
//
//   /G4M/PTS    directory
//
//         TKVersion  ostream;   Print PTStoolkit version
//         AppVersion  ostream;   Print PTS application version
//         G4Version  ostream;   Print Geant4 version
//         RunSummary  ostream;   Print Run summary
//
//  (HISTORY)
//   2014-08-07 T.Aso commands for printing versions.
//
//---------------------------------------------------------------------
#include "globals.hh"
#include <fstream>
#include "G4MGeometryMessenger.hh"
#include "G4MVGeometryBuilder.hh"

G4MGeometryMessenger::G4MGeometryMessenger(G4MVGeometryBuilder* builder) {
  fBuilder = builder;

  fDir = new G4UIdirectory("/G4M/");
  fDir->SetGuidance("UI commands ");

  fCmdSelection = new G4UIcmdWithAString("/G4M/System",this);
  fCmdSelection->SetGuidance("Selection of beam-line system");
  fCmdSelection->SetParameterName("system",false);
  fCmdSelection->AvailableForStates(G4State_PreInit);

  fCmdChange = new G4UIcmdWithAString("/G4M/ChangeSystem",this);
  fCmdChange->SetGuidance("Change beam-line system");
  fCmdChange->SetParameterName("system",false);
  fCmdChange->AvailableForStates(G4State_Idle);

  fPTSDir = new G4UIdirectory("/G4M/PTS/");
  fPTSDir->SetGuidance("UI commands for PTS versions");

  fCmdTKVersion = new G4UIcmdWithAString("/G4M/PTS/TKVersion",this);
  fCmdTKVersion->SetGuidance("Print PTS toolkit version number.");
  fCmdTKVersion->SetParameterName("oname",true);
  fCmdTKVersion->SetDefaultValue("stdout");
  fCmdTKVersion->AvailableForStates(G4State_PreInit,G4State_Idle);

  fCmdAppVersion = new G4UIcmdWithAString("/G4M/PTS/AppVersion",this);
  fCmdAppVersion->SetGuidance("Print PTS Application version number.");
  fCmdAppVersion->SetParameterName("oname",true);
  fCmdAppVersion->SetDefaultValue("stdout");
  fCmdAppVersion->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  fCmdG4Version = new G4UIcmdWithAString("/G4M/PTS/G4Version",this);
  fCmdG4Version->SetGuidance("Print Geant4 version number.");
  fCmdG4Version->SetParameterName("oname",true);
  fCmdG4Version->SetDefaultValue("stdout");
  fCmdG4Version->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  fCmdRunSummary = new G4UIcmdWithAString("/G4M/PTS/RunSummary",this);
  fCmdRunSummary->SetGuidance("Print PTS Run Summary.");
  fCmdRunSummary->SetParameterName("oname",true);
  fCmdRunSummary->SetDefaultValue("stdout");
  fCmdRunSummary->AvailableForStates(G4State_PreInit,G4State_Idle);

}

G4MGeometryMessenger::~G4MGeometryMessenger() {
  delete fCmdSelection;
  delete fCmdChange;

  delete fCmdTKVersion;
  delete fCmdAppVersion;
  delete fCmdG4Version;
  delete fCmdRunSummary;

  delete fDir;
  delete fPTSDir;
}

void G4MGeometryMessenger::SetNewValue(G4UIcommand* command, G4String newValue) {
  if ( command == fCmdSelection ){
    fBuilder->SetSystem(newValue);
  }else if ( command == fCmdChange ){
    fBuilder->ChangeSystem(newValue);
    //
  }else if ( command == fCmdTKVersion ){
    if ( newValue == "stdout"){
      fBuilder->TKVersion(G4cout);
    }else{
      std::ofstream out(newValue);
      fBuilder->TKVersion(out);      
      out.close();
    }
  }else if ( command == fCmdAppVersion ){
    if ( newValue == "stdout"){
      fBuilder->AppVersion(G4cout);
    }else{
      std::ofstream out(newValue);
      fBuilder->AppVersion(out);      
      out.close();
    }
  }else if ( command == fCmdG4Version ){
    if ( newValue == "stdout"){
      fBuilder->LinkedG4Version(G4cout);
    }else{
      std::ofstream out(newValue);
      fBuilder->LinkedG4Version(out);      
      out.close();
    }
  }else if ( command == fCmdRunSummary ){
    if ( newValue == "stdout"){
      fBuilder->RunSummary(G4cout);
    }else{
      std::ofstream out(newValue);
      fBuilder->RunSummary(out);      
      out.close();
    }
 }else{
    G4cerr << "%%%%%%  Command not found %%%%%%%"<<G4endl;
 }
}


G4String G4MGeometryMessenger::GetCurrentValue(G4UIcommand* command){
  if ( (command == fCmdSelection) || (command = fCmdChange) ) 
    return fBuilder->GetSystemName();
  else return G4String();
}

