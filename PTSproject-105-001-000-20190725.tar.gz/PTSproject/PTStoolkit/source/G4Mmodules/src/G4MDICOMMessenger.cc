//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// (Desctiption)
//    Messenger for DICOM Module
//
//
//   /G4M/DICOM/     directory ; Specific to DICOM modules.
//     Commands:
//        select     dicomModuleName;  Select DICOM Module for messeging
//        file       dicomFileName;    DICOM list file name
//        isocenter  3 vector unit;    isocenter position in CT frame
//        complement bool ;    Enable complement of slices.
//        mesh       double  unit ;    Size of Remesing cube
//        meshBin    int          ;    Remesh in 2D by combining pixels
//        winXmin    double  unit ;    Minimum X position of Valid window 
//        winXmax    double  unit ;    Maximum X position of Valid window 
//        winYmin    double  unit ;    Minimum Y position of Valid window 
//        winYmax    double  unit ;    Maximum Y position of Valid window 
//        winZmin    double  unit ;    Minimum Z position of Valid window 
//        winZmax    double  unit ;    Maximum Z position of Valid window 
//        trim       bool;             Triming volume.
//        minvalue   double  ;         Acceptable minimum Value
//        maxvalue   double  ;         Acceptable maximum Value
//        ctair      double  ;         CT Value of Air, needed at edge.
//        label      true  ;         CT labeling for outline extraction.
//        ctcutoff   double  ;         CT value for cut off outside of body
//        densityResol double ;         CT Value resolution in density
//        ct2density table file name;  CT2Density table file.
//        paramtype  type name;        Geometry param type.
//        gantry     double unit;      Gantry Angle
//        couchAngle double unit;      Couch Angle
//        dataOrientation string;      Data orientation in NONE,HFS,FFS,HFP,FFP
//        vis  bool ; Visuallization of voxels (Before install).
//
//        update;     Update placement of DICOM geometry.
//        renameMaterial  string string; Rename mateial name.
//        showMatList string int : Show material list
//
//
//        rts        bool;             Enable RTS data.
//        roiCtValReplacer string;      RoiCTmap file name.
//
//
// (HISTORY)
//   15-Feb-07  T.Aso Separated from G4MParticleTherapyMessenger
//   25-Jul-07  T.Aso ctoffset command was introduced.
//   15-Dec-08  T.Aso ctoffset command was modified as isocenter.
//                    The new command defines the isocenter position
//                    on the CT image.
//                    couchAngle command was introduced.
//                    Introduce 2D mesh algorithm and trimming algorithm. 
//   18-Mar-09  T.Aso New command for density resolution for creating materials
//                    in DICOM data.
//   08-Sep-10  T.Aso Add valid window in Z.
//   2013-03-26 T.Aso RTS related: rts and ROIctValReplacer commands.
//   2013-03-26 T.Aso RTS related: rts and ROIctValReplacer commands.
//   2013-11-22 T.Aso Data orientation.
//   2014-01-31 T.Aso Commands for complement and label.                    
//   2014-02-07 T.Aso Commands for update placement.
//   2014-03-11 T.Aso Commands for voxel visualization.
//   2014-03-27 T.Aso Commands for material list.
//
//---------------------------------------------------------------------
//
#include "G4MDICOMMessenger.hh"
#include "G4MVDICOM.hh"

G4MDICOMMessenger::G4MDICOMMessenger(G4MVDICOM* dicom):fDICOM(dicom) {

    fDirDICOM = new G4UIdirectory("/G4M/DICOM/");
    fDirDICOM->SetGuidance("UI commands for DICOM Handling");

    fCmdDICOMSelect = new G4UIcmdWithAString("/G4M/DICOM/select",this);
    fCmdDICOMSelect->SetGuidance("Select DICOM module for messeaging");
    fCmdDICOMSelect->SetParameterName("dicomselect",false);
    fCmdDICOMSelect->AvailableForStates(G4State_Idle);

    fCmdDICOMFile = new G4UIcmdWithAString("/G4M/DICOM/file",this);
    fCmdDICOMFile->SetGuidance("Select DICOM File to be read.");
    fCmdDICOMFile->SetParameterName("dicomfile",false);
    fCmdDICOMFile->AvailableForStates(G4State_Idle);

    fCmdDICOMIsocenter = 
        new G4UIcmdWith3VectorAndUnit("/G4M/DICOM/isocenter",this);
    fCmdDICOMIsocenter->SetGuidance("Isocenter position in CT frame ");
    fCmdDICOMIsocenter->SetParameterName("isocenterX","isocenterY",
                                        "isocenterZ",false,false);
    fCmdDICOMIsocenter->AvailableForStates(G4State_Idle);

    fCmdDICOMComplement  = new G4UIcmdWithABool("/G4M/DICOM/complement",this);
    fCmdDICOMComplement->SetGuidance("DICOM Complement enable/disable");
    fCmdDICOMComplement->AvailableForStates(G4State_Idle);

    fCmdDICOMMesh = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/mesh",this);
    fCmdDICOMMesh->SetGuidance("DICOM Mesh cube size ");
    fCmdDICOMMesh->SetGuidance("Or DICOM Mesh in 2D by combining pixels.");
    fCmdDICOMMesh->SetParameterName("dicommesh",false);
    fCmdDICOMMesh->SetDefaultUnit("mm");
    fCmdDICOMMesh->AvailableForStates(G4State_Idle);

    fCmdDICOMMeshBin  = new G4UIcmdWithAnInteger("/G4M/DICOM/mesh/bin",this);
    fCmdDICOMMeshBin->SetGuidance("DICOM 2D Mesh");
    fCmdDICOMMeshBin->AvailableForStates(G4State_Idle);

    fCmdDICOMWinXmin = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/winXmin",this);
    fCmdDICOMWinXmin->SetGuidance("DICOM Valid Window X minimum position");
    fCmdDICOMWinXmin->SetParameterName("dicomWXmin",false);
    fCmdDICOMWinXmin->SetDefaultUnit("mm");
    fCmdDICOMWinXmin->AvailableForStates(G4State_Idle);

    fCmdDICOMWinXmax = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/winXmax",this);
    fCmdDICOMWinXmax->SetGuidance("DICOM Valid Window X maximum position");
    fCmdDICOMWinXmax->SetParameterName("dicomWXmax",false);
    fCmdDICOMWinXmax->SetDefaultUnit("mm");
    fCmdDICOMWinXmax->AvailableForStates(G4State_Idle);

    fCmdDICOMWinYmin = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/winYmin",this);
    fCmdDICOMWinYmin->SetGuidance("DICOM Valid Window Y minimum position");
    fCmdDICOMWinYmin->SetParameterName("dicomWYmin",false);
    fCmdDICOMWinYmin->SetDefaultUnit("mm");
    fCmdDICOMWinYmin->AvailableForStates(G4State_Idle);

    fCmdDICOMWinYmax = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/winYmax",this);
    fCmdDICOMWinYmax->SetGuidance("DICOM Valid Window Y maximum position");
    fCmdDICOMWinYmax->SetParameterName("dicomWYmax",false);
    fCmdDICOMWinYmax->SetDefaultUnit("mm");
    fCmdDICOMWinYmax->AvailableForStates(G4State_Idle);

    fCmdDICOMWinZmin = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/winZmin",this);
    fCmdDICOMWinZmin->SetGuidance("DICOM Valid Window Z minimum position");
    fCmdDICOMWinZmin->SetParameterName("dicomWZmin",false);
    fCmdDICOMWinZmin->SetDefaultUnit("mm");
    fCmdDICOMWinZmin->AvailableForStates(G4State_Idle);

    fCmdDICOMWinZmax = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/winZmax",this);
    fCmdDICOMWinZmax->SetGuidance("DICOM Valid Window Z maximum position");
    fCmdDICOMWinZmax->SetParameterName("dicomWZmax",false);
    fCmdDICOMWinZmax->SetDefaultUnit("mm");
    fCmdDICOMWinZmax->AvailableForStates(G4State_Idle);

    fCmdDICOMTrim  = new G4UIcmdWithABool("/G4M/DICOM/trim",this);
    fCmdDICOMTrim->SetGuidance("DICOM Valid Triming");
    fCmdDICOMTrim->AvailableForStates(G4State_Idle);

    fCmdDICOMValueMin = new G4UIcmdWithADouble("/G4M/DICOM/minvalue",this);
    fCmdDICOMValueMin->SetGuidance("Acceptable minimum value");
    fCmdDICOMValueMin->SetParameterName("dicomctmin",false);
    fCmdDICOMValueMin->AvailableForStates(G4State_Idle);

    fCmdDICOMValueMax = new G4UIcmdWithADouble("/G4M/DICOM/maxvalue",this);
    fCmdDICOMValueMax->SetGuidance("Acceptable maximum value");
    fCmdDICOMValueMax->SetParameterName("dicomctmax",false);
    fCmdDICOMValueMax->AvailableForStates(G4State_Idle);

    fCmdDICOMAirCT = new G4UIcmdWithADouble("/G4M/DICOM/ctair",this);
    fCmdDICOMAirCT->SetGuidance("CT value of Air");
    fCmdDICOMAirCT->SetParameterName("dicomairct",false);
    fCmdDICOMAirCT->AvailableForStates(G4State_Idle);

    fCmdDICOMLabel  = new G4UIcmdWithABool("/G4M/DICOM/label",this);
    fCmdDICOMLabel->SetGuidance("DICOM label enable/disable");
    fCmdDICOMLabel->AvailableForStates(G4State_Idle);

    fCmdDICOMCTCut = new G4UIcmdWithADouble("/G4M/DICOM/ctcutoff",this);
    fCmdDICOMCTCut->SetGuidance("CT cut off value");
    fCmdDICOMCTCut->SetParameterName("dicomactcut",false);
    fCmdDICOMCTCut->AvailableForStates(G4State_Idle);

    fCmdDICOMCT2Density = new G4UIcmdWithAString("/G4M/DICOM/ct2density",this);
    fCmdDICOMCT2Density->SetGuidance("CT2Density File to be read.");
    fCmdDICOMCT2Density->SetParameterName("dicomct2densfile",false);
    fCmdDICOMCT2Density->AvailableForStates(G4State_Idle);

    fCmdDICOMParamType = new G4UIcmdWithAString("/G4M/DICOM/paramtype",this);
    fCmdDICOMParamType->SetGuidance("DICOM Parametrisation type");
    fCmdDICOMParamType->SetParameterName("dicomptype",false);
    fCmdDICOMParamType->AvailableForStates(G4State_Idle);

    fCmdDICOMCTSamp = new G4UIcmdWithAnInteger("/G4M/DICOM/ctsamp",this);
    fCmdDICOMCTSamp->SetGuidance("DICOM CT Sampling rate");
    fCmdDICOMCTSamp->SetParameterName("dicomctsamp",false);
    fCmdDICOMCTSamp->AvailableForStates(G4State_Idle);

    fCmdDICOMDensResol = 
      new G4UIcmdWithADouble("/G4M/DICOM/densityResol",this);
    fCmdDICOMDensResol->SetGuidance("DICOM CT Density Resolution");
    fCmdDICOMDensResol->SetParameterName("dicomdensresol",false);
    fCmdDICOMDensResol->AvailableForStates(G4State_Idle);

    fCmdDICOMGantry = new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/gantry",this);
    fCmdDICOMGantry->SetGuidance("DICOM Gantry Angle");
    fCmdDICOMGantry->SetParameterName("dicomgantry",false);
    fCmdDICOMGantry->SetDefaultUnit("deg");
    fCmdDICOMGantry->AvailableForStates(G4State_Idle);

    fCmdDICOMCouchAngle = 
      new G4UIcmdWithADoubleAndUnit("/G4M/DICOM/couchAngle",this);
    fCmdDICOMCouchAngle->SetGuidance("DICOM Couch Angle");
    fCmdDICOMCouchAngle->SetParameterName("dicomCouchAngle",false);
    fCmdDICOMCouchAngle->SetDefaultUnit("deg");
    fCmdDICOMCouchAngle->AvailableForStates(G4State_Idle);

    fCmdDICOMDataOrient = new G4UIcmdWithAString("/G4M/DICOM/dataOrientation",this);
    fCmdDICOMDataOrient->SetGuidance("Set DICOM data orientation.");
    fCmdDICOMDataOrient->SetGuidance("NONE, HFS, FFS, HFP, FFP");
    fCmdDICOMDataOrient->SetParameterName("dicomorient",false);
    fCmdDICOMDataOrient->AvailableForStates(G4State_Idle);

    fCmdDICOMUpdate = new G4UIcmdWithoutParameter("/G4M/DICOM/update",this);
    fCmdDICOMUpdate->SetGuidance("Update DICOM placement.");
    fCmdDICOMUpdate->AvailableForStates(G4State_Idle);

    fCmdDICOMVis  = new G4UIcmdWithABool("/G4M/DICOM/vis",this);
    fCmdDICOMVis->SetGuidance("DICOM Visulaize voxels");
    fCmdDICOMVis->AvailableForStates(G4State_Idle);

    fCmdDICOMRenameMat = new G4UIcommand("/G4M/DICOM/renameMaterial",this);
    fCmdDICOMRenameMat->SetGuidance("Rename Material name in MaterialList");
    fCmdDICOMRenameMat->SetGuidance("Usage: /G4M/DICOM/renameMaterial str1 name");
    fCmdDICOMRenameMat->SetGuidance("oname: (string) strig pattern in material");
    fCmdDICOMRenameMat->SetGuidance("nname: (string) new material name");
    G4UIparameter* param;
    param = new G4UIparameter("oname",'s',false);
    fCmdDICOMRenameMat->SetParameter(param);
    param = new G4UIparameter("nname",'s',false);
    fCmdDICOMRenameMat->SetParameter(param);

    fCmdDICOMShowMatList = new G4UIcommand("/G4M/DICOM/showMatList",this);
    fCmdDICOMShowMatList->SetGuidance("Show  MaterialList");
    fCmdDICOMShowMatList->SetGuidance("Usage: /G4M/DICOM/showMatList oname lvl");
    fCmdDICOMShowMatList->SetGuidance("oname: (string) stdout or filename");
    fCmdDICOMShowMatList->SetGuidance("lvl: (int) verbose level");
    //G4UIparameter* param;
    param = new G4UIparameter("oname",'s',true);
    param->SetDefaultValue("stdout");
    fCmdDICOMShowMatList->SetParameter(param);
    param = new G4UIparameter("lvl",'i',true);
    param->SetDefaultValue(1);
    fCmdDICOMShowMatList->SetParameter(param);
    

    fCmdDICOMRTS  = new G4UIcmdWithABool("/G4M/DICOM/rts",this);
    fCmdDICOMRTS->SetGuidance("Enable/Disable DICOM RTS");
    fCmdDICOMRTS->AvailableForStates(G4State_Idle);

    fCmdROICTReplacerFile = new G4UIcmdWithAString("/G4M/DICOM/roiCtValReplacer",this);
    fCmdROICTReplacerFile->SetGuidance("Replacing CTs with assigned mapping file");
    fCmdROICTReplacerFile->SetParameterName("roiCtValMap",false);
    fCmdROICTReplacerFile->AvailableForStates(G4State_Idle);

}

G4MDICOMMessenger::~G4MDICOMMessenger() {

  delete fDirDICOM;
  delete fCmdDICOMSelect;
  delete fCmdDICOMFile;
  delete fCmdDICOMIsocenter;
  delete fCmdDICOMComplement;
  delete fCmdDICOMMesh;
  delete fCmdDICOMMeshBin;
  delete fCmdDICOMWinXmin;
  delete fCmdDICOMWinXmax;
  delete fCmdDICOMWinYmin;
  delete fCmdDICOMWinYmax;
  delete fCmdDICOMWinZmin;
  delete fCmdDICOMWinZmax;
  delete fCmdDICOMTrim;
  delete fCmdDICOMValueMin;
  delete fCmdDICOMValueMax;
  delete fCmdDICOMAirCT;
  delete fCmdDICOMLabel;
  delete fCmdDICOMCTCut;
  delete fCmdDICOMCT2Density;
  delete fCmdDICOMCTSamp;
  delete fCmdDICOMDensResol;
  delete fCmdDICOMParamType;
  delete fCmdDICOMGantry;
  delete fCmdDICOMCouchAngle;
  delete fCmdDICOMDataOrient;

  delete fCmdDICOMUpdate;

  delete fCmdDICOMVis;
  delete fCmdDICOMRenameMat;
  delete fCmdDICOMShowMatList;

  delete fCmdDICOMRTS;
  delete fCmdROICTReplacerFile;
}

void G4MDICOMMessenger::SetNewValue(G4UIcommand* command, G4String newValue) {

  if ( command == fCmdDICOMFile ){
     fDICOM->SetDICOMFile(newValue);
  }else if( command == fCmdDICOMIsocenter ){
      G4ThreeVector center = fCmdDICOMIsocenter->GetNew3VectorValue(newValue);
      center /= mm;
      fDICOM->SetIsocenter( center );
  }else if( command == fCmdDICOMComplement ){
      fDICOM->SetComplement(fCmdDICOMComplement->GetNewBoolValue(newValue));
  }else if( command == fCmdDICOMMesh ){
      fDICOM->SetRemesh(fCmdDICOMMesh->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMMeshBin ){
      fDICOM->SetRemeshBin(fCmdDICOMMeshBin->GetNewIntValue(newValue));  
  }else if( command == fCmdDICOMWinXmin ){
      fDICOM->SetXmin(fCmdDICOMWinXmin->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMWinXmax ){
      fDICOM->SetXmax(fCmdDICOMWinXmax->GetNewDoubleValue(newValue));
  }else if ( command == fCmdDICOMWinYmin ){
      fDICOM->SetYmin(fCmdDICOMWinYmin->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMWinYmax ){
      fDICOM->SetYmax(fCmdDICOMWinYmax->GetNewDoubleValue(newValue));
  }else if ( command == fCmdDICOMWinZmin ){
      fDICOM->SetZmin(fCmdDICOMWinZmin->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMWinZmax ){
      fDICOM->SetZmax(fCmdDICOMWinZmax->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMTrim ){
    fDICOM->SetTrim(fCmdDICOMTrim->GetNewBoolValue(newValue));
  }else if( command == fCmdDICOMValueMin ){
     fDICOM->SetMinValue(fCmdDICOMValueMin->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMValueMax ){
     fDICOM->SetMaxValue(fCmdDICOMValueMax->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMAirCT ){
     fDICOM->SetAirCTValue(fCmdDICOMAirCT->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMLabel ){
      fDICOM->SetLabel(fCmdDICOMLabel->GetNewBoolValue(newValue));
  }else if( command == fCmdDICOMCTCut ){
      fDICOM->SetCTCutOff(fCmdDICOMCTCut->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMCTSamp ){
     fDICOM->SetCTSample(fCmdDICOMCTSamp->GetNewIntValue(newValue));
  }else if( command == fCmdDICOMDensResol ){
     fDICOM->SetDensityResol(fCmdDICOMDensResol->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMCT2Density ){
     fDICOM->SetFileCT2Density(newValue);
  }else if( command ==  fCmdDICOMParamType ){
     fDICOM->SetParamType(newValue);
  }else if( command == fCmdDICOMGantry ){
     fDICOM->SetGantry(fCmdDICOMGantry->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMCouchAngle ){
     fDICOM->SetCouchAngle(fCmdDICOMCouchAngle->GetNewDoubleValue(newValue));
  }else if( command == fCmdDICOMDataOrient ){
     fDICOM->SetDataOrientation(newValue);
  }else if( command == fCmdDICOMUpdate ){
     fDICOM->UpdatePlacement();
  }else if( command == fCmdDICOMVis ){
      fDICOM->SetVis(fCmdDICOMVis->GetNewBoolValue(newValue));
  }else if( command == fCmdDICOMRenameMat ){
    G4String oname, nname;
    std::istringstream iss(newValue);
    iss >> oname >> nname;
    fDICOM->RenameMaterial(oname, nname);
  }else if( command == fCmdDICOMShowMatList ){
    G4String oname;
    G4int lvl;
    std::istringstream iss(newValue);
    iss >> oname >> lvl;
    if ( oname == "stdout" ){
      fDICOM->ShowMatList(G4cout, lvl);
    }else{
      std::ofstream fout(oname);
      fDICOM->ShowMatList(fout, lvl);
      fout.close();
    }
  }else if( command == fCmdDICOMRTS ){
    fDICOM->EnableRTS(fCmdDICOMRTS->GetNewBoolValue(newValue));
  }else  if ( command == fCmdROICTReplacerFile ){
     fDICOM->SetROICTReplacerFile(newValue);
  }
}

G4String G4MDICOMMessenger::GetCurrentValue(G4UIcommand* ) {
  return G4String("I do not know,");
}

