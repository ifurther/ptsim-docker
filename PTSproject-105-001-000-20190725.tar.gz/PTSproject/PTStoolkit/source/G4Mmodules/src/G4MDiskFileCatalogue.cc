//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters 
// 
//  (History)
//   04-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MDiskFileCatalogue.hh"
#include "G4MDisk.hh"
#include <fstream>
#include <sstream>

G4MDiskFileCatalogue::G4MDiskFileCatalogue(const G4String& name,
					   const G4String& fileName)
  :G4MVDiskCatalogue(name),fDefaultFileName(fileName){
}

G4MDiskFileCatalogue::~G4MDiskFileCatalogue()
{}

void G4MDiskFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(radius, fdZ, material);
}

void G4MDiskFileCatalogue::Prepare(G4String& pname){
  /////////////////////////////////////////////////////////////////
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String& msg="file open error"+pname;
    G4Exception("G4MDiskFileCatalogue::Prepare()","G4MDiskFileCata00",
		FatalException,msg);
  }else{
    ifs.getline(chline,512);  //scatterer ID
    ifs.getline(chline,512);  //description

    ifs.getline(chline,512);  //effective physical thickness
    std::istringstream iss1(chline);
    iss1 >> thickness;
    fdZ = thickness*mm /2.;

    ifs.getline(chline,512);  //radius
    std::istringstream iss2(chline);
    iss2 >> radius;
    radius *=mm;

    ifs.getline(chline,512);  //material
    std::istringstream iss3(chline);
    iss3 >> material;

    ifs.getline(chline,512); // Density

  }
  ifs.close();
}

void G4MDiskFileCatalogue::Apply(){
  fModule->SetAllParameters(radius,fdZ,material);
}







 
