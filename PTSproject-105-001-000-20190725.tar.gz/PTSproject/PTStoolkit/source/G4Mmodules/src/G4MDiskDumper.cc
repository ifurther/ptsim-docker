//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Disk BeamModule with SD for Particle Dump
//
// (HISTORY)  
//  30-Nov-2007 T.Aso
// 2017-03-15 T.Aso for threading
//---------------------------------------------------------------------
//
#include "G4MDiskDumper.hh"
#include "G4LogicalVolume.hh"
#include "G4SDManager.hh"
#include "G4MDumpInfoSD.hh"

G4MDiskDumper::G4MDiskDumper(const G4String &name, 
                             G4double dr, G4double dz,
                             const G4String &mat)
  : G4MDisk(name,dr,dz,mat)
{}

G4MDiskDumper::G4MDiskDumper(const G4String &name)
  : G4MDisk(name)
{}

G4MDiskDumper::G4MDiskDumper(G4MVDiskCatalogue* catalogue)
  : G4MDisk(catalogue)
{}

G4MDiskDumper::~G4MDiskDumper()
{}

void G4MDiskDumper::buildNode(G4VPhysicalVolume *phys)
{
    G4LogicalVolume* logical = phys->GetLogicalVolume();
    fSdLVList.push_back(logical);   
}

void G4MDiskDumper::BuildInSDandField(){
  // Manager
  G4SDManager *sdm = G4SDManager::GetSDMpointer();
  /// Sensitive Detector
  G4MDumpInfoSD* sd = dynamic_cast<G4MDumpInfoSD*>
    (sdm->FindSensitiveDetector(GetName(),false));
  if ( !sd ) {
    G4cout << "++ G4MDiskDumper::  Create Sensitive Detector "
           <<GetName()<<G4endl;
    sd = new G4MDumpInfoSD(GetName());
    sdm->AddNewDetector(sd);
  }
  // Logical name
  for (G4int i = 0; i < (G4int)fSdLVList.size(); i++){
    fSdLVList[i]->SetSensitiveDetector(sd);
  }
}
