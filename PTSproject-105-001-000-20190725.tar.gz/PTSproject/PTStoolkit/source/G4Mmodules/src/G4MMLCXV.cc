//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//   Class for MLC Beam Module.
//    G4MMLC(const G4String& name, const G4ThreeVector& dxyz, 
//           const G4String& matMLC, 
//           G4int nyleaf, G4double y0leaf, 
//           std::vector<G4double>& leafposition)
//    name : Module Name
//    dxyz : Half length Size of MLC envelope
//    matMLC: Matrial name of MLC
//    nyleaf:  Number of leaf pair, namly total nyleaf*2 for left and right.
//    y0leaf:  y offset of first leaf. First leaf must be start from -Y.
//    leafposition:  Position of leafs, i.e the open edge of ridges.
//
//       Numbering of leaf for leaf position.
//   +Y
//    |__ +X 
//             nyleaf-1   2*nyleaf-1
//                .         .
//                .         .
//                2       nyleaf+2
//                1       nyleaf+1
//                0       nyleaf+0
//
//
//  (HISTORY)
//   06-FEB-2006 ASO  Coverted from G4MLC for responding HIBMC requirement.
//   22-JAN-2006 ASO  Add Visualization Attributes.
//   2018-03-22  T.ASO fMatAir was moved to G4MVBeamModule.
//
//---------------------------------------------------------------------
//
#include "G4MMLCXV.hh"
#include "G4PVParameterised.hh"
#include "G4LogicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MMLCXV::G4MMLCXV(const G4String& name, 
                 const G4ThreeVector& dxyz,
                 const G4String& matMLC,
                 G4int nyleaf, const G4ThreeVector& dlxyz,
                 G4double y0leaf, 
                 std::vector<G4double>& leafthickness,
                 std::vector<G4double>& leafposition,
                 const G4String& matAir) 
  :G4MVBeamModule(name,dxyz),fMatMLC(matMLC),
   fNLeafPair(nyleaf),fLeafDxyz(dlxyz),fy0Leaf(y0leaf),
   theThicknessVector(leafthickness),
   thePositionVector(leafposition),fCatalogue(NULL)
{
  fMatAir=matAir;
}

G4MMLCXV::G4MMLCXV(const G4String& name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}

G4MMLCXV::G4MMLCXV(G4MVMLCXVCatalogue* catalogue)
  : G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MMLCXV::~G4MMLCXV() {
  theThicknessVector.clear();
  thePositionVector.clear();
  if ( fCatalogue ) delete fCatalogue;
}

void G4MMLCXV::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MMLCXV::SetAllParameters(const G4ThreeVector& dxyz, 
                               const G4String& matMLC,
                               G4int nyleaf, const G4ThreeVector& dlxyz,
                               G4double y0leaf, 
                               std::vector<G4double>& leafthickness,
                               std::vector<G4double>& leafposition,
                               const G4String& matAir) 
{
   theThicknessVector.clear();
   thePositionVector.clear();
   //
   fEnvelopeSize=dxyz;
   fMatMLC=matMLC;
   fNLeafPair=nyleaf;
   fLeafDxyz=dlxyz;
   fy0Leaf=y0leaf;
   theThicknessVector=leafthickness;
   thePositionVector=leafposition;
   fMatAir = matAir;
}

void G4MMLCXV::Dump(std::ostream& out){
  out << fNLeafPair << G4endl;
  out << 1 << G4endl;
  for(G4int i = 0; i < fNLeafPair; i++){
    out << i<<","
        <<theThicknessVector[i]<<","
        <<thePositionVector[i]<<","
        <<thePositionVector[fNLeafPair+i]<< G4endl;
  }
}


void G4MMLCXV::SetMatMLC(const G4String& mat) {
  fMatMLC = mat;
}

void G4MMLCXV::SetLeafDxyz(const G4ThreeVector& dlxyz) {
  fLeafDxyz = dlxyz;
}

G4ThreeVector G4MMLCXV::GetLeafDxyz() const{
  return fLeafDxyz;
}

void G4MMLCXV::SetLeafThickness(std::vector<G4double>& xleafthick) {
  theThicknessVector = xleafthick;
}

void G4MMLCXV::SetLeafPosition(std::vector<G4double>& xleafpos) {
  thePositionVector = xleafpos;
}

G4VPhysicalVolume* G4MMLCXV::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* matAir = G4Material::GetMaterial(fMatAir);
  G4VSolid* solid = 
    new G4Box(GetName(),fEnvelopeSize.x(),fEnvelopeSize.y(),fEnvelopeSize.z());
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,          // Solid 
                                 matAir,         // Material
                                 GetName());     // Name
  logical->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,1.0,1.0)));

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                     GetRotation(),
                     GetTranslation(),
                     logical,                      // Logical volume  
                      GetName(),                   // Name
                     worldlog,                     // Mother  volume 
                     false,                         // Not used 
                     0);                            // Copy number  
  return physical;
}

void G4MMLCXV::buildNode(G4VPhysicalVolume* physvol) {

  G4Material* matMLC= G4Material::GetMaterial(fMatMLC);

  fLeafDxyz.setY(theThicknessVector[0]); // dummy.

  //-----  MLC "Leaf" 
  G4String MLCname = fMatMLC;
  G4VSolid* sol =  new G4Box(MLCname,
                             fLeafDxyz.x(),fLeafDxyz.y(),fLeafDxyz.z());
  G4LogicalVolume* log = new G4LogicalVolume(sol,matMLC,MLCname);
  log->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.3,0.3)));

  fParameterisation = 
    new G4MMLCXVParameterisation(fNLeafPair,
                                 fLeafDxyz.x(),fLeafDxyz.z(),
                                 fy0Leaf,
                                 theThicknessVector,
                                 matMLC);
  fParameterisation->CalculateActiveVolume(thePositionVector,fEnvelopeSize);
  G4int nofvolume = fParameterisation->GetNofActiveVolume();
  if ( nofvolume > 0 ) {
    G4VPhysicalVolume *phys = 
      new G4PVParameterised(GetName(),
                            log,
                            physvol->GetLogicalVolume(),
                            kZAxis,
                            nofvolume,
                            fParameterisation);
    fParamPhysVol = phys;
  }
}

