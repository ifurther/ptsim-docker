//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Template class for defining a new Module 
//
// (HISTORY)  
//   2012-11-18  T.Aso
//   2018-04-22  T.Aso Catalogue.
//
//---------------------------------------------------------------------
//
#include "G4MBMTemplate.hh"
#include "G4Material.hh"
#include "G4PVPlacement.hh"
#include "G4Box.hh"
//---------------------------------------------------------------------
G4MBMTemplate::G4MBMTemplate(const G4String& name)
  : G4MVBeamModule(name),fCatalogue(NULL)
{}
//---------------------------------------------------------------------
G4MBMTemplate::G4MBMTemplate(G4MVBMTemplateCatalogue* catalogue)
: G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}
//---------------------------------------------------------------------
G4MBMTemplate::~G4MBMTemplate()
{}
//---------------------------------------------------------------------
void G4MBMTemplate::ApplyFromCatalogue(G4String& newValue){
  G4cout << "G4MBMTemplate::ApplyFromCatalogue() " << newValue<<G4endl;
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}
//---------------------------------------------------------------------
void G4MBMTemplate::Dump(std::ostream& out){
  out << "G4MBMTemplate::Dump()" << G4endl;
}
//---------------------------------------------------------------------
G4VPhysicalVolume* G4MBMTemplate::buildEnvelope(G4LogicalVolume* worldlog)
{
  //
  //  Envelope of this Beam Module.
  //
  //
  // Material (example)
  G4Material *mat = G4Material::GetMaterial("G4_WATER");
  // 
  // Solid  (example)
  G4Box *solid = new G4Box(GetName(),5.*cm,5.*cm,5.*cm);
  //
  // LogicalVolume (example)
  G4LogicalVolume *lv = new G4LogicalVolume(solid, mat, GetName());
  //
  // PhysicslVolume (example) 
  //    The rotation and position can be modified by UI commands.
  G4VPhysicalVolume* physical = new G4PVPlacement(GetRotation(),
                                                  GetTranslation(),
                                                  lv,
                                                  GetName(),
                                                  worldlog,
                                                  false,
                                                  0);
  return physical;
}
//---------------------------------------------------------------------
void G4MBMTemplate::buildNode(G4VPhysicalVolume* physvol){
  //
  //  Define sub-components inside the envelope
  //
  G4LogicalVolume *logMother = physvol->GetLogicalVolume();
  logMother->GetName();  //Dummay
  //
  // The daughter volume should be inside of the "logMother".
  //


}
//---------------------------------------------------------------------
