//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MDiskComposer
//
//  (HISTORY)
// 2014-10-31 T.Aso Support FileCatalogue.   
//   
//
//---------------------------------------------------------------------
//
#include "G4MDiskComposer.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4Transform3D.hh"
#include "G4Material.hh"
#include "G4VisAttributes.hh"

G4MDiskComposer::G4MDiskComposer(const G4String& name, const G4String& mat,
                                 G4double dr,G4double dz)
  :G4MVModuleComposer(name,G4ThreeVector(0.0,dr,dz)),
   fMatName(mat),fCatalogue(NULL){
}

G4MDiskComposer::G4MDiskComposer(const G4String& name)
  :G4MVModuleComposer(name),fCatalogue(NULL){
}

G4MDiskComposer::G4MDiskComposer(G4MVDiskComposerCatalogue* catalogue)
  : G4MVModuleComposer(catalogue->GetName()),fCatalogue(catalogue)
{
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

void G4MDiskComposer::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MDiskComposer::SetAllParameters(const G4String& mat,
                                       G4double dr,G4double dz){
  fMatName=mat;
  SetEnvelopeSize(0.0,dr,dz);
}

G4MDiskComposer::~G4MDiskComposer() {
  if ( fCatalogue ) delete fCatalogue;
}

void G4MDiskComposer::Dump(std::ostream& out){
  out << "# Envelope Size Radius, Thickness (mm)" <<G4endl;
  out << GetDR()/mm <<" , " << GetDZ()/mm << G4endl;
  out << "# Envelope Material" <<G4endl;
  out << fMatName<<G4endl;
  G4MVModuleComposer::Dump(out);
}

G4VPhysicalVolume* G4MDiskComposer::buildEnvelope(G4LogicalVolume* worldlog){
  G4Material* mat = G4Material::GetMaterial(fMatName);
  G4double dr = GetDR();
  G4double dz = GetDZ();
  G4VSolid* solid = new G4Tubs(GetName(),0.,dr,dz,0.,twopi);
  G4LogicalVolume* logical = new G4LogicalVolume(
                                 solid,            // Solid 
                                 mat,              // Material
                                 GetName()         // Name
                                 );

  G4VisAttributes * visAttr = new G4VisAttributes(G4Colour(1.0,0.0,0.0));
  logical->SetVisAttributes(visAttr);

  G4VPhysicalVolume* physical  = new G4PVPlacement(
                   GetRotation(),                                  
                   GetTranslation(),                               
                   logical,        // Logical volume  
                   GetName(),      // Name
                   worldlog,       // Mother  volume 
                   false,          // Not used 
                   0);             // Copy number  
  return physical;
}



