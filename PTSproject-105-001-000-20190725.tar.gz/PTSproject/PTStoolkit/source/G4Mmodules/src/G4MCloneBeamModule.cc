//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for CloneBeamModule shape component
//
// (HISTORY)  
//
//---------------------------------------------------------------------
//
#include "G4Material.hh"
#include "G4MCloneBeamModule.hh"
#include "G4PVPlacement.hh"


G4MCloneBeamModule::G4MCloneBeamModule(const G4String& name)
  : G4MVBeamModule(name){
  fType = 1;
}

G4MCloneBeamModule::~G4MCloneBeamModule()
{}

void G4MCloneBeamModule::CleanUpVolumes(){
  const G4VPhysicalVolume* phys = GetPhysicalVolume();
  if ( phys ) {
    G4LogicalVolume* mother = phys->GetMotherLogical();
    mother->RemoveDaughter(phys);
    delete phys;
    SetPhysicalVolume(0);
  } else {
    G4cout << "@@@ PhysicalVolume is not exists ..." << GetName() << G4endl;
  }
}

G4VPhysicalVolume* G4MCloneBeamModule::buildEnvelope(G4LogicalVolume*)
{
  return 0;
}

void G4MCloneBeamModule::buildNode(G4VPhysicalVolume*){;}
