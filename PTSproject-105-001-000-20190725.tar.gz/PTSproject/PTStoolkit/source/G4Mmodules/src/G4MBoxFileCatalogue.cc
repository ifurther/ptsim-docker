//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Box type module
// 
//  (History)
//   22-JAN-07   T.Aso
//
//---------------------------------------------------------------------
//
#include "G4MBoxFileCatalogue.hh"
#include "G4MBox.hh"
#include <fstream>
#include <sstream>

G4MBoxFileCatalogue::G4MBoxFileCatalogue(const G4String& name,
					 const G4String& fileName)
  :G4MVBoxCatalogue(name),fDefaultFileName(fileName){
}

G4MBoxFileCatalogue::~G4MBoxFileCatalogue()
{}

void G4MBoxFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  fModule->SetAllParameters(dxyz, material);
}

void G4MBoxFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MBoxFileCalalogue::Prepare()","G4MBoxFileCata00",
		FatalException,msg);
  }else{
    ifs.getline(chline,512);  // degrader ID
    ifs.getline(chline,512);  // description

    ifs.getline(chline,512);  // effective physical size 
    std::istringstream iss1(chline);
    G4double fx,fy,fz;
    iss1 >> fx >> fy >> fz;   // Full Size
    dxyz.setX(fx*mm/2.);
    dxyz.setY(fy*mm/2.);
    dxyz.setZ(fz*mm/2.);

    ifs.getline(chline,512);  //material
    std::istringstream iss3(chline);
    iss3 >> material;

    ifs.getline(chline,512); // Density

  }
  ifs.close();
}

void G4MBoxFileCatalogue::Apply(){
   fModule->SetAllParameters(dxyz, material);
   fModule->ReBuild();
}







 
