//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Desctiption)
//    This Class represents a Scanning Manget.
//
// (HISTORY)
//   07-OCT-05  T.ASO  Found a lack of constructor
//                     G4MScanningMagnet(G4MVScanningMagnet*).
//                     The implementation is added to source file.
//   22-Jan-07  T.Aso  Add VisAttributes.
//   10-Aug-10  T.Aso  Introduce SetMagFieldByAngle() method.(Removed)
//  2012-06-06  T.Aso  remove warning.
//  2014-11-23 T.Aso  Introduce SetFieldByDist() method.
//   2014-12-01 T.Aso  Add methods for creating fieldmap.
//  2017-03-05 T.Aso for Threading
//---------------------------------------------------------------------
//
#include "G4MScanningMagnet.hh"
#include "G4MVScanningField.hh"

#include <iostream>
#include "G4Material.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"

#include "G4ParticleDefinition.hh"
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"
#include "G4NucleiProperties.hh"

#include "G4FieldManager.hh"
#include "G4VisAttributes.hh"

#include "G4AutoDelete.hh"

G4MScanningMagnet::G4MScanningMagnet(const G4String& name, 
                                   const G4String& matframe,
                                   const G4ThreeVector& dxyzframe, 
                                   const G4String& matfield, 
                                   const G4ThreeVector& dxyzfield, 
                                   G4MVScanningField* bfield) 
  :G4MVBeamModule(name,dxyzframe),fmatFrame(matframe),
   fmatField(matfield),fBDxyz(dxyzfield),fMagField(bfield),fCatalogue(NULL)
{
  SetPidForBField(2212);
  fParticleE=0.0;
  fCentroidZ=0.0;
  fFieldMap = NULL;
  fFieldCoeff = NULL;

  fMessenger = new G4MScanningMagnetMessenger(this);
}

G4MScanningMagnet::G4MScanningMagnet(const G4String& name) 
  :G4MVBeamModule(name),fCatalogue(NULL)
{
  SetPidForBField(2212);
  fParticleE=0.0;
  fCentroidZ=0.0;
  fFieldMap = NULL;
  fFieldCoeff = NULL;

  fMessenger = new G4MScanningMagnetMessenger(this);
}

G4MScanningMagnet::G4MScanningMagnet(G4MVScanningMagnetCatalogue* catalogue)
  :G4MVBeamModule(catalogue->GetName()),fCatalogue(catalogue)
{
  SetPidForBField(2212);
  fParticleE=0.0;
  fCentroidZ=0.0;
  fFieldMap = NULL;
  fFieldCoeff = NULL;

  fMagField=0;
  fMessenger = new G4MScanningMagnetMessenger(this);
  fCatalogue->SetModule(this);
  fCatalogue->Init();
}

G4MScanningMagnet::~G4MScanningMagnet() {
  if ( fMagField ) delete fMagField;
  if ( fCatalogue ) delete fCatalogue;
  if ( fFieldMap ) delete fFieldMap;
  if ( fFieldCoeff ) delete fFieldCoeff;
  delete fMessenger;
}

void G4MScanningMagnet::ApplyFromCatalogue(G4String& newValue){
  fCatalogue->Prepare(newValue);
  fCatalogue->Apply();
}

void G4MScanningMagnet::SetAllParameters(const G4String& matframe,
                                        const G4ThreeVector& dxyzframe, 
                                        const G4String& matfield, 
                                        const G4ThreeVector& dxyzfield, 
                                        G4MVScanningField* bfield) 
{
  fmatFrame=matframe;
  fEnvelopeSize=dxyzframe;
  fmatField=matfield;
  fBDxyz=dxyzfield;
  if ( !fMagField ) fMagField=bfield;
}

G4VPhysicalVolume* G4MScanningMagnet::buildEnvelope(G4LogicalVolume* worldlog) {
  //---- Frame 
  G4Material* matFrame = G4Material::GetMaterial(fmatFrame);
  G4VSolid* solidFrame = 
    new G4Box(GetName(),fEnvelopeSize.x(),fEnvelopeSize.y(),fEnvelopeSize.z());
  G4LogicalVolume* logicalFrame = new G4LogicalVolume(
                                 solidFrame,       // Solid 
                                 matFrame,         // Material
                                 GetName());       // Name
  std::cout << "###############################################" << std::endl;
  G4VPhysicalVolume* physical  = new G4PVPlacement(
                     GetRotation(),
                     GetTranslation(),
                     logicalFrame,        
                      GetName(),          
                     worldlog,   
                     false,      
                     0);         
  return physical;
}

void G4MScanningMagnet::buildNode(G4VPhysicalVolume* physvol) {

  G4LogicalVolume* logicalFrame = physvol->GetLogicalVolume();
  //
  //--- BField is less than envelope
  if ( fBDxyz.z() < fEnvelopeSize.z() ) {
    G4Material* matHole = G4Material::GetMaterial(fmatField);
    G4VSolid* solidHole = 
      new G4Box(GetName(),fBDxyz.x(),fBDxyz.y(),fEnvelopeSize.z());
    G4LogicalVolume* logicalHole = new G4LogicalVolume(
                                                       solidHole,     
                                                       matHole,       
                                                       GetName()); 

    logicalFrame->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.5,0.5)));
    //G4VPhysicalVolume* physHole = 
    new G4PVPlacement(0,G4ThreeVector(0,0,0),logicalHole,GetName(),
                      logicalFrame,false,0);
    logicalFrame = logicalHole;
  }

  //--- BField  Installed into  Frame
  G4Material* matB = G4Material::GetMaterial(fmatField);
  G4VSolid* solidB = 
    new G4Box(GetName(),fBDxyz.x(),fBDxyz.y(),fBDxyz.z());
  G4LogicalVolume* logicalB = new G4LogicalVolume(
                                 solidB,     
                                 matB,       
                                 GetName()); 

  logicalFrame->SetVisAttributes(new G4VisAttributes(G4Colour(1.0,0.5,0.5)));

  //* Attach B-Field to logical volume
  fFieldLVList.push_back(logicalB);

  //G4VPhysicalVolume* physB = 
  new G4PVPlacement(0,G4ThreeVector(0,0,0),logicalB,GetName(),
                    logicalFrame,false,0);
}

void G4MScanningMagnet::BuildInSDandField(){
  //
    if ( !fMagFieldCache.Get() ){
      G4MVScanningField* field = fMagField->Copy();
      fMagFieldCache.Put(field);
      G4AutoDelete::Register(field);
    }
  //
  // Logical name
    for (G4int i = 0; i < (G4int)fFieldLVList.size(); i++){
      G4FieldManager* fieldManager = fFieldLVList[i]->GetFieldManager();
      if( fieldManager ){
        fieldManager->SetDetectorField(fMagFieldCache.Get());
      }else{
        fieldManager = new G4FieldManager(fMagFieldCache.Get());
      }
      fFieldLVList[i]->SetFieldManager(fieldManager,true);
    }
}

void G4MScanningMagnet::SetMagField(G4MVScanningField* bfield){
  fMagField = bfield;
  if ( fMagFieldCache.Get() ) {
    fMagFieldCache.Put(bfield);
  }
}

G4MVScanningField* G4MScanningMagnet::GetMagField() const{
  G4MVScanningField* field = fMagFieldCache.Get();
  if ( field ) return field;
  return fMagField;
}

void G4MScanningMagnet::SetPidForBField(G4int pid){
    fParticleID = pid;
    fMass   = 0.0;
    fCharge = 0.0;
    //
    G4ParticleDefinition* pdef = 
        G4ParticleTable::GetParticleTable()->FindParticle(fParticleID);
    if ( !pdef ) {
      G4int Z,A,J;
      G4double E;
      if( G4IonTable::GetNucleusByEncoding(fParticleID,Z,A,E,J) ){
      fMass   = G4NucleiProperties::GetNuclearMass(A,Z);
      fCharge = Z;
      }else{
        G4Exception("G4MScanningMagnet::SetFieldByDist","G4MScanMagnet00",
                    FatalException,"ScanningMagnet unknown particle");
      }
    }else{
      fMass   = pdef->GetPDGMass();
      fCharge = pdef->GetPDGCharge();
    }
}

void G4MScanningMagnet::SetFieldValue(G4double value){
  G4MVScanningField* field = GetMagField();
  if ( field ) {
    field->SetMagField(value);
  }else {
    G4Exception("G4ScanningMagnet::SetFieldValue()","G4MScanMag00",
                JustWarning,": No field ");
  }
}

void G4MScanningMagnet::SetSign(G4int isign){
  G4MVScanningField* field = GetMagField();
  if ( field ) {
    field->SetSign(isign);
  }else {
    G4Exception("G4ScanningMagnet::SetSign()","G4MScanMag00",
                JustWarning,": No field ");
  }
}

void G4MScanningMagnet::CreateFieldMap(G4bool bi){
  if ( fFieldMap ) delete fFieldMap;
  fFieldMap = new G4Physics2DVector();
  fFieldMap->SetBicubicInterpolation(bi);
}

void G4MScanningMagnet::DeleteFieldMap(){
  if ( fFieldMap ) delete fFieldMap;
}

G4bool G4MScanningMagnet::CheckFieldMap(){
  if ( !fFieldMap ) {
    G4Exception("G4ScanningMagnet::SetFieldMap()","G4MScanMag00",
                JustWarning,": No field map. Create it frist.");
    return false;
  }else{
    return true;
  }
}

void G4MScanningMagnet::StoreFieldMap(std::ofstream& Out){
  if ( CheckFieldMap() ) fFieldMap->Store(Out);
}
void G4MScanningMagnet::RetrieveFieldMap(std::ifstream& In){
  if ( CheckFieldMap() ) fFieldMap->Retrieve(In);
}
void G4MScanningMagnet::PutXFieldMap(size_t idx, G4double value){
  if ( CheckFieldMap() ) fFieldMap->PutX(idx,value);
}
void G4MScanningMagnet::PutYFieldMap(size_t idy, G4double value){
  if ( CheckFieldMap() ) fFieldMap->PutY(idy,value);
}
void G4MScanningMagnet::PutValueFieldMap(size_t idx, size_t idy, G4double value){
  if ( CheckFieldMap() ) fFieldMap->PutValue(idx,idy,value);
}

void G4MScanningMagnet::CreateFieldCoeff(G4bool bi){
  if ( fFieldCoeff ) delete fFieldCoeff;
  fFieldCoeff = new G4Physics2DVector();
  fFieldCoeff->SetBicubicInterpolation(bi);
}

void G4MScanningMagnet::DeleteFieldCoeff(){
  if ( fFieldCoeff ) delete fFieldCoeff;
}

G4bool G4MScanningMagnet::CheckFieldCoeff(){
  if ( !fFieldCoeff ) {
    G4Exception("G4ScanningMagnet::SetFieldCoeff()","G4MScanMag00",
                JustWarning,": No field map. Create it frist.");
    return false;
  }else{
    return true;
  }
}

void G4MScanningMagnet::StoreFieldCoeff(std::ofstream& Out){
  if ( CheckFieldCoeff() ) fFieldCoeff->Store(Out);
}
void G4MScanningMagnet::RetrieveFieldCoeff(std::ifstream& In){
  if ( CheckFieldCoeff() ) fFieldCoeff->Retrieve(In);
}
void G4MScanningMagnet::PutXFieldCoeff(size_t idx, G4double value){
  if ( CheckFieldCoeff() ) fFieldCoeff->PutX(idx,value);
}
void G4MScanningMagnet::PutYFieldCoeff(size_t idy, G4double value){
  if ( CheckFieldCoeff() ) fFieldCoeff->PutY(idy,value);
}
void G4MScanningMagnet::PutValueFieldCoeff(size_t idx, size_t idy, G4double value){
  if ( CheckFieldCoeff() ) fFieldCoeff->PutValue(idx,idy,value);
}

void G4MScanningMagnet::SetFieldByDist(G4double targetPos){
    //
    G4double fieldValue = 0.;
    //
    if ( fFieldMap ) {
      //
      fieldValue = fFieldMap->Value(fParticleE, targetPos);
      //
    }else{
      //
      if (fParticleE > 0. ){
        G4double mom  = sqrt((fParticleE+fMass)*(fParticleE+fMass)-fMass*fMass);
        //fFieldValue = 
        //    mom/charge/(fDxyzfield.z()*2.0)
        //    *fTargetPos/sqrt(fZ*fCentroidZ+fTargetPos*fTargetPos);
        G4double sintheta = 
            targetPos/sqrt(targetPos*targetPos+fCentroidZ*fCentroidZ);
        //** Simple p = 0.3 B rho ( for proton )
        fieldValue = 
            (mom/MeV)/0.3/(fCharge/eplus)*sintheta/(fBDxyz.z()*2./mm)*tesla;
        //
        if ( fFieldCoeff ) {
          fieldValue *= fFieldCoeff->Value(fParticleE, targetPos);
        }
        //G4cout<<" mom " << mom/MeV << " MeV" << G4endl;
        //G4cout<<" dz x2  " << fDxyzfield.z()*2./mm<< " mm"<<G4endl;
        //G4cout<<" r   " << targetPos/mm << " mm"<<G4endl;
        //G4cout<<" posZ "<<fCentroidZ/mm <<" mm"<<G4endl;
        //G4cout<<" sin " <<targetPos/sqrt(fCentroidZ*fCentroidZ+targetPos*targetPos)
        //<<G4endl;
      }else {
        fieldValue = 0.0;
      }
      //G4cout << " FieldValue " << fieldValue/tesla << " tesla "<<G4endl;
    }

    SetFieldValue(fieldValue);
}
