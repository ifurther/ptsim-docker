//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//=============================================================
//  Created
//  2014-11-23  T.Aso
//  2016-01-14 T.Aso  eidFile2 command.
//
//=============================================================
#include "G4MScanBeamMessenger.hh"
#include "G4MScanBeamManager.hh"
#include "G4UIparameter.hh"
#include "G4Tokenizer.hh"

G4MScanBeamMessenger::G4MScanBeamMessenger(G4MScanBeamManager* scanbeam)
  :fScanBeamMgr(scanbeam) {

  //
  fDir = new G4UIdirectory("/G4M/ScanBeam/");
  fDir->SetGuidance("UI commands for modules");

  fCmdVerbose = new G4UIcmdWithAnInteger("/G4M/ScanBeam/verbose",this);
  fCmdVerbose->SetGuidance("Scan Beam: Verbose");
  fCmdVerbose->SetParameterName("verbose",false);
  fCmdVerbose->AvailableForStates(G4State_Idle);

  fCmdSetScanMag = new G4UIcommand("/G4M/ScanBeam/scanMagXY",this);
  fCmdSetScanMag->SetGuidance("Assign scan magnet X and Y by its name");
  fCmdSetScanMag->SetGuidance("Usage: /G4M/ScanBeam/scanMagXY mnameX mnameY");
  fCmdSetScanMag->SetGuidance("mnameX: beam module for scanning manget in X");
  fCmdSetScanMag->SetGuidance("mnameY: beam module for scanning manget in Y");
  G4UIparameter* param;
  param = new G4UIparameter("mnameX",'s',false);
  fCmdSetScanMag->SetParameter(param);
  param = new G4UIparameter("mnameY",'s',false);
  fCmdSetScanMag->SetParameter(param);

  fCmdEIDFile = new G4UIcmdWithAString("/G4M/ScanBeam/eidFile",this);
  fCmdEIDFile->SetGuidance("Scan Beam: EID file");
  fCmdEIDFile->SetParameterName("eidFile",false);
  fCmdEIDFile->AvailableForStates(G4State_Idle);

  fCmdEIDFile2 = new G4UIcmdWithAString("/G4M/ScanBeam/eidFile2",this);
  fCmdEIDFile2->SetGuidance("Scan Beam: EID file with Sigma of angle");
  fCmdEIDFile2->SetParameterName("eidFile",false);
  fCmdEIDFile2->AvailableForStates(G4State_Idle);

  fCmdScanFile = new G4UIcmdWithAString("/G4M/ScanBeam/scanFile",this);
  fCmdScanFile->SetGuidance("Scan Beam: scan spot file");
  fCmdScanFile->SetParameterName("scanFile",false);
  fCmdScanFile->AvailableForStates(G4State_Idle);

  fCmdWeightFile = new G4UIcmdWithAString("/G4M/ScanBeam/weightFile",this);
  fCmdWeightFile->SetGuidance("Scan Beam: Dose weight file");
  fCmdWeightFile->SetParameterName("weightFile",false);
  fCmdWeightFile->AvailableForStates(G4State_Idle);

  fCmdShow = new G4UIcmdWithAString("/G4M/ScanBeam/show",this);
  fCmdShow->SetGuidance("Scan Beam: Show Parameters");
  fCmdShow->SetGuidance("Syntax: /G4M/ScanBeam/show  name");
  fCmdShow->SetGuidance("name:  eid or spot or weight ");
  fCmdShow->SetParameterName("showFile",false);
  fCmdShow->AvailableForStates(G4State_Idle);


  fCmdCalcProb= new G4UIcmdWithoutParameter("/G4M/ScanBeam/calcProb",this);
  fCmdCalcProb->SetGuidance("Scan Beam: Update Probability");
  fCmdCalcProb->AvailableForStates(G4State_Idle);

  //
}

G4MScanBeamMessenger::~G4MScanBeamMessenger() {
  delete   fDir;
  delete   fCmdVerbose;
  delete   fCmdSetScanMag;
  delete   fCmdEIDFile;
  delete   fCmdEIDFile2;
  delete   fCmdScanFile;
  delete   fCmdWeightFile;
  delete   fCmdShow;
  delete   fCmdCalcProb;
}

void G4MScanBeamMessenger::SetNewValue(G4UIcommand* cmd, 
                                       G4String newValue ) {

  if ( cmd == fCmdSetScanMag ){
    G4String mnamex, mnamey;
    std::istringstream iss(newValue);
    iss >> mnamex >> mnamey;
    fScanBeamMgr->SetScanningMagnet(mnamex,mnamey);
  }else if ( cmd == fCmdVerbose ){
    fScanBeamMgr->SetVerbose(fCmdVerbose->GetNewIntValue(newValue));
  }else if ( cmd == fCmdEIDFile ){
    fScanBeamMgr->ReadEIDFile(newValue);
  }else if ( cmd == fCmdEIDFile2 ){
    fScanBeamMgr->ReadEIDFileWithAngSigma(newValue);
  }else if ( cmd == fCmdScanFile ){
    fScanBeamMgr->ReadScanFile(newValue);
  }else if ( cmd == fCmdWeightFile ) {
    fScanBeamMgr->ReadDoseWeightFile(newValue);
  }else if ( cmd == fCmdShow ) {
    if ( newValue == "eid" ){
      fScanBeamMgr->ShowEID();
    }else if ( newValue == "weight"){
      fScanBeamMgr->ShowEWeight();
    }else if ( newValue == "spot"){
      fScanBeamMgr->Show();
    }else{
      G4cout << " no option for "<<newValue<<G4endl;
    }
  }else if ( cmd == fCmdCalcProb ) {
    fScanBeamMgr->CalculateProbability();
  }

}

G4String G4MScanBeamMessenger::GetCurrentValue(G4UIcommand*) {
  return G4String();
}

