//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Box type module
// 
//  (History)
//   2014-10-31  T.Aso
//   2014-12-01  T.Aso Suppress compile warnings.
//
//---------------------------------------------------------------------
//
#include "G4MBoxComposerFileCatalogue.hh"
#include "G4MVGeometryBuilder.hh"
#include "G4MVParticleTherapySystem.hh"
#include "G4MBoxComposer.hh"
#include <fstream>
#include <sstream>

G4MBoxComposerFileCatalogue::G4MBoxComposerFileCatalogue(const G4String& name,
                                         const G4String& fileName)
  :G4MVBoxComposerCatalogue(name),fDefaultFileName(fileName){
  subModuleVec.clear();
}

G4MBoxComposerFileCatalogue::~G4MBoxComposerFileCatalogue()
{
  subModuleVec.clear();
}

void G4MBoxComposerFileCatalogue::Init(){
  Prepare(fDefaultFileName);
  //fModule->SetAllParameters(material,dxyz);
  Apply();
}

void G4MBoxComposerFileCatalogue::Prepare(G4String& pname){
  char chline[512];
  std::ifstream ifs;
  G4String filename = pname;
  ifs.open(filename.c_str());  //file open
  if(!ifs){
    const G4String msg = "file open error"+filename;
    G4Exception("G4MBoxComposerFileCalalogue::Prepare()","G4MBoxComposerFileCata00",
                FatalException,msg);
  }else{
    ifs.getline(chline,512);  // effective physical size 
    std::istringstream iss1(chline);
    G4double fx,fy,fz;
    iss1 >> fx >> fy >> fz;   // Full Size
    dxyz.setX(fx*mm/2.);
    dxyz.setY(fy*mm/2.);
    dxyz.setZ(fz*mm/2.);

    ifs.getline(chline,512);  //material
    std::istringstream iss2(chline);
    iss2 >> material;

    ifs.getline(chline,512); // Number of sub-modules
    std::istringstream iss3(chline); 
    G4int N;
    iss3 >> N;
    
    subModuleVec.clear();

    G4String subm;
    for (G4int i = 0; i < N; i++ ){
      ifs.getline(chline,512); // Number of sub-modules
      std::istringstream iss4(chline); 
      iss4 >> subm;
      subModuleVec.push_back(subm);
      G4cout << " BoxComposerFileCatalogue:: " << subm<< G4endl;
    }
  }
  ifs.close();
}

void G4MBoxComposerFileCatalogue::Apply(){

  G4MVParticleTherapySystem* system= G4MVGeometryBuilder::GetSystem();
  fModule->Clear();
  fModule->SetAllParameters( material, dxyz);
  for (size_t i = 0;  i < subModuleVec.size(); i++){
    G4MVBeamModule* module = system->GetModule(subModuleVec[i]);
    if ( !module ) {
      G4Exception("G4MBoxComposerFileCata::Apply()",
                  "G4MBoxCompFileCata00",JustWarning,": No sub module.. Break ");
      break;
    }
    G4cout << " BoxComposerFileCatalogue::Apply " << subModuleVec[i]<< G4endl;
    fModule->AddModule(module);
    fModule->AddToCreateList(subModuleVec[i]);
  }
  fModule->ReBuild();
}
