//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// (Description)
//    Class for parameterisation of G4MPTCollimator.
//    This class realizes PTCollimator structure using parameterisation.
//    The Air(Drill) hole is parameterised.
//
// (HISTORY)
//   2012-06-06 T.Aso Copied from Bolus and modified for PTCol.
//   2012-09-10 T.Aso the vector type of theMap was modified from G4int
//                   to short.
// 2015-12-14  T.Aso  Dummy Compute dimensions for Sphere.
//
//---------------------------------------------------------------------
//
#ifndef G4MPTCollimatorParameterisation_h
#define G4MPTCollimatorParameterisation_h 1

#include "globals.hh"
#include "G4VPVParameterisation.hh"
#include <vector>
class G4VPhysicalVolume;
class G4VLogicalVolume;
class G4Box;
class G4Material;

// Dummy declarations to get rid of warnings ...
class G4Trd;
class G4Trap;
class G4Cons;
class G4Orb;
class G4Sphere;
class G4Torus;
class G4Para;
class G4Hype;
class G4Tubs;
class G4Polycone;
class G4Polyhedra;

class G4MPTCollimatorParameterisation: public G4VPVParameterisation {

public:

  //Constructor and Destructor
  G4MPTCollimatorParameterisation(G4int nx, G4int ny,
                                  std::vector<short>& map,
                                  G4double xpitch,
                                  G4double ypitch,
                                  G4double x0,
                                  G4double y0,
                                  G4Material* mat,
                                  G4int ixdir=1,G4int iydir=1);

  virtual ~G4MPTCollimatorParameterisation();

  void  SetPitch(G4double px, G4double py);
  void  SetNxy(G4int nx, G4int ny);
  void  CalculateActiveVolume();
  G4int GetNofActiveVolume();

  void ComputeTransformation(const G4int copyNo, 
                             G4VPhysicalVolume* physVol)const;
  void ComputeDimensions(G4Box& boxel, const G4int copyNo,
                         const G4VPhysicalVolume* physVol) const;

  G4Material* ComputeMaterial(const G4int copyNo,
                              G4VPhysicalVolume* physVol,
                              const G4VTouchable* parentTouch=0);


protected:

private:  // Dummy declarations to get rid of warnings ...

  void ComputeDimensions (G4Trd&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Trap&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Cons&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Sphere&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Orb&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Torus&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Para&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Hype&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Tubs&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Polycone&,const G4int,const G4VPhysicalVolume*)
    const {}
  void ComputeDimensions (G4Polyhedra&,const G4int,const G4VPhysicalVolume*) 
    const {}
  void ComputeDimensions (G4Ellipsoid&,const G4int,const G4VPhysicalVolume*)
    const {}

private:
  G4int fNx,fNy;
  std::vector<short> theMap;
  G4double  fxPitch;
  G4double  fyPitch;
  G4double  fx0;
  G4double  fy0;
  G4Material* fmat;
  G4int fxdir,fydir;

  G4double*  fpX;
  G4double*  fpY;
  G4double*  fpZ;
  G4int fNofVolume;

};

#endif
