//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    Concrete Beam Module Class for RidgeWSctFilter .
// 
// (HISTORY)
//  05-OCT-05  T.ASO
//  05-OCT-05  T.ASO  Add bar length in Constructor.
//  01-DEC-05  T.ASO  Add FrameDxyz.
//  2012-06-22 T.Aso  Add scattering plate option for FukuiCC. 
//
// -----------------------------------------------------------------
//

#ifndef G4MRIDGEWSCTFILTER_HH
#define G4MRIDGEWSCTFILTER_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4VPhysicalVolume.hh"
#include <vector>
#include "G4MVRidgeWSctFilterCatalogue.hh"

class G4MRidgeWSctFilter : public G4MVBeamModule {
  public:
    G4MRidgeWSctFilter(const G4String& name, const G4String& mat, 
		   G4int nbar, G4double barpitch, G4double barlen,
		   const std::vector<G4double>& xfin, 
		   const std::vector<G4double>& zfin);

    G4MRidgeWSctFilter(const G4String& name);

    G4MRidgeWSctFilter(G4MVRidgeWSctFilterCatalogue* catalogue);

    virtual ~G4MRidgeWSctFilter();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4String& mat, 
			  G4int nbar, G4double barpitch, G4double barlen,
			  const std::vector<G4double>& xfin, 
			  const std::vector<G4double>& zfin,
			  const G4String& sctmat="", G4double sctthick=0.0);

    virtual void  Dump(std::ostream& out);

    void SetMatRidge(const G4String& mat){ fMatRidge = mat;}

    void SetNBar(G4int nbar){ fnbar = nbar; }

    void SetBarPitch(G4double pitch) {  fbarPitch = pitch;}

    void SetBarLength(G4double barlen) { fbarLength = barlen;}

    void SetFin(const std::vector<G4double>& x, 
		const std::vector<G4double>& z);

    void SetSctOption(G4String& mat, G4double thick)
    { fSctMat = mat;   fSctThick = thick; }
      

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
    G4String fMatRidge;
    G4int    fnbar;
    G4double fbarPitch;
  
    G4double fbarLength;

    std::vector<G4double> fxFin;
    std::vector<G4double> fzFin;

    G4String fSctMat;
    G4double fSctThick;

  private:
    G4MVRidgeWSctFilterCatalogue* fCatalogue;
};
#endif /* G4MRIDGEWSCTFILTER_HH */
