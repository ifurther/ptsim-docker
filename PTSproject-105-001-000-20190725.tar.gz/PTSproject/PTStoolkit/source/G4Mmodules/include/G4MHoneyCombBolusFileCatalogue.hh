//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MHoneyCombBolus.
// 
//  (History)
//   2014-03-10   T.Aso
//---------------------------------------------------------------------
//
#ifndef G4MHONEYCOMBBOLUSFILECATALOGUE_HH
#define G4MHONEYCOMBBOLUSFILECATALOGUE_HH

#include "G4MVHoneyCombBolusCatalogue.hh"
#include "G4ThreeVector.hh"
#include <vector>

class G4MHoneyCombBolusFileCatalogue : public G4MVHoneyCombBolusCatalogue{
  public:
    G4MHoneyCombBolusFileCatalogue(const G4String& name,const G4String& filename); 
    virtual ~G4MHoneyCombBolusFileCatalogue();

  public:
    virtual void Init();
    virtual void Prepare(G4String& pname);
    virtual void Apply();
    virtual void Dump(){};

 protected:
     G4String fDefaultFileName;

     G4ThreeVector fDxyzBolus;
     G4String fMatBolus;
     G4int fNx;
     G4int fNy;
     G4double fx0;
     G4double fy0;
     G4double fPitchX;
     G4double fPitchY;
     G4double fFact;

     std::vector<G4double> theThickness;
};

#endif



