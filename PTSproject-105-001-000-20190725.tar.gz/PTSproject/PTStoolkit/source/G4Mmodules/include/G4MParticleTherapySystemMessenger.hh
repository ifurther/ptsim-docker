//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Desctiption)
//    Messenger for Particle Therapy System
//
//
//   /G4M/Module/    directory
//     Commands:
//        install    moduleName pwName layered; Install the module as a physical volume
//        installIfExist    moduleName pwName layered; Install the module if the physical volume
//        uninstall  moduleName  ; Uninstall the module from world volume
//        cloneIfExist   mNameFrom mNameTo copyid x y z rx ry rz; Install the module if the physical volume
//        installAll    ; Rebuild all modules except Room
//        installBM     ; Rebuild all modules except Room, WP,and DICOM
//        uninstallAll  ; Uninstall all modules except Room
//        uninstallBM   ; Uninstall all modules except Room, WP,and DICOM
//        rebuild    moduleName  ; Combination of Uninstall/Install.
//        list       level  oname  ; Listing available modules and status
//        listInWorld     worldName; Listing modules installed in worldName
//        lang  id       ;  Lang. in dump command. id=0 JPN, id!=0 ENG.
//
//     Commands
//        select     moduleName  ; Select Module for messeging to module
//        typeid     catalogue id; Select a Module parameter from 
//                                 the selected module's Catalogue.
//        dump       N/A         ; Dump module parameter.
//        dump       filename    ; Dump module parameter.
//        translate  x y z unit  ; Translate the selected module
//        rotate     Ox Oy Oz unit  ; Rotate the selected module
//        downEdgeZ  z unit      ; Place downstream Edge of the module
//        upEdgeZ    z unit      ; Place upstream Edge of the module
//        attachZ    module ; Place the selected module with DICOM.
//
//     Commands
//        verbose    level       ; Vebose level
//
//        selectLV   {moduleName}  {idSelect}; Select LV
//        dumpLV     {moduleName} ;
//        createSD   {SDName} {ColName} {edepFlag} {depx} {depy} {depz} {depm} {deps}; 
//        setDepthSD {SDName} {depx} {depy} {depz} {depm} {deps} 
//        setEdepSD  {SDName} {flag} 
//        setStepSD  {SDName} {flag} 
//        attachSD   {SDname}; (Not completed.)
//        detachSD   (Not completed.)
//        attachTrgID  {SDName} {ID}; (not completed.)
//
//        physicsModified ; /run/geometryModified and 
//                        G4ProductionCutsTable::PhysicsTableUpdated().
//
//
//        
// (HISTORY)
//   05-OCT-05  Created/Modified T.Aso
//   05-OCT-05  Add select command and its command group.  T.Aso
//   09-NOV-05  CmdUpdateEvent moved from HIBMCSetup.
//   05-DEC-05  Add Rebuild command.
//   05-DEC-05  Add Rebuild command.
//   14-FEB-07  G4MDICOM was replaced to G4MVDICOM, T.ASO
//   15-FEB-07  G4MDICOM related commands are moved into G4MDICOMMessenger. TA
//   14-FEB-07  G4MDICOM was replaced to G4MVDICOM, T.ASO
//   15-FEB-07  G4MDICOM related commands are moved into G4MDICOMMessenger. TA
//   10-Aug-10  selectLV and dumpLV commands.
//   2012-06-06 T.Aso installAll, uninstallAll, dump commands. 
//   2012-11-16 T.Aso installBM, uninstallBM, dump commands. 
//   2013-03-27 T.Aso install command has one more option for specifying 
//                    a parallel world geometry.
//                    listInWorld command is introduced.
//   2013-11-01 T.Aso lang command.
//   2014-02-05 T.Aso attachZ command.
//   2014-03-31 T.Aso install command was modifed. installIfExist command.
//   2014-08-07 T.Aso add ostream in list command.
//   2016-04-07 T.Aso (attachSD, attachTrgID)
//   2016-07-16 T.Aso stepSD.
//---------------------------------------------------------------------
//
#ifndef G4MPARITCLETHERAPYSYSTEMMESSENGER_HH
#define G4MPARITCLETHERAPYSYSTEMMESSENGER_HH

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4LogicalVolume.hh"

class G4MVParticleTherapySystem;
class G4MVBeamModule;

class G4MParticleTherapySystemMessenger: public G4UImessenger {
  public:
    G4MParticleTherapySystemMessenger(G4MVParticleTherapySystem* system);

    ~G4MParticleTherapySystemMessenger();

    virtual void SetNewValue(G4UIcommand* command, G4String newValue);

    virtual G4String GetCurrentValue(G4UIcommand* command);

  private:
    G4UIdirectory* fDir;
    //G4UIcmdWithAString* fCmdInstall;
    G4UIcommand* fCmdInstall;
    G4UIcommand* fCmdInstallIfExist;
    G4UIcommand* fCmdCloneIfExist;
    G4UIcmdWithAString* fCmdUnInstall;
    G4UIcmdWithoutParameter* fCmdInstallAll;
    G4UIcmdWithoutParameter* fCmdUnInstallAll;
    G4UIcmdWithoutParameter* fCmdInstallBM;
    G4UIcmdWithoutParameter* fCmdUnInstallBM;
    G4UIcmdWithAString* fCmdReBuild;
    G4UIcommand* fCmdList;
    G4UIcmdWithAString* fCmdListInWorld;
    G4UIcmdWithAnInteger* fCmdLang;

    G4UIcmdWithAString* fCmdAttachZ;

    G4UIcmdWithAString* fCmdSelect;
    G4UIcmdWithAString* fCmdTypeID;

    G4UIcmdWith3VectorAndUnit* fCmdTranslate;
    G4UIcmdWith3VectorAndUnit* fCmdRotate;

    G4UIcmdWithADoubleAndUnit* fCmdDownEdgeZ;
    G4UIcmdWithADoubleAndUnit* fCmdUpEdgeZ;

    G4UIcmdWithAnInteger* fCmdVerbose;

    G4UIcmdWithoutParameter* fCmdDump;
    G4UIcmdWithAString* fCmdDumpFile;

    G4UIcmdWithoutParameter*  fCmdUpdate;

    G4UIcommand* fCmdLVSelect;
    G4UIcmdWithAString* fCmdLVDump;

    G4UIcommand* fCmdCreateSD;
    G4UIcommand* fCmdSetDepthSD;
    G4UIcommand* fCmdSetEdepSD;
    G4UIcommand* fCmdSetStepSD;
    G4UIcmdWithAString* fCmdSDAttach;
    G4UIcmdWithoutParameter* fCmdSDDetach;
    G4UIcommand*        fCmdAttachTrgID;

    G4UIcmdWithoutParameter*  fCmdPhysicsModified;


  //
    G4MVParticleTherapySystem *fSystem;

  private:
    G4MVBeamModule* fcurrentModule;
    G4LogicalVolume* fcurrentLV;
};

#endif /* G4MPARITCLETHERAPYSYSTEMMESSENGER_HH */
