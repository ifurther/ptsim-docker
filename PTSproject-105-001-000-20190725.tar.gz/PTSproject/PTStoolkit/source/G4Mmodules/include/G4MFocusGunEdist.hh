//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MFocusGunEdist
//
//  Modified from G4MBeamGun
//  11-JAN-07  T.ASO Modify for CLHEP2.0
//
//---------------------------------------------------------------------
//
#ifndef G4MFocusGunEdist_h
#define G4MFocusGunEdist_h 1

#include "globals.hh"
#include "G4PhysicsOrderedFreeVector.hh"
#include "G4ParticleGun.hh"
#include "CLHEP/Random/Randomize.h"

class G4Event;
class G4MFocusGunEdistMessenger;

// class description:
//
class G4MFocusGunEdist:public G4ParticleGun
{
  public: // with description
     G4MFocusGunEdist();

  public:
     virtual ~G4MFocusGunEdist();

  public: // with description
     virtual void GeneratePrimaryVertex(G4Event* evt);

     void ClearEnergyDist();
     void InsertEnergyDist(G4double energy, G4double prob);
     void IntegrateEnergyDist();
     void SampleEnergyDist(G4int npoint=0);
     void SetSample(G4int n){ nsample = n;} ;

     //-- Settings for focused beam
     void SetFocusDistanceX(const G4double FX){ FocusX = FX; }
     G4double GetFocusDistanceX() const{ return FocusX; }

     void SetFocusDistanceY(const G4double FY){ FocusY = FY; }
     G4double GetFocusDistanceY() const{ return FocusY; }

     void SetSpatialExpanseX(const G4double SigX){ SigmaX = SigX; }
     G4double GetSpatialExpanseX() const{ return SigmaX; }

     void SetSpatialExpanseY(const G4double SigY){ SigmaY = SigY; }
     G4double GetSpatialExpanseY() const{ return SigmaY; }
     //

  protected:  
     // Energy Dist by Histogram (Energy).
     // Energy Dist by Histogram (Prob).
     G4PhysicsOrderedFreeVector EdistPOFV;
     G4PhysicsOrderedFreeVector IntEdistPOFV;
     G4PhysicsOrderedFreeVector ZeroPhysVector; //for reset.
     G4bool isIntEdist;
     G4int  nsample;

  // Focused beam parameters
     G4double FocusX;   // Focus position in mm.
     G4double FocusY;
     G4double SigmaX;   //  
     G4double SigmaY; 
  //

  private:
     G4MFocusGunEdistMessenger* theFocusMessenger;
     
};

#endif


