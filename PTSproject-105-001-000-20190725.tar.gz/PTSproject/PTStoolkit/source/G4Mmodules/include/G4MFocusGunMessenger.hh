//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//---------------------------------------------------------------------
//  G4MFocusGunMessenger
//
//  Modified 
//  By W.Takase
//  24-DEC-08  T.Aso Remove emittance setting
//
//---------------------------------------------------------------------
//
// 
#ifndef G4MFocusGunMessenger_h
#define G4MFocusGunMessenger_h 1

class G4MFocusGun;
class G4UIcommand;
class G4UIdirectory;
class G4UIcmdWith3VectorAndUnit;
class G4UIcmdWith3Vector;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWithAString;
class G4ParticleTable;

#include "G4UImessenger.hh"
#include "globals.hh"

class G4MFocusGunMessenger: public G4UImessenger
{
  public:
    G4MFocusGunMessenger(G4MFocusGun * fPtclGun);
    ~G4MFocusGunMessenger();
    
  public:
    void SetNewValue(G4UIcommand * command,G4String newValues);
    G4String GetCurrentValue(G4UIcommand * command);

  private:
    G4MFocusGun * fParticleGun;

  private: //commands
    G4UIdirectory *             gunDirectory;
    G4UIcmdWithADoubleAndUnit * eflucCmd;
    G4UIcmdWithAString        * beamFileCmd;
    G4UIcmdWithADoubleAndUnit * focusDistXCmd;
    G4UIcmdWithADoubleAndUnit * focusDistYCmd;
    G4UIcmdWithADoubleAndUnit * spExpandXCmd;
    G4UIcmdWithADoubleAndUnit * spExpandYCmd;
};

#endif

