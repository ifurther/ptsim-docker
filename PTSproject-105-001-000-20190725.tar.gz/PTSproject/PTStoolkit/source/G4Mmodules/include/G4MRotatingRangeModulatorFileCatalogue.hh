//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for Disk type module
// 
//  (History)
//   04-Oct-05   T.Aso
//   2011. Sep. Kawashima and Aso (TNCT).
//
//---------------------------------------------------------------------
//

#ifndef ROTATINGRANGEMODULATORFILEFILECATALOGUE_HH
#define ROTATINGRANGEMODULATORFILEFILECATALOGUE_HH

#include "G4MVRotatingRangeModulatorCatalogue.hh"

class G4MRotatingRangeModulatorFileCatalogue : public G4MVRotatingRangeModulatorCatalogue{
  public:
    G4MRotatingRangeModulatorFileCatalogue(const G4String& name, const G4String& fileName); 
    virtual ~G4MRotatingRangeModulatorFileCatalogue();

  public:
    virtual void Init();
    virtual void Prepare(G4String& pname);
    virtual void Apply();
    virtual void Dump(){};

 private:
  
  char chline[512];

  // Envelope
  G4String material;
  G4double Rin,Rout, dZ;

 private:
  G4String fDefaultFileName;

};

#endif



