//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  (Desctiption)
//   This is a class for catalogue of parameters for MLC
// 
//  (History)
//   06-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
#ifndef G4MMLCFILECATALOGUE_HH
#define G4MMLCFILECATALOGUE_HH

#include "G4MVMLCCatalogue.hh"
#include "G4ThreeVector.hh"
#include <vector>

class G4MMLCFileCatalogue : public G4MVMLCCatalogue{
  public:
    G4MMLCFileCatalogue(const G4String& name); 
    virtual ~G4MMLCFileCatalogue();

  public:
    virtual void Init();
    virtual void Prepare(G4String& pname);
    virtual void Apply();
    virtual void Dump(){};

 private:
    G4ThreeVector fFrameDxyz;
    G4String fMatMLC;
    G4String fMatHole;

    G4int fNLeafPair;
    G4double fy0Leaf;
    G4double fDyLeaf;

    std::vector<G4double> thePositionVector;

};

#endif



