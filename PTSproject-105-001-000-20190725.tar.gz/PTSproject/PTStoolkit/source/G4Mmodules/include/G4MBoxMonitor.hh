//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MBoxMonitor
//
// (HISTORY)
//   06-Oct-05   T.Aso
//                    
// -----------------------------------------------------------------
//                    
#ifndef G4MBOXMONITOR_HH
#define G4MBOXMONITOR_HH

#include "globals.hh"
#include "G4MVMonitor.hh"
#include "G4MVBoxMonitorCatalogue.hh"
#include <vector>

class G4MBoxMonitor : public G4MVMonitor {
  public:

    G4MBoxMonitor(const G4String& name,const std::vector<G4double>& dx,
		                        const std::vector<G4double>& dy,
		                        const std::vector<G4double>& dz,
   		                        const std::vector<G4String>& mat,
		                        const std::vector<G4double>& pos,
		                        const G4String& masterMat="Air");

    G4MBoxMonitor(const G4String& name);

    G4MBoxMonitor(G4MVBoxMonitorCatalogue* catalogue);


    virtual ~G4MBoxMonitor();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const std::vector<G4double>& dx,
		          const std::vector<G4double>& dy,
		          const std::vector<G4double>& dz,
   		          const std::vector<G4String>& mat,
			  const std::vector<G4double>& pos,
			  const G4String& masterMat="Air");

    const std::vector<G4double>& GetDxVec()const  { return fDx;}
    const std::vector<G4double>& GetDyVec()const { return fDy;}
    const std::vector<G4double>& GetDzVec()const   { return fDz;}
    const std::vector<G4String>& GetMatVec()const { return fMaterial;}
    const std::vector<G4double>& GetZVec()const   { return fZ;}

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
     std::vector<G4double> fDx;
     std::vector<G4double> fDy;
     std::vector<G4double> fDz;
     std::vector<G4String> fMaterial;
     std::vector<G4double> fZ;
     G4String fMasterMat;

     // Master Volume Size
     G4double fZoffset;

  private:
     G4MVBoxMonitorCatalogue* fCatalogue;

};
#endif /* G4MBOXMONITOR_HH */
