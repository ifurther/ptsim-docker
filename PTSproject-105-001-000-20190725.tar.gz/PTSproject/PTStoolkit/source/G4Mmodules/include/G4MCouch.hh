//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MCouch
//
//  (HISTORY)
// 2014-02-07 T.Aso Created.
//
//---------------------------------------------------------------------
//
#ifndef G4MCOUCH_HH
#define G4MCOUCH_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVCouchCatalogue.hh"

class G4MCouch : public G4MVBeamModule {
public:
  G4MCouch(const G4String& name, 
                  const std::vector<G4ThreeVector>& dxyz,
                  const std::vector<G4double>& y,
                  const std::vector<G4String>& mats);
  // contents of the vectors must be ordered from the most outer volume

  G4MCouch(const G4String& name);

  G4MCouch(G4MVCouchCatalogue* catalogue);

  virtual ~G4MCouch();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(const std::vector<G4ThreeVector>& dxyz,
                        const std::vector<G4double>& y,
                        const std::vector<G4String>& mats);

  const std::vector<G4ThreeVector>& GetDxyz() const
  { return fDxyz; }
  const std::vector<G4double>& GetY() const
  { return fY; }
  const std::vector<G4String>& GetMatName() const
  { return fMatName; }

  void SetDxyz(const std::vector<G4ThreeVector>& dxyz)
  { fDxyz = dxyz; }
  void SetY(const std::vector<G4double>& y )
  {  fY = y; }
  void SetMatName(const std::vector<G4String>& mat)
  {  fMatName = mat; }
 
protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume *physvol);

private:
  std::vector<G4ThreeVector> fDxyz;
  std::vector<G4double> fY;
  std::vector<G4String> fMatName;

private:
  G4MVCouchCatalogue* fCatalogue;

};

#endif
