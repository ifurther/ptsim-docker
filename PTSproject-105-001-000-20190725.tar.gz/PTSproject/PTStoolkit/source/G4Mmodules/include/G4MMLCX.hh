//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//   Class for MLC Beam Module.
//    G4MMLC(const G4String& name, const G4ThreeVector& dxyz, 
//           const G4String& matMLC, 
//           G4int nyleaf, G4double y0leaf, 
//           std::vector<G4double>& leafposition)
//    name : Module Name
//    dxyz : Half length Size of MLC envelope
//    matMLC: Matrial name of MLC
//    nyleaf:  Number of leaf pair, namly total nyleaf*2 for left and right.
//    y0leaf:  y offset of first leaf. First leaf must be start from -Y.
//    leafposition:  Position of leafs, i.e the open edge of ridges.
//
//       Numbering of leaf for leaf position.
//   +Y
//    |__ +X 
//             nyleaf-1   2*nyleaf-1
//                .         .
//                .         .
//                2       nyleaf+2
//                1       nyleaf+1
//                0       nyleaf+0
//
//
//  (HISTORY)
//   06-FEB-2006 ASO  Coverted from G4MLC for responding HIBMC requirement.
//   2012-06-0  T.ASO Dump().
//   2018-03-22  T.ASO fMatAir was moved to G4MVBeamModule.
//
//---------------------------------------------------------------------
//

#ifndef G4MMLCX_HH
#define G4MMLCX_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MMLCXParameterisation.hh"
#include "G4ThreeVector.hh"
#include "G4MVMLCXCatalogue.hh"
#include <vector>

class G4MMLCX : public G4MVBeamModule {
  public:
    G4MMLCX(const G4String& name, 
            const G4ThreeVector& dxyz, 
            const G4String& matMLC, 
            G4int nyleaf, 
            const G4ThreeVector& dlxyz,
            G4double y0leaf, 
            std::vector<G4double>& leafposition,
            const G4String& matAir="Air");

    G4MMLCX(const G4String& name);

    G4MMLCX(G4MVMLCXCatalogue* catalogue);

    virtual ~G4MMLCX();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector& dxyz, 
                          const G4String& matMLC, 
                          G4int nyleaf, const G4ThreeVector& dlxyz,
                          G4double y0leaf, 
                          std::vector<G4double>& leafposition,
                          const G4String& matAir="Air");

    virtual void  Dump(std::ostream& out);

    void SetMatMLC(const G4String& mat);

    void SetLeafDxyz(const G4ThreeVector& dlxyz);

    G4ThreeVector GetLeafDxyz() const;

    void SetLeafPosition(std::vector<G4double>& xleafpos);

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
    G4String fMatMLC;
    G4int fNLeafPair;
    G4ThreeVector fLeafDxyz;
    G4double fy0Leaf;
    std::vector<G4double> thePositionVector;
  //G4String fMatAir;
    G4MMLCXParameterisation* fParameterisation;
    G4VPhysicalVolume* fParamPhysVol;

  private:
    G4MVMLCXCatalogue* fCatalogue;
    
};

#endif /* G4MMLCX_HH */
