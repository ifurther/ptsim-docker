//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MGLUtil
//    Graphical library for handling images.
//
//  (HISTORY)
//   2012-09-10 T.Aso Created. 
//   2014-05-19 T.Aso modify the define statement.
//                         
//
//---------------------------------------------------------------------
//
#ifndef G4MGLUtil_HH
#define G4MGLUtil_HH

#include "globals.hh"
#include <vector>
#include <stack>
using namespace std;

class G4MGLUtil  {
  public:

  G4MGLUtil();
  virtual ~G4MGLUtil(){;}

  void SetVerbose(G4int vl){ fVerbose = vl; };

  G4int searchInsideXPY(G4int iymin, G4int iymax, 
                              std::vector<short>& map, 
                              G4int nx, G4int ny, G4int& ixS, G4int& iyS);
  G4int searchInsideXNY(G4int iymin, G4int iymax, 
                              std::vector<short>& map, 
                              G4int nx, G4int ny, G4int& ixS, G4int& iyS);
  G4bool searchInsideY(G4int ixmin, G4int ixmax, 
                              std::vector<short>& map, 
                              G4int nx, G4int ny, G4int& ixS, G4int& iyS);

  void drawLine(G4int ix0, G4int iy0, G4int ix1, G4int iy1,
                       std::vector<short>& map, G4int nx, G4int ny );

  void paint(G4int ix0, G4int iy0, std::vector<short>& map,
                    G4int nx, G4int ny);

  void scanLine(G4int XL, G4int XR, G4int iy0, std::vector<short>& map,
                       G4int nx, G4int ny,
                       std::stack<short>& stackX, std::stack<short>& stackY);

  public:
    G4int fVerbose;
  //    G4int debugid;
  //    G4int debugz;
  //    G4int debugmapid;

};
#endif /* G4MGLUtil_HH */
