//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Description)
//    Class for Patient Collimator Beam Module
//
//  (History)
//   2012-06-06  T.ASO Copied from Bolus and modified for PTCol.
//   2012-09-10  T.Aso Graphics functions such as drawline, paint, 
//                     scanline are moved to G4MGLUtil class.
//                     
//
//---------------------------------------------------------------------
//

#ifndef G4MPTCOLLIMATOR_HH
#define G4MPTCOLLIMATOR_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MPTCollimatorParameterisation.hh"
#include "G4ThreeVector.hh"
#include <vector>
#include <stack>
#include "G4MVPTCollimatorCatalogue.hh"


class G4MPTCollimator : public G4MVBeamModule {
  public:
    G4MPTCollimator(const G4String& name, 
		    const G4ThreeVector& dxyz,
		    const G4String& mat,
		    G4double dx, G4double dy,
		    std::vector<G4double>& xvec,
		    std::vector<G4double>& yvec,
		    G4int xdir=1, G4int ydir=1
		    );

    G4MPTCollimator(const G4String& name);

    G4MPTCollimator(G4MVPTCollimatorCatalogue* catalogue);

    virtual ~G4MPTCollimator();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector& dxyz,
			  const G4String& mat,
			  G4double dx, G4double dy,
			  std::vector<G4double>& xvec,
			  std::vector<G4double>& yvec,
			  G4int xdir=1, G4int ydir=1
			  );

    virtual void  Dump(std::ostream& out);

    void SetMatName(G4String& mat ){ fMatName = mat; }

    void SetDxy(G4double dx,G4double dy){ fdx = dx; fdy = dy; }
    G4double GetDx() const { return fdx; }
    G4double GetDy() const { return fdy; }

    void  SetXYVector(std::vector<G4double>& vx, std::vector<G4double>& vy)
   {  theXVec = vx; theYVec = vy; }
    void  SetXYVector(std::vector<G4double>& v);

    std::vector<G4double>& GetXVector() { return theXVec;}
    std::vector<G4double>& GetYVector() { return theYVec;}

    void FillPixelParam();

  protected:

    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);



  private:
  // Input
    G4String fMatName;
    std::vector<G4double> theXVec;
    std::vector<G4double> theYVec;
    G4double fdx,fdy;
    G4int    fxdir,fydir;

  // Calculated inside
    G4double fx0, fy0;
    G4int    fnx, fny;
    std::vector<G4int> theIxVec;
    std::vector<G4int> theIyVec;
    std::vector<short> theMap;
 
  //
    G4MPTCollimatorParameterisation* fParameterisation;

  private:
    G4MVPTCollimatorCatalogue* fCatalogue;
};

#endif /* G4MPTCollimator_HH */
