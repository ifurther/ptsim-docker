//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MBoxStructure
//
//  (HISTORY)
//
//---------------------------------------------------------------------
//
#ifndef G4MBOXSTRUCTURE_HH
#define G4MBOXSTRUCTURE_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVBoxStructureCatalogue.hh"

class G4MBoxStructure : public G4MVBeamModule {
public:
  G4MBoxStructure(const G4String& name, 
		  const std::vector<G4ThreeVector>& dxyz,
		  const std::vector<G4double>& z,
		  const std::vector<G4String>& mats);
  // contents of the vectors must be ordered from the most outer volume

  G4MBoxStructure(const G4String& name);

  G4MBoxStructure(G4MVBoxStructureCatalogue* catalogue);

  virtual ~G4MBoxStructure();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(const std::vector<G4ThreeVector>& dxyz,
			const std::vector<G4double>& z,
			const std::vector<G4String>& mats);

  const std::vector<G4ThreeVector>& GetDxyz() const
  { return fDxyz; }
  const std::vector<G4double>& GetZ() const
  { return fZ; }
  const std::vector<G4String>& GetMatName() const
  { return fMatName; }

  void SetDxyz(const std::vector<G4ThreeVector>& dxyz)
  { fDxyz = dxyz; }
  void SetZ(const std::vector<G4double>& z )
  {  fZ = z; }
  void SetMatName(const std::vector<G4String>& mat)
  {  fMatName = mat; }
 
protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume *physvol);

private:
  std::vector<G4ThreeVector> fDxyz;
  std::vector<G4double> fZ;
  std::vector<G4String> fMatName;

private:
  G4MVBoxStructureCatalogue* fCatalogue;

};

#endif
