//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Block Collimator ( Almost idential to G4MDiskStructure )
//
// (HISTORY)  
//  22-JAN-07 T.Aso Overload SetAllParameters().
//
//---------------------------------------------------------------------
//
#ifndef G4MBLOCKCOLLIMATOR_HH
#define G4MBLOCKCOLLIMATOR_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVBlockCollimatorCatalogue.hh"

class G4MBlockCollimator : public G4MVBeamModule {
public:
  G4MBlockCollimator(const G4String &name, 
		     const std::vector<G4double> &aDXs,
		     const std::vector<G4double> &aDYs,
		     G4double aDz,
		     const std::vector<G4String> &mats);
  // contents of the vectors must be ordered from the most outer volume

  G4MBlockCollimator(const G4String &name);

  G4MBlockCollimator(G4MVBlockCollimatorCatalogue* catalogue);

  virtual ~G4MBlockCollimator();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(const std::vector<G4double> &aDXs,
			const std::vector<G4double> &aDYs,
			G4double aDZ,
			const std::vector<G4String> &mats);

  void SetAllParameters(const G4ThreeVector& dxyzBlock, 
			const G4String& matBlock,
			G4double winX, G4double winY,
			const G4String& matWin);

  const std::vector<G4double> &GetDXs() const
  { return dxs; }
  const std::vector<G4double> &GetDYs() const
  { return dys; }

  const std::vector<G4String> &GetMatNames() const
  { return matNames;}

  void SetDXs(const std::vector<G4double> &aDXs)
  { dxs = aDXs; }
  void SetDYs(const std::vector<G4double> &aDYs)
  { dys = aDYs; }

  void SetMatNames(const std::vector<G4String> &mats);
 
protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume *physvol);

private:
  std::vector<G4double> dxs;
  std::vector<G4double> dys;
  std::vector<G4String> matNames;

private:
  G4MVBlockCollimatorCatalogue* fCatalogue;
};
     
#endif
