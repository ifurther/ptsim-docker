//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MRoom
//
//  (HISTORY)
//
//---------------------------------------------------------------------
//
#ifndef G4MROOM_HH
#define G4MROOM_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MVRoomCatalogue.hh"

class G4MRoom : public G4MVBeamModule {
  public:
    G4MRoom(const G4String name, const G4ThreeVector dxyz);

    G4MRoom(const G4String name);

    G4MRoom(G4MVRoomCatalogue* catalogue);

    virtual ~G4MRoom();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector dxyz);

    void SetMatName(const G4String& mat){  fMatName = mat;}
    const G4String& GetMatName() const{ return fMatName;}

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
    G4String      fMatName;

  private:
    G4MVRoomCatalogue* fCatalogue;
};

#endif /* G4MROOM_HH_HEADER_INCLUDED_BD0C4413 */
