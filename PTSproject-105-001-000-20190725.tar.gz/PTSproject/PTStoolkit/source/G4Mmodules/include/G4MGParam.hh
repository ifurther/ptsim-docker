//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (HISTORY)
// 2017-12-21 T.Aso
// 
//
// -----------------------------------------------------------------
//
#ifndef G4MGPARAM_HH
#define G4MGPARAM_HH

#include "G4TwoVector.hh"
#include "G4String.hh"

class G4MGParam {
  public:
    G4MGParam(){;}; 
    G4MGParam(G4int _nx, G4int _ny)
    { nx = _nx; ny=_ny; };
    G4MGParam(G4TwoVector& v, G4String& _m, G4int _nx, G4int _ny)
    { dxy = v; mat = _m; nx = _nx; ny=_ny; };

    virtual ~G4MGParam(){};

  void Set(G4TwoVector& v, G4String& _m, G4int _nx, G4int _ny)
  { dxy = v; mat = _m; nx = _nx; ny=_ny; };

  G4TwoVector& GetDxy() { return dxy; };
  G4double GetDx() { return dxy.x(); };
  G4double GetDy() { return dxy.y(); };
  G4String&  GetMat() { return mat; };
  void GetNxy(G4int& _nx, G4int& _ny)
  { _nx = nx; _ny = ny; };
  G4int GetNx(){ return nx;};
  G4int GetNy(){ return ny;};

 private:
  G4TwoVector dxy;
  G4String    mat;
  G4int       nx, ny;
};

#endif /* G4MGPARAM_HEADER */

