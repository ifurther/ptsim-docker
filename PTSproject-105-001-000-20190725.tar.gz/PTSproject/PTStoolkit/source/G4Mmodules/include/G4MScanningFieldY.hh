//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MScanningFieldX
//
//  (HISTORY)
//  2014-11-23  T.Aso   Add a sign for swiching B field direction
//   2017-03--15 T.Aso Threading
//---------------------------------------------------------------------
//
#ifndef G4MSCANNINGFIELDY_HH
#define G4MSCANNINGFIELDY_HH

#include "globals.hh"
#include "G4MVScanningField.hh"

class G4MScanningFieldY : public G4MVScanningField {
  public:
    G4MScanningFieldY(G4double yVal=0.0, G4int isign=1);
    G4MScanningFieldY(const G4MScanningFieldY& right);

    virtual G4MScanningFieldY* Copy();

    virtual ~G4MScanningFieldY();

  void SetMagField(double yVal);
  protected:
  //virtual void calcField();

};

#endif /* G4MSCANNINGFIELDY_HH */
