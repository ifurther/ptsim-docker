//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Description)
//    Class for Bolus Beam Module
//
//  (History)
//   06-OCT-05  T.ASO  Paramterised Volume created only for 
//                     fParameterisation->GetNofActiveVolume() > 0 .
//   2012-06-06 T.Aso  Merged with NCC type bolus which can assign
//                     drill smearing.
//   2014-01-08 T.Aso  Added GetDir().
//
//---------------------------------------------------------------------
//

#ifndef G4MBOLUS_HH
#define G4MBOLUS_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MBolusParameterisation.hh"
#include "G4ThreeVector.hh"
#include <vector>
#include "G4MVBolusCatalogue.hh"


class G4MBolus : public G4MVBeamModule {
  public:
    G4MBolus(const G4String& name, 
             const G4ThreeVector& dxyz,
             const G4String& mat,
             G4int nx, G4int ny, 
             G4double x0, G4double y0,
             G4double pitchx, G4double pitchy, 
             std::vector<G4double>& thickvector);

    G4MBolus(const G4String& name);

    G4MBolus(G4MVBolusCatalogue* catalogue);

    virtual ~G4MBolus();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector& dxyz,
                          const G4String& mat,
                          G4int nx, G4int ny, 
                          G4double x0, G4double y0,
                          G4double pitchx, G4double pitchy, 
                          std::vector<G4double>& thickvector);

    virtual void  Dump(std::ostream& out);

    void SetNxy(G4int nx, G4int ny);

    void GetNxy(G4int& nx, G4int& ny);

    void SetXYOrigin(G4double x0, G4double y0);

    void SetThickVector(std::vector<G4double>& thickVec);

    std::vector<G4double> GetThickVector() const
    { return theThickVector;}

    void SetPitch(G4double xpitch, G4double ypitch);

    void GetPitch(G4double& xpitch, G4double& ypitch);

    void SetMatBolus(const G4String& mat)
    { fMatBolus = mat; }

    void SetDrillPitch(G4double & dpitch)
    {  fDrillPitch = dpitch; }

    void Smearing();

    void SetDir(G4int idx, G4int idy)
    { xdir = idx; ydir = idy; }

    void GetDir(G4int& idx, G4int& idy)
    { idx = xdir; idy= ydir; }

  protected:

    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
    G4String fMatBolus;
    G4int fNx;
    G4int fNy;

    G4double fx0;
    G4double fy0;

    G4int xdir;    
    G4int ydir;    

    G4double fPitchX;
    G4double fPitchY;
    G4double fDrillPitch;

    std::vector<G4double> theThickVector;
    G4MBolusParameterisation* fParameterisation;

  private:
    G4MVBolusCatalogue* fCatalogue;
};

#endif /* G4MBOLUS_HH */
