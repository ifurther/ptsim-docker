//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MGeometryMessenger
//
//   /G4M/    directory
//      Commands
//         System   sysname
//         ChangeSystem sysname
//
//         TKVersion  ostream;   Print PTStoolkit version
//         AppVersion  ostream;   Print PTS application version
//         G4Version  ostream;   Print Geant4 version
//         RunSummary  ostream;   Print Run summary
//
//  (HISTORY)
//   2014-08-07 T.Aso commands for printing versions.
//
//---------------------------------------------------------------------
#ifndef G4MGEOMETRYMESSENGER_HH
#define G4MGEOMETRYMESSENGER_HH

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"

class G4MVGeometryBuilder;

class G4MGeometryMessenger : public G4UImessenger{
  public:
    G4MGeometryMessenger(G4MVGeometryBuilder* builder);
    virtual ~G4MGeometryMessenger();

    virtual void SetNewValue(G4UIcommand* command, G4String newValue);
    virtual G4String GetCurrentValue(G4UIcommand* command);

  private:
    G4MVGeometryBuilder *fBuilder;
    G4UIdirectory*  fDir;
    G4UIcmdWithAString*  fCmdSelection;
    G4UIcmdWithAString*  fCmdChange;

  //
    G4UIdirectory*  fPTSDir;
    G4UIcmdWithAString* fCmdTKVersion;
    G4UIcmdWithAString* fCmdAppVersion;
    G4UIcmdWithAString* fCmdG4Version;
    G4UIcmdWithAString* fCmdRunSummary;


};

#endif /* G4MGEOMETRYMESSENGER_HH */
