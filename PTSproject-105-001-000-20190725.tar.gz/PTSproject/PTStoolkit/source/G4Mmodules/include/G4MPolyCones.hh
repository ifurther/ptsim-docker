//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shape component
//
// (HISTORY)  
//
//
//---------------------------------------------------------------------
//
#ifndef G4MPOLYCONE_HH
#define G4MPOLYCONE_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVPolyConesCatalogue.hh"

class G4MPolyCones : public G4MVBeamModule {
public:
  G4MPolyCones(const G4String &name, G4double aDR, G4double aDZ, 
          const G4String &mat);

  G4MPolyCones(const G4String &name);

  G4MPolyCones(G4MVPolyConesCatalogue* catalogue);

  virtual ~G4MPolyCones();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(G4double dr, G4double dz, const G4String& mat);
  void SetAllParameters(const G4String& mat,
                        G4double rin, G4double rout,G4double dz, 
                        G4int ncone,
                        std::vector<G4String>& conematrial, 
                        std::vector<G4int>& nplane, 
                        std::vector<G4double>& v_rinner, 
                        std::vector<G4double>& v_router, 
                        std::vector<G4double>& v_zplane);


  void SetMatName(const G4String& mat){ fMatName=mat; }

  const G4String& GetMatName() const{ return fMatName; }


  void SetNofCone(G4int snc){NofCone = snc;}
  void AddMaterial(G4String str){material.push_back(str);}
  void AddNofPlane(G4int nop){NofPlane.push_back(nop);}
  void AddZPlane(G4double azp){zPlane.push_back(azp);}
  void AddRInner(G4double ari){rInner.push_back(ari);}
  void AddROuter(G4double aro){rOuter.push_back(aro);}

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume* physVol);

private:  
  G4String fMatName;
  
  static const G4int N = 50;
  G4int NofCone;
  std::vector<G4String> material;
  std::vector<G4int> NofPlane;
  std::vector<G4double> zPlane;
  std::vector<G4double> rInner;
  std::vector<G4double> rOuter;

private:
  G4MVPolyConesCatalogue* fCatalogue;
};

#endif
