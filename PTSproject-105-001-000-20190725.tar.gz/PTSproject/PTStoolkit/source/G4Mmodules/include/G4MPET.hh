//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Box shape component
//
// (HISTORY)  
// 2017-12-22 T.Aso
//---------------------------------------------------------------------
//
#ifndef G4MPET_HH
#define G4MPET_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVPETCatalogue.hh"

class G4MPET : public G4MVBeamModule {
public:
  G4MPET(const G4String& name, 
         const G4ThreeVector& dxyz, const G4String& mat);

  G4MPET(const G4String &name);

  G4MPET(G4MVPETCatalogue* catalogue);

  virtual ~G4MPET();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(const G4ThreeVector& dxyz, const G4String& mat);

  void SetMatName(const G4String& mat)
  {  matName = mat; }

  const G4String& GetMatName() const
  { return matName; }

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

  virtual void buildNode(G4VPhysicalVolume* physvol);

private:  
  G4String matName;

private:
  G4MVPETCatalogue* fCatalogue;
};

#endif
