//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MFanBeam
//
//  (HISTROY)
//   T.ASO updated with the help of Y.Jizou.
//   2014-05-19 T.Aso remove unused variables.
//
//---------------------------------------------------------------------
//
//
#ifndef G4MFanBeam_h
#define G4MFanBeam_h 1

#include "globals.hh"
#include "G4ParticleGun.hh"
#include "CLHEP/Random/Randomize.h"

class G4Event;
class G4MFanBeamMessenger;

// class description:
//
class G4MFanBeam:public G4ParticleGun
{
  public: // with description
     G4MFanBeam();
     virtual ~G4MFanBeam();

  public: // with description
     virtual void GeneratePrimaryVertex(G4Event* evt);


  public:
     void SetGaussSpot(G4bool flg=true){ gaussSpot=flg;}
     G4bool GetGaussSpot(){ return gaussSpot;}

     void SetEnergyFluctuation(const G4double de);
     G4double GetEnergyFluctuation() const;

     void SetRadius(const G4double r);
     G4double GetRadius();
     void SetTheta(const G4double theta);
     G4double GetTheta();
     void SetZ(const G4double z);
     G4double GetZ();

     void SetPhi(G4double phi);
     G4double GetPhi();


  protected:  
  // Beam Spot Size 1Sigma Gaussian (Length Unit)
     G4bool   gaussSpot;
  // Energy Fluctuation in dE (Energy Unit).
     G4double beamdE;

  //InitialPosition
     G4double fR;
     G4double fTheta;
     G4double fZ;

  //Phi
     G4double fPhi;

  private:
  //CLHEP::HepRandomEngine*     anEngine;
     G4MFanBeamMessenger* theBeamMessenger;

};

#endif







