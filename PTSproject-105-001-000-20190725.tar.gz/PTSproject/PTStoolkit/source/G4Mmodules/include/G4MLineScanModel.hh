//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MLineScanModel
//
//  (HISTORY)
//  2018-09-09 T.Aso Created.
//
//---------------------------------------------------------------------
//
#ifndef G4MLineScanModel_HH
#define G4MLineScanModel_HH

#include "globals.hh"
#include <vector>
#include "G4MVScanModel.hh"
#include "G4TwoVector.hh"

class G4MScanBeamManager;

class G4MLineScanModel : public G4MVScanModel {
  public:
    G4MLineScanModel(const G4String& name);

    virtual ~G4MLineScanModel();

  public:
    // 
    virtual void ReadScanFile(G4String& filename);
    // Calculate event density of the spot.
    virtual void CalculateProbability();
    //
    virtual size_t GetSize(){ return (G4int)fEIDVec.size();}
    virtual G4int GetEID(G4int index){ return fEIDVec[index];}
    virtual G4double GetXcoord(G4int index);
    virtual G4double GetYcoord(G4int index);
    virtual const G4TwoVector& GetCoord(G4int index);
    virtual G4double GetX(G4int index, G4int i);
    virtual G4double GetY(G4int index, G4int i);
    virtual G4double GetDose(G4int index){ return fDoseVec[index];}
    virtual G4double GetProb(G4int index){ return fProbVec[index];}
  //
  protected:
    void Clear();

  private:
  //
    std::vector<G4int>        fEIDVec;  // EnergyID
    std::vector<G4TwoVector>  fXYSVec;       // XY-Start
    std::vector<G4TwoVector>  fXYEVec;       // XY-End
    std::vector<G4double>     fDoseVec;  // Dose
    std::vector<G4double>     fProbVec;  // Probability

    G4TwoVector  fSpotCoord; // Randomized spot coordinate.

};
#endif /* G4MLINESCANMODEL_HH */
