//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// Class Description
//  G4MBox
// 
// (HISTORY)
// 2014-10-31 T.Aso Support FileCatalogue.
//
//---------------------------------------------------------------------
//
#ifndef G4MBOXCOMPOSER_HH
#define G4MBOXCOMPOSER_HH

#include "globals.hh"
#include "G4ThreeVector.hh"
#include "G4RotationMatrix.hh"
#include "G4VPhysicalVolume.hh"
#include "G4LogicalVolume.hh"
#include "G4Transform3D.hh"
#include "G4MVModuleComposer.hh"
#include "G4MVBoxComposerCatalogue.hh"

class G4MBoxComposer : public G4MVModuleComposer {
  public:
    G4MBoxComposer(const G4String& name, const G4String& mat,
                   const G4ThreeVector& dxyz); 

    G4MBoxComposer(const G4String& name);

    G4MBoxComposer(G4MVBoxComposerCatalogue* catalogue);

    virtual ~G4MBoxComposer();

    virtual void ApplyFromCatalogue(G4String& newValue);

    virtual void Dump(std::ostream& out);

    void SetAllParameters(const G4String& mat,
                          const G4ThreeVector& dxyz);


  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

  private:
    G4String fMat;

  private:
    G4MVBoxComposerCatalogue* fCatalogue;
};
#endif /* G4MBOXCOMPOSER_HH*/
