//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//  Module for Propeller type component
//
// (HISTORY)
//  T.ASO
//  22-JAN-2007  T.Aso Add Visualization attributes.
//---------------------------------------------------------------------
//
#ifndef G4MPropellerBlades_HH
#define G4MPropellerBlades_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVPropellerBladesCatalogue.hh"

class G4MPropellerBlades : public G4MVBeamModule {
public:
  G4MPropellerBlades(const G4String &name, 
		     G4double radius,
		     std::vector<G4double>& angles, 
		     std::vector<G4double>& DZs, 
		     G4int nfin, const G4String &mat);

  G4MPropellerBlades(const G4String &name);

  G4MPropellerBlades(G4MVPropellerBladesCatalogue* catalogue);

  virtual ~G4MPropellerBlades();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(G4double radius, 
			std::vector<G4double>& angles, 
			std::vector<G4double>& DZs, 
			G4int nfin,const G4String &mat);

  void SetMatName(const G4String& mat){matName = mat;}
  const G4String& GetMatName() const{ return matName; }

  void SetMasterMat(const G4String& mat){fMasterMat = mat;}
  const G4String& GetMasterMat() const{return fMasterMat;}

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

  virtual void buildNode(G4VPhysicalVolume* physvol);

private:  
    G4String fMasterMat;
    std::vector<G4double>  fBladeAngle;
    std::vector<G4double>  fBladedZ;
    G4int  fnFin;
    G4String matName;
  private:
    G4MVPropellerBladesCatalogue* fCatalogue;

};

#endif
