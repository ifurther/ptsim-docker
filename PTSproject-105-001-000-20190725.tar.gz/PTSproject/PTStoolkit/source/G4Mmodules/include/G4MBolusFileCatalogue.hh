//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for G4MBolus.
// 
//  (History)
//   22-JAN-07   T.Aso
//   10-Aug-10   T.Aso  File format was modified. 
//                      Introduce drillPicth for smearing. Originally,
//                      this was used for NCC, but now it moved to 
//                      standard.
//                     
//
//---------------------------------------------------------------------
//
#ifndef G4MBOLUSFILECATALOGUE_HH
#define G4MBOLUSFILECATALOGUE_HH

#include "G4MVBolusCatalogue.hh"
#include "G4ThreeVector.hh"
#include <vector>

class G4MBolusFileCatalogue : public G4MVBolusCatalogue{
  public:
    G4MBolusFileCatalogue(const G4String& name,const G4String& filename); 
    virtual ~G4MBolusFileCatalogue();

  public:
    virtual void Init();
    virtual void Prepare(G4String& pname);
    virtual void Apply();
    virtual void Dump(){};

  protected:
    virtual void Smearing();

 protected:
     G4String fDefaultFileName;

     G4ThreeVector fDxyzBolus;
     G4String fMatBolus;
     G4int fNx;
     G4int fNy;
     G4double fx0;
     G4double fy0;
     G4double fPitchX;
     G4double fPitchY;

     G4double fDrillPitch;

     std::vector<G4double> theThickness;
};

#endif



