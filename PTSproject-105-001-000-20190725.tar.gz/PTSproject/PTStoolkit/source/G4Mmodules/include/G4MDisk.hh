//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shape component
//
// (HISTORY)  
// 2012-06-06 T.Aso support Dump() method.
// 2013-01-15 T.Aso support Dump(std::ostream&) method.
//
//
//---------------------------------------------------------------------
//
#ifndef G4MDISK_HH
#define G4MDISK_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVDiskCatalogue.hh"

class G4MDisk : public G4MVBeamModule {
public:
  G4MDisk(const G4String &name, G4double aDR, G4double aDZ, 
          const G4String &mat);

  G4MDisk(const G4String &name);

  G4MDisk(G4MVDiskCatalogue* catalogue);

  virtual ~G4MDisk();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(G4double dr, G4double dz, const G4String& mat);

  void SetMatName(const G4String& mat){ fMatName=mat; }

  const G4String& GetMatName() const{ return fMatName; }

  virtual void  Dump(std::ostream& out);

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume* physvol);

private:  
  G4String fMatName;

private:
  G4MVDiskCatalogue* fCatalogue;
};

#endif
