//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
// -----------------------------------------------------------------
// (Class Description)
//    Class for storing particle information for EvtInterface
//
// (HISTORY)
// 30 Nov. 2007 T.Aso
//   2017-03--15 T.Aso Threading
// -----------------------------------------------------------------
//
#ifndef G4MEvtParticle_h
#define G4MEvtParticle_h 1

#include "globals.hh"
#include "evtdefs.hh"
#include "G4Allocator.hh"
#include "G4PrimaryParticle.hh"

class G4MEvtParticle 
{
  public:
      inline void *operator new(size_t);
      inline void operator delete(void *aStackedTrack);

      G4MEvtParticle();
      G4MEvtParticle(G4PrimaryParticle* pp, 
                     G4double& px, G4double& py, G4double& pz,G4double& t);
      G4MEvtParticle(G4PrimaryParticle* pp, G4ThreeVector& pos, G4double& t);
      ~G4MEvtParticle();

      const G4MEvtParticle & operator=(const G4MEvtParticle &right);
      G4int operator==(const G4MEvtParticle &right) const;
      G4int operator!=(const G4MEvtParticle &right) const;

  private:
      G4PrimaryParticle * theParticle;
      G4ThreeVector position; 
      G4double      time;

  public:
    inline G4PrimaryParticle * GetTheParticle() {return theParticle;};
    inline G4ThreeVector& GetPosition(){return position;};
    inline G4double& GetTime(){return time;};
};

extern G4EVENT_DLL G4ThreadLocal G4Allocator<G4MEvtParticle>* aEvtParticleAllocator;

inline void * G4MEvtParticle::operator new(size_t)
{
  if ( !aEvtParticleAllocator ){
    aEvtParticleAllocator = new G4Allocator<G4MEvtParticle>;
  }
  return (void *) aEvtParticleAllocator->MallocSingle();
}

inline void G4MEvtParticle::operator delete(void * aEvtParticle)
{
  aEvtParticleAllocator->FreeSingle((G4MEvtParticle *) aEvtParticle);
}


#endif

