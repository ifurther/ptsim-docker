//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//   Class for MLC Beam Module.
//    G4MMLC(const G4String& name, const G4ThreeVector& dxyz, 
//	     const G4String& matMLC, 
//	     G4int nyleaf, G4double y0leaf, G4double dyleaf,
//	     std::vector<G4double>& leafposition)
//    name : Module Name
//    dxyz : Half length Size of MLC envelope
//    matMLC: Matrial name of MLC
//    nyleaf:  Number of leaf pair, namly total nyleaf*2 for left and right.
//    y0leaf:  y offset of first leaf. First leaf must be start from -Y.
//    dyleaf:  half length of a leaf thickness.
//    leafposition:  Position of leafs, i.e the open edge of ridges.
//
//       Numbering of leaf for leaf position.
//   +Y
//    |__ +X 
//             nyleaf-1   2*nyleaf-1
//                .         .
//                .         .
//                2       nyleaf+2
//                1       nyleaf+1
//                0       nyleaf+0
//
//
//  (HISTORY)
//   06-OCT-ASO   Add desctiption.
//
//---------------------------------------------------------------------
//
#ifndef G4MMLC_HH
#define G4MMLC_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MMLCParameterisation.hh"
#include "G4ThreeVector.hh"
#include "G4MVMLCCatalogue.hh"
#include <vector>

class G4MMLC : public G4MVBeamModule {
  public:
    G4MMLC(const G4String& name, const G4ThreeVector& dxyz, 
	   const G4String& matMLC, 
	   G4int nyleaf, G4double y0leaf, G4double dyleaf,
	   std::vector<G4double>& leafposition);

    G4MMLC(const G4String& name);

    G4MMLC(G4MVMLCCatalogue* catalogue);

    virtual ~G4MMLC();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector& dxyz, 
			  const G4String& matMLC, 
			  G4int nyleaf, G4double y0leaf, G4double dyleaf,
			  std::vector<G4double>& leafposition);

    void SetMatMLC(const G4String& mat);

    void SetLeafPosition(std::vector<G4double>& xleafpos);

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
    G4String fMatMLC;
    G4String fMatHole;
    G4int fNLeafPair;
    G4double fy0Leaf;
    G4double fDyLeaf;
    std::vector<G4double> thePositionVector;

    G4MMLCParameterisation* fParameterisation;

    G4VPhysicalVolume* fParamPhysVol;

  private:
    G4MVMLCCatalogue* fCatalogue;
    
};



#endif /* G4MMLC_HH */
