//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Description)
//    Class for Patient CollimatorEx Beam Module
//
//  (History)
// 2014-04-08 T.Toshito and T.Aso
//            Patient collimator using G4ExtrudedSolid
// 2014-04-10 T.Aso Add SetXYVector(v) for compatibility.
//
//---------------------------------------------------------------------
//

#ifndef G4MPTCOLLIMATOREX_HH
#define G4MPTCOLLIMATOREX_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4ThreeVector.hh"
#include "G4TwoVector.hh"
#include <vector>
#include <stack>
#include "G4MVPTCollimatorExCatalogue.hh"

class G4MPTCollimatorEx : public G4MVBeamModule {
  public:
    G4MPTCollimatorEx(const G4String& name, 
                    const G4ThreeVector& dxyz,
                    const G4String& mat,
                    std::vector<G4TwoVector>& polygon,
                    G4int dir=1
                    );

    G4MPTCollimatorEx(const G4String& name);

    G4MPTCollimatorEx(G4MVPTCollimatorExCatalogue* catalogue);

    virtual ~G4MPTCollimatorEx();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector& dxyz,
                          const G4String& mat,
                          std::vector<G4TwoVector>& polygon,
                          G4int fdir=1
                          );

    virtual void  Dump(std::ostream& out);

    void SetMatName(G4String& mat ){ fMatName = mat; }

    void  SetXYVector(std::vector<G4TwoVector>& polygon)
   { theXYVec.clear(); theXYVec = polygon; }

    void  SetXYVector(std::vector<G4double>& v);
 
    std::vector<G4TwoVector>& GetXYVector() { return theXYVec;}

    void SetDir(G4int dir) { fdir = dir; }

  protected:

    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);


  private:
  // Input
    G4String fMatName;
    std::vector<G4TwoVector> theXYVec;
    G4int    fdir;
 
  //
  private:
    G4MVPTCollimatorExCatalogue* fCatalogue;
};

#endif /* G4MPTCollimatorEx_HH */
