//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Description)
//    Class for Bolus Beam Module (Honeycomb holes)
//
//  (History)
//   2014-03-10   T.Aso
//
//---------------------------------------------------------------------
//

#ifndef G4MHoneyCombBolus_HH
#define G4MHoneyCombBolus_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MHoneyCombBolusParameterisation.hh"
#include "G4ThreeVector.hh"
#include <vector>
#include "G4MVHoneyCombBolusCatalogue.hh"


class G4MHoneyCombBolus : public G4MVBeamModule {
  public:
    G4MHoneyCombBolus(const G4String& name, 
             const G4ThreeVector& dxyz,
             const G4String& mat,
             G4int nx, G4int ny, 
             G4double x0, G4double y0,
             G4double pitchx, G4double pitchy, 
             std::vector<G4double>& thickvector);

    G4MHoneyCombBolus(const G4String& name);

    G4MHoneyCombBolus(G4MVHoneyCombBolusCatalogue* catalogue);

    virtual ~G4MHoneyCombBolus();

    virtual void ApplyFromCatalogue(G4String& newValue);

    void SetAllParameters(const G4ThreeVector& dxyz,
                          const G4String& mat,
                          G4int nx, G4int ny, 
                          G4double x0, G4double y0,
                          G4double pitchx, G4double pitchy, 
                          G4double fac,
                          std::vector<G4double>& thickvector);

    virtual void  Dump(std::ostream& out);

    void SetNxy(G4int nx, G4int ny);

    void GetNxy(G4int& nx, G4int& ny);

    void SetXYOrigin(G4double x0, G4double y0);

    void SetThickVector(std::vector<G4double>& thickVec);

    std::vector<G4double> GetThickVector() const
    { return theThickVector;}

    void SetPitch(G4double xpitch, G4double ypitch);

    void GetPitch(G4double& xpitch, G4double& ypitch);

    void SetMatBolus(const G4String& mat)
    { fMatBolus = mat; }

    void SetFactor(G4double fac)
    { fFact = fac;}

    void SetDir(G4int idx, G4int idy)
    { xdir = idx; ydir = idy; }

    void GetDir(G4int& idx, G4int& idy)
    { idx = xdir; idy= ydir; }

  protected:

    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
    G4String fMatBolus;
    G4int fNx;
    G4int fNy;

    G4double fx0;
    G4double fy0;

    G4int xdir;    
    G4int ydir;    

    G4double fPitchX;
    G4double fPitchY;
    G4double fFact;

    std::vector<G4double> theThickVector;
    G4MHoneyCombBolusParameterisation* fParameterisation;

  private:
    G4MVHoneyCombBolusCatalogue* fCatalogue;
};

#endif /* G4MHoneyCombBolus_HH */
