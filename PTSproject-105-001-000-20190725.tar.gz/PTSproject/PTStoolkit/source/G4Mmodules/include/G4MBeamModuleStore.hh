//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//
// -----------------------------------------------------------------
// (Class Description)
//  G4MBeamModuleStore:
//    Collection class for beam modules.
//
// 05 Oct. 2005 T.Aso
// 07 Dec. 2007 T.Aso introduce a flag at Get() method for suppressing
//                   warning about non-existing modules.
// 10 Aug. 2010 T.Aso Introduce Remove() method.
// 14 Mar. 2012 T.Aso Add Get(G4int i),GetName(), GetNumMudule().
// 2013-01-15   T.Aso Modify ModuleList(int lvl,)
// 2013-03-27   T.Aso ModuleListInWorld() for checking if mass/paralell
//                    geometry is used.
// 2013-10-24   T.Aso SetLang()
// 2014-03-11   T.Aso fVerbose.
//
// -----------------------------------------------------------------
//
#ifndef G4MBEAMMODULESTORE_HH
#define G4MBEAMMODULESTORE_HH

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include <map>

//
// class description:
//
class G4MBeamModuleStore {
  public:
    G4MBeamModuleStore();
    ~G4MBeamModuleStore();

    void Add(G4String name, G4MVBeamModule* module);

    G4MVBeamModule* Get(G4String name, G4bool quiet=false);
    G4MVBeamModule* Get(G4int i);
    G4String GetName(G4int i);

    void Clear();
    void Remove(const G4String& name);

    void ModuleList(G4int lvl=0, std::ostream& out=G4cout);
    void ModuleListInWorld(G4LogicalVolume* worldLV, std::ostream& out=G4cout);

    G4int NumModule();

    void SetLang(G4int l);

    void SetVerbose(G4int v ) { fVerbose = v; }

  private:
    std::map<G4String,G4MVBeamModule*> theModules;

    G4int fVerbose;
};

#endif /* G4MBEAMMODULESTORE_HH */
