//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MAnatmicalPhantom
//
// (HISTORY)
//   Created   T.Aso
//                    
// -----------------------------------------------------------------
//                    
#ifndef G4MANATOMICALPHANTOM_HH
#define G4MANATOMICALPHANTOM_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVAnatomicalPhantomCatalogue.hh"

//Node's
struct Node
{
  G4double posRadius;
  G4double posAngle;
  G4double nodeRadius;
  G4String Material;
  G4bool Exist;
  Node(){};
  Node(G4double pR, G4double pA, G4double nR, G4String M, G4bool E)
  {
    posRadius = pR;
    posAngle = pA;
    nodeRadius = nR;
    Material = M;
    Exist = E;
  }
};

class G4MAnatomicalPhantom : public G4MVBeamModule {
public:
  G4MAnatomicalPhantom(G4MVAnatomicalPhantomCatalogue* catalogue);
  G4MAnatomicalPhantom(const G4String &name);
  virtual ~G4MAnatomicalPhantom();

  void SetEnvelopeParameter(G4String mat,
			    G4double xr,
			    G4double yr,
			    G4double halfZ,
			    G4String es
);
  void AddNode(Node n){nVec.push_back(n);}

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume* physvol);

private:  
  //Envelope's
  G4double drx, dry, dz;
  G4String MatName;
  G4String EShapeName;

  //Node's
  std::vector<Node> nVec; 

  //For loading parameter file
  G4MVAnatomicalPhantomCatalogue* fCatalogue;
};

#endif
