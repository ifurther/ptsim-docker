//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  Created by T.Aso
//
// 2019-03-20 T.Aso Copied from G4MWaterPhantomMessenger
//
//
//---------------------------------------------------------------------
//
#ifndef G4MCYLINDERPHANTOMMESSENGER_HH
#define G4MCYLINDERPHANTOMMESSENGER_HH

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"

class G4MCylinderPhantom;

class G4MCylinderPhantomMessenger : public G4UImessenger{
  public:

  G4MCylinderPhantomMessenger(G4MCylinderPhantom* wp, 
                           const G4String& name="Phantom");
    ~G4MCylinderPhantomMessenger();

    virtual void SetNewValue(G4UIcommand* command, G4String newValue);
    virtual G4String GetCurrentValue(G4UIcommand* command);

  private:
    G4UIdirectory* fDir;
    // CylinderPhantom
    G4UIcommand*fCmdCylinderPhantomSize;
    G4UIcmdWith3Vector*       fCmdCylinderPhantomDim;
    G4UIcommand*fCmdCylinderPhantomSDSize;
    G4UIcommand*fCmdCylinderPhantomSDOffs;
    G4UIcmdWithAString*       fCmdCylinderPhantomMaterial;
    G4UIcmdWithABool*         fCmdCylinderPhantomBEdep;

    G4MCylinderPhantom *fWP;
};
#endif
