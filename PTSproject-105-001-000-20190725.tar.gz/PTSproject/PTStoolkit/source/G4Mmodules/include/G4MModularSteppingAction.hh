//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularSteppingAction.hh,v 1.1 2006/08/22 08:09:37 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularSteppingAction
//
//  Stepping Action
//  T.Aso
//
//  06-MAR-09  T.Aso Create
//
//====================================================================


#ifndef G4MModularSteppingAction_h
#define G4MModularSteppingAction_h 1

#include "globals.hh"
#include <vector>
#include "G4UserSteppingAction.hh"
#include "G4MVSteppingActionConstructor.hh"

class G4MModularSteppingAction : public G4UserSteppingAction {

  public:
    G4MModularSteppingAction();
    virtual ~G4MModularSteppingAction();

    virtual void UserSteppingAction(const G4Step*);   

  public: // with description 
    void RegisterSteppingAction(G4MVSteppingActionConstructor* act);

    const G4MVSteppingActionConstructor* Get(G4int index) const;
    const G4MVSteppingActionConstructor* Get(const G4String& name) const;

  protected: // with description  
    typedef std::vector<G4MVSteppingActionConstructor*> 
    G4MStepActionConstVector;

    G4MStepActionConstVector* stepActionVector;
};

inline
void G4MModularSteppingAction::RegisterSteppingAction(G4MVSteppingActionConstructor* act)
{
  stepActionVector->push_back(act);
}

inline
const G4MVSteppingActionConstructor* 
G4MModularSteppingAction::Get(G4int idx) const
{
  G4int i;
  G4MStepActionConstVector::iterator itr= stepActionVector->begin();
  for (i=0; i<idx && itr!= stepActionVector->end() ; ++i) ++itr;
  if (itr!= stepActionVector->end()) return (*itr);
  else return 0;
}

inline
const G4MVSteppingActionConstructor* 
G4MModularSteppingAction::Get(const G4String& name) const
{
  G4MStepActionConstVector::iterator itr;
  for (itr = stepActionVector->begin(); itr!= stepActionVector->end(); ++itr)
    {
      if ( name == (*itr)->GetName()) break;
  }
  if (itr!= stepActionVector->end()) return (*itr);
  else return 0;
}


#endif
