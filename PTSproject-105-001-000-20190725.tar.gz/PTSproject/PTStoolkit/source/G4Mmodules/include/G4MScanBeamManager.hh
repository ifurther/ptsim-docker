//
//
// class G4MScanBeamManager
//
// Class description:
//
// 
// --------------------------------------------------------------------
//
// (Created) 
//  2014-11-23  T.Aso Manager class for a beam scanning mode.
//
// (Modification)
//  2014-12-25  T.Aso fCounter
//  2016-01-14  T.Aso ReadEIDFileWithAngSigma() for angle variance.
//  2017-04-03  T.Aso ThreadLocal.
//
//
#ifndef G4MSCANBEAMMANGER_HH
#define G4MSCANBEAMMANGER_HH

#include "globals.hh"
#include <vector>
#include <stdio.h>

class G4MVScanModel;
class G4MBeamGun;
class G4MScanningMagnet;
class G4MScanBeamMessenger;


class G4MScanBeamManager {
  public:
    static G4MScanBeamManager* GetPointer();

    virtual ~G4MScanBeamManager();
    static G4bool IsExist();

  // Assign Scan Model
    void SetScanModel(G4MVScanModel* model);
    G4MVScanModel* GetScanModel(){ return fScanModel; }

  // Assign Primary Generator 
    void SetBeamGun(G4MBeamGun* gene);
    G4MBeamGun* GetBeamGun(){ return fBeamGun;}
    void AppendEID(G4double energy, G4double sigX, G4double sigY,
                   G4double angSX=-1.0, G4double angSY=-1.0);

  // Assign Scanning Magnets
    void SetScanningMagnet(G4String& smxName, G4String& smyName);
  // Set Number of Event to be Processed
    void SetNumberOfEventToBeProcessed(G4int nevent)
  { fNofEvToBeProcessed = nevent; }

  // ReadDataFiles
    void ReadEIDFile(G4String& filename);
    void ReadEIDFileWithAngSigma(G4String& filename);
    void ReadDoseWeightFile(G4String& filename);
    void ReadScanFile(G4String& filename);

  // Calculate or return dose weight in the energy.
   G4double GetEIDEnergy(G4int eid){ return fEIDEneVec[eid]; }

  // Calculate or return dose weight in the energy.
    G4double GetWeight(G4double e);
    G4double GetWeight(G4int index);

  // Calculate event density of the spot.
    void CalculateProbability();

    G4int SampleSeq(G4int nevProcessed=-1);

    void Clear();
    void ClearEID();
    void Show(std::ostream& out=G4cout);
    void ShowEID(std::ostream& out=G4cout);
    void ShowEWeight(std::ostream& out=G4cout);

    void SetVerbose(G4int v);

  protected:
    void SetPrimaryParam(G4long seq);
    void SetScanMagnetParam(G4long seq);

  protected:
    G4int fVerbose;

  private:
    G4MVScanModel*    fScanModel;
    G4MBeamGun*       fBeamGun;
    G4MScanningMagnet* fSMX;
    G4MScanningMagnet* fSMY;

    G4int fNofEvToBeProcessed;

  private:
  //
  //
    std::vector<G4double>  fEIDEneVec;  // Energy 
    std::vector<G4double>  fEIDSigEVec;  // Energy flac.
    std::vector<G4double>  fEIDSigXVec;  // SigmaX
    std::vector<G4double>  fEIDSigYVec;  // SigmaY
    std::vector<G4double>  fEIDAngSXVec;  // SX of angle
    std::vector<G4double>  fEIDAngSYVec;  // SY of angle
  //
  //   std::vector<G4int>     fEIDVec;  // EnergyID
  //    std::vector<G4double>  fXVec;       // X
  //    std::vector<G4double>  fYVec;       // Y
  //    std::vector<G4double>  fDoseVec;  // Dose
  //    std::vector<G4double>  fProbVec;  // Probability
  //
    std::vector<G4double>  fEVec;  // Energy
    std::vector<G4double>  fWeightVec;  // Weight

  private:
    G4MScanBeamManager();
    G4MScanBeamMessenger* fMessenger;

    static G4ThreadLocal G4MScanBeamManager *ptrScanMgr;

    size_t fCounter;

};

// ====================================================================
// inline definition
// ====================================================================
inline G4MScanBeamManager* G4MScanBeamManager::GetPointer()
{
  if(!ptrScanMgr)  ptrScanMgr= new G4MScanBeamManager();
  return ptrScanMgr;
}

inline G4bool G4MScanBeamManager::IsExist()
{
  if ( ptrScanMgr ) return TRUE;
  else              return FALSE;
}

#endif 
