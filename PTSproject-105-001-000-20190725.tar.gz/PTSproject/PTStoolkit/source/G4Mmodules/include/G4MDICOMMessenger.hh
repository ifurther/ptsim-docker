//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// (Desctiption)
//    Messenger for DICOM Module
//
//
//   /G4M/DICOM/     directory ; Specific to DICOM modules.
//     Commands:
//        select     dicomModuleName;  Select DICOM Module for messeging
//        file       dicomFileName;    DICOM list file name
//        isocenter  3 vector unit;    isocenter position in CT frame
//        complement bool ;    Enable complement of slices.
//        mesh       double  unit ;    Size of Remesing cube
//        meshBin    int          ;    Remesh in 2D by combining pixels
//        winXmin    double  unit ;    Minimum X position of Valid window 
//        winXmax    double  unit ;    Maximum X position of Valid window 
//        winYmin    double  unit ;    Minimum Y position of Valid window 
//        winYmax    double  unit ;    Maximum Y position of Valid window 
//        winZmin    double  unit ;    Minimum Z position of Valid window 
//        winZmax    double  unit ;    Maximum Z position of Valid window 
//        trim       bool;             Trimming the valid window volume
//        minvalue   double  ;         Acceptable minimum Value
//        maxvalue   double  ;         Acceptable maximum Value
//        ctair      double  ;         CT Value of Air, needed at edge.
//        label      true  ;         CT labeling for outline extraction.
//        ctcutoff   double  ;         CT value for cut off outside of body
//        densityResol double ;         CT Value resolution in density
//        ct2density table file name;  CT2Density table file.
//        paramtype  type name;        Geometry param type.
//        gantry     double unit;      Gantry Angle
//        couchAngle double unit;      Couch Angle
//        dataOrientation string;      Data orientation in NONE,HFS,FFS,HFP,FFP
//
//        vis  bool ; Visuallization of voxels
//        renameMaterial  string string; Rename mateial name.
//        showMatList string int : Show material list
//
//        update;     Update placement of DICOM geometry.
//
//
//        rts        bool;             Enable RTS data.
//        ROIctValReplacer string;      RoiCTmap file name.
//
// (HISTORY)
//   15-Feb-07  T.Aso Separated from G4MParticleTherapyMessenger
//   25-Jul-07  T.Aso ctoffset command was introduced.
//   15-Dec-08  T.Aso ctoffset command was modified as isocenter.
//                    The new command defines the isocenter position
//                    on the CT image.
//                    couchAngle command was introduced.
//                    Introduce 2D mesh algorithm and trimming algorithm. 
//   18-Mar-09  T.Aso New command for density resolution for creating materials
//                    in DICOM data.
//   08-Sep-10  T.Aso Add valid window in Z.
//   2013-03-26 T.Aso RTS related: rts and ROIctValReplacer commands.
//   2013-11-22 T.Aso Data orientation.
//   2014-01-31 T.Aso Commands for complement and label.
//   2014-02-07 T.Aso Commands for update placement.
//   2014-03-11 T.Aso Commands for voxel visualization.
//   2014-03-27 T.Aso Commands for material list.
//                    
//---------------------------------------------------------------------
//
//

#ifndef G4MDICOMMESSENGER_HH
#define G4MDICOMMESSENGER_HH

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIcommand.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithABool.hh"
#include "G4UIcmdWith3VectorAndUnit.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithoutParameter.hh"

class G4MVDICOM;

class G4MDICOMMessenger: public G4UImessenger {
  public:
    G4MDICOMMessenger(G4MVDICOM* dicom);

    ~G4MDICOMMessenger();

    virtual void SetNewValue(G4UIcommand* command, G4String newValue);

    virtual G4String GetCurrentValue(G4UIcommand* command);

  private:
    G4UIdirectory* fDirDICOM;
    G4UIcmdWithAString* fCmdDICOMSelect;
    G4UIcmdWithAString* fCmdDICOMFile;
    G4UIcmdWith3VectorAndUnit* fCmdDICOMIsocenter;
    G4UIcmdWithABool* fCmdDICOMComplement;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMMesh;
    G4UIcmdWithAnInteger*          fCmdDICOMMeshBin;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMWinXmin;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMWinXmax;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMWinYmin;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMWinYmax;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMWinZmin;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMWinZmax;
    G4UIcmdWithABool* fCmdDICOMTrim;
    G4UIcmdWithADouble* fCmdDICOMValueMin;
    G4UIcmdWithADouble* fCmdDICOMValueMax;
    G4UIcmdWithADouble* fCmdDICOMAirCT;
    G4UIcmdWithABool* fCmdDICOMLabel;
    G4UIcmdWithADouble* fCmdDICOMCTCut;
    G4UIcmdWithAString* fCmdDICOMCT2Density;
    G4UIcmdWithAnInteger* fCmdDICOMCTSamp;
    G4UIcmdWithADouble* fCmdDICOMDensResol;
    G4UIcmdWithAString* fCmdDICOMParamType;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMGantry;
    G4UIcmdWithADoubleAndUnit* fCmdDICOMCouchAngle;
    G4UIcmdWithAString* fCmdDICOMDataOrient;

    G4UIcmdWithoutParameter* fCmdDICOMUpdate;

    G4UIcmdWithABool* fCmdDICOMVis;
    G4UIcommand* fCmdDICOMRenameMat;
    G4UIcommand* fCmdDICOMShowMatList;

    G4UIcmdWithABool* fCmdDICOMRTS;
    G4UIcmdWithAString* fCmdROICTReplacerFile;

    G4MVDICOM *fDICOM;
};

#endif /* G4MDICOMMESSENGER_HH */
