//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
//---------------------------------------------------------------------
//  G4MFileEvtInterface
//
//  (HISTROY)
//   29-Nov-2007  T.ASO  Create.
//   19-Mar-2008  T.Aso  Verbose and methods for Open/Close File is
//                      moved from G4MFileEvtInterface. 
//  2017-03-15 T.Aso for threading.
//---------------------------------------------------------------------
//
//

#ifndef G4MFileEvtInterface_h
#define G4MFileEvtInterface_h 1

#include <fstream> 
#include <vector>
#include "globals.hh"
#include "G4MVEvtInterface.hh"

class G4MFileEvtInterface:public G4MVEvtInterface
{
  public: // with description
    G4MFileEvtInterface();

  public:
    virtual ~G4MFileEvtInterface();

    virtual void OpenEventFile(G4String& evfile);
    virtual void CloseEventFile();

    void SetFileName(G4String& evfile){ fFilename=evfile;};
    G4String& GetFileName(){return fFilename; };

  protected: // with description
    virtual void getParticleInfo();

  private:  
    G4String fFilename;
    std::ifstream inputFile;
    
};

#endif







