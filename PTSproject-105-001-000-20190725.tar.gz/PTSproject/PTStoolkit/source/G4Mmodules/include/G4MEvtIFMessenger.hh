//////////////////////////////////////////////////////////////////////////
//Copyright (2003-2010): Katsuya Amako, Tsukuasa Aso, Go Iwai, Akinori
//Kimura, Koichi Murakami, Takashi Sasaki, Toshiyuki Toshito, Tomohiro
//Yamashita
//
//PTSim Public License
//To use PTSim software, which is distributed under the Apache License
//Version 2.0, you must agree to its license terms and conditions.
//http://www.apache.org/licenses/LICENSE-2.0
//
//PTSim 3rd Party License
//PTSim is developed to use the Geant4 Toolkit distributed under
//the Geant4 Software License.
//http://www.geant4.org/geant4/license/
//////////////////////////////////////////////////////////////////////////
//
//
//---------------------------------------------------------------------
// class description:
//
//  This is a concrete class of G4UImessenger which handles commands for
// G4MEvtIF.
//
// (History)
//  30-Nov-2007 T.Aso Created.
//   2017-03-15 T.Aso Threading
//   2019-04-04 T.Aso File format ASCII/Binary.
//---------------------------------------------------------------------
// 
#ifndef G4MEvtIFMessenger_h
#define G4MEvtIFMessenger_h 1

class G4MVEvtInterface;
class G4UIdirectory;
class G4UIcmdWithAString;
class G4UIcmdWithoutParameter;
class G4UIcmdWithAnInteger;

#include "G4UImessenger.hh"
#include "globals.hh"

class G4MEvtIFMessenger: public G4UImessenger
{
  public:
    G4MEvtIFMessenger(G4MVEvtInterface * fEvtIF);
   ~G4MEvtIFMessenger();
    
  public:
    void SetNewValue(G4UIcommand * command,G4String newValues);
    G4String GetCurrentValue(G4UIcommand * command);

  private:
    G4MVEvtInterface * fEvtGun;

  private: //commands
    G4UIdirectory *             gunDirectory;
    G4UIcmdWithAString        * openCmd;
    G4UIcmdWithoutParameter   * closeCmd;
    G4UIcmdWithAnInteger      * verboseCmd;
    G4UIcmdWithAString        * fmtCmd;
};

#endif

