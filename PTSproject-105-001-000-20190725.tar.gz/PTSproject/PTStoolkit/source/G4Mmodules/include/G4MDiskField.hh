//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Cylinder shape component with B-Field
//
// (HISTORY)  
// 2019-07-19 T.Aso
//---------------------------------------------------------------------
//
#ifndef G4MDISKFIELD_HH
#define G4MDISKFIELD_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MDisk.hh"
#include "G4MVDiskCatalogue.hh"
#include "G4Cache.hh"

class G4MModuleField;
class G4MDiskFieldMessenger;

class G4MDiskField : public G4MDisk {

public:
  G4MDiskField(const G4String &name, G4double aDR, G4double aDZ, 
               const G4String &mat);

  G4MDiskField(const G4String &name);

  G4MDiskField(G4MVDiskCatalogue* catalogue);

  virtual ~G4MDiskField();

  virtual void BuildInSDandField();

  G4MModuleField* GetModuleField(){ return fModuleField; }

  void SetFieldValue(const G4ThreeVector& bval);

protected:
  virtual void buildNode(G4VPhysicalVolume* physvol);

private:
  G4MModuleField *fModuleField;
  G4MDiskFieldMessenger* fMessenger;
  G4Cache<G4MModuleField*> fModuleFieldCache;

};

#endif
