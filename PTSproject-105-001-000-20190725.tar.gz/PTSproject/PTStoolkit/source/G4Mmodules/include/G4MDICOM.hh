//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
// (Class Description)
//    DICOM Module
//
// (HISTORY)
// 21 Oct. 2005 T.Aso Sensitive Detector is created at first time only.
//                    After second case, the SD is obtained from SDManager.
// 01 Dec. 2005 T.Aso Add G4Region for production cut.
// 24 Aug. 2006 T.Aso Add member of G4ProductionCuts for maintain cuts 
//                    information.
//                    This is required to re-installing module after 
//                    uninstallation.
// 27 Feb. 2007 T.Aso Change class structure to have G4VDICOM super class.
//                    Most of methods was moved to the super class.
// 2017-03-15 T.Aso Threading
//---------------------------------------------------------------------
// 

#ifndef G4MDICOM_HH
#define G4MDICOM_HH

#include "globals.hh"
#include "G4MVDICOM.hh"
#include "G4Material.hh"

class G4MDICOM : public G4MVDICOM {
  public:
    G4MDICOM(G4String name);

    G4MDICOM(G4MVDICOMCatalogue* catalogue);

    virtual ~G4MDICOM();

   virtual void BuildInSDandField();

  protected: 
    virtual void buildNode(G4VPhysicalVolume* physvol);

    virtual void SetSensitive(G4String& SDName, G4LogicalVolume* logical);

};
#endif /* G4MDICOM_HH */
