//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Jaw shape component
//
// (HISTORY)  
//  2015-12-14 T.Aso
//---------------------------------------------------------------------
//
#ifndef G4MJAW_HH
#define G4MJAW_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVJawCatalogue.hh"

class G4MJaw : public G4MVBeamModule {
public:
  G4MJaw(const G4String& name,
         const G4ThreeVector& dxyz, const G4String& blkmat,
         G4double sdist, G4double aperture, G4double zpos,
         G4int dir=1);

  G4MJaw(const G4String &name);

  G4MJaw(G4MVJawCatalogue* catalogue);

  virtual ~G4MJaw();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(const G4ThreeVector& dxyz, const G4String& blkmat,
                        G4double sdist, G4double aperture, G4double zpos,
                        G4int dir);

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

  virtual void buildNode(G4VPhysicalVolume* physvol);

private:  
  G4ThreeVector fDxyzBlock;
  G4String fBlkMat;
  G4double fSourceDist;
  G4double fAperture;
  G4double fZpos;
  G4int    fDir;
  //
  G4double     fTheta;
  G4ThreeVector fBlkPos;

private:
  G4MVJawCatalogue* fCatalogue;
};

#endif
