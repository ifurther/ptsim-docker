//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shape component
//
// (HISTORY)  
// 2011. Sep. Kawashima and Aso (TNCT).
//
//
//---------------------------------------------------------------------
//
#ifndef G4MROTATINGRANGEMODULATOR_HH
#define G4MROTATINGRANGEMODULATOR_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVRotatingRangeModulatorCatalogue.hh"

class G4MRotatingRangeModulator : public G4MVBeamModule {
public:
  G4MRotatingRangeModulator(const G4String &name, G4double aDR, G4double aDZ, 
	  const G4String &mat);

  G4MRotatingRangeModulator(const G4String &name);
  G4MRotatingRangeModulator(G4MVRotatingRangeModulatorCatalogue* catalogue);

  virtual ~G4MRotatingRangeModulator();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(G4double din, G4double drout, G4double dz, const G4String& mat);

  void SetMatName(const G4String& mat){ fMatName=mat; }

  const G4String& GetMatName() const{ return fMatName; }

  void resetAll();

  void SetNofPart(G4int np){ NofPart = np; }
  void AddNofTrack(G4int nt){ NofTrack.push_back(nt); }
  void AddOffset(G4double os){ offset.push_back(os); }
  void AddDirection(G4int drc){ direction.push_back(drc); }
  void AddNofFan(G4int nf){ NofFan.push_back(nf); }
  void AddInnerRadius(G4double ri){ innerRadius.push_back(ri); }

  void AddOffsetAngle(G4double oa){ offsetAngle.push_back(oa); }
  void AddFanDZ(G4double fz){ segDZ.push_back(fz); }
  void AddFanPhi(G4double fp){ segPhi.push_back(fp); }
  void AddFanMaterialName(G4String& fmn){ segMatName.push_back(fmn); }
  void AddOuterRadius(G4double ro){ outerRadius.push_back(ro); }
protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
  virtual void buildNode(G4VPhysicalVolume* physVol);

private:  
  G4String fMatName;
  
  G4int NofPart; //
  std::vector<G4int> NofTrack;//
  std::vector<G4int> NofFan;//

  std::vector<G4double> offset;//
  std::vector<G4int> direction;//

  std::vector<G4double> innerRadius;//
  std::vector<G4double> outerRadius;//
  std::vector<G4double> offsetAngle;//

  std::vector<G4double> segDZ;
  std::vector<G4double> segPhi;
  std::vector<G4String> segMatName;

private:
  G4MVRotatingRangeModulatorCatalogue* fCatalogue;
};

#endif
