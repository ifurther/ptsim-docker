//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Box shape component
//
// (HISTORY)  
// 2017-12-22 T.Aso
//---------------------------------------------------------------------
//
#ifndef G4METCC_HH
#define G4METCC_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MVBeamModule.hh"
#include "G4MVETCCCatalogue.hh"
#include "G4MGParam.hh"

class G4METCC : public G4MVBeamModule {
public:
  G4METCC(const G4String& name, 
         const G4ThreeVector& dxyz, const G4String& mat);

  G4METCC(const G4String &name);

  G4METCC(G4MVETCCCatalogue* catalogue);

  virtual ~G4METCC();

  virtual void ApplyFromCatalogue(G4String& newValue);
  virtual void BuildInSDandField();

  void SetAllParameters(const G4ThreeVector& dxyz, const G4String& mat);

  void SetMatName(const G4String& mat)
  {  matName = mat; }

  const G4String& GetMatName() const
  { return matName; }

  void SetInsideVol(G4ThreeVector& dxyz, G4String& mat)
  { fInsideDxyz = dxyz;  fInsideMat = mat; };

  void SetGasVol(G4ThreeVector& dxyz, G4String& mat, G4double zoff)
  { fGasDxyz = dxyz; fGasZoffset = zoff; fGasMat = mat;};

  void SetSubVol(G4int nx, G4int ny, 
                 G4ThreeVector& dxyz, G4ThreeVector& offset,
                 G4TwoVector& pitch, G4String& mat)
  { fNsubX = nx; fNsubY = ny, fSubDxyz = dxyz; fSubOffset = offset;
    fSubPitch = pitch; fSubMat = mat; };

  void SetLayerVol(G4int nlayer, 
                   std::vector<G4ThreeVector>& dxyz,
                   std::vector<G4double>& offset,
                   std::vector<G4String>& mat)
  { fNlayer=nlayer; fLayerDxyz=dxyz; fLayerOffZ=offset; fLayerMat=mat;};

  void SetTowerVol(std::vector<G4MGParam*>& tower){ fTower= tower; };

protected:
  virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);

  virtual void buildNode(G4VPhysicalVolume* physvol);

private:  
  G4String matName;
  //
  G4ThreeVector  fInsideDxyz;
  G4String fInsideMat;
  G4ThreeVector fGasDxyz;
  G4double fGasZoffset;
  G4String fGasMat;
  G4int fNsubX, fNsubY;
  G4ThreeVector fSubDxyz, fSubOffset;
  G4TwoVector fSubPitch;
  G4String fSubMat;
  G4int fNlayer;
  std::vector<G4ThreeVector> fLayerDxyz;
  std::vector<G4double> fLayerOffZ;
  std::vector<G4String> fLayerMat;
  std::vector<G4MGParam*> fTower;

private:
  G4MVETCCCatalogue* fCatalogue;
};

#endif
