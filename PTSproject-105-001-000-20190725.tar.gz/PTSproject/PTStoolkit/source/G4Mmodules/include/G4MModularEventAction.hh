//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularSteppingAction.hh,v 1.1 2006/08/22 08:09:37 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularEventAction
//
//  Event Action
//  T.Aso
//
//  06-MAR-09  T.Aso Create
// 2017-03-15 T.Aso for threading
// 2017-09-17 T.Aso Remove fRun
//====================================================================


#ifndef G4MModularEventAction_h
#define G4MModularEventAction_h 1

#include "globals.hh"
#include <vector>
#include "G4UserEventAction.hh"
#include "G4MVEventActionConstructor.hh"
class G4Run;

class G4MModularEventAction : public G4UserEventAction {

  public:
    G4MModularEventAction();
    virtual ~G4MModularEventAction();

    virtual void BeginOfEventAction(const G4Event* aevent);
    virtual void EndOfEventAction(const G4Event* aevent);

  public: // with description 
    void RegisterEventAction(G4MVEventActionConstructor* act);

    const G4MVEventActionConstructor* Get(G4int index) const;
    const G4MVEventActionConstructor* Get(const G4String& name) const;

  public:
    G4bool IsNewRun();
  
  protected: // with description  
    typedef std::vector<G4MVEventActionConstructor*> 
    G4MEventActionConstVector;
    G4MEventActionConstVector* eventActionVector;
  //G4Run* fRun;
    G4int  fRunID;
};

inline
void G4MModularEventAction::RegisterEventAction(G4MVEventActionConstructor* act)
{
  act->SetModularEventAction(this);
  eventActionVector->push_back(act);
}

inline
const G4MVEventActionConstructor* 
G4MModularEventAction::Get(G4int idx) const
{
  G4int i;
  G4MEventActionConstVector::iterator itr= eventActionVector->begin();
  for (i=0; i<idx && itr!= eventActionVector->end() ; ++i) ++itr;
  if (itr!= eventActionVector->end()) return (*itr);
  else return 0;
}

inline
const G4MVEventActionConstructor* 
G4MModularEventAction::Get(const G4String& name) const
{
  G4MEventActionConstVector::iterator itr;
  for (itr = eventActionVector->begin(); itr!= eventActionVector->end(); ++itr)
    {
      if ( name == (*itr)->GetName()) break;
  }
  if (itr!= eventActionVector->end()) return (*itr);
  else return 0;
}


#endif
