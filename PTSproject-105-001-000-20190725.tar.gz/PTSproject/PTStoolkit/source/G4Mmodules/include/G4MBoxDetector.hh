//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MBoxDetector
//
// (HISTORY)
//   2014-09-16 Created for PET study. T.Aso
//   2015-07--26 T.Aso sdLog for temporary use.
//   2016-04--07 T.Aso Messenger
//   2016-07--16 T.Aso ApplyFromCatalogue.
//   2017-03--15 T.Aso Threading/sdLog was moved to G4MVBeamModule.
// -----------------------------------------------------------------
//
//                    
// 
#ifndef G4MBOXDETECTOR_HH_HEADER_INCLUDED_BCF5D1DD
#define G4MBOXDETECTOR_HH_HEADER_INCLUDED_BCF5D1DD

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MVBoxDetectorCatalogue.hh"
class G4MBoxDetectorMessenger;

class G4MBoxDetector : public G4MVBeamModule {
  public:

  G4MBoxDetector(const G4String& name);

  G4MBoxDetector(G4MVBoxDetectorCatalogue* catalogue);

  virtual ~G4MBoxDetector();

  virtual void ApplyFromCatalogue(G4String& newValue);
  virtual void BuildInSDandField();

  void  SetAllParameters(G4ThreeVector& dxyz, G4String& mat);

  virtual void  Dump(std::ostream& out);

  public:
   void SetSector(G4ThreeVector& dxyz, G4String& mat);
   void SetModule(G4int n[3], G4ThreeVector& dxyz, G4String& mat,
                  G4ThreeVector& offset, G4ThreeVector& pitch);
   void SetSubModule(G4int n[3], G4ThreeVector& dxyz, G4String& mat,
                     G4ThreeVector& offset, G4ThreeVector& pitch);
   void SetLayer(G4int nz, 
                 std::vector<G4ThreeVector>& dxyzVec, 
                 std::vector<G4String>&  matVec,
                 std::vector<G4double>&  offsetVec);
   void SetTower(std::vector<G4ThreeVector>& nVec, 
                 std::vector<G4ThreeVector>& dxyzVec, 
                 std::vector<G4String>& matVec,
                 std::vector<G4ThreeVector>& offsetVec,
                 std::vector<G4ThreeVector>& pitchVec);

  public:
   void SetBEdep(G4bool b=true);
   void SetDepth(G4int d_x, G4int d_y, G4int d_z, G4int d_m=0, G4int d_s=0);

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
     G4MVBoxDetectorCatalogue* fCatalogue;

  private:
  // Sector
  G4ThreeVector  fDxyzSect;
  G4String fMatSect;
  // Module
  G4int fNxyzMod[3];
  G4ThreeVector  fDxyzMod;
  G4String fMatMod;
  G4ThreeVector  fOffsetMod;
  G4ThreeVector  fPitchMod;
  // SubSubModule
  G4int fNxyzSubMod[3];
  G4ThreeVector  fDxyzSubMod;
  G4String fMatSubMod;
  G4ThreeVector  fOffsetSubMod;
  G4ThreeVector  fPitchSubMod;
  // Layer
  G4int fNzLay;
  std::vector<G4ThreeVector> fDxyzLayVec;
  std::vector<G4String> fMatLayVec;
  std::vector<G4double> fZoffLayVec;
  // Tower
  std::vector<G4ThreeVector> fNxyzTowVec;
  std::vector<G4ThreeVector>  fDxyzTowVec;
  std::vector<G4String> fMatTowVec;
  std::vector<G4ThreeVector>  fOffsetTowVec;
  std::vector<G4ThreeVector>  fPitchTowVec;

  private:
  G4bool  bEdep;

  G4MBoxDetectorMessenger* fMessenger;

};



#endif /* G4MPHANTOM_HH_HEADER_INCLUDED_BCF5D1DD */
