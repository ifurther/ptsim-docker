//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Box shape component with B-Field.
//
// (HISTORY)  
//
//---------------------------------------------------------------------
//
#ifndef G4MBOXFIELD_HH
#define G4MBOXFIELD_HH

#include <vector>
#include "G4ThreeVector.hh"
#include "G4String.hh"
#include "G4MBox.hh"
#include "G4MVBoxCatalogue.hh"
#include "G4Cache.hh"

class G4MModuleField;
class G4MBoxFieldMessenger;

class G4MBoxField : public G4MBox {

public:
  G4MBoxField(const G4String& name, 
              const G4ThreeVector& dxyz, const G4String& mat);

  G4MBoxField(const G4String &name);

  G4MBoxField(G4MVBoxCatalogue* catalogue);

  virtual ~G4MBoxField();

  virtual void BuildInSDandField();

  G4MModuleField* GetModuleField(){ return fModuleField; }

  void SetFieldValue(const G4ThreeVector& bval);

protected:
  virtual void buildNode(G4VPhysicalVolume* physvol);

private:
  G4MModuleField *fModuleField;
  G4MBoxFieldMessenger* fMessenger;
  G4Cache<G4MModuleField*> fModuleFieldCache;

};

#endif
