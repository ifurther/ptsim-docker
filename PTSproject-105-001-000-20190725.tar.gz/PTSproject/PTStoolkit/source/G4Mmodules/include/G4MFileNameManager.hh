//
//---------------------------------------------------------------------
//
// (Description)
//    FileNameManager
//
// (HISTORY)  
// 2015-03-17 T.Aso
//
//---------------------------------------------------------------------
//
#ifndef G4MFileNameManager_HH
#define G4MFileNameManager_HH

#include "G4String.hh"

class G4MFileNameManager{
public:
  G4MFileNameManager(){;};

  virtual ~G4MFileNameManager(){;};

  G4String GetRankFileName(const G4String basename) const;
  G4String GetFullFileName(const G4String basename) const;
  G4String TakeOffExtension(G4String& name) const;

};

#endif
