//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MBeamGunMessenger
//
//  This is a concrete class of G4UImessenger which handles commands for
// G4MBeamGun.
//
//  (HISTORY)
//   2014-02-07 T.Aso eflucPerc command. ( energy fluctuation in % ).
//   2016-01-14 T.Aso angSigma command. ( Angular variance in mrad ).
//
//---------------------------------------------------------------------
//
// 

#ifndef G4MBeamGunMessenger_h
#define G4MBeamGunMessenger_h 1

class G4MBeamGun;
class G4UIcommand;
class G4UIdirectory;
class G4UIcmdWithABool;
class G4UIcmdWith3VectorAndUnit;
class G4UIcmdWith3Vector;
class G4UIcmdWithADoubleAndUnit;
class G4UIcmdWithAString;
class G4ParticleTable;

#include "G4UImessenger.hh"
#include "globals.hh"

// class description:
class G4MBeamGunMessenger: public G4UImessenger
{
  public:
    G4MBeamGunMessenger(G4MBeamGun * fPtclGun);
    ~G4MBeamGunMessenger();
    
  public:
    void SetNewValue(G4UIcommand * command,G4String newValues);
    G4String GetCurrentValue(G4UIcommand * command);

  private:
    G4MBeamGun * fParticleGun;

  private: //commands
    G4UIdirectory *             gunDirectory;
    G4UIcmdWithABool          * gausSpotCmd;
    G4UIcmdWith3VectorAndUnit * spotCmd;
    G4UIcmdWithADoubleAndUnit * eflucCmd;
    G4UIcmdWithADoubleAndUnit * eflucPercCmd;
    G4UIcmdWith3Vector        * emitCmd;
    G4UIcommand               * angCmd;
    G4UIcmdWithAString        * fileCmd;
};

#endif

