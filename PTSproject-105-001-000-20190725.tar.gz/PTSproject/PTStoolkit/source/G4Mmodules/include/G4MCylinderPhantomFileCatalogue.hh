//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters for WatarPhantom module
// 
//  (History)
//  2019-03-20 T.Aso Copied from G4MWaterPhantomFileCatalogue
//
//---------------------------------------------------------------------
//
#ifndef CYLINDERPHANTOMFILECATALOGUE_HH
#define CYLINDERPHANTOMFILECATALOGUE_HH

#include "G4MVCylinderPhantomCatalogue.hh"
#include "G4ThreeVector.hh"

class G4MCylinderPhantomFileCatalogue : public G4MVCylinderPhantomCatalogue{
  public:
    G4MCylinderPhantomFileCatalogue(const G4String& name, 
                                    const G4String& fileName); 
    virtual ~G4MCylinderPhantomFileCatalogue();

  public:
    virtual void Init();
    virtual void Prepare(G4String& pname);
    virtual void Apply();
    virtual void Dump(){};

 private:
  G4ThreeVector  drpz;
  G4ThreeVector  drpzsd;
  G4int          nr,np,nz;
  G4ThreeVector  offsetsd;
  G4String material;

 private:
  G4String fDefaultFileName;
};

#endif



