//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// $Id: G4MModularTrackingAction.hh,v 1.1 2006/08/22 08:09:37 aso Exp $
// GEANT4 tag $Name:  $
//
//====================================================================
// (Class) G4MModularTrackingAction
//
//  Tracking Action
//  T.Aso
//
//  06-MAR-09  T.Aso Create
//
//====================================================================


#ifndef G4MModularTrackingAction_h
#define G4MModularTrackingAction_h 1

#include "globals.hh"
#include <vector>
#include "G4UserTrackingAction.hh"
#include "G4MVTrackingActionConstructor.hh"

class G4MModularTrackingAction : public G4UserTrackingAction {

  public:
    G4MModularTrackingAction();
    virtual ~G4MModularTrackingAction();

    virtual void PreUserTrackingAction(const G4Track*);
    virtual void PostUserTrackingAction(const G4Track*);

  public: // with description 
    void RegisterTrackingAction(G4MVTrackingActionConstructor* act);

    const G4MVTrackingActionConstructor* Get(G4int index) const;
    const G4MVTrackingActionConstructor* Get(const G4String& name) const;

  protected: // with description  
    typedef std::vector<G4MVTrackingActionConstructor*> 
    G4MTrackActionConstVector;
    G4MTrackActionConstVector* trackActionVector;
    G4bool  isInitialized;
};


inline
void G4MModularTrackingAction::RegisterTrackingAction(G4MVTrackingActionConstructor* act)
{
  if ( fpTrackingManager ){
    act->SetTrackingManagerPointer(fpTrackingManager);
  }
  trackActionVector->push_back(act);
}

inline
const G4MVTrackingActionConstructor* 
G4MModularTrackingAction::Get(G4int idx) const
{
  G4int i;
  G4MTrackActionConstVector::iterator itr= trackActionVector->begin();
  for (i=0; i<idx && itr!= trackActionVector->end() ; ++i) ++itr;
  if (itr!= trackActionVector->end()) return (*itr);
  else return 0;
}

inline
const G4MVTrackingActionConstructor* 
G4MModularTrackingAction::Get(const G4String& name) const
{
  G4MTrackActionConstVector::iterator itr;
  for (itr = trackActionVector->begin(); itr!= trackActionVector->end(); ++itr)
    {
      if ( name == (*itr)->GetName()) break;
  }
  if (itr!= trackActionVector->end()) return (*itr);
  else return 0;
}


#endif
