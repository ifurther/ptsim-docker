//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//  G4MBeamGun
//
//  (HISTORY)
//   T.ASO Created
//   31-JAN-2007  T.ASO  Modify initializing parameters.
//   2014-02-07 T.Aso   SetEnergyFluctByPercent(const G4double perc).
//   2016-01-14 T.Aso   AngleSigma for angluar variances.
//
//---------------------------------------------------------------------
//
#ifndef G4MBeamGun_h
#define G4MBeamGun_h 1

#include "globals.hh"
#include "G4ParticleGun.hh"
#include "CLHEP/Random/Randomize.h"

class G4Event;
class G4MBeamGunMessenger;

//
// class description:
//
class G4MBeamGun:public G4ParticleGun
{
  public: 
     G4MBeamGun();
     virtual ~G4MBeamGun();

  public: 
     virtual void GeneratePrimaryVertex(G4Event* evt);

  public:
     void SetGaussSpot(G4bool flg=true){ gaussSpot=flg;}
     G4bool GetGaussSpot(){ return gaussSpot;}

     void SetSpotSize(const G4ThreeVector& spot)
     { beamSpot = spot; }
     const G4ThreeVector& GetSpotSize() const
     { return beamSpot; }

     void SetEnergyFluctuation(const G4double de)
     { beamdE = de; }
     void SetEnergyFluctByPercent(const G4double perc);
     G4double GetEnergyFluctuation() const
     { return beamdE; }

     void SetEmittance(const G4ThreeVector& emit)
     { beamEmit = emit;}
     const G4ThreeVector& GetEmittance() const
     { return beamEmit; }

      void SetAngleSigma(G4double xang, G4double yang)
     { angX  = xang;  angY = yang; }
     void GetAngleSigma(G4double& xang, G4double& yang) const
     { xang = angX;  yang = angY; }

  protected:  
  // Beam Spot Size 1Sigma Gaussian (Length Unit)
     G4bool   gaussSpot;
     G4ThreeVector beamSpot;
  // Energy Fluctuation in dE (Energy Unit).
     G4double beamdE;
  // Emittance; But this is not used.
     G4ThreeVector beamEmit;
  // Angle in X,Y
     G4double angX, angY;

  private:
     G4MBeamGunMessenger* theBeamMessenger;
};

#endif







