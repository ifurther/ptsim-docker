//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
//  (Desctiption)
//   This is a class for catalogue of parameters
// 
//  (History)
//   04-Oct-05   T.Aso
//
//---------------------------------------------------------------------
//
#ifndef ROOMFILEFILECATALOGUE_HH
#define ROOMFILEFILECATALOGUE_HH

#include "G4MVRoomCatalogue.hh"

class G4MRoomFileCatalogue : public G4MVRoomCatalogue{
  public:
    G4MRoomFileCatalogue(const G4String& name, const G4String& fileName); 
    virtual ~G4MRoomFileCatalogue();

  public:
    virtual void Init();
    virtual void Prepare(G4String& pname);
    virtual void Apply();
    virtual void Dump(){};

 private:
    G4double fdX,fdY,fdZ;
    char chline[512];
    G4String material;

 private:
  G4String fDefaultFileName;

};
#endif



