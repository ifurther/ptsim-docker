//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
//---------------------------------------------------------------------
//
// (Description)
//    Module for Disk shaped structure 
//
// (HISTORY)  
//
//
//---------------------------------------------------------------------
//
#ifndef G4MRINGSTRUCTURE_HH
#define G4MRINGSTRUCTURE_HH

#include "G4MVBeamModule.hh"
#include "G4MVDiskStructureCatalogue.hh"
#include <vector>

class G4MDiskStructure : public G4MVBeamModule {
public:
  G4MDiskStructure(const G4String &name,
		    const std::vector<G4double> &DRs,
		    const std::vector<G4double> &DZs,
		    const std::vector<G4double> &Zs,
		    const std::vector<G4String> &mats);

  G4MDiskStructure(const G4String &name);

  G4MDiskStructure(G4MVDiskStructureCatalogue* catalogue);

  virtual ~G4MDiskStructure();

  virtual void ApplyFromCatalogue(G4String& newValue);

  void SetAllParameters(const std::vector<G4double> &DRs,
			const std::vector<G4double> &DZs,
			const std::vector<G4double> &Zs,
			const std::vector<G4String> &mats);

  void SetAllParameters(const std::vector<G4double> &DRs,
			const std::vector<G4double> &DZs,
			const std::vector<G4double> &StartAng,
			const std::vector<G4double> &EndAng,
			const std::vector<G4double> &Zs,
			const std::vector<G4String> &mats);

  const std::vector<G4double>& GetDRs() const{ return fDrs;}

  const std::vector<G4double>& GetDZs() const{ return fDzs;}

  const std::vector<G4double>& GetZs() const{ return fZs;}

  const std::vector<G4String>& GetMatNames() const
  { return fMatNames; }
  
  void SetDRs(const std::vector<G4double>& newDRs){fDrs=newDRs;}

  void SetDZs(const std::vector<G4double>& newDZs){fDzs=newDZs;}

  void SetZs(const std::vector<G4double>& newZs){fZs=newZs;}

  void SetMatNames(const std::vector<G4String> &mats)
  { fMatNames=mats; }

protected:
  virtual G4VPhysicalVolume *buildEnvelope(G4LogicalVolume *worldlog);

  virtual void buildNode(G4VPhysicalVolume *physvol);

private:
  std::vector<G4double> fDrs;
  std::vector<G4double> fDzs;
  std::vector<G4double> fStartAngles;
  std::vector<G4double> fEndAngles;
  std::vector<G4double> fZs;
  std::vector<G4String> fMatNames;

private:
  G4MVDiskStructureCatalogue* fCatalogue;
};

#endif
