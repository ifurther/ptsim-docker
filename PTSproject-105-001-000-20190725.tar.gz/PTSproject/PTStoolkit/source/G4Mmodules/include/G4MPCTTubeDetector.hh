//
// ********************************************************************
// * DISCLAIMER                                                       *
// *                                                                  *
// * The following disclaimer summarizes all the specific disclaimers *
// * of contributors to this software. The specific disclaimers,which *
// * govern, are listed with their locations in:                      *
// *   http://cern.ch/geant4/license                                  *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.                                                             *
// *                                                                  *
// * This  code  implementation is the  intellectual property  of the *
// * GEANT4 collaboration.                                            *
// * By copying,  distributing  or modifying the Program (or any work *
// * based  on  the Program)  you indicate  your  acceptance of  this *
// * statement, and all its terms.                                    *
// ********************************************************************
//
// -----------------------------------------------------------------
// (Class Description)
//    G4MPCTTubeDetector
//
// (HISTORY)
//   Created for PortonCT study. T.Aso
//   19 Dec. 2010 T.Aso Add file catalogue constructor.
//  2017-03-15 T.Aso for threading.
// -----------------------------------------------------------------
//
//                    
// 
#ifndef G4MPCTPHANTOM_HH_HEADER_INCLUDED_BCF5D1DD
#define G4MPCTPHANTOM_HH_HEADER_INCLUDED_BCF5D1DD

#include "globals.hh"
#include "G4MVBeamModule.hh"
#include "G4MVPCTTubeDetectorCatalogue.hh"


class G4MPCTTubeDetector : public G4MVBeamModule {
  public:

  G4MPCTTubeDetector(const G4String& name, 
                     G4double rin=40.*cm,G4double rout=41.*cm,G4double dz=1.*cm,
                     G4String mat="Air");
  
  G4MPCTTubeDetector(const G4String& name);

  G4MPCTTubeDetector(G4MVPCTTubeDetectorCatalogue* catalogue);

  virtual ~G4MPCTTubeDetector();

  virtual void BuildInSDandField();

  void  SetAllParameters(G4double rin, G4double rout, G4double dz, G4String& mat);

  void SetSize(G4double rin, G4double rout, G4double dz);

  protected:
    virtual G4VPhysicalVolume* buildEnvelope(G4LogicalVolume* worldlog);
    virtual void buildNode(G4VPhysicalVolume* physvol);

  private:
     G4MVPCTTubeDetectorCatalogue* fCatalogue;

  private:
  G4double fRin;
  G4double fRout;
  G4double fDz;
  G4String fMaterial;

};



#endif /* G4MPCTPHANTOM_HH_HEADER_INCLUDED_BCF5D1DD */
